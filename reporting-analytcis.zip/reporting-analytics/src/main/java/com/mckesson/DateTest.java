package com.mckesson;

import java.text.SimpleDateFormat;

public class DateTest {

    public static void main(String[] args) {
        try {

            String input = "2019-10-17T13:53:58.000+00:00";

            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy kk:mm");

            System.out.println(formatter.format(javax.xml.bind.DatatypeConverter.parseDateTime(input).getTime()));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
