package com.mckesson.app.vo;

import java.util.ArrayList;
import java.util.List;

/**
 * Abstract representation of an report related item from the end users perspective. This might be a reference
 * to a Dashboard, Report, or Folder. From a UI perspective, all items are presented and managed thgouh a common interface.
 */
public class ReportItemVo {

    public static final String ITEM_TYPE_REPORT = "ITEM_TYPE_REPORT";
    public static final String ITEM_TYPE_DASHBOARD = "ITEM_TYPE_DASHBOARD";
    public static final String ITEM_TYPE_FOLDER = "ITEM_TYPE_FOLDER";

    private String id;
    private String name;
    private String description;
    private String type;
    private String lastAction;
    private String lastActionType;
    private String lastActionAuthor;
    private int favoriteCount;
    private String thumbnailUrl;
    private String author;
    private int queryCount;
    private String runTime;
    private String createdAt;
    private String createdBy;
    private String lastUpdated;
    private String lastViewed;
    private String parentId;
    private int viewCount;
    private String view;
    private String clientId;
    /**
     * When current object is a representation of a folder, provides ability to include
     */
    private List<ReportItemVo> children = new ArrayList();

    /**
     * Used to indicate if the current user in scope has permissions to edit this object.
     */
    private boolean currentUserMayEdit;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLastAction() {
        return lastAction;
    }

    public void setLastAction(String lastAction) {
        this.lastAction = lastAction;
    }

    public String getLastActionType() {
        return lastActionType;
    }

    public void setLastActionType(String lastActionType) {
        this.lastActionType = lastActionType;
    }

    public String getLastActionAuthor() {
        return lastActionAuthor;
    }

    public void setLastActionAuthor(String lastActionAuthor) {
        this.lastActionAuthor = lastActionAuthor;
    }

    public int getFavoriteCount() {
        return favoriteCount;
    }

    public void setFavoriteCount(int favoriteCount) {
        this.favoriteCount = favoriteCount;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    public String toString() {
        return "id=>" + id + ", name=>" + name + ", type=>" + type;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getQueryCount() {
        return queryCount;
    }

    public void setQueryCount(int queryCount) {
        this.queryCount = queryCount;
    }

    public String getRunTime() {
        return runTime;
    }

    public void setRunTime(String runTime) {
        this.runTime = runTime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public boolean isCurrentUserMayEdit() {
        return currentUserMayEdit;
    }

    public void setCurrentUserMayEdit(boolean currentUserMayEdit) {
        this.currentUserMayEdit = currentUserMayEdit;
    }

    public String getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getLastViewed() {
        return lastViewed;
    }

    public void setLastViewed(String lastViewed) {
        this.lastViewed = lastViewed;
    }

    public int getViewCount() {
        return viewCount;
    }

    public void setViewCount(int viewCount) {
        this.viewCount = viewCount;
    }

    public List<ReportItemVo> getChildren() {
        return children;
    }

    public void setChildren(List<ReportItemVo> children) {
        this.children = children;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }


    public String getView() {
        return view;
    }

    public void setView(String view) {
        this.view = view;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

}
