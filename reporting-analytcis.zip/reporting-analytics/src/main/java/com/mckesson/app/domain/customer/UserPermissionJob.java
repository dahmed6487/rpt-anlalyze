package com.mckesson.app.domain.customer;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UserPermissionJob {
    @Id
    private String user_id;
    private long customer_id;


    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public long getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(long customer_id) {
        this.customer_id = customer_id;
    }

    /**
     * Generic put method to map JPA native Query to this object.
     *
     * @param column
     * @param value
     */
    public void put(Object column, Object value) {
        if (column.equals("name")) {
            setUser_id((String) value);
        } else if (column.equals("customer_id")) {
            setCustomer_id((long) value);
        }
    }
}
