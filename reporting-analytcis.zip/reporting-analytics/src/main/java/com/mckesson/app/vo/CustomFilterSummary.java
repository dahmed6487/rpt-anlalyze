package com.mckesson.app.vo;

public class CustomFilterSummary {

    public Long id;
    public String name;
    public String userId;
    public String creationDate;
    public String lastUpdateDate;
    public String author;
    public String[] sharedTeams;
    public String explore;
    public String otherDefinition;

    public CustomFilterSummary(Long id, String name, String userId, String creationDate, String lastUpdateDate, String author, String[] sharedTeams, String explore, String otherDefinition) {
        this.id = id;
        this.name = name;
        this.userId = userId;
        this.creationDate = creationDate;
        this.lastUpdateDate = lastUpdateDate;
        this.author = author;
        this.sharedTeams = sharedTeams;
        this.explore = explore;
        this.otherDefinition = otherDefinition;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String[] getSharedTeams() {
        return sharedTeams;
    }

    public void setSharedTeams(String[] sharedTeams) {
        this.sharedTeams = sharedTeams;
    }

    public String getExplore() {
        return explore;
    }

    public void setExplore(String explore) {
        this.explore = explore;
    }

    public String getOtherDefinition() {
        return otherDefinition;
    }

    public void setOtherDefinition(String otherDefinition) {
        this.otherDefinition = otherDefinition;
    }
}
