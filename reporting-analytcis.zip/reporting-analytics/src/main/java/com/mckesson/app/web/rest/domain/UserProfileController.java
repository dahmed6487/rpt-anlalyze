package com.mckesson.app.web.rest.domain;

import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.domain.customer.Customer;
import main.java.com.mckesson.app.domain.customer.UserMapping;
import main.java.com.mckesson.app.domain.user.UserProfile;
import main.java.com.mckesson.app.domain.user.UserProfilesDto;
import main.java.com.mckesson.app.service.customer.UserMappingService;
import main.java.com.mckesson.app.service.user.UserProfileService;
import main.java.com.mckesson.app.util.StringUtils;
import main.java.com.mckesson.app.util.UserAuthentication;

/**
 * Class used to drive UserProfile operations to display data on Admin/Domain screen
 */
@RestController
@RequestMapping("/api/user")
public class UserProfileController {

    private static final Logger LOG = LoggerFactory.getLogger(UserProfileController.class);

    private final UserAuthentication userAuthentication;
    private final UserProfileService userProfileService;
    private final UserMappingService userMappingService;

    @Autowired
    public UserProfileController(UserAuthentication userAuthentication, UserProfileService userProfileService, UserMappingService userMappingService) {
        this.userAuthentication = userAuthentication;
        this.userProfileService = userProfileService;
        this.userMappingService = userMappingService;
    }

    @Value("${appconfig.wordPressHelpLink}")
    private String wordPressHelpLink;

    @Value("${appconfig.ahaLink}")
    private String ahaLink;

    @GetMapping("/authenticated")
    public ResponseEntity getCurrentUserName() {
        ReportUser loggedInUser = userAuthentication.getLoggedInUser();
        if (loggedInUser == null) {
            return new ResponseEntity("Unauthenticated", HttpStatus.OK);
        }
        return new ResponseEntity(userAuthentication.getLoggedInUser().getUsername(), HttpStatus.OK);
    }

    @GetMapping("/get/login-user")
    public ReportUser getContext() {
        ReportUser loggedInUser = userAuthentication.getLoggedInUser();
        return loggedInUser;
    }

    /**
     * @param username
     * @return
     */
    @GetMapping("/username/{username}")
    public ResponseEntity<UserProfile> findByUserName(@PathVariable("username") String username, @RequestParam(required = false) String customerId) {
        Optional<UserProfile> userProfile = userProfileService.findByUserName(username);

        if (userProfile.isPresent()) {
            if (StringUtils.isNotBlank(customerId)) {
                UserMapping mapping = userMappingService.findCustomerMapping(username, Long.valueOf(customerId));
                if (mapping != null) {
                    return new ResponseEntity(userProfile.get(), HttpStatus.OK);
                } else {
                    return new ResponseEntity(HttpStatus.NOT_FOUND);
                }
            } else {
                return new ResponseEntity(userProfile.get(), HttpStatus.OK);
            }
        } else {
            return new ResponseEntity(HttpStatus.NOT_FOUND);
        }
    }

    /**
     * @param email
     * @return
     */
    @GetMapping("/email/{email}")
    public UserProfile getUserDetailsByEmail(@PathVariable("email") String email) {
        return userProfileService.getUserDetailsByEmail(email);
    }

    /**
     * @param userProfile
     * @return
     */
    // Create User
    @PostMapping(value = "/create")
    public UserProfile createUserProfile(@RequestBody UserProfile userProfile) {
        return userProfileService.createUserProfile(userProfile);
    }

    @GetMapping("/get")
    public UserProfilesDto getCustomerUsers(@RequestParam String page, @RequestParam(required = false) Long customerId, @RequestParam(required = false) String sortBy, @RequestParam(required = false) String sortDirection) {
        Page<UserProfile> userProfilePage = userProfileService.getUsers(page, customerId, sortBy, sortDirection);
        UserProfilesDto userProfilesDto = new UserProfilesDto();
        userProfilesDto.setUserProfiles(userProfilePage.getContent());
        userProfilesDto.setTotalPages(userProfilePage.getTotalPages());
        return userProfilesDto;
    }

    @GetMapping("/get/active")
    public UserProfilesDto getActiveUsers(@RequestParam String page, @RequestParam(required = false) Long customerId, @RequestParam(required = false) String sortBy, @RequestParam(required = false) String sortDirection) {
        Page<UserProfile> userProfilePage = userProfileService.getActiveUsers(userAuthentication.getLoggedInUser(), page, customerId, sortBy, sortDirection);
        UserProfilesDto userProfilesDto = new UserProfilesDto();
        userProfilesDto.setUserProfiles(userProfilePage.getContent());
        userProfilesDto.setTotalPages(userProfilePage.getTotalPages());
        return userProfilesDto;
    }

    @GetMapping("/search")
    public UserProfilesDto searchAllUsersPage(@RequestParam String page, @RequestParam String search, @RequestParam(required = false) String customerName, @RequestParam(required = false) String sortBy, @RequestParam(required = false) String sortDirection) {
        Page<UserProfile> userProfilePage = userProfileService.searchUsers(userAuthentication.getLoggedInUser(), page, search, customerName, sortBy, sortDirection);
        UserProfilesDto userProfilesDto = new UserProfilesDto();
        userProfilesDto.setUserProfiles(userProfilePage.getContent());
        userProfilesDto.setTotalPages(userProfilePage.getTotalPages());
        return userProfilesDto;
    }

    @GetMapping("/search/active")
    public UserProfilesDto searchAllActiveUsersPage(@RequestParam String page, @RequestParam String search, @RequestParam(required = false) String customerName, @RequestParam(required = false) String sortBy, @RequestParam(required = false) String sortDirection) {
        Page<UserProfile> userProfilePage = userProfileService.searchActiveUsers(userAuthentication.getLoggedInUser(), page, search, customerName, sortBy, sortDirection);
        UserProfilesDto userProfilesDto = new UserProfilesDto();
        userProfilesDto.setUserProfiles(userProfilePage.getContent());
        userProfilesDto.setTotalPages(userProfilePage.getTotalPages());
        return userProfilesDto;
    }

    /**
     * Update or Save user details based userProfile info
     *
     * @param userProfile
     * @return
     */
    @PutMapping("/update")
    public ResponseEntity updateUserProfile(@RequestBody UserProfile userProfile) {
        if (userProfileService.updateUserProfile(userProfile)) {
            return new ResponseEntity(HttpStatus.OK);
        } else {
            return new ResponseEntity(HttpStatus.NOT_FOUND);
        }
    }

    /**
     * @param username
     * @return
     */
    @PostMapping("/delete/username/{username}")
    public ResponseEntity<String> deleteUserProfile(@PathVariable String username) {
        return userProfileService.deleteUserProfile(username);
    }

    /**
     * It will delete related child mapping also
     *
     * @param userProfile
     * @return
     */
    @PostMapping("/delete")
    public ResponseEntity<String> deleteAllUsers(@RequestBody List<UserProfile> userProfile) {
        return userProfileService.deleteAllUsers(userProfile);
    }


    /**
     * @return
     */
    @GetMapping("/teams")
    public ResponseEntity<List<CollaborationTeam>> getTeamsForUser(@RequestParam(required = false) String userId) {
        if (userId == null) {
            userId = userAuthentication.getLoggedInUser().getUsername();
        }

        List<CollaborationTeam> teams = userMappingService.getTeamsForUser(userId);
        return new ResponseEntity<>(teams, HttpStatus.OK);
    }

    /**
     * API to get wordPress link
     *
     * @return
     */
    @GetMapping("/help/link")
    public String getHelpLink() {
        return wordPressHelpLink;
    }

    /**
     * API to get Aha link
     *
     * @return
     */
    @GetMapping("/aha/link")
    public String getAhaLink() {
        return ahaLink;
    }

    @GetMapping("/customers/{userId}")
    public ResponseEntity<List<Customer>> getCustomers(@PathVariable String userId) {
        List<Customer> customer = userProfileService.getCustomers(userId);
        return new ResponseEntity<>(customer, HttpStatus.OK);
    }

    @GetMapping("/check/era-access")
    public String checkERAAccess() {
       String userId = userAuthentication.getLoggedInUser().getUsername();
         userProfileService.checkERAAccess(userId,null);
        return "OK";
    }
}
