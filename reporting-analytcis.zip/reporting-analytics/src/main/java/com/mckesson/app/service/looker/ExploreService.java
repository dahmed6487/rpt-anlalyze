package com.mckesson.app.service.looker;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import main.java.com.mckesson.app.domain.looker.ExploreRef;

/**
 * Currently a placeholder for managing explore to custom group relations. Strong possibility this
 * object will be changed/renamed as details of how these relations are managed.
 */
public interface ExploreService {

    ExploreRef findById(Long id);

    Optional<ExploreRef> findByName(String name);

    ExploreRef insert(String name);

    ExploreRef save(ExploreRef ref);

    List<ExploreRef> saveAll(Collection<ExploreRef> refs);

}
