package com.mckesson.app.service.looker.api;

import java.util.HashMap;

import org.springframework.stereotype.Component;

import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.util.MappingUtils;
import main.java.com.mckesson.app.util.RestClient;
import main.java.com.mckesson.app.vo.looker.DashboardVo;

@Component
public class DashboardApi extends ApiBase {

    public DashboardVo getDashboard(String dashboardId, String[] fields, String authToken) {
        try {
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/dashboards/" + dashboardId;
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, params);
            DashboardVo dashboard = new DashboardVo();
            MappingUtils.populateFromJson(jsonResponse, dashboard);
            return dashboard;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public void deleteDashboard(String dashboardId, String authToken) {
        try {
            String requestUrl = this.lookerApiHost + "/dashboards/" + dashboardId;
            RestClient.performDELETEOperation(authToken, requestUrl);
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public DashboardVo createDashboard(DashboardVo dashboard, String[] fields, String authToken) {
        try {
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String jsonBody = MappingUtils.serializeToJson(dashboard);
            String requestUrl = this.lookerApiHost + "/dashboards";
            String jsonResponse = RestClient.performPOSTOperation(authToken, requestUrl, jsonBody, params);
            MappingUtils.populateFromJson(jsonResponse, dashboard);
            return dashboard;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public DashboardVo updateDashboard(DashboardVo dashboard, String[] fields, String authToken) {
        try {
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/dashboards/" + dashboard.getId();
            //String jsonBody = MappingUtils.serializeToJson(dashboard);

            String jsonBody = "{ \"title\":\"" + dashboard.getTitle() + "\",\"description\":\"" + dashboard.getDescription() + "\" }";

            String jsonResponse = RestClient.performPATCHOperation(authToken, requestUrl, jsonBody, params);
            MappingUtils.populateFromJson(jsonResponse, dashboard);
            return dashboard;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

}
