package com.mckesson.app.service.looker;

import org.springframework.stereotype.Service;

@Service("SharedCustomFilterService")
public class SharedCustomFilterServiceImpl implements SharedCustomFilterService {

}
