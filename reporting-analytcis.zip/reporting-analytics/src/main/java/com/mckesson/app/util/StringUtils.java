package com.mckesson.app.util;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.TimeZone;
import java.util.regex.Pattern;

import org.apache.commons.lang.CharUtils;
import org.apache.commons.lang.WordUtils;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.apache.commons.lang.time.DateFormatUtils;

import com.google.common.collect.Lists;
import com.google.common.primitives.Doubles;

public class StringUtils extends org.apache.commons.lang.StringUtils {

    public static final String[] EMPTY_ARRAY = new String[0];

    private static final Random OBS_RANDOM = new SecureRandom();

    static final byte[] HEX_CHAR_TABLE = {(byte) '0', (byte) '1', (byte) '2', (byte) '3', (byte) '4', (byte) '5',
            (byte) '6', (byte) '7', (byte) '8', (byte) '9', (byte) 'a', (byte) 'b', (byte) 'c', (byte) 'd', (byte) 'e',
            (byte) 'f'};

    private final static String HTML_LT = "&lt;";
    private final static String HTML_GT = "&gt;";
    private final static String HTML_QUOTE = "&quot;";
    private final static String HTML_APOS = "&#039;";
    private final static String HTML_SLASH = "&#092;";
    private final static String HTML_AMP = "&amp;";

    // Pharma accounts are always 6 digits with preceding 0s
    public static String formatPharmaAccountId(long accountId) {
        return StringUtils.leftPad(String.valueOf(accountId), 6, "0");
    }

    public static String formatPharmaName(String name) {
        return StringUtils.trim(StringUtils.remove(name, ","));
    }

    /**
     * Must be pre-sorted for chars for binary search
     *
     * @param in
     * @param chars
     * @return
     */
    public static String allow(String in, String chars) {
        if (in == null) {
            return null;
        }
        if (in.length() == 0) {
            return "";
        }
        if (chars == null || chars.length() == 0) {
            return in;
        }

        char[] c = in.toCharArray();
        StringBuffer sb = new StringBuffer(c.length);
        for (int i = 0; i < c.length; i++) {
            if (chars.indexOf(c[i]) >= 0) {
                sb.append(c[i]);
            }
        }
        return sb.length() == in.length() ? in : sb.toString().trim();
    }

    public static String allowAlpha(String in) {
        if (in == null) {
            return null;
        }
        if (in.length() == 0) {
            return "";
        }

        char[] c = in.toCharArray();
        StringBuffer sb = new StringBuffer(c.length);
        for (int i = 0; i < c.length; i++) {
            if ((Character.isLetter(c[i]) || Character.isWhitespace(c[i]))
                    && Character.UnicodeBlock.of(c[i]) == Character.UnicodeBlock.BASIC_LATIN) {
                sb.append(c[i]);
            }
        }
        return sb.length() == in.length() ? in : sb.toString().trim();
    }

    public static String allowLatin(String in) {
        if (in == null) {
            return null;
        }
        if (in.length() == 0) {
            return "";
        }

        char[] c = in.toCharArray();
        StringBuffer sb = new StringBuffer(c.length);
        for (int i = 0; i < c.length; i++) {
            if (Character.UnicodeBlock.of(c[i]) == Character.UnicodeBlock.BASIC_LATIN) {
                sb.append(c[i]);
            }
        }
        return sb.length() == in.length() ? in : sb.toString().trim();
    }

    public static String allowNonControl(String in) {
        if (in == null) {
            return null;
        }
        if (in.length() == 0) {
            return "";
        }

        char[] c = in.toCharArray();
        StringBuffer sb = new StringBuffer(c.length);
        for (int i = 0; i < c.length; i++) {
            if (!CharUtils.isAsciiControl(c[i])) {
                sb.append(c[i]);
            }
        }
        return sb.length() == in.length() ? in : sb.toString().trim();
    }

    private final static Pattern PATTERN_URL = Pattern.compile(
            "(https?:\\/\\/(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}(\\.[a-z]{2,4})?\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*))");
    private final static Pattern PATTERN_EMAIL = Pattern
            .compile("(([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}))");

    public static String formatHTML(String in) {
        if (in == null || in.length() == 0) {
            return "";
        }
        in = in.replaceAll("(\\r|\\n)+", "<br /><br />");
        in = PATTERN_EMAIL.matcher(in).replaceAll("<a href=\"mailto:$1\">$1</a>");
        in = PATTERN_URL.matcher(in).replaceAll("<a href=\"$1\" rel=\"nofollow\" target=\"_new\">$1</a>");
        return in;
    }

    public static String allowAlphanumeric(String in) {
        if (in == null) {
            return null;
        }
        if (in.length() == 0) {
            return "";
        }

        char[] c = in.toCharArray();
        StringBuffer sb = new StringBuffer(c.length);
        for (int i = 0; i < c.length; i++) {
            if ((Character.isLetterOrDigit(c[i]) || Character.isWhitespace(c[i]))
                    && Character.UnicodeBlock.of(c[i]) == Character.UnicodeBlock.BASIC_LATIN) {
                sb.append(c[i]);
            }
        }
        return sb.length() == in.length() ? in : sb.toString().trim();
    }

    /**
     * Allow only characters not in the passed set of chars and are alpha numeric or
     * space
     *
     * @param in
     * @param chars
     * @return
     */
    public static String disallow(String in, String chars) {
        if (in == null) {
            return null;
        }
        if (in.length() == 0) {
            return "";
        }
        if (chars == null || chars.length() == 0) {
            return in;
        }

        char[] c = in.toCharArray();
        StringBuffer sb = new StringBuffer(c.length);
        for (int i = 0; i < c.length; i++) {
            // ITASCA-6736 - remove control characters
            // !CharUtils.isAsciiControl(c[i]) Rolling this back until we fully understand
            // the extent of \n and \r cahracters.
            if (chars.indexOf(c[i]) < 0 && Character.UnicodeBlock.of(c[i]) == Character.UnicodeBlock.BASIC_LATIN) {
                sb.append(c[i]);
            }
        }
        return sb.length() == in.length() ? in : sb.toString().trim();
    }

    public final static String DISALLOW_INPUT = "<>%;()'\"";

    public final static String DISALLOW_EMAIL = "<>\"";

    public static String inputValue(String in, int len) {
        if (in == null || in.length() == 0) {
            return in;
        }
        in = StringUtils.trim(in);
        in = StringUtils.disallow(in, DISALLOW_INPUT);
        in = StringUtils.left(in, len);
        in = StringUtils.upperCase(in);
        return in;
    }

    public static String inputString(String in) {
        return inputString(in, length(in));
    }

    public static String inputString(String in, int len) {
        if (in == null || in.length() == 0) {
            return in;
        }
        in = StringUtils.trim(in);
        in = StringUtils.disallow(in, DISALLOW_INPUT);
        in = StringUtils.left(in, len);
        return in;
    }

    public static String inputEmail(String in, int len) {
        if (in == null || in.length() == 0) {
            return in;
        }
        in = StringUtils.trim(in);
        in = StringUtils.disallow(in, DISALLOW_EMAIL);
        in = StringUtils.left(in, len);
        in = StringUtils.lowerCase(in);
        return in;
    }

    /**
     * Ignores &amp;=
     *
     * @param in
     * @return
     */
    public static String QueryEncode(String in) {
        if (in == null) {
            return null;
        }
        if (in.length() == 0) {
            return in;
        }

        StringBuffer r = new StringBuffer(in.length() * 2);
        char c;
        for (int i = 0; i < in.length(); i++) {
            c = in.charAt(i);
            if (c == '<') {
                r.append(HTML_LT);
            } else if (c == '>') {
                r.append(HTML_GT);
            } else if (c == '\"') {
                r.append(HTML_QUOTE);
            } else if (c == '\'') {
                r.append(HTML_APOS);
            } else if (c == '\\') {
                r.append(HTML_SLASH);
            } else {
                r.append(c);
            }
        }
        return r.toString();
    }

    public static String HTMLEncode(String in) {
        if (in == null) {
            return null;
        }
        if (in.length() == 0) {
            return in;
        }
        return HTMLEncode(new StringBuffer(in.length() * 2), in);
    }

    public static String HTMLEncode(StringBuffer r, String in) {
        if (r == null) {
            throw new NullPointerException("SB cannot be null");
        }
        if (in == null) {
            return null;
        }
        if (in.length() == 0) {
            return in;
        }

        r.setLength(0);
        char c;
        for (int i = 0; i < in.length(); i++) {
            c = in.charAt(i);
            if (c == '<') {
                r.append(HTML_LT);
            } else if (c == '>') {
                r.append(HTML_GT);
            } else if (c == '\"') {
                r.append(HTML_QUOTE);
            } else if (c == '\'') {
                r.append(HTML_APOS);
            } else if (c == '\\') {
                r.append(HTML_SLASH);
            } else if (c == '&') {
                r.append(HTML_AMP);
            } else {
                r.append(c);
            }
        }
        return r.toString();
    }

    public static String stringOrNull(Object o) {
        return o == null ? null : o.toString();
    }

    public static String stringOrBlank(Object o) {
        return o == null ? "" : o.toString();
    }

    public static String leftPart(String in, int left) {
        if (in != null && in.length() > 0) {
            int s = in.indexOf(' ');
            if (s > 0) {
                return left(in, Math.min(s - 1, left));
            } else {
                return left(in, left);
            }
        }
        return in;
    }

    public static String getHexString(byte[] raw) throws UnsupportedEncodingException {
        byte[] hex = new byte[2 * raw.length];
        int index = 0;

        for (byte b : raw) {
            int v = b & 0xFF;
            hex[index++] = HEX_CHAR_TABLE[v >>> 4];
            hex[index++] = HEX_CHAR_TABLE[v & 0xF];
        }
        return new String(hex, StandardCharsets.US_ASCII);
    }

    public static String pluralForm(String orig) {
        if (orig == null || StringUtils.isBlank(orig) || orig.endsWith("s") || orig.length() < 3) {
            return orig;
        }

        if (orig.endsWith("y")) {
            return orig.substring(0, orig.length() - 2) + "ies";
        } else {
            return orig + "s";
        }
    }

    public static String removeplural(String orig) {
        if (orig == null || StringUtils.isBlank(orig) || !orig.toLowerCase().endsWith("s")) {
            return orig;
        }

        if (orig.toLowerCase().endsWith("ies")) {
            if (orig.length() >= 6) {
                return orig.substring(0, orig.length() - 3);
            }
        } else if (orig.toLowerCase().endsWith("s")) {
            if (orig.length() >= 4) {
                return orig.substring(0, orig.length() - 1);
            }
        }

        return orig;
    }

    public static String normalize(String orig) {
        return StringUtils.upperCase(StringUtils.trimToNull(orig));
    }

    public static String dropLeadingZeros(String orig) {
        if (orig == null) {
            return null;
        }

        int i;
        for (i = 0; i < orig.length() && orig.charAt(i) == '0'; i++) {
        }
        if (i > 0) {
            return orig.substring(i);
        } else {
            return orig;
        }
    }

    public static boolean equals(String str, long num) {
        return (StringUtils.isNumeric(str) && Long.parseLong(str, 10) == num);
    }

    public static boolean equals(String str, List<String> args) {
        for (String s : args) {
            if (StringUtils.equals(str, s)) {
                return true;
            }
        }
        return false;
    }

    public static boolean equals(String str, String... args) {
        return equals(str, Arrays.asList(args));
    }

    public static boolean containsAll(String orig, String[] parts) {
        for (int i = 0; i < parts.length; i++) {
            if (orig.indexOf(parts[i]) < 0) {
                return false;
            }
        }
        return true;
    }

    public static boolean containsValue(String orig, String search) {
        return containsValue(orig, search, ' ');
    }

    public static boolean containsValue(String orig, String search, char sep) {
        if (isNotBlank(search) && isNotBlank(orig)) {
            if (equals(orig, search)) {
                return true;
            } else if (contains(orig, sep + search)) {
                return true;
            } else return contains(orig, search + sep);
        }
        return false;
    }

    public static String obs(String in) {
        return obs(in, true);
    }

    public static String obs(String in, boolean obs) {
        if (obs && in != null) {
            StringBuffer sb = new StringBuffer(in.length());
            char c;
            int n, shift;
            for (int i = 0; i < in.length(); i++) {
                shift = OBS_RANDOM.nextInt(26);
                c = in.charAt(i);
                if (Character.isWhitespace(c)) {
                    sb.append(c);
                } else if (Character.isLetter(c)) {
                    n = shift % 26;
                    if (Character.isUpperCase(c)) {
                        sb.append((char) ('A' + n));
                    } else {
                        sb.append((char) ('a' + n));
                    }
                } else if (Character.isDigit(c)) {
                    n = shift % 10;
                    sb.append((char) ('0' + n));
                } else {
                    sb.append(c);
                }
            }
            return sb.toString();
        }
        return in;
    }

    public static String stripChars(String in, String out) {
        if (in == null || out == null) {
            return in;
        }

        StringBuffer sb = new StringBuffer(in.length());
        char c;
        for (int i = 0; i < in.length(); i++) {
            c = in.charAt(i);
            if (out.indexOf(c) == -1) {
                sb.append(c);
            }
        }
        return sb.toString().trim();
    }

    public static String stripWhitespace(String in) {
        if (in == null) {
            return in;
        }

        StringBuffer sb = new StringBuffer(in.length());
        char c;
        for (int i = 0; i < in.length(); i++) {
            c = in.charAt(i);
            if (!Character.isWhitespace(c)) {
                sb.append(c);
            }
        }
        return sb.toString().trim();
    }

    /**
     * null values will sort last when sorting ascending order e.g. if first is not
     * null and second is null, the second is considered greater so return -1
     *
     * @param first
     * @param second
     * @return int
     */
    public static int compare(String first, String second) {
        if (first != null) {
            if (second == null) {
                return -1;
            } else {
                return first.compareTo(second);
            }
        }
        return (second != null) ? 1 : 0;
    }

    public static void main(String[] arg) {
        System.out.println(combine(new String[]{"A", "B", "C S "}, ", "));
        System.out.println(removeplural("onesies"));
        System.out.println(removeplural("bags"));
        System.out.println(removeplural("sies"));
        System.out.println(removeplural("os"));
        System.out.println(removeplural("onesies".toUpperCase()));
        System.out.println(removeplural("bags".toUpperCase()));
        System.out.println(removeplural("sies".toUpperCase()));
        System.out.println(removeplural("os".toUpperCase()));

        System.out.println(Lists.newArrayList(splitCommon("810,810-edi")));
        System.out.println(Lists.newArrayList(splitCommon("810, 810-edi")));
        System.out.println(Lists.newArrayList(splitCommon("810;810-edi")));
        System.out.println(Lists.newArrayList(splitCommon("810 810-edi")));
        System.out.println(Lists.newArrayList(splitCommon("810 || | 810-edi")));

        System.out.println(formatHTML("This\n\n\nis\r\na\rtest for pete's sake"));

        String all = "";
        for (int i = 'a'; i <= 'z'; i++) {
            all += (char) i;
        }
        for (int i = 'A'; i <= 'Z'; i++) {
            all += (char) i;
        }
        for (int i = '0'; i <= '9'; i++) {
            all += (char) i;
        }
        all += "!@#$%^&*()_+  \r\n---";

        System.out.println(all);
        for (int i = 0; i < 10; i++) {
            System.out.println(obs(all));
        }

        System.out.println(abbreviateMiddle("123456789012345678901234567890", 5, 0));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 5, 1));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 5, 2));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 5, 3));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 5, 4));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 5, 5));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 10, 0));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 10, 1));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 10, 2));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 10, 3));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 10, 4));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 10, 5));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 10, 10));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 11, 0));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 11, 1));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 11, 2));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 11, 3));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 11, 4));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 11, 5));
        System.out.println(abbreviateMiddle("123456789012345678901234567890", 11, 11));

        String[] ids = {"foo bar", "19043", "A349302", "234320-", "329043-3943", "343902.343", "-432343"};
        for (String i : ids) {
            System.out.println(isIdentifier(i) + "\t" + i);
        }

        System.out.println(splitHL7Name("Derek Bodin")[0]);
        System.out.println(splitHL7Name("Derek, Bodin")[0]);
    }

    public static String padString(String original, char padChar, int length) {
        if (original.length() >= length) {
            return original;
        }

        char[] chars = new char[length - original.length()];
        Arrays.fill(chars, padChar);
        return new String(chars) + original;
    }

    public static String cleanWhitespace(String in) {
        if (in == null) {
            return null;
        }
        StringBuffer sb = new StringBuffer(in);
        boolean lastWhite = false;
        for (int i = sb.length() - 1; i >= 0; i--) {
            if (Character.isWhitespace(sb.charAt(i))) {
                if (lastWhite) {
                    sb.deleteCharAt(i);
                } else {
                    sb.setCharAt(i, ' ');
                    lastWhite = true;
                }
            } else {
                lastWhite = false;
            }
        }
        return sb.toString().trim();
    }

    public static int getNumberOfParts(String in, String seperator) {
        if (isBlank(in)) {
            return 0;
        }

        return in.split(RegexUtil.escapeRegexSpecialChars(seperator)).length;
    }

    /**
     * Splits a string using a given seperator, and returns the rightmost
     * <code>numberOfParts</code> parts of the string, preserving the seperator
     * between those parts. For example, given in="com.mckesson.foo.bar",
     * seperator="." and numberOfParts=2, this function will return "foo.bar".
     * <p>
     * If numberOfParts is greater than the number of parts that exist, the entire
     * string is returned.
     * <p>
     * If numberOfParts is negative, it is made positive and interpreted as the
     * number of segments to skip from the left. For example, given
     * in="com.mckesson.foo.bar", seperator="." and numberOfParts=-1, this function
     * will return 'mckesson.foo.bar'.
     *
     * @param in
     * @param seperator
     * @param numberOfParts
     * @return
     */
    public static String rightParts(String in, String seperator, int numberOfParts) {
        if (org.apache.commons.lang.StringUtils.isBlank(in)) {
            return in;
        }

        String[] parts = in.split(RegexUtil.escapeRegexSpecialChars(seperator));
        if (numberOfParts < 0) {
            numberOfParts = parts.length - -numberOfParts;
        }

        if (numberOfParts < 1) {
            return "";
        }

        if (parts.length <= numberOfParts) {
            return in;
        }

        StringBuffer sb = new StringBuffer(in.length());
        for (int i = parts.length - numberOfParts; i < parts.length; i++) {
            sb.append(parts[i]).append(seperator);
        }
        sb.setLength(sb.length() - seperator.length());

        return sb.toString();
    }

    /**
     * Splits a string using a given seperator, and returns the leftmost
     * <code>numberOfParts</code> parts of the string, preserving the seperator
     * between those parts. For example, given in="com.mckesson.foo.bar",
     * seperator="." and numberOfParts=2, this function will return "com.mckesson".
     * <p>
     * If numberOfParts is greater than the number of parts that exist, the entire
     * string is returned.
     * <p>
     * If numberOfParts is negative, it is made positive and interpreted as the
     * number of segments to skip from the right. For example, given
     * in="com.mckesson.foo.bar", seperator="." and numberOfParts=-1, this function
     * will return 'com.mckesson.foo'.
     *
     * @param in
     * @param seperator
     * @param numberOfParts
     * @return
     */
    public static String leftParts(String in, String seperator, int numberOfParts) {
        if (org.apache.commons.lang.StringUtils.isBlank(in)) {
            return in;
        }

        String[] parts = in.split(RegexUtil.escapeRegexSpecialChars(seperator));
        if (numberOfParts < 0) {
            numberOfParts = parts.length - -numberOfParts;
        }

        if (numberOfParts < 1) {
            return "";
        }

        if (parts.length <= numberOfParts) {
            return in;
        }

        StringBuffer sb = new StringBuffer(in.length());
        for (int i = 0; i < numberOfParts; i++) {
            sb.append(parts[i]).append(seperator);
        }
        sb.setLength(sb.length() - seperator.length());

        return sb.toString();
    }

    public static String makeUnique(String base, int maxLength, StringUniquenessVerifier verifier) {
        int index = 0;
        while (String.valueOf(index).length() <= maxLength) {
            String stringToTest = getIndexedString(base, index, maxLength);
            if (verifier.isUnique(stringToTest)) {
                return stringToTest;
            } else {
                index++;
            }
        }

        return null;
    }

    /**
     * Returns a string with the given base, of no longer than maxlength, that is
     * guaranteed not to exist in the supplied collection of strings already.
     * Returns null if such a string cannot be created. (highly unlikely, unless
     * maxLength is very close to base.length())
     */
    public static String makeUnique(String base, int maxLength, Collection strings) {
        return makeUnique(base, maxLength, new CollectionStringUniquenessVerifier(strings));
    }

    static class CollectionStringUniquenessVerifier implements StringUniquenessVerifier {
        private final Collection collection;

        public CollectionStringUniquenessVerifier(Collection collection) {
            this.collection = collection;
        }

        @Override
        public boolean isUnique(String s) {
            return !collection.contains(s);
        }
    }

    public static String getIndexedString(String base, int index, int maxLength) {
        String indexString = "";

        if (index > 0) {
            indexString = String.valueOf(index);
        }
        if ((indexString + base).length() > maxLength) {
            base = org.apache.commons.lang.StringUtils.left(base, maxLength - indexString.length());
        }

        return org.apache.commons.lang.StringUtils.left(base + indexString, maxLength);
    }

    public static String[] getCommaDelimitedList(String list) {
        return getDelimitedList(",", list);
    }

    public static String[] getSpaceDelimitedList(String list) {
        return getDelimitedList("[\\ ]+", list);
    }

    public static String[] getDelimitedList(String pattern, String list) {
        if (StringUtils.isBlank(list)) {
            return new String[0];
        }

        String[] parts = list.split(pattern);
        for (int i = 0; i < parts.length; i++) {
            String part = parts[i];
            parts[i] = part.trim();
        }

        return parts;
    }

    public static String convertToXmlEscaped(String in) {
        char myChar = '\u2122';
        Character tm = Character.valueOf(myChar);

        char myChar2 = '\u00A9';
        Character copyright = Character.valueOf(myChar2);

        char myChar3 = '\u00AE';
        Character registered = Character.valueOf(myChar3);

        StringBuffer sb = new StringBuffer();
        char c;
        for (int i = 0; i < in.length(); i++) {
            c = in.charAt(i);
            Character ch = Character.valueOf(c);
            if (ch.equals(tm)) {
                sb.append("&#8482;");
            } else if (ch.equals(copyright)) {
                sb.append("&#169;");
            } else if (ch.equals(registered)) {
                sb.append("&#174;");
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static String convertToTextEscaped(String in) {
        char myChar = '\u2122';
        Character tm = Character.valueOf(myChar);

        char myChar2 = '\u00A9';
        Character copyright = Character.valueOf(myChar2);

        char myChar3 = '\u00AE';
        Character registered = Character.valueOf(myChar3);

        StringBuffer sb = new StringBuffer();
        char c;
        for (int i = 0; i < in.length(); i++) {
            c = in.charAt(i);
            Character ch = Character.valueOf(c);
            if (ch.equals(tm)) {
                sb.append("(TM)");
            } else if (ch.equals(copyright)) {
                sb.append("(C)");
            } else if (ch.equals(registered)) {
                sb.append("(R)");
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static boolean isDouble(String n) {
        try {
            Double.parseDouble(n);
        } catch (NumberFormatException e) {
            return false;
        }
        return true;
    }

    /**
     * Allows for things like $4,500.04
     *
     * @param in
     * @return
     */
    public static boolean isNumericFormatted(String in) {
        if (in == null) {
            return false;
        }
        for (char c : in.toCharArray()) {
            if (!Character.isDigit(c) && '.' != c && ',' != c && '$' != c) {
                return false;
            }
        }
        return true;
    }

    /**
     * Only allows numbers and '.'
     *
     * @param in
     * @return
     */
    public static String allowNumericFormatted(String in) {
        if (in == null) {
            return null;
        }
        StringBuffer sb = new StringBuffer(in.length());
        for (char c : in.toCharArray()) {
            if (Character.isDigit(c) || '.' == c) {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static String allowNumeric(String in) {
        if (in == null) {
            return null;
        }
        StringBuffer sb = new StringBuffer(in.length());
        for (char c : in.toCharArray()) {
            if (Character.isDigit(c)) {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static String allowNumericFormatted(String in, String def) {
        String out = allowNumericFormatted(in);
        return out == null || "".equals(out) ? def : out;
    }

    // null safe.
    public static String[] concat(String[] s1, String[] s2) {
        if (s1 == null && s2 == null) {
            return new String[0];
        }
        if (s1 == null) {
            return s2;
        }
        if (s2 == null) {
            return s1;
        }

        String[] result = new String[s1.length + s2.length];

        System.arraycopy(s1, 0, result, 0, s1.length);
        System.arraycopy(s2, 0, result, s1.length, s2.length);

        return result;
    }

    public static String filterNonAscii(String inString) {
        // Create the encoder and decoder for the character encoding
        Charset charset = StandardCharsets.US_ASCII;
        CharsetDecoder decoder = charset.newDecoder();
        CharsetEncoder encoder = charset.newEncoder();

        // This line is the key to removing "unmappable" characters.
        encoder.onUnmappableCharacter(CodingErrorAction.IGNORE);
        String result = inString;

        try {
            // Convert a string to bytes in a ByteBuffer
            ByteBuffer bbuf = encoder.encode(CharBuffer.wrap(inString));

            // Convert bytes in a ByteBuffer to a character ByteBuffer and then to a string.
            CharBuffer cbuf = decoder.decode(bbuf);
            result = cbuf.toString();
        } catch (CharacterCodingException cce) {
            String errorMessage = "Exception during character encoding/decoding: " + cce.getMessage();
            System.err.println(errorMessage);
            cce.printStackTrace();
        }

        return result;
    }

    public static byte[] getBytes(String s, String charset) {
        if (s == null) {
            return new byte[0];
        }
        try {
            return s.getBytes(charset);
        } catch (UnsupportedEncodingException e) {
            return s.getBytes();
        }
    }

    public static byte[] toUTF8(String s) {
        if (s == null) {
            return new byte[0];
        }
        return s.getBytes(StandardCharsets.UTF_8);
    }

    public static String toUTF8(byte[] b) {
        if (b == null || b.length == 0) {
            return "";
        }
        return new String(b, StandardCharsets.UTF_8);
    }

    public static boolean isNumericNotBlank(String str) {
        return StringUtils.isNumeric(str) && StringUtils.isNotBlank(str);
    }

    public static boolean isNotBlank(String... args) {
        for (String a : args) {
            if (StringUtils.isBlank(a)) {
                return false;
            }
        }
        return true;
    }

    public static boolean isAnyBlank(String... args) {
        for (String a : args) {
            if (StringUtils.isBlank(a)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isBlank(String... args) {
        for (String a : args) {
            if (StringUtils.isNotBlank(a)) {
                return false;
            }
        }
        return true;
    }

    public static String abbreviateNice(String in, int maxSize) {
        if (in == null || in.length() <= maxSize) {
            return in;
        }
        int i = in.lastIndexOf(' ', maxSize);
        if (i <= 0) {
            return abbreviate(in, maxSize);
        } else {
            return in.substring(0, i);
        }
    }

    // fallingback to abbreviate throws an error if length <=4
    public static String abbreviateMiddle(String in, int maxSize, int tail) {
        if (in == null || in.length() <= maxSize) {
            return in;
        }
        if (maxSize - tail < 4) {
            return abbreviate(in, maxSize);
        }

        String abbr = abbreviate(in, maxSize - tail);
        abbr += in.substring(in.length() - tail);

        return abbr;
    }

    private final static char[] DESC_DELIM = new char[]{' ', '/', '-'};

    public static String toCamelCase(String str) {
        return WordUtils.capitalizeFully(str, DESC_DELIM);
    }

    public static String toString(Object o) {
        if (o == null) {
            return "null";
        }
        return ToStringBuilder.reflectionToString(o, ToStringStyle.SHORT_PREFIX_STYLE);
    }

    // get value of Object, not the string representation of Object like above
    public static String valueOf(Object o) {
        if (o == null) {
            return null;
        }
        return o.toString();
    }

    public static String nvl(String s1, String s2) {
        return StringUtils.isNotBlank(s1) ? s1 : s2;
    }

    public static String[] splitCommon(String s) {
        if (isNotBlank(s)) {
            return s.split("[\\s;,\\|]+");
        }
        return new String[0];
    }

    public static String convertFromCamelForm(String name) {
        if (isNotBlank(name)) {
            StringBuffer sb = new StringBuffer(name.length() + 2);
            for (int i = 0; i < name.length(); i++) {
                if (i > 0 && Character.isUpperCase(name.charAt(i))) {
                    sb.append(' ');
                }
                sb.append(name.charAt(i));
            }
            return sb.toString();
        }
        return name;
    }

    public static String[] splitHL7Name(String s) {
        if (isNotBlank(s)) {
            s = s.split(",")[0];
            return s.split("\\s+");
        }
        return new String[0];
    }

    private static final Pattern Identifier = Pattern.compile("^\\w+((\\-|\\.)(\\w)+)*$");

    public static boolean isIdentifier(String s) {
        return s != null && Identifier.matcher(s).matches();
    }

    public static String toString(Throwable e) {
        if (e == null) {
            return "";
        }
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        PrintStream pout = new PrintStream(bout);

        e.printStackTrace(pout);
        pout.flush();
        return bout.toString();
    }

    public static String combine(String[] strings, String sep) {
        if (strings == null || sep == null) {
            return null;
        }
        return combine(Lists.newArrayList(strings), sep);
    }

    public static String combine(Collection<String> strings, String sep) {
        if (strings == null || sep == null) {
            return null;
        }
        if (strings.size() == 0) {
            return "";
        }

        StringBuffer result = new StringBuffer();
        for (String s : strings) {
            result.append(s).append(sep);
        }
        if (result.length() > 0) {
            result.setLength(result.length() - sep.length());
        }
        return result.toString();
    }

    public static String nvlCombine(String sep, String... strings) {
        if (strings == null) {
            return "";
        }
        return nvlCombine(sep, Lists.newArrayList(strings));
    }

    /**
     * This method is similar to the join method and the combine methods.<br>
     * The primary difference is that Null/blank strings are ignored and no
     * separator is added.<br>
     * Also this method will never return a null string. If there are no strings to
     * combine it will return a blank string (i.e. "");
     *
     * @param sep     The separator to use.
     * @param strings the collection of strings to combine.
     * @return A string containing all the strings separated by sep.
     */
    public static String nvlCombine(String sep, Collection<String> strings) {
        if (strings == null || strings.size() == 0) {
            return "";
        }
        StringBuffer sb = new StringBuffer();
        for (String s : strings) {
            if (isNotBlank(s)) {
                if (sb.length() > 0 && sep != null) {
                    sb.append(sep);
                }
                sb.append(s);
            }
        }
        return sb.toString();
    }

    public static String ensureLengthRight(String str, int length) {
        return ensureLengthRight(str, length, ' ');
    }

    public static String ensureLengthRight(String str, int length, char pad) {
        int l = length(str);
        if (l < length) {
            return rightPad(str, length, pad);
        }
        if (l > length) {
            return left(str, length);
        }

        return str;
    }

    private final static double[] EXTRACT_DIGITS_NONE = new double[0];

    public static double[] extractDigits(String in) {
        if (StringUtils.isNotBlank(in)) {
            List<Double> result = null;
            StringBuffer sb = new StringBuffer(4);
            boolean fraction = false;
            for (char c : in.toCharArray()) {
                if (c == ',') {
                    continue;
                } else if (c != '/' && (Character.isDigit(c) || c == '.')) {
                    sb.append(c);
                } else {
                    if (sb.length() > 0) {
                        if (result == null) {
                            result = Lists.newArrayList();
                        }
                        try {
                            double d = Double.parseDouble(sb.toString());
                            if (fraction && result.size() > 0 && d > 0) {
                                Double num = result.remove(result.size() - 1);
                                result.add(num.doubleValue() / d);
                            } else {
                                result.add(d);
                            }
                        } catch (Exception e) {
                        }
                        sb.setLength(0);
                        fraction = c == '/';
                    }
                }
            }

            if (sb.length() > 0) {
                if (result == null) {
                    result = Lists.newArrayList();
                }

                try {
                    double d = Double.parseDouble(sb.toString());
                    if (fraction && result.size() > 0 && d > 0) {
                        Double num = result.remove(result.size() - 1);
                        result.add(num.doubleValue() / d);
                    } else {
                        result.add(d);
                    }
                } catch (Exception e) {
                }
            }

            if (result != null && !result.isEmpty()) {
                return Doubles.toArray(result);
            }
        }

        return EXTRACT_DIGITS_NONE;
    }

    public static Comparator<String> compareAlphanumeric() {
        return new Comparator<String>() {

            @Override
            public int compare(String o1, String o2) {
                int c = 0;

                double[] d1 = getDigits(o1);
                double[] d2 = getDigits(o2);

                if (d1.length > 0 && d2.length > 0) {
                    for (int i = 0; c == 0 && i < d1.length && i < d2.length; i++) {
                        c = Doubles.compare(d1[i], d2[i]);
                    }
                }

                return c != 0 ? c : StringUtils.compare(o1, o2);
            }

            private double[] getDigits(String in) {
                return extractDigits(in);
            }

        };
    }

    public static Comparator<String> compareSizes() {
        return new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                int i1 = sizeIndex(o1);
                int i2 = sizeIndex(o2);

                if (i1 > 0 && i2 > 0) {
                    if (i1 == i2) {
                        return o1.compareTo(o2);
                    }
                    return i1 - i2;
                } else if (i1 > 0) {
                    return -1;
                } else if (i2 > 0) {
                    return 1;
                }

                return 0;
            }

            private int sizeIndex(String in) {
                if (in != null) {
                    String uin = in.toUpperCase();
                    for (int i = 0; i < SIZES.length; i++) {
                        if (uin.startsWith(SIZES[i])) {
                            return i;
                        }
                    }
                }
                return -1;
            }
        };
    }

    private final static String[] SIZES_MOD = new String[]{"X", "XX", "2X", "2 X", "XXX", "3X", "3 X", "4X", "4 X",
            "5X", "5 X"};
    private static final String[] SIZES;

    static {
        List<String> sizes = Lists.newArrayListWithExpectedSize(32);

        for (String mod : SIZES_MOD) {
            sizes.add(0, mod + "S");
            sizes.add(0, mod + " S");
            sizes.add(0, mod + "-S");
        }

        sizes.add("SMALL");
        sizes.add("MEDIUM");
        sizes.add("LARGE");

        for (String mod : SIZES_MOD) {
            sizes.add(mod + "L");
            sizes.add(mod + " L");
            sizes.add(mod + "-L");
        }

        SIZES = sizes.toArray(new String[sizes.size()]);
    }

    public static final boolean isEmpty(String s) {
        return s == null || s.length() == 0;
    }

    public static final boolean isEmptyOrZero(String s) {
        return isEmpty(s) || "0".equals(s);
    }

    public static final boolean isTrue(String s) {
        return s != null && "y".equalsIgnoreCase(s);
    }

    public static final String concat(String sep, String... s) {
        StringBuilder sb = new StringBuilder();

        for (String string : s) {
            if (string == null || string.length() == 0) {
                continue;
            }

            if (sb.length() != 0) {
                sb.append(sep);
            }
            sb.append(string);
        }

        return sb.toString();
    }

    public static String toGeneralizedTimeString(String input) throws ParseException {
        if (input == null || input.length() == 0 || "0".equals(input)) {
            return null;
        }

        input = input.replaceAll(",", "");

        TimeZone edtTimezone = TimeZone.getTimeZone("US/Eastern");
        SimpleDateFormat dateParser = new SimpleDateFormat("yyyyMMdd");
        dateParser.setTimeZone(edtTimezone);
        dateParser.setLenient(false);

        Date date = dateParser.parse(input);

        TimeZone utcTimezone = TimeZone.getTimeZone("UTC");
        SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyyMMddHHmmss");
        dateFormatter.setTimeZone(utcTimezone);

        return dateFormatter.format(date) + 'Z';
    }

    public static String toGeneralizedMonthString(String input) {
        if (input == null || input.length() == 0 || "0".equals(input)) {
            return null;
        }

        input = input.replaceAll(",", "");

        SimpleDateFormat dateParser = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        dateParser.setLenient(false);

        Date date = new Date();
        try {
            date = dateParser.parse(input);
        } catch (ParseException e) {
            System.err.println("error parsing date :" + input);
        }

        SimpleDateFormat dateFormatter = new SimpleDateFormat("MMM'' yy");

        return dateFormatter.format(date);
    }

    public static String toGeneralizedTimeString(Date date) throws ParseException {
        if (date != null) {
            return toGeneralizedTimeString(DateFormatUtils.format(date, "yyyyMMdd"));
        }

        return null;
    }
}