package com.mckesson.app.web.rest.looker;

import java.io.StringReader;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.omg.CORBA.Environment;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import com.mckesson.lib.rest.client.RestResponse;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.domain.looker.DashboardDto;
import main.java.com.mckesson.app.domain.looker.LookerEvent;
import main.java.com.mckesson.app.service.looker.LookerEventsService;
import main.java.com.mckesson.app.service.looker.LookerExploreService;
import main.java.com.mckesson.app.service.looker.LookerService;
import main.java.com.mckesson.app.util.UserAuthentication;
import main.java.com.mckesson.app.vo.looker.DashboardVo;
import main.java.com.mckesson.app.vo.looker.DimensionVo;

@RestController
@RequestMapping("/looker")
public class LookerController {

    private static final Logger log = LoggerFactory.getLogger(LookerController.class);

    private final UserAuthentication userAuthentication;
    private final LookerService lookerService;
    private final LookerExploreService lookerExploreService;
    private final LookerEventsService lookerEventsService;
    private final Environment env;
    private final HttpServletRequest request;

    @Autowired
    public LookerController(UserAuthentication userAuthentication, LookerService lookerService, LookerExploreService lookerExploreService, LookerEventsService lookerEventsService, Environment env, HttpServletRequest request) {
        this.userAuthentication = userAuthentication;
        this.lookerService = lookerService;
        this.lookerExploreService = lookerExploreService;
        this.lookerEventsService = lookerEventsService;
        this.env = env;
        this.request = request;
    }


    /**
     * Service request to generate an embed frame for a selected dashboard, and optional set of filters.
     * <p>
     * Example request format: /dashboard/123?filters=[account id=112233&account name=sample company]
     *
     * @param dashboardId
     * @param filters
     * @return
     * @throws Exception
     */
    @GetMapping(value = "/dashboard/{dashboardId}", produces = "text/plain")
    public String getDashboardEmbedUrl(@PathVariable String dashboardId,
                                       @RequestParam(name = "filters", required = false) String filters,
                                       @RequestParam(name = "customerId") String customerId,
                                       @RequestParam(name = "finalUserAttribute", required = false) String finalUserAttribute ) throws Exception {
        log.info("Servicing request for dashboard " + dashboardId + ", filters: " + filters);
        if (filters != null) {
            filters = filters.substring(1, filters.length() - 2);
        }
        ReportUser reportUser = userAuthentication.getLoggedInUser();

        String embedDomain = request.getHeader("Host");
        String embedUrl = lookerService.getDashboardEmbedUrlForCurrentUser(reportUser, dashboardId, filters, embedDomain, customerId, finalUserAttribute);
        log.info("Embed url prepared: " + embedUrl);

        return embedUrl;
    }

    @GetMapping(value = "/dashboard-descriptions")
    public ResponseEntity<String> getDashboardDescriptions(@RequestParam(name = "folderId") String folderId) {
        Optional<List<DashboardVo>> optionalDashboardVos = lookerService.getDashboardDescriptions(folderId);

        if (optionalDashboardVos.isPresent()) {
            return new ResponseEntity<>(new Gson().toJson(optionalDashboardVos.get()), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/look/{lookId}", produces = "text/plain")
    public String getLookEmbedUrl(@PathVariable String lookId, @RequestParam(name = "customerId") String customerId,
                                  @RequestParam(name = "finalUserAttribute", required = false) String finalUserAttribute) throws Exception {
        log.info("Servicing request for dashboard " + lookId);
        String embedDomain = request.getHeader("Host");
        ReportUser reportUser = userAuthentication.getLoggedInUser();

        String embedUrl = lookerService.getLookEmbedUrlForCurrentUser(reportUser, lookId, embedDomain, customerId,finalUserAttribute);
        log.info("Embed url prepared: " + embedUrl);
        return embedUrl;
    }

    @GetMapping(value = "/dashboard/ids", produces = "application/json")
    public String getLookEmbedUrl() throws Exception {
        log.info("Servicing request for dashboard ids");
        StringBuilder dashboardIds = new StringBuilder();
        dashboardIds.append("{\"home\":\"").append(env.getProperty("dashboardids.home")).append("\",\"")
                .append("purchaseHistory\":\"").append(env.getProperty("dashboardids.purchaseHistory")).append("\",\"")
                .append("controlledSubstances\":\"").append(env.getProperty("dashboardids.controlledSubstances")).append("\",\"")
                .append("omits\":\"").append(env.getProperty("dashboardids.omits")).append("\",\"")
                .append("reference\":\"").append(env.getProperty("dashboardids.reference")).append("\",\"")
                .append("creditsAndReturns\":\"").append(env.getProperty("dashboardids.creditsAndReturns")).append("\",\"")
                .append("idb\":\"").append(env.getProperty("dashboardids.idb")).append("\"}");
        return dashboardIds.toString();
    }

    /**
     * Retrieve embed URL for a selected 'explore'. In addition to generating a one time, embed link for the provided criteria, any application associated
     * custom groupings will appear in the resulting UI based on the current user, group associations, selected 'explore', and previously configured
     * custom groups.
     *
     * @param modelName
     * @param explore
     * @param qid
     * @return
     * @throws Exception
     */
    @GetMapping(value = "/explore/{modelName}/{explore}", produces = "text/plain")
    public String getExploreEmbedUrl(@PathVariable String modelName, @PathVariable String explore,
                                     @RequestParam(name = "qid", required = false) String qid,
                                     @RequestParam(name = "exploreType", required = false) String exploreType,
                                     @RequestParam(name = "customerId") String customerId,
                                     @RequestParam(name = "finalUserAttribute", required = false) String finalUserAttribute) throws Exception {
        log.info("Servicing request for explore " + modelName + " " + explore);
        String embedDomain = request.getHeader("Referer");
        ReportUser reportUser = userAuthentication.getLoggedInUser();

        String embedUrl = lookerService.getExploreEmbedUrlForCurrentUser(reportUser, modelName, explore, qid, exploreType, embedDomain, customerId, finalUserAttribute);
        log.info("Embed url prepared: " + embedUrl);

        return embedUrl;
    }


    @GetMapping(value = "/dashboard/explore/{modelName}/{explore}", produces = "text/plain")
    public String getDashboardExploreEmbedUrl(@PathVariable String modelName, @PathVariable String explore,
                                              @RequestParam(name="qid", required = false) String qid,
                                              @RequestParam(name= "exploreType", required = false) String exploreType,
                                              @RequestParam(name="customerId") String customerId,
                                              @RequestParam(name = "finalUserAttribute", required = false) String finalUserAttribute) throws Exception {
        log.info("Servicing request for explore " + modelName + " " + explore);
        String embedDomain = request.getHeader("Referer");
        ReportUser reportUser = userAuthentication.getLoggedInUser();

        String embedUrl = lookerService.getDashboardExploreEmbedUrlForCurrentUser(reportUser,modelName, explore, qid, exploreType, embedDomain,customerId, finalUserAttribute);
        log.info("Embed url prepared: " + embedUrl);

        return embedUrl;
    }

    @PostMapping(value = "event/save")
    public String saveLookerEvent(@RequestBody String jsonBody) {
        JsonParser parser = new JsonParser();
        JsonReader reader = new JsonReader(new StringReader(jsonBody));
        reader.setLenient(true);
        ReportUser reportUser = userAuthentication.getLoggedInUser();

        JsonElement jsonTree = parser.parse(reader);
        JsonObject jsonObject = jsonTree.getAsJsonObject();

        String eventType = jsonObject.get("type").getAsString();

        LookerEvent lookerEvent = new LookerEvent();
        lookerEvent.setEventType(eventType);
        lookerEvent.setEventData(jsonBody);
        lookerEvent.setUserId(reportUser.getUsername());

        lookerEventsService.insertLookerEvent(lookerEvent);

        return "Success";
    }

    @GetMapping(value = "/visible/dimensions")
    public Collection<DimensionVo> getVisibleDimensions(@RequestParam(required = false) String explore) {
        ReportUser reportUser = userAuthentication.getLoggedInUser();

        if (explore == null)
            return lookerExploreService.getAllVisibleDimensions(reportUser.getUsername());
        else
            return lookerExploreService.getVisibleDimensionsByExplore(reportUser.getUsername(), explore);
    }

    @GetMapping(value = "/dimension/values")
    public ResponseEntity<List<String>> getValuesForViewAndDimension(@RequestParam String view,
                                                                     @RequestParam String field,
                                                                     @RequestParam String userInput) {
        Optional<List<String>> values = lookerService.getValuesForDimension(view, field, userInput);

        if (values.isPresent()) {
            return new ResponseEntity<>(values.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/api/logout")
    public void logout(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);
        SecurityContextHolder.clearContext();
        session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity handleException(Exception e) {
        e.printStackTrace();
        return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(SecurityException.class)
    public ResponseEntity handleSecurityException(SecurityException e) {
        e.printStackTrace();
        return new ResponseEntity(HttpStatus.UNAUTHORIZED);
    }

    /**
     * For scenarios where a previously selected dashboard/embed/report is selected in a previous session, and they are returning
     * to view the same item (complete with any applied filters, etc) this API call will accept the embed URL from the Looker
     * embed event.
     * <p>
     * For instances for when the page has been loaded, the event is...
     * <p>
     * For instances where something has changed, the event is reported as 'page:properties:changed', and the dashboard.url attribute will contain the relative
     * url of the content.
     *
     * @param origEmbedUrl
     * @return
     */
    @GetMapping(value = "/session", produces = "text/plain")
    public String getRawRequestUrl(@RequestParam("model") String origEmbedUrl) {
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        try {
            String embedUrl = null;
            embedUrl = this.lookerService.getEmbedUrlForFullConfig(reportUser, origEmbedUrl);
            return embedUrl;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }


    @GetMapping(value = "get/solutions")
    public ResponseEntity<List<DashboardDto>> getSolutions(@RequestParam(name = "customerName") String customerName) {
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        Optional<List<DashboardDto>> optionalDashboardDtos = lookerService.getSolutions(customerName, reportUser);

        if (optionalDashboardDtos.isPresent()) {
            return new ResponseEntity<>(optionalDashboardDtos.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping(value = "/account-configuration-report/{customerId}")
    public void getAccountConfigurationReport(@PathVariable String customerId, final HttpServletResponse response) throws Exception {
        ReportUser reportUser = userAuthentication.getLoggedInUser();

        String[] data;
        RestResponse<String> responseEntity = lookerService.getAccountConfigurationReport(reportUser, customerId);

        data = responseEntity.getEntity().split("\n");

        Timestamp timestamp = new Timestamp(System.currentTimeMillis());


        String fileName = "Account Configuration " + customerId.toLowerCase() + " " + timestamp.getTime() + ".xlsx";

        response.addHeader("Content-disposition", "attachment; filename=" + fileName);
        response.setContentType("application/vnd.ms-excel");

        Workbook workbook = new XSSFWorkbook();
        workbook.createSheet("sheet1");
        workbook.setSheetName(0, "sheet1");
        Sheet sheet = workbook.getSheetAt(0);

        int rowIndex = 0;
        int columnIndex = 0;

        for (String rowData : data) {
            columnIndex = 0;
            sheet.createRow(rowIndex);
            for (String colData : rowData.split("\t")) {
                sheet.getRow(rowIndex).createCell(columnIndex).setCellValue(colData);
                columnIndex++;
            }
            rowIndex = rowIndex + 1;
        }

        workbook.write(response.getOutputStream());
        response.flushBuffer();
    }

    @GetMapping(value = "/get/schedules")
    public ResponseEntity<String> getScheduledPlans() throws Exception {
        log.info("GET /schedules");
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        ResponseEntity<String> response = lookerService.getScheduledPlans(reportUser);
        return response;
    }

    @DeleteMapping(value = "/schedules/{scheduledPlanId}")
    public void deleteScheduledPlan(@PathVariable String scheduledPlanId) throws Exception {
        log.info(String.format("DELETE /schedules/%s", scheduledPlanId));
        lookerService.deleteScheduledPlan(scheduledPlanId);
    }
}