package com.mckesson.app.util.crypto.legacy;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.MessageDigest;

public class FileHash {
    private final byte[] hashBytes;
    private final String hashString;
    private final long length;

    public FileHash(byte[] hashBytes, String hashString, long length) {
        if (hashBytes != null && hashBytes.length > 0) {
            this.hashBytes = new byte[hashBytes.length];
            System.arraycopy(hashBytes, 0, this.hashBytes, 0, hashBytes.length);

            // this.hashBytes = Arrays.copyOf(hashBytes, hashBytes.length);
        } else {
            this.hashBytes = new byte[0];
        }
        this.hashString = hashString;
        this.length = length;
    }

    public byte[] getHashBytes() {
        return hashBytes;
    }

    public String getHashString() {
        return hashString;
    }

    public long getLength() {
        return length;
    }

    /**
     * Uses SHA-1 hash. this method should only be used for finger printing files
     * and not for hashing sensitive information like passwords.
     */
    public static FileHash hash(InputStream in) {
        StringBuffer hash = new StringBuffer(64);
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] bytes = new byte[512];
            long size = 0;
            int read = 0;
            while ((read = in.read(bytes)) != -1) {
                md.update(bytes, 0, read);
                size += read;
            }
            byte[] bhash = md.digest();

            for (byte b : bhash) {
                hash.append(Integer.toHexString(0xFF & b));
            }
            return new FileHash(bhash, hash.toString(), size);

        } catch (Exception e) {
            return new FileHash(new byte[0], null, -1);
        }
    }

    public static FileHash hash(byte[] bytes) {
        return hash(new ByteArrayInputStream(bytes));
    }

    public static FileHash hash(String s) {
        return hash(s.getBytes());
    }

    public static void main(String[] args) {
        System.out.println(FileHash.hash(new byte[0]).getHashString());
        System.out.println(FileHash.hash(new byte[0]).getLength());
    }
}