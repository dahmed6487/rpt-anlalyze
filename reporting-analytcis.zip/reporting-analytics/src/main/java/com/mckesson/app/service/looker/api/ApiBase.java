package com.mckesson.app.service.looker.api;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.http.client.utils.URIBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import main.java.com.mckesson.app.cache.EnvironmentSpecificKeyGenerator;
import main.java.com.mckesson.app.domain.looker.AuthToken;
import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.util.MappingUtils;
import main.java.com.mckesson.app.util.RestClient;

public abstract class ApiBase {
    @Value("${looker.apiKey}")
    private String lookerApiKey;

    @Value("${looker.apiSecret}")
    private String lookerApiSecret;

    @Value("${looker.apiHost}")
    String lookerApiHost;

    public void setConfig(String apiKey, String apiSecret, String host) {
        this.lookerApiKey = apiKey;
        this.lookerApiSecret = apiSecret;
        this.lookerApiHost = host;
    }

    @Cacheable(value = "looker_auth_token", keyGenerator = EnvironmentSpecificKeyGenerator.NAME)
    public String getAuthToken() {
        RestTemplate restTemplate = new RestTemplate();
        ObjectMapper mapper = new ObjectMapper();

        String url = this.lookerApiHost + "/login";
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url)
                .queryParam("client_id", lookerApiKey)
                .queryParam("client_secret", lookerApiSecret);

        try {
            ResponseEntity<String> response = restTemplate.exchange(builder.toUriString(), HttpMethod.POST, null, String.class);
            JsonNode jsonNode = mapper.readTree(response.getBody());
            return jsonNode.findValue("access_token").asText();
        } catch (RestClientException | IOException e) {
            throw new ApiException(e.getMessage() + ", request url: " + url);
        }
    }

    @Cacheable(value = "looker_auth_token_user_id", keyGenerator = EnvironmentSpecificKeyGenerator.NAME)
    public String getAuthTokenForUserId(String authToken, String userId) {
        String requestUrl = null;
        try {

            HashMap<String, String> params = new HashMap();
            params.put("client_id", lookerApiKey);
            params.put("client_secret", lookerApiSecret);

            requestUrl = lookerApiHost + "/login/" + userId;
            String authResponse = RestClient.performPOSTOperation(authToken, requestUrl, null, params);
            AuthToken newAuthToken = new AuthToken();
            MappingUtils.populateFromJson(authResponse, newAuthToken);
            return newAuthToken.getAuthToken();
        } catch (Exception e) {
            throw new AccessDeniedException("Unable to authenticate as user with id '" + userId + "'");
        }
    }

    static String getUrl(String apiEndpoint, HashMap<String, String> params) throws Exception {

        if (params == null) {
            return apiEndpoint;
        }

        URIBuilder ub = new URIBuilder(apiEndpoint);
        if (params != null) {
            Iterator<String> i = params.keySet().iterator();
            String key;
            while (i.hasNext()) {
                key = i.next();
                ub.addParameter(key, params.get(key));
            }
        }

        return ub.toString().replaceAll("\\+", "%20");
    }
	
	/*
	public static String performPOSTOperation(String authToken, String apiEndpoint, HashMap<String, String> params) {
        return performPOSTOperation(authToken, apiEndpoint, null, params);
    }*/
	

	/*
	public static String performPOSTOperation(String authToken, String apiEndpoint, String jsonPostBody,
            HashMap<String, String> params) {

        long startTime = System.currentTimeMillis();

        URL url;
        HttpURLConnection conn = null;
        StringBuffer response;
        BufferedReader br;
        String output;
        String requestUrl = null;
        try {
            requestUrl = getUrl(apiEndpoint, params);
            url = new URL(requestUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            if (authToken != null) {
                conn.setDoInput(true);
                conn.setRequestProperty("Authorization", "token " + authToken);
            } else {
                conn.setDoInput(true);
            }

            if (jsonPostBody != null) {

                conn.setRequestProperty("Content-Type", "application/json");

                conn.setDoOutput(true);
                OutputStream outputStream = conn.getOutputStream();
                outputStream.write(jsonPostBody.getBytes("UTF-8"));
                outputStream.flush();
            }

            conn.connect();
            response = new StringBuffer();

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }

            br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            while ((output = br.readLine()) != null) {
                response.append(output);
            }

            conn.disconnect();

            System.out.println("Elapsed time for POST operation (" + apiEndpoint + ")  was "
                    + (System.currentTimeMillis() - startTime) + ")ms");
            return response.toString();
        } catch (Exception ex) {
            throw new ApiException(
                    "Unable to connect to specified url (exception)..." + requestUrl + jsonPostBody + ex.toString());
        }
    }*/


    public HashMap<String, String> getFieldCriteria(String[] fieldCriteria, HashMap<String, String> params) {
        if (params == null) {
            params = new HashMap();
        }

        if (fieldCriteria == null || fieldCriteria.length < 1) {
            return params;
        }

        StringBuilder sb = new StringBuilder();
        for (String curField : fieldCriteria) {
            sb.append(curField + ",");
        }

        if (fieldCriteria.length < 1) {
            return params;
        }

        String fieldFmt = sb.toString();
        fieldFmt = fieldFmt.substring(0, fieldFmt.length() - 1);
        params.put("fields", fieldFmt);
        return params;
    }
}
