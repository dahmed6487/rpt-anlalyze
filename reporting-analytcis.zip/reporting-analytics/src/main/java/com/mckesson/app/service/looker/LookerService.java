package com.mckesson.app.service.looker;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.mckesson.lib.rest.client.RestResponse;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.domain.looker.DashboardDto;
import main.java.com.mckesson.app.vo.looker.DashboardVo;

public interface LookerService {
    String getDashboardEmbedUrlForCurrentUser(ReportUser reportUser, String dashboardId, String filters, String embedDomain, String customerId, String finalUserAttribute) throws Exception;

    String getLookEmbedUrlForCurrentUser(ReportUser reportUser, String lookId, String embedDomain, String customerId, String finalUserAttribute) throws Exception;

    String getExploreEmbedUrlForCurrentUser(ReportUser reportUser, String modelName, String explore, String qid, String exploreType, String embedDomain, String customerId,String finalUserAttribute) throws Exception;

    String getDashboardEmbedUrlForEmbedUser(ReportUser reportUser, String dashboardId, String filters, String embedDomain);

    Optional<List<String>> getValuesForDimension(String view, String field, String userInput);

    String getEmbedUrlForFullConfig(ReportUser reportUser, String embedUrl) throws Exception;

    Optional<List<DashboardVo>> getDashboardDescriptions(String folderId);

    Optional<List<DashboardDto>> getSolutions(String customerName,ReportUser reportUser);

    String getDashboardExploreEmbedUrlForCurrentUser(ReportUser reportUser, String modelName, String explore, String qid, String exploreType, String embedDomain, String customerId, String finalUserAttribute) throws Exception;

    RestResponse<String> getAccountConfigurationReport(ReportUser reportUser, String customerId) throws Exception;

    ResponseEntity<String> getScheduledPlans(ReportUser reportUser) throws Exception;

    void deleteScheduledPlan(String scheduleId) throws Exception;


}
