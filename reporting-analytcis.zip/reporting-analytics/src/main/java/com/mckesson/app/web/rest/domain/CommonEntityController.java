package com.mckesson.app.web.rest.domain;

import java.util.List;
import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import main.java.com.mckesson.app.domain.admin.CommonEntity;
import main.java.com.mckesson.app.service.admin.CommonEntityService;


@RestController
@RequestMapping("/api/common-entity")
public class CommonEntityController {

    private static final Logger LOG = LoggerFactory.getLogger(CommonEntityController.class);

    private final CommonEntityService commonEntityService;

    @Autowired
    public CommonEntityController(CommonEntityService commonEntityService) {
        this.commonEntityService = commonEntityService;
    }

    @GetMapping("/get/user/{id}")
    public List<CommonEntity> getById(@PathVariable String id) {
        return commonEntityService.getById(id);
    }

    @GetMapping("/get")
    public List<CommonEntity> getAll() {
        return commonEntityService.getAllCommonEntities();
    }
}