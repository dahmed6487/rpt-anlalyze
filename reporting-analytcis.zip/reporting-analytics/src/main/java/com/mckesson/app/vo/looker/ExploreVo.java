package com.mckesson.app.vo.looker;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * A VO mapping the metadata returned for an <em>Explore</em> JSON object from the Looker API.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExploreVo {

    @JsonProperty("description")
    public String description;
    @JsonProperty("label")
    public String label;
    @JsonProperty("hidden")
    public Boolean hidden;
    @JsonProperty("group_label")
    public String groupLabel;
    @JsonProperty("name")
    public String name;

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Boolean getHidden() {
        return hidden;
    }

    public void setHidden(Boolean hidden) {
        this.hidden = hidden;
    }

    public String getGroupLabel() {
        return groupLabel;
    }

    public void setGroupLabel(String groupLabel) {
        this.groupLabel = groupLabel;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
