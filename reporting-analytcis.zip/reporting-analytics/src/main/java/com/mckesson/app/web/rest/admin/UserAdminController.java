package com.mckesson.app.web.rest.admin;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.service.looker.UserAdminService;
import main.java.com.mckesson.app.util.UserAuthentication;
import main.java.com.mckesson.app.vo.looker.UserVo;

@RestController
@RequestMapping("/admin/user")
public class UserAdminController {

    Logger logger = LoggerFactory.getLogger(UserAdminController.class);

    private final UserAuthentication userAuthentication;
    private final UserAdminService userAdminService;
    private final HttpServletRequest request;

    @Autowired
    public UserAdminController(UserAuthentication userAuthentication, UserAdminService userAdminService, HttpServletRequest request) {
        this.userAuthentication = userAuthentication;
        this.userAdminService = userAdminService;
        this.request = request;
    }

    @RequestMapping(method = RequestMethod.GET, path = "/objects")
    public ResponseEntity createUser() {
        ReportUser reportUser = userAuthentication.getLoggedInUser();

        //Mock request call
        UserVo user = new UserVo();

        String embedDomain = request.getHeader("Host");

        userAdminService.createUser(reportUser, user, embedDomain);

        //ReportItemVo results = spaceManagementService.getFolderStructureForCurrentUser();

        return new ResponseEntity(null, HttpStatus.OK);
    }


}
