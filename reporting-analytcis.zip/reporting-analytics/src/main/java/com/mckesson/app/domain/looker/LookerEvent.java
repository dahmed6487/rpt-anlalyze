package com.mckesson.app.domain.looker;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LOOKER_EVENTS")
public class LookerEvent {

    @Id
    @Column(name = "LKE_ID")
    private long id;

    @Column(name = "EVENT_DATA")
    private String eventData;

    @Column(name = "EVENT_TYPE")
    private String eventType;

    @Column(name = "USER_ID")
    private String userId;

    public long getId() {
        return id;
    }

    public String getEventData() {
        return eventData;
    }

    public void setEventData(String eventData) {
        this.eventData = eventData;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

}
