package com.mckesson.app.service.looker.api;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.StringJoiner;
import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.util.MappingUtils;
import main.java.com.mckesson.app.util.RestClient;
import main.java.com.mckesson.app.vo.looker.DashboardVo;
import main.java.com.mckesson.app.vo.looker.FolderVo;
import main.java.com.mckesson.app.vo.looker.LookVo;

@Component
public class SpaceApi extends ApiBase {

    Logger logger = LoggerFactory.getLogger(SpaceApi.class);

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    public SpaceApi() {
        restTemplate = new RestTemplate();
        objectMapper = new ObjectMapper();
    }

    public List<FolderVo> getFoldersForUser() {
        return null;
    }

    /**
     * Retrieve folder and collection of contents.
     *
     * @param folderId
     * @return
     */
    public FolderVo getFolderWithContents(long folderId) {
        String authToken = getAuthToken();
        return getFolderWithContents(folderId);
    }

    public FolderVo getFolderWithContents(String folderId, String authToken) {
        try {
            String[] fields = {"id", "name", "looks", "dashboards", "created_at", "favorite_count", "child_count"};
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/spaces/" + folderId;
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, params);
            FolderVo folder = new FolderVo();
            MappingUtils.populateFromJson(jsonResponse, folder);
            return folder;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public List<FolderVo> getChildFolders(String parentId, String authToken) {
        try {
            String[] fields = {"id", "name", "created_at", "parent_id", ""};
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            params.put("parent_id", parentId);
            String requestUrl = this.lookerApiHost + "/spaces/search";
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, params);
            return MappingUtils.getCollectionFromJson(jsonResponse, FolderVo.class);
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public FolderVo getFolder(String folderId, String[] fields, String authToken) {
        try {
            FolderVo folder = new FolderVo();
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/spaces/" + folderId;
            String[] responseSummary = RestClient.performGETOperationWithResponseCode(authToken, requestUrl, params);
            if (responseSummary[0].equals("401") || responseSummary[0].equals("404")) {
                throw new AccessDeniedException("You do not have access to selected folder in looker '" + folderId + "'");
            }
            String jsonResponse = responseSummary[1];
            System.out.println(jsonResponse);
            MappingUtils.populateFromJson(jsonResponse, folder);
            return folder;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public FolderVo createFolder(FolderVo folder, String authToken) {
        try {
            String[] fields = {"id", "name", "created_at"};
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/spaces";
            String jsonBody = MappingUtils.serializeToJson(folder);
            String jsonResponse = RestClient.performPOSTOperation(authToken, requestUrl, jsonBody, params);

            FolderVo newFolder = new FolderVo();
            MappingUtils.populateFromJson(jsonResponse, newFolder);
            return newFolder;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public List<FolderVo> getAncestors(String folderId, String authToken) {
        try {
            String[] fields = {"id", "name", "created_at"};
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/spaces/" + folderId + "/ancestors";
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, params);
            return MappingUtils.getCollectionFromJson(jsonResponse, FolderVo.class);
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public void deleteFolder(String folderId, String authToken) {
        try {
            String requestUrl = this.lookerApiHost + "/spaces/" + folderId;
            RestClient.performDELETEOperation(authToken, requestUrl);
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public List<LookVo> getLooksForFolder(String folderId, String[] fields, String authToken) {
        try {
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());

            String requestUrl = this.lookerApiHost + "/spaces/" + folderId + "/looks";
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, params);
            return MappingUtils.getCollectionFromJson(jsonResponse, LookVo.class);
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    @Retryable(value = {ApiException.class})
    public List<DashboardVo> getDashboardsForFolder(String folderId, String[] fields, String authToken) {
        String url = this.lookerApiHost + "/spaces/" + folderId + "/dashboards";

        StringJoiner stringJoiner = new StringJoiner(",");
        for (String field : fields) {
            stringJoiner.add(field);
        }

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("fields", stringJoiner.toString());

        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", "Bearer " + authToken);

        try {
            ResponseEntity<String> response = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, new HttpEntity<>(headers), String.class);
            return objectMapper.readValue(response.getBody(), new TypeReference<List<DashboardVo>>() {
            });
        } catch (RestClientException | IOException e) {
            logger.error("Failed to get dashboards for folder " + folderId + " from Looker: " + e.getMessage());
            throw new ApiException("Failed to get dashboards from Looker: " + e.getMessage());
        }
    }

    public FolderVo updateSpace(FolderVo space, String authToken) {
        try {
            String requestUrl = this.lookerApiHost + "/spaces/" + space.getId();
            String jsonBody = MappingUtils.serializeToJson(space);

            String jsonResponse = RestClient.performPATCHOperation(authToken, requestUrl, jsonBody, null);
            MappingUtils.populateFromJson(jsonResponse, space);
            return space;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

}
