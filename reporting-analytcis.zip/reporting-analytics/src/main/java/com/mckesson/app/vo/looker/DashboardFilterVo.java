package com.mckesson.app.vo.looker;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DashboardFilterVo {

    private Integer id;
    private String name;
    private String explore;
    private String dimension;
    private String model;
    private String criteriaValue;
    private String title;
    private boolean applied;
    private String authorId;
    private String[] sharedTeams;
    private boolean editable;
    private boolean isSharedWithUser;

    @JsonProperty("default_value")
    private String defaultValue;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getExplore() {
        return explore;
    }

    public void setExplore(String explore) {
        this.explore = explore;
    }

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCriteriaValue() {
        return criteriaValue;
    }

    public void setCriteriaValue(String criteriaValue) {
        this.criteriaValue = criteriaValue;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isApplied() {
        return applied;
    }

    public void setApplied(boolean applied) {
        this.applied = applied;
    }

    public String getAuthorId() {
        return authorId;
    }

    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }

    public String[] getSharedTeams() {
        return sharedTeams;
    }

    public void setSharedTeams(String[] sharedTeams) {
        this.sharedTeams = sharedTeams;
    }

    public boolean isEditable() {
        return editable;
    }

    public void setEditable(boolean editable) {
        this.editable = editable;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public boolean isSharedWithUser() {
        return isSharedWithUser;
    }

    public void setSharedWithUser(boolean isSharedWithUser) {
        this.isSharedWithUser = isSharedWithUser;
    }

}
