package com.mckesson.app.web.rest.looker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.service.looker.TeamSpaceManagementService;
import main.java.com.mckesson.app.util.UserAuthentication;
import main.java.com.mckesson.app.vo.ReportItemVo;
import main.java.com.mckesson.app.vo.looker.FolderVo;

/**
 * API endpoint responsible for accessing report objects shared by a given 'team'.
 */
@RestController
@RequestMapping("/report-management/team")
public class TeamSpaceManagementController {

    private final UserAuthentication userAuthentication;
    private final TeamSpaceManagementService spaceService;

    @Autowired
    public TeamSpaceManagementController(UserAuthentication userAuthentication, TeamSpaceManagementService spaceService) {
        this.userAuthentication = userAuthentication;
        this.spaceService = spaceService;
    }

    /**
     * Retrieve collection of shared objects for the current user's team.
     *
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, path = "/{customerName}/objects")
    public ResponseEntity getSharedItems(@PathVariable("customerName") String customerName) {
        ReportItemVo folder = spaceService.getTeamFolderStructure(userAuthentication.getLoggedInUser(), customerName);
        return new ResponseEntity(folder, HttpStatus.OK);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity handlePermissionViolation() {
        return new ResponseEntity(HttpStatus.UNAUTHORIZED);
    }

    @RequestMapping(method = RequestMethod.DELETE, path = "/folder/{folderId}")
    public ResponseEntity deleteSelectedFolders(@PathVariable(name = "folderId") String folderId) {
        spaceService.deleteFolder(userAuthentication.getLoggedInUser().getUsername(), folderId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.DELETE, path = "/report/{reportId}")
    public ResponseEntity deleteSelectedReports(@PathVariable(name = "reportId") String reportId) {
        spaceService.deleteReport(userAuthentication.getLoggedInUser().getUsername(), reportId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.DELETE, path = "/dashboard/{dashboardId}")
    public ResponseEntity deleteSelectedDashboards(@PathVariable(name = "dashboardId") String dashboardId) {
        spaceService.deleteDashboard(userAuthentication.getLoggedInUser().getUsername(), dashboardId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.POST, path = "/{customerName}/folders/children")
    public ResponseEntity createFolder(@RequestBody ReportItemVo folder,@PathVariable("customerName") String customerName) {
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        spaceService.createFolder(reportUser, folder.getName(), null,customerName);
        return new ResponseEntity(HttpStatus.CREATED);
    }

    @RequestMapping(method = RequestMethod.POST, path = "/{customerName}/folders/{parentFolderId}/children")
    public ResponseEntity createFolder(@RequestBody ReportItemVo folder, @PathVariable String parentFolderId,@PathVariable("customerName") String customerName) {
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        ReportItemVo report = spaceService.createFolder(reportUser, folder.getName(), parentFolderId,customerName);
        return new ResponseEntity(report, HttpStatus.CREATED);
    }

    @RequestMapping(method = RequestMethod.PUT, path = "/folders/{folderId}")
    public ResponseEntity updateFolder(@RequestBody ReportItemVo reportItem, @PathVariable String folderId) {

        FolderVo folder = new FolderVo();
        folder.setId(reportItem.getId());
        folder.setName(reportItem.getName());
        folder.setParentId(reportItem.getParentId());

        spaceService.updateSpace(folder);

        return new ResponseEntity(folder, HttpStatus.OK);
    }

}
