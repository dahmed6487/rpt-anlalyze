package com.mckesson.app.web.rest.login;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.omg.CORBA.Environment;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.util.UserAuthentication;

/**
 * Class used for redirection when User logout
 */
@RestController
@RequestMapping("/api")
public class LogoutController {

    private static final Logger LOG = LoggerFactory.getLogger(LogoutController.class);

    private final Environment env;
    private final UserAuthentication userAuthentication;

    @Autowired
    public LogoutController(Environment env, UserAuthentication userAuthentication) {
        this.env = env;
        this.userAuthentication = userAuthentication;
    }

    /**
     * @param request
     * @return
     */
    @GetMapping("/signout")
    public ResponseEntity<String> logoutPage(HttpServletRequest request) {
        ReportUser loggedInUser = userAuthentication.getLoggedInUser();
        if(loggedInUser.isSudoUser()) {
            LOG.info("$$$$$$$$$$$$$$$$$$$$$$ Sudo user logged out $$$$$$$$$$$$$$$$$$$$$$  ",loggedInUser.getUsername().trim().toLowerCase());
        }
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        SecurityContext context = SecurityContextHolder.getContext();
        context.setAuthentication(null);
        SecurityContextHolder.clearContext();
        return new ResponseEntity<String>(env.getProperty("spring.security.oauth2.client.provider.okta.signout-uri"), HttpStatus.ACCEPTED);
    }

    /**
     * @param request
     * @return
     */
    @GetMapping("/error")
    public ResponseEntity<String> error(HttpServletRequest request) {
        throw new AccessDeniedException("Access Denied !");
    }
}
