package com.mckesson.app.repository.user;

import java.awt.print.Pageable;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import main.java.com.mckesson.app.domain.user.UserProfile;

public interface UserProfileRepository extends PagingAndSortingRepository<UserProfile, String> {

    @Query("from UserProfile where username = :username")
    UserProfile getUserDetailsByUsername(@Param("username") String username);

    @Query("from UserProfile where email = :email")
    UserProfile getUserDetailsByEmail(@Param("email") String email);

    Page<UserProfile> findByUsernameContainingIgnoreCaseOrFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCase(String searchString, String searchString2, String searchString3, Pageable pageable);

    List<UserProfile> save(Iterable<? extends UserProfile> entities);

    @Query(value = "select up.* from user_map_collab_team_relation umctr, user_mapping um, user_profile up where umctr.collaboration_team_id = ?1 and umctr.user_mapping_id = um.user_mapping_id and um.user_id = up.user_id", nativeQuery = true)
    Optional<List<UserProfile>> getMembersByCollabTeamId(String collabTeamId);

    @Query(value = "select user_profile.* " +
            "from user_mapping, user_profile " +
            "where (user_mapping.customer_id = ?1 and user_mapping.user_id = user_profile.user_id)"
            , nativeQuery = true)
    Page<UserProfile> getCustomerUsers(long customerId, Pageable pageable);


    @Query(value = "select user_profile.* " +
            "from user_mapping, user_profile " +
            "where (user_mapping.customer_id = ?1 and user_mapping.user_id = user_profile.user_id and user_profile.email is not null and user_profile.email <> '')"
            , nativeQuery = true)
    Page<UserProfile> getActiveUsers(long customerId, Pageable pageable);

    @Query(value = "select * from user_profile where (email is not null and email <> '')", nativeQuery = true)
    Page<UserProfile> getAllActiveUsers(Pageable pageable);

    @Query(value = "select distinct user_profile.* " +
            "from user_mapping, user_profile " +
            "where (user_mapping.customer_id = ?1 and user_mapping.user_id = user_profile.user_id) and (upper(user_profile.user_id) like upper(concat('%', ?2,'%')) or upper(user_profile.firstname) like upper(concat('%', ?2,'%')) or upper(user_profile.lastname) like upper(concat('%', ?2,'%')) or upper(user_profile.email) like upper(concat('%', ?2,'%')))"
            , nativeQuery = true)
    Page<UserProfile> searchCustomerUsersByUsernameOrFirstNameOrLastNameOrEmail(long customerId, String searchString, Pageable pageable);

    @Query(value = "select distinct user_profile.* " +
            "from user_mapping, user_profile " +
            "where (user_profile.email is not null and user_profile.email <> '') and (user_mapping.customer_id = ?1 and user_mapping.user_id = user_profile.user_id) and (upper(user_profile.user_id) like upper(concat('%', ?2,'%')) or upper(user_profile.firstname) like upper(concat('%', ?2,'%')) or upper(user_profile.lastname) like upper(concat('%', ?2,'%')) or upper(user_profile.email) like upper(concat('%', ?2,'%')))"
            , nativeQuery = true)
    Page<UserProfile> searchActiveCustomerUsersByUsernameOrFirstNameOrLastNameOrEmail(long customerId, String searchString, Pageable pageable);

    @Query(value = "select distinct user_profile.* " +
            "from user_mapping, user_profile " +
            "where (user_mapping.user_id = user_profile.user_id) and (user_mapping.customer_id in (select distinct customer_id from user_mapping where user_id=?3)) and (upper(user_profile.user_id) like upper(concat('%', ?1,'%')) or upper(user_profile.firstname) like upper(concat('%', ?1,'%')) or upper(user_profile.lastname) like upper(concat('%', ?1,'%')) or upper(user_profile.email) like upper(concat('%', ?1,'%')))"
            , nativeQuery = true)
    Page<UserProfile> searchAllUsersByUsernameOrFirstNameOrLastNameOrEmail(String searchString, Pageable pageable,String userId);

    @Query(value = "select distinct user_profile.* " +
            "from user_profile " +
            "where (upper(user_profile.user_id) like upper(concat('%', ?1,'%')) or upper(user_profile.firstname) like upper(concat('%', ?1,'%')) or upper(user_profile.lastname) like upper(concat('%', ?1,'%')) or upper(user_profile.email) like upper(concat('%', ?1,'%')))"
            , nativeQuery = true)
    Page<UserProfile> searchAllUsersByUsernameOrFirstNameOrLastNameOrEmailForAS(String searchString, Pageable pageable);


//    @Query(value = "select distinct user_profile.* " +
//            "from user_mapping, user_profile " +
//            "where (user_profile.email is not null and user_profile.email <> '') and (user_mapping.user_id = user_profile.user_id) and (user_mapping.customer_id in (select distinct customer_id from user_mapping where user_id=?2)) and (upper(user_profile.user_id) like upper(concat('%', ?1,'%')) or upper(user_profile.firstname) like upper(concat('%', ?1,'%')) or upper(user_profile.lastname) like upper(concat('%', ?1,'%')) or upper(user_profile.email) like upper(concat('%', ?1,'%')))"
//            , nativeQuery = true)
//    Page<UserProfile> searchAllActiveUsersByUsernameOrFirstNameOrLastNameOrEmail(String searchString, String userId, Pageable pageable);

    @Query(value = "select distinct user_profile.* " +
            "from user_profile " +
            "where (user_profile.email is not null and user_profile.email <> '') and (upper(user_profile.user_id) like upper(concat('%', ?1,'%')) or upper(user_profile.firstname) like upper(concat('%', ?1,'%')) or upper(user_profile.lastname) like upper(concat('%', ?1,'%')) or upper(user_profile.email) like upper(concat('%', ?1,'%')))"
            , nativeQuery = true)
    Page<UserProfile> searchAllActiveUsersByUsernameOrFirstNameOrLastNameOrEmailForAS(String searchString, Pageable pageable);

    // TODO: Filter based on future internal admin/sales/support permissions
    @Query(value = "select distinct user_profile.* " +
            "from user_profile " +
            "where (user_profile.email is not null and user_profile.email <> '') and (upper(user_profile.user_id) like upper(concat('%', ?1,'%')) or upper(user_profile.firstname) like upper(concat('%', ?1,'%')) or upper(user_profile.lastname) like upper(concat('%', ?1,'%')) or upper(user_profile.email) like upper(concat('%', ?1,'%')))"
            , nativeQuery = true)
    Page<UserProfile> searchActiveUsersByUsernameOrFirstNameOrLastNameOrEmailForIA(String searchString, Pageable pageable);

    // Pull external users for Customer Admin
    @Query(value = "select user_profile.* " +
            "from user_mapping, user_profile " +
            "where (user_mapping.customer_id = ?1 and user_mapping.user_id = user_profile.user_id and user_profile.email is not null and user_profile.email <> '' and user_profile.internal = 'false')"
            , nativeQuery = true)
    Page<UserProfile> getActiveExternalUsers(long customerId, Pageable pageable);

    @Query(value = "select distinct user_profile.* " +
            "from user_mapping, user_profile " +
            "where (user_profile.email is not null and user_profile.email <> '' and user_profile.internal = 'false') and (user_mapping.customer_id = ?1 and user_mapping.user_id = user_profile.user_id) and (upper(user_profile.user_id) like upper(concat('%', ?2,'%')) or upper(user_profile.firstname) like upper(concat('%', ?2,'%')) or upper(user_profile.lastname) like upper(concat('%', ?2,'%')) or upper(user_profile.email) like upper(concat('%', ?2,'%')))"
            , nativeQuery = true)
    Page<UserProfile> searchActiveExternalCustomerUsersByUsernameOrFirstNameOrLastNameOrEmail(long customerId, String searchString, Pageable pageable);

    @Transactional
    @Modifying
    @Query(value = "update user_profile set last_login_date=?2 where user_id =?1", nativeQuery = true)
    void updateLastLoginDate(String username, Date date);
}
