package com.mckesson.app.service.admin;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mckesson.lib.model.platform.PlatformId;

import main.java.com.mckesson.app.auth.permission.UserType;
import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.domain.admin.Module;
import main.java.com.mckesson.app.domain.customer.ContentAccessDto;
import main.java.com.mckesson.app.domain.customer.Customer;
import main.java.com.mckesson.app.domain.customer.UserMapping;
import main.java.com.mckesson.app.domain.user.UserProfile;
import main.java.com.mckesson.app.misc.EntityNotFoundException;
import main.java.com.mckesson.app.misc.ErrorMessagesEnum;
import main.java.com.mckesson.app.repository.admin.CollaborationTeamRepository;
import main.java.com.mckesson.app.repository.admin.ModuleRepository;
import main.java.com.mckesson.app.repository.customer.CustomerRepository;
import main.java.com.mckesson.app.repository.user.UserProfileRepository;
import main.java.com.mckesson.app.service.customer.CustomerService;
import main.java.com.mckesson.app.service.customer.UserMappingService;
import main.java.com.mckesson.app.service.looker.CollaborationTeamServiceLooker;
import main.java.com.mckesson.app.service.looker.SpaceManagementService;
import main.java.com.mckesson.app.service.looker.api.ContentApi;
import main.java.com.mckesson.app.service.looker.api.FolderApi;
import main.java.com.mckesson.app.service.looker.api.GroupApi;
import main.java.com.mckesson.app.service.user.UserProfileService;
import main.java.com.mckesson.app.util.UserAuthentication;
import main.java.com.mckesson.app.vo.looker.ContentVo;
import main.java.com.mckesson.app.vo.looker.FolderVo;

@Service
@Transactional
public class CollaborationTeamService {

    @Value("${looker.sharedFolderId}")
    String sharedFolderId;

    private static final Logger log = LoggerFactory.getLogger(CollaborationTeamService.class);

    private final CollaborationTeamRepository collaborationTeamRepository;
    private final CollaborationTeamServiceLooker collaborationTeamServiceLooker;
    private final UserProfileRepository userProfileRepo;
    private final UserAuthentication userAuthentication;
    private final UserMappingService userMappingService;
    private final ModuleRepository moduleRepository;
    private final CustomerService customerService;
    private final CustomerRepository customerRepository;
    private final FolderApi folderApi;
    private final GroupApi groupApi;
    private final ContentApi contentApi;
    private final SpaceManagementService spaceManagementService;
    private final ModuleRepository moduleRepo;
    private final ObjectMapper objectMapper;


    @Autowired
    public CollaborationTeamService(CollaborationTeamRepository collaborationTeamRepository, CollaborationTeamServiceLooker collaborationTeamServiceLooker, UserProfileService userProfileService,
                                    UserProfileRepository userProfileRepo, UserAuthentication userAuthentication, UserMappingService userMappingService, ModuleRepository moduleRepository, CustomerService customerService, CustomerRepository customerRepository, FolderApi folderApi, GroupApi groupApi, ContentApi contentApi, SpaceManagementService spaceManagementService, ModuleRepository moduleRepo, ObjectMapper objectMapper) {
        this.collaborationTeamRepository = collaborationTeamRepository;
        this.collaborationTeamServiceLooker = collaborationTeamServiceLooker;
        this.userProfileRepo = userProfileRepo;
        this.userAuthentication = userAuthentication;
        this.userMappingService = userMappingService;
        this.moduleRepository = moduleRepository;
        this.customerService = customerService;
        this.customerRepository = customerRepository;
        this.folderApi = folderApi;
        this.groupApi = groupApi;
        this.contentApi = contentApi;
        this.spaceManagementService = spaceManagementService;
        this.moduleRepo = moduleRepo;
        this.objectMapper = objectMapper;
    }

    public List<CollaborationTeam> getAllTeams() {
        return collaborationTeamRepository.findAll();
    }

    public void createTeams(List<CollaborationTeam> collaborationTeams, String parentId) throws Exception {
        String authToken = folderApi.getAuthToken();
        for (int i = 0; collaborationTeams.size() > i; i++) {
            FolderVo folderId = collaborationTeamServiceLooker.createFolder(parentId, collaborationTeams.get(i).getName(), authToken);
            collaborationTeams.get(i).setExternalId(Long.parseLong(folderId.getId()));
            collaborationTeamRepository.save(collaborationTeams.get(i));
        }
    }

    public CollaborationTeam createTeam(CollaborationTeam team) {
        String authToken = folderApi.getAuthToken();
        team.setCreatedBy(userAuthentication.getLoggedInUser().getUsername());
        team.setCreatedDate(new Date());
        team.setPlatformId(PlatformId.SAP.getCodeAsString());

        Long customerId = team.getCustomerId();
        FolderVo newTeamFolder = createLookerFolder(customerId, team.getName(), authToken);
        team.setExternalId(Long.parseLong(newTeamFolder.getId()));
        collaborationTeamRepository.save(team);
        List<BigInteger> customerModuleIds = moduleRepository.findByCustomerId(customerId);
        for (BigInteger moduleId : customerModuleIds) {
            Optional<Module> moduleOptional = moduleRepository.findByModuleId(moduleId.longValue());

            if (moduleOptional.isPresent()) {
                ensureContentAccessIsAccessible(team.getCollaborationTeamId(), moduleOptional.get(), authToken);
            }
        }

        if (newTeamFolder != null) {
            GroupVo createdGroup = createLookerGroupForNewTeamAndSetPermissions(team.getName(), newTeamFolder.getContentMetadataId(), authToken);
            if (createdGroup != null) {
                boolean accessIsSetup = setupAccessOfNewGroupToMatchCustomer(createdGroup.getId().toString(), customerId, authToken);
                if (accessIsSetup) {
                    return team;
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } else {
            return null;
        }
    }

    private FolderVo createLookerFolder(Long customerId, String teamName, String authToken) {
        Optional<Customer> optionalCustomerById = customerRepository.findById(customerId);
        if (optionalCustomerById.isPresent()) {
            try {
                return collaborationTeamServiceLooker.createFolder(String.valueOf(collaborationTeamRepository.getFolderId(customerId)), teamName, authToken);
            } catch (Exception e) {
                log.error("Exception thrown in createLookerFolder " + e.getMessage());
                return null;
            }
        } else {
            return null;
        }
    }

    private GroupVo createLookerGroupForNewTeamAndSetPermissions(String groupName, String teamFolderContentMetadataId,String authToken) {
        GroupVo groupToCreate = new GroupVo();
        groupToCreate.setName(groupName);

        GroupVo createdGroup = groupApi.createGroup(groupToCreate, authToken);
        Long groupId = createdGroup.getId();

        ContentVo newContentAccess = new ContentVo();
        newContentAccess.setGroupId(String.valueOf(groupId));
        newContentAccess.setContentMetadataId(teamFolderContentMetadataId);
        newContentAccess.setPermissionType("edit");

        contentApi.giveGroupAccess(authToken, newContentAccess);
        return createdGroup;
    }

    private boolean setupAccessOfNewGroupToMatchCustomer(String groupId, Long customerId, String authToken) {
        Optional<Customer> customerOptional = customerRepository.findByCustomerId(customerId);

        if (customerOptional.isPresent()) {
            Optional<List<String>> customerModulesOptional = customerService.findContentAccessesByCommonEntityId(customerOptional.get().getCommonEntityId(), "canned report");

            if (customerModulesOptional.isPresent()) {
                List<String> customerModules = customerModulesOptional.get();

                for (String moduleName : customerModules) {

                    List<FolderVo> folders;
                    try {
                        folders = spaceManagementService.getFoldersByName(sharedFolderId, moduleName);
                    } catch (Exception e) {
                        return false;
                    }

                    if (folders != null && !folders.isEmpty()) {
                        FolderVo folder = folders.get(0);

                        ContentVo newContentAccess = new ContentVo();
                        newContentAccess.setGroupId(groupId);
                        newContentAccess.setContentMetadataId(folder.getContentMetadataId());
                        newContentAccess.setPermissionType("view");

                        contentApi.giveGroupAccess(authToken, newContentAccess);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean updateTeam(CollaborationTeam team) {
//        boolean lookerFolderUpdated = collaborationTeamServiceLooker.updateTeam("1", team.getExternalId().toString(), team.getName());

        if (true) {
            Optional<CollaborationTeam> teamToUpdate = collaborationTeamRepository.findById(team.getCollaborationTeamId());

            if (teamToUpdate.isPresent()) {
                teamToUpdate.get().setName(team.getName());
                teamToUpdate.get().setUpdatedBy(userAuthentication.getLoggedInUser().getUsername());
                teamToUpdate.get().setUpdatedDate(new Date());
                collaborationTeamRepository.save(teamToUpdate.get());
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public ResponseEntity<String> deleteTeams(List<CollaborationTeam> collaborationTeam) {
        List<Long> list = new ArrayList();
        Date deletedDate = new Date();
        collaborationTeam.stream().forEach(c ->{ list.add(c.getCollaborationTeamId());
                collaborationTeamServiceLooker.deleteTeams(c.getCollaborationTeamId()); // delete looker folder with folderId
                collaborationTeamServiceLooker.removeGroup(c.getName()); // delete looker group with group name
        } );
        collaborationTeamRepository.deleteRelation(list);
        collaborationTeamRepository.inActive(deletedDate, list);
        return new ResponseEntity<String>("Your request has been completed successfully", HttpStatus.ACCEPTED);
    }

    public List<CollaborationTeam> getTeamsForIds(List<Long> ids) {
        return collaborationTeamRepository.findAllById(ids);
    }


    /**
     * Retrieve collection of team ids for current user.
     *
     * @return
     */
    public HashSet<String> getTeamIdsForCurrentUser(String userId) {

        List<CollaborationTeam> collaborationTeams = collaborationTeamRepository.getTeamIdsForCurrentUser(userId);
        final HashSet<String> teamIdsForUser = new HashSet<>();
        collaborationTeams.forEach(collaborationTeam -> teamIdsForUser.add(collaborationTeam.getCollaborationTeamId().toString()));
        return teamIdsForUser;
    }

    public ResponseEntity<String> insertOrUpdateRelation(Long teamId, Long customerId, List<UserProfile> users) {
        for (UserProfile user : users) {
            UserMapping mapping = userMappingService.findCustomerMapping(user.getUsername(), customerId);
            if (mapping != null) {
                collaborationTeamRepository.insertOrUpdateRelation(teamId, mapping.getUserMappingId());
            }
        }
        return new ResponseEntity<>("Your request has been completed successfully", HttpStatus.ACCEPTED);
    }

    public boolean removeTeamFromUser(Long teamId, Long customerId, String userId) {
        UserMapping mapping = userMappingService.findCustomerMapping(userId, customerId);
        try {
            collaborationTeamRepository.deleteRelationByTeamAndUser(teamId, mapping.getUserMappingId());
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return false;
        }
        return true;
    }

    public ResponseEntity<String> deleteRelationById(List<Integer> list) {
        collaborationTeamRepository.deleteRelationById(list);
        return new ResponseEntity<>("Your request has been completed successfully", HttpStatus.ACCEPTED);
    }

    /**
     * 1) Admins have access to all teams
     * 2) customer admin will be based on customer
     * 3) all other based on user mapping
     *
     * @param user
     * @return
     */
    public List<CollaborationTeam> getTeamIdForCustomer(ReportUser user, String customerName) {
        try {
            List<CollaborationTeam> list = null;

            if (user.isInternal() || user.getRole().getType().equals(UserType.SuperAdmin) || user.getRole().getType().equals(UserType.CustomerAdmin))
                list = collaborationTeamRepository.getCustAdminCollTeams(customerName);
            else
                list = collaborationTeamRepository.getTeamIdForCustomer(user.getUsername(), customerName);

            if (list.size() > 0)
                return list;
            else
                throw new EntityNotFoundException(ErrorMessagesEnum.valueOf("CUST_TEAMS_NOT_FOUND").getErrorMsg());
        } catch (NullPointerException e) {
            throw new UsernameNotFoundException(ErrorMessagesEnum.valueOf("NOT_FOUND").getErrorMsg());
        }
    }

    public List<CollaborationTeam> searchTeamsForUser(ReportUser user, String searchVal) {
        if (user.isInternal())
            return user.getRole().getType().equals(UserType.InternalUser) ?
                    collaborationTeamRepository.searchTeamsForBetaUser(searchVal) : collaborationTeamRepository.searchTeamsForInternalUser(searchVal);
        else
            return collaborationTeamRepository.searchTeamsForUser(user.getUsername(), searchVal);
    }

    public Optional<CollaborationTeam> getTeams(String collabTeamId) {
        return collaborationTeamRepository.findById(Long.parseLong(collabTeamId));
    }

    public List<CollaborationTeam> getTeams(ReportUser user, String customerId, String userRole) {
        try {
            List<CollaborationTeam> list = null;

            if (user.isInternal())
                list = user.getRole().getType().equals(UserType.InternalUser) ?
                        collaborationTeamRepository.getBetaCollTeamsBypage(user.getUsername()) : collaborationTeamRepository.getSuperAdminCollTeamsBypage(user.getUsername());

            else
                list = collaborationTeamRepository.getTeamsForUseBypage(user.getUsername());

            if (list.size() > 0)
                return list;
            else
                throw new EntityNotFoundException(ErrorMessagesEnum.valueOf("TEAMS_NOT_FOUND").getErrorMsg());
        } catch (NullPointerException e) {
            throw new UsernameNotFoundException(ErrorMessagesEnum.valueOf("NO_ERA_ACCESS").getErrorMsg());
        }
    }

    public Optional<List<CollaborationTeam>> getTeamsByCustomerId(long customerId) {
        return collaborationTeamRepository.findByCustomerId(customerId);
    }

    public Optional<List<UserProfile>> getMembersByCollabTeamId(String collabTeamId) {
        return userProfileRepo.getMembersByCollabTeamId(collabTeamId);
    }

    public boolean deleteTeam(Long id) {
        CollaborationTeam team = collaborationTeamRepository.findById(id).orElseThrow(() -> new EntityNotFoundException(ErrorMessagesEnum.valueOf("TEAMS_NOT_FOUND").getErrorMsg()));
        if (team == collaborationTeamRepository.getTopLevelCustomerTeam(team.getCustomerId())) {
            log.warn("Top level Collaboration Teams cannot be deleted - id[" + id + "]");
            return false;
        } else {

            try {
                if (team.getExternalId() != null)
                    collaborationTeamServiceLooker.deleteTeams(team.getExternalId());
            } catch (Exception e) {
                log.error("Exception thrown in deleteTeams " + e.getMessage());
            }

            try {
                collaborationTeamServiceLooker.removeGroup(team.getName());
            } catch (Exception e) {
                log.error("Exception thrown in removeGroup " + e.getMessage());
            }

            collaborationTeamRepository.deleteUserMapTeamRelation(team.getCollaborationTeamId());
            collaborationTeamRepository.deleteModuleTeamRelation(team.getCollaborationTeamId());
            collaborationTeamRepository.delete(team);
            return true;
        }
    }

    public Optional<List<String>> findContentAccessesByTeamId(Long teamId) {

        List<String> modules;
        ArrayList<String> foundModule =  moduleRepo.getModulesForTeam(teamId);
        if (foundModule.size()>0) {
            Optional<CollaborationTeam> team = collaborationTeamRepository.findById(teamId);
            modules = validateModulesByCustomerAccesses(foundModule, team.get());
            return Optional.of(modules);
        } else {
            return Optional.empty();
        }
    }

    private List<String> validateModulesByCustomerAccesses(List<String> modules, CollaborationTeam team) {
        Optional<Customer> customerOptional = customerRepository.findByCustomerId(team.getCustomerId());

        if (customerOptional.isPresent()) {
            Optional<List<String>> customerModulesOptional = customerService.findContentAccessesByCommonEntityId(customerOptional.get().getCommonEntityId(), "canned report");

            if (customerModulesOptional.isPresent()) {
                List<String> customerModules = customerModulesOptional.get();

                List<String> filteredModules = modules.stream()
                        .distinct()
                        .filter(customerModules::contains)
                        .collect(Collectors.toList());
                return filteredModules;
            } else {
                throw new EntityNotFoundException("Customer modules could not be found for team: " + team.getName() + " trying to compare" +
                        " team modules to customer modules.");
            }
        } else {
            throw new EntityNotFoundException("Customer could not be found for team: " + team.getName() + " trying to compare" +
                    "team modules to customer modules.");
        }
    }

    public ResponseEntity<String> updateTeamContentAccesses(long teamId, List<ContentAccessDto> contentAccesses) throws JsonProcessingException {
        ArrayList<String> topLevelTeamAccess = new ArrayList<>();
        collaborationTeamRepository.removeTeamAccess(teamId);
        for (ContentAccessDto contentAccess : contentAccesses) {
            if (contentAccess.isAccessible()) {
                if (collaborationTeamRepository.checkTopLevelAccess(teamId, contentAccess.getModule()).size() > 0) {  // check if Top level team relation exits
                    if (collaborationTeamRepository.checkExistingAccess(teamId, contentAccess.getModule()).size() == 0) {
                        collaborationTeamRepository.updateAccess(teamId, contentAccess.getModule());
                    }
                } else {
                    assert topLevelTeamAccess != null;
                    topLevelTeamAccess.add(contentAccess.getModule());
                }
            }
        }
        assert topLevelTeamAccess != null;
        if(topLevelTeamAccess.size()>0)
            return new ResponseEntity<>(objectMapper.writeValueAsString(topLevelTeamAccess),HttpStatus.PARTIAL_CONTENT);
            else
        return new ResponseEntity<>(HttpStatus.OK);
    }

    private boolean ensureContentAccessIsAccessible(long teamId, Module module, String authToken) {
        long moduleId = module.getModuleId();
        String moduleTitle = module.getTitle();

        Optional<CollaborationTeam> collaborationTeamOptional = collaborationTeamRepository.findByCollaborationTeamId(teamId);

        if (collaborationTeamOptional.isPresent()) {
            CollaborationTeam collaborationTeam = collaborationTeamOptional.get();
            Optional<Customer> customerOptional = customerRepository.findByCustomerId(collaborationTeam.getCustomerId());

            if (customerOptional.isPresent()) {
                boolean ensureTeamHasAccessToLookerFolder = ensureTeamHasAccessToLookerFolder(collaborationTeam.getName(), moduleId, authToken);
                if (ensureTeamHasAccessToLookerFolder) {
                    Optional<List<String>> customerModulesOptional = customerService.findContentAccessesByCommonEntityId(customerOptional.get().getCommonEntityId(), "canned report");

                    if (customerModulesOptional.isPresent()) {
                        List<String> customerModules = customerModulesOptional.get();

                        if (!customerModules.contains(moduleTitle)) {
                            return false;
                        }
                    } else {
                        throw new EntityNotFoundException("Could not get customer modules for customer " + customerOptional.get().getCommonEntityId() +
                                " trying to validate the new content access request does not conflict with the customer's access");
                    }
                } else {
                    return false;
                }
            } else {
                throw new EntityNotFoundException("Could not get customer for team " + teamId +
                        " trying to validate the new content access request does not conflict with the customer's access");
            }
        } else {
            throw new EntityNotFoundException("Could not get customer ID for team " + teamId +
                    " trying to validate the new content access request does not conflict with the customer's access");
        }


        int existingRecords = moduleRepository.countRecordsTeamModuleRelationByTeamIdAndModuleId(teamId, moduleId);
        if (existingRecords > 0) {
            return true;
        } else {
            int createdRecords = moduleRepository.saveTeamModuleRelation(teamId, moduleId);
            return createdRecords > 0;
        }
    }

    private boolean ensureTeamHasAccessToLookerFolder(String teamName, long moduleId, String authToken) {
        GroupVo group=new GroupVo();
        group.setName(teamName);
        GroupVo teamLookerGroup = groupApi.createGroup(group, authToken);
        Long teamLookerGroupId = teamLookerGroup.getId();

        boolean teamHasAccessToLookerFolder = customerService.getGroupAccessOfLookerFolder(teamLookerGroupId, moduleId);
        if (teamHasAccessToLookerFolder) {
            return true;
        } else {
            return customerService.modifyAccessSoGroupHasAccessToLookerFolder(teamLookerGroupId, moduleId);
        }
    }

    private boolean ensureContentAccessIsNotAccessible(long teamId, long moduleId, String authToken) throws Exception {
        Optional<CollaborationTeam> collaborationTeamOptional = collaborationTeamRepository.findByCollaborationTeamId(teamId);

        if (collaborationTeamOptional.isPresent()) {
            CollaborationTeam collaborationTeam = collaborationTeamOptional.get();

            boolean ensureTeamDoesNotHaveAccessToLookerFolder = ensureTeamDoesNotHaveAccessToLookerFolder(collaborationTeam.getName(), moduleId, authToken);
            if (ensureTeamDoesNotHaveAccessToLookerFolder) {
                int existingRecords = moduleRepository.countRecordsTeamModuleRelationByTeamIdAndModuleId(teamId, moduleId);

                if (existingRecords == 0) {
                    return true;
                } else {
                    int recordsRemoved = moduleRepository.removeTeamModuleRelation(teamId, moduleId);
                    return recordsRemoved > 0;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private boolean ensureTeamDoesNotHaveAccessToLookerFolder(String teamName, long moduleId, String authToken) throws Exception {
        GroupVo teamLookerGroup = groupApi.getGroupByName(teamName, authToken);
        Long teamLookerGroupId = teamLookerGroup.getId();

        boolean customerHasAccessToLookerFolder = customerService.getGroupAccessOfLookerFolder(teamLookerGroupId, moduleId);

        if (!customerHasAccessToLookerFolder) {
            return true;
        } else {
            return customerService.modifyAccessSoGroupDoesNotHaveAccessToLookerFolder(teamLookerGroupId, moduleId);
        }
    }
}
