package com.mckesson.app.service.looker.api;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Component;

import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.util.MappingUtils;
import main.java.com.mckesson.app.util.RestClient;
import main.java.com.mckesson.app.vo.looker.RoleVo;

@Component
public class RoleApi extends ApiBase {

    public List<RoleVo> listGroups(String[] fields, String authToken) {

        try {
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/roles";
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, params);
            return MappingUtils.getCollectionFromJson(jsonResponse, RoleVo.class);
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }

    }

}
