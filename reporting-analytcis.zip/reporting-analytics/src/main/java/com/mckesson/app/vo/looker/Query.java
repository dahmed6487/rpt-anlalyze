package com.mckesson.app.vo.looker;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Query {

    @JsonProperty("id")
    public Long id;
    @JsonProperty("view")
    public String view;
    @JsonProperty("client_id")
    public String clientId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getView() {
        return view;
    }

    public void setView(String view) {
        this.view = view;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }
}
