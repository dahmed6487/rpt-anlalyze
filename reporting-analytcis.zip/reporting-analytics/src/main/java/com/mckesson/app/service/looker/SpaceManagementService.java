package com.mckesson.app.service.looker;

import java.util.List;
import java.util.Map;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.vo.ReportItemVo;
import main.java.com.mckesson.app.vo.looker.DashboardVo;
import main.java.com.mckesson.app.vo.looker.FolderVo;
import main.java.com.mckesson.app.vo.looker.LookVo;

/**
 * Users have the ability through the R&A application to perform a subset of report management functions, such as cloning,
 * sharing, and organizing reports into folders/spaces. This component is responsible for these operations at a user level.
 * Similar functionality is available at the 'team' level, which is managed by the TeamSpaceManagement module.
 * Reports (Looks), Dashboards, and the folders used to manage them are exposed through this interface.
 * The concept of ownership, or who can management items belonging to a particular user is driven by the location of the items
 * in relation to the current user's root space. Due to restrictions in the Looker product, embed users do not have the ability to
 * create folders, so these are created under a system account. All content relative to a given user is contains under that user's
 * root embed directory/space. All checks used to determine if the current user is the owner of a given object are based on the
 * location of the object (does it exist under the current user's root folder, or any subfolder of?
 */
public interface SpaceManagementService {

    /**
     * Retrieve a list of all report items for the current user. These items are 'owned' and
     * managed by the current user. All folders, looks, and dashboards under the current user's folder
     * are returned. Top level structure is a reference to the user's default root level space, which in turn
     * will represent the entire physical model of the user's space. i.e. all child folders, reports, and dashboards will be
     * recursively included.
     *
     * @return
     */
    ReportItemVo getFolderStructureForCurrentUser(ReportUser reportUser);

    /**
     * Create a folder for the current user. By default, new folders are created under the embed user's folder.
     *
     * @param name     Name for the new folder.
     * @param parentId Optional id for the parent folder. If none is provided, then the folder is created at the root level.
     * @return
     */
    ReportItemVo createFolder(ReportUser reportUser, String name, String parentId);

    /**
     * Perform delete operation on selected folder. This is dependent of the fact that the folder is empty, and if
     * it considered to be owned by the current user.
     *
     * @param id
     */
    void deleteFolder(ReportUser reportUser, String id);

    /**
     * This is dependent of the fact that the folder is empty, and if it considered to be owned by the current user.
     *
     * @param id
     */
    void deleteReport(ReportUser reportUser, String id);

    /**
     * This is dependent of the fact that the folder is empty, and if it considered to be owned by the current user.
     *
     * @param id
     */
    void deleteDashboard(ReportUser reportUser, String id);

    void updateSpace(FolderVo folder);

    void updateDashboard(DashboardVo dashboard);

    void updateLook(LookVo look);

    Map<String, List<List<String>>> shareReport(ReportUser reportUser, LookVo look, List<List<String>> teams, List<List<Integer>> teamIds, Boolean overWriteFlag);

    /**
     * Retrieve collection of dashboards for selected folder and current user. Operation requires that the current user has permissions as assigned by Looker
     * to view the selected folder.
     *
     * @param parentFolderId
     * @return
     */
    List<ReportItemVo> listDashboardsForFolder(ReportUser reportUser, String parentFolderId);

    List<FolderVo> listChildrenForFolder(ReportUser reportUser, String parentFolderId);

    List<FolderVo> getFoldersByName(String parentFolderId, String folderName) throws Exception;

    List<FolderVo> getFolderChildren(String folderId) throws Exception;

    List<ReportItemVo> listDashboardsForFolderDashboardJobService(String toString);
}
