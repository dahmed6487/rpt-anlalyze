package com.mckesson.app.domain.customer;

public class CustomerAccount {
    private String customerAccountId;
    private String customerAccountName;
    private String address;
    private String city;
    private String state;
    private String zip;
    private String commonEntityId;
    private String commonEntityName;

    public CustomerAccount(String customerAccountId, String customerAccountName, String address, String city, String state, String zip, String commonEntityId, String commonEntityName) {
        this.customerAccountId = customerAccountId;
        this.customerAccountName = customerAccountName;
        this.address = address;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.commonEntityId = commonEntityId;
        this.commonEntityName = commonEntityName;
    }

    public String getCustomerAccountId() {
        return customerAccountId;
    }

    public void setCustomerAccountId(String newCustomerAccountId) {
        customerAccountId = newCustomerAccountId;
    }

    public String getCustomerAccountName() {
        return customerAccountName;
    }

    public void setCustomerAccountName(String newCustomerAccountname) {
        customerAccountName = newCustomerAccountname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String newAddress) {
        address = newAddress;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String newCity) {
        city = newCity;
    }

    public String getState() {
        return state;
    }

    public void setState(String newState) {
        state = newState;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String newZip) {
        zip = newZip;
    }

    public String getCommonEntityId() {
        return commonEntityId;
    }

    public void setCommonEntityId(String newCommonEntityId) {
        commonEntityId = newCommonEntityId;
    }

    public String getCommonEntityName() {
        return commonEntityName;
    }

    public void setCommonEntityName(String newCommonEntityName) {
        commonEntityName = newCommonEntityName;
    }
}
