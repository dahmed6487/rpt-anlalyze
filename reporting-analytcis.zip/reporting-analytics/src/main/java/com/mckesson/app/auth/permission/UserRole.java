package com.mckesson.app.auth.permission;

import java.util.List;

import com.google.common.collect.Lists;

public class UserRole {

    private final UserType type;

    private final boolean editContent;
    private final boolean localAdmin;
    private final boolean adminAccess;
    private final boolean userManagementAccess;
    private final boolean customerManagementAccess;
    private final boolean teamManagementAccess;
    private final boolean accountSegmentationAccess;
    private final boolean vendorPurchasesAccess;
    private final boolean sudoAccess;


    private List<Long> reportExclusions = Lists.newArrayList();

    public UserRole(UserType type) {
        this.type = type;
        this.editContent = type.isAdmin();
        this.localAdmin = type.isAdmin();
        this.adminAccess = type.isAdmin();
        this.userManagementAccess = type.hasUserManagementAccess();
        this.customerManagementAccess = type.hasCustomerManagementAccess();
        this.teamManagementAccess = type.hasTeamManagementAccess();
        this.accountSegmentationAccess = type.hasAccountSegmentationAccess();
        this.vendorPurchasesAccess = type.hasVendorPurchasesAccess();
        this.sudoAccess = type.canSudo();

    }

    public UserRole(UserType type, List<Long> reportExclusions) {
        this.type = type;
        this.reportExclusions.addAll(reportExclusions);
        this.editContent = type.isAdmin();
        this.localAdmin = type.isAdmin();
        this.adminAccess = type.isAdmin();
        this.userManagementAccess = type.hasUserManagementAccess();
        this.customerManagementAccess = type.hasCustomerManagementAccess();
        this.teamManagementAccess = type.hasTeamManagementAccess();
        this.accountSegmentationAccess = type.hasAccountSegmentationAccess();
        this.vendorPurchasesAccess = type.hasVendorPurchasesAccess();
        this.sudoAccess = type.canSudo();

    }

    public UserType getType() {
        return type;
    }

    public boolean getEditContent() { return editContent; }

    public boolean getLocalAdmin() { return localAdmin; }

    public boolean getAdminAccess() { return adminAccess; }

    public boolean getUserManagementAccess() { return userManagementAccess; }

    public boolean getCustomerManagementAccess() { return customerManagementAccess; }

    public boolean getAccountSegmentationAccess() { return accountSegmentationAccess; }

    public boolean getTeamManagementAccess() { return teamManagementAccess; }

    public boolean getVendorPurchasesAccess() { return vendorPurchasesAccess; }

    public  boolean getSudoAccess() { return sudoAccess; }

    public boolean isInternal() {
        return this.type.isInternal();
    }

    public boolean isCustomer() {
        return this.type.isCustomer();
    }

    public boolean isCustomerUser() {
        return this.type.isCustomerUser();
    }

    public boolean canAccessAllAccounts() { return this.type.canAccessAllAccounts(); }

    public boolean hasHealthSystem123Access() { return this.type.hasHealthSystem123Access(); }

    public boolean canCreateCustomGroups() { return this.type.canCreateCustomGroups(); }

    public boolean canShareToTeams() { return this.type.canShareToTeams(); }

    public boolean canManageRoles() { return this.type.canManageRoles(); }

    public List<Long> getReportExclusions() {
        return reportExclusions;
    }

    public void setReportExclusions(List<Long> reportExclusions) {
        this.reportExclusions = reportExclusions;
    }

    public void addReportExclusion(long reportId) {
        this.reportExclusions.add(reportId);
    }

    public static UserRole defaultRole() {
        return new UserRole(UserType.CustomerUser);
    }

    public boolean canSudo() { return this.type.canSudo(); }
}
