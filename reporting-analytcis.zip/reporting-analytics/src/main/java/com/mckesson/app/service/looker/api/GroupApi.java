package com.mckesson.app.service.looker.api;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.util.MappingUtils;
import main.java.com.mckesson.app.util.RestClient;
import main.java.com.mckesson.app.vo.looker.UserVo;

@Component
public class GroupApi extends ApiBase {

	private static final Logger LOG = LoggerFactory.getLogger(GroupApi.class);
	
	public List<GroupVo> listGroups(String authToken){
		try {
			String requestUrl = this.lookerApiHost +"/groups";
			String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, new HashMap<>());
			return MappingUtils.getCollectionFromJson(jsonResponse, GroupVo.class);
		} catch(Exception e) {
			throw new ApiException(e.getMessage());
		}
	}
	
	public GroupVo createGroup(GroupVo group, String authToken){
		try {
			String requestUrl = this.lookerApiHost + "/groups";
			String jsonBody = MappingUtils.serializeToJson(group);
			String jsonResponse = RestClient.performPOSTOperation(authToken, requestUrl, jsonBody, new HashMap<>());
			
			GroupVo newGroup = new GroupVo();
			MappingUtils.populateFromJson(jsonResponse, newGroup);
			if(newGroup.getId() == null || newGroup.getName() == null)
				newGroup = getGroupByName(group.getName(), authToken);
			return newGroup;
		} catch(Exception e) {
			LOG.error(" Error occured while createGroup"+group.getName() +" getMessage "+e.getMessage());
			return null;
		}
	}

	public GroupVo getGroupByName(String groupName, String authToken) {
		try {
			String requestUrl = this.lookerApiHost +"/groups/search?name="+ URLEncoder.encode(groupName, "UTF-8").replace("+", "%20");					;
			String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, new HashMap<>());
			List<GroupVo> groups = MappingUtils.getCollectionFromJson(jsonResponse, GroupVo.class);
			if (groups.size() > 0)
				return MappingUtils.getCollectionFromJson(jsonResponse, GroupVo.class).get(0);
		} catch(Exception e) {
			LOG.error(e.getMessage(), e);
		}
		return null;
	}
	
	
	public void deleteUserFromGroup(Long groupId, String userId, String authToken){
		String requestUrl = this.lookerApiHost + "/groups/users/"+ userId;
		try {
			RestClient.performDELETEOperation(authToken, requestUrl);
		} catch(Exception e) {
			throw new ApiException(e.getMessage());
		}
	}
	
	
	public GroupVo getGroup(Long groupId, String authToken) {
		try {
			String requestUrl = this.lookerApiHost +"/groups/"+ groupId;
			String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, new HashMap<>());
			GroupVo group = new GroupVo();
			MappingUtils.populateFromJson(jsonResponse, group);
			return group;
		} catch(Exception e) {
			throw new ApiException(e.getMessage());
		}
	}
	
	public GroupVo updateGroup(GroupVo group, String[] fields, String authToken) {
		try {
			HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
			String jsonBody = MappingUtils.serializeToJson(group);
			String requestUrl = this.lookerApiHost +"/groups/"+ group.getId();
			String jsonResponse = RestClient.performPUTOperation(authToken, requestUrl, jsonBody, params);
			MappingUtils.populateFromJson(jsonResponse, group);
			return group;
		} catch(Exception e) {
			throw new ApiException(e.getMessage());
		}
	}

	public GroupVo renameGroupName(String groupId, String groupName, String authToken) {
		try {
			GroupVo group = new GroupVo();
			String jsonBody = "{\n" +
					"  \"name\": \""+groupName+"\"\n" +
					"}";

			String requestUrl = this.lookerApiHost +"/groups/"+ groupId;
			String jsonResponse = RestClient.performPATCHOperation(authToken, requestUrl, jsonBody, null);
			MappingUtils.populateFromJson(jsonResponse, group);
			return group;
		} catch(Exception e) {
			return null;
		}
	}
	
	public void deleteGroup(Long groupId, String authToken) {
		try {
			String requestUrl = this.lookerApiHost + "/groups/"+ groupId;
			RestClient.performDELETEOperation(authToken, requestUrl);
		} catch(Exception e) {
			throw new ApiException(e.getMessage());
		}
	}
	
	public List<UserVo> getUsersByGroup(Long groupId, String authToken){
		String[] fields = {"id","first_name","last_name", "display_name", "external_user_id"};
		return getUsersByGroup(groupId, fields, authToken);
	}
	
	public List<UserVo> getUsersByGroup(Long groupId, String[] fields, String authToken){
		String requestUrl = this.lookerApiHost + "/groups/"+ groupId +"/users";
		try {
			HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
			String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, params);
			return MappingUtils.getCollectionFromJson(jsonResponse, UserVo.class);
		} catch(Exception e) {
			throw new ApiException(e.getMessage(), e);
		}
		
	}
	
	public void addUserToGroup(Long groupId, String userId, String[] fields, String authToken) {
		String requestUrl = this.lookerApiHost + "/groups/"+ groupId +"/users";
		try {
			HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
			String jsonBody = "{\"user_id\":\""+ userId +"\"}";
			RestClient.performPATCHOperation(authToken, requestUrl, jsonBody, params);
		} catch(Exception e) {
			throw new ApiException(e.getMessage());
		}
	}
	
}

