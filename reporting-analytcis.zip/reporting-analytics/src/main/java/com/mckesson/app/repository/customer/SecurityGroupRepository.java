package com.mckesson.app.repository.customer;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import main.java.com.mckesson.app.domain.customer.SecurityGroup;

public interface SecurityGroupRepository extends JpaRepository<SecurityGroup, Long>, JpaSpecificationExecutor<SecurityGroup> {
    // List<SecurityGroup> save(Iterable<? extends SecurityGroup> entities);

    @Transactional
    @Modifying
    @Query(value = "update #{#entityName} t set t.deletedDate= ?1 where t.securityGroupId in ?2 ")
    void inActive(Date deletedDate, List<Long> list);

    @Transactional
    @Modifying
    @Query(value = "update security_group t set  deleted_date=null where t.security_group_id in ?1 ", nativeQuery = true)
    void active(List<Long> list);

    @Transactional
    @Modifying
    @Query(value = "insert into security_group(platform, customer_id, name, external_id, created_by, created_date, deleted_date) values ('P',?1,?2,?3,'SYSTEM',?4,?5)", nativeQuery = true)
    void insertSecurityGroup(Long customerId, String groupName, Long groupId, Date createdDate, Date DeletedDate);

    @Query(value = "select distinct s.* from security_group s where s.customer_id in (select distinct customer_id from customer where common_entity_name= ?1)", nativeQuery = true)
    List<SecurityGroup> getSecurityGroup(String customerId);

    @Query(value = "select sg.* from user_map_security_group_relation r,security_group sg,user_mapping um where um.user_mapping_id=r.user_mapping_id and r.security_group_id=sg.security_group_id and um.deleted_date is null and sg.deleted_date is null and um.user_id=?1", nativeQuery = true)
    List<SecurityGroup> getUserGroupIds(String username);

    @Query(value = "select sg.*  from user_mapping um,security_group sg,user_map_security_group_relation r" +
            " where um.customer_id=sg.customer_id and r.security_group_id=sg.security_group_id and r.user_mapping_id=um.user_mapping_id and um.user_id=?1 and um.customer_id=?2", nativeQuery = true)
    List<SecurityGroup> getCustGroups(String user_id, long customer_id);

    @Query(value = "select distinct s.* from security_group s where s.name = ?1", nativeQuery = true)
    List<SecurityGroup> getSecurityGroupByName(String name);

    @Query(value = "select distinct s.* from security_group s where deleted_date is null and external_id is not null and created_by='SYSTEM' and created_date > DATE_SUB(NOW(), INTERVAL 8 HOUR)", nativeQuery = true)
    List<SecurityGroup> getNewSecurityGroups();

    @Query(value = "select distinct s.* from security_group s where s.created_by='SYSTEM' and s.customer_id in (select distinct customer_id from customer where amdm_era_ownr_party_id= ?1)", nativeQuery = true)
    List<SecurityGroup> getSecurityGroupByCustomerId(String commonEntityId);

    @Modifying
    @Query(value = "delete from user_map_security_group_relation where created_by='SYSTEM' and user_mapping_id in (select user_mapping_id from user_mapping where customer_id=?1)", nativeQuery = true)
    void deleteSecurityTeamMapping(long customerId);

    @Modifying
    @Query(value = "delete from user_map_module_relation where created_by='SYSTEM' and user_mapping_id in (select user_mapping_id from user_mapping where customer_id=?1)", nativeQuery = true)
    void deleteModuleMapping(long customerId);

    @Modifying
    @Query(value = "delete from security_group where created_by='SYSTEM' and customer_id=?1", nativeQuery = true)
    void deleteSecurity(long customerId);

    @Query(value = "select * from security_group where external_id is null", nativeQuery = true)
    List<SecurityGroup> getMissingGroupIdGroups();

    @Query(value = "select * from security_group where created_by='SYSTEM' and customer_id=?1", nativeQuery = true)
    SecurityGroup getSecurityGroupByNameByCustomerId(long customerId);
}
