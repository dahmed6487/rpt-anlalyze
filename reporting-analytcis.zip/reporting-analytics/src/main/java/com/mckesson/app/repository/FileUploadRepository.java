package com.mckesson.app.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import main.java.com.mckesson.app.domain.FileUpload;


public interface FileUploadRepository extends JpaRepository<FileUpload, Long>, JpaSpecificationExecutor<FileUpload> {

    @Query(value = "insert into file_upload (file_name, created_date_time, created_by, upload_status) VALUES (?1,?2,?3,?4)",nativeQuery = true)
    void uploadFile(String filename, Date date, String userId, String uploadStatus);

    @Query(value = "select max(load_file_id) from file_upload where file_name=?1 and created_by=?2 and upload_status='PENDING' and customer_id=?3",nativeQuery = true)
    Long getLoadFileId(String fileName,String createdBy, long customerId);

    @Query(value = "select excel_column_name,table_column_name,column_description,is_mandatory from non_mckesson_columns_mapping where is_active='Y' order by column_order",nativeQuery = true)
    List<Object[]> getUploadFileTemplate();

    @Query(value = "select count(*) from non_mckesson_purchases_staging_data where load_file_id=?1 and length(error_description)>0",nativeQuery = true)
    Long getErrorCount(Long loadFileId);

    @Query(value = "select f.*,t.amdm_era_ownr_name from file_upload f, customer t where upload_type='NON_MCKESSON_PURCHASES' and f.customer_id=t.customer_id and t.amdm_era_ownr_name=?1 and f.created_by=?2 order by uploaded_date_time desc",nativeQuery = true)
    List<Object[]> getUploadedFilesInfo(String customerName, String userId);

    @Modifying
    @Query(value = "delete from non_mckesson_purchases_data where load_file_id=?1",nativeQuery = true)
    void deleteFileData(Long loadFileId);

    @Modifying
    @Query(value = "delete from custom_account_fields where load_file_id=?1",nativeQuery = true)
    void deleteFileDataAccount(Long loadFileId);

    @Modifying
    @Query(value = "update file_upload set upload_status='Delete Requested' where upload_type='NON_MCKESSON_PURCHASES' and load_file_id=?1",nativeQuery = true)
    void deleteFileInfo(Long loadFileId);

    @Query(value = "select UPPER(excel_column_name) from non_mckesson_columns_mapping where is_active='Y' and is_mandatory='Y' order by column_order",nativeQuery = true)
    ArrayList<Object> getMandatoryColumns();

    @Query(value = "select count(*) from v_if_ra_dim_item_curr where EM_ITEM_NUM is not null and EM_ITEM_NUM=?1",nativeQuery = true)
    Long validateItemNumber(String columnValue);

    @Query(value = "select count(*) from non_mckesson_columns_mapping where is_active='Y' and excel_column_name=?1",nativeQuery = true)
    Long checkInvalidColumns(String columnName);

    @Query(value = "select count(*) from non_mckesson_columns_mapping where is_active='Y' and is_mandatory='Y'",nativeQuery = true)
    Long checkMandatoryColumnsCount();

    @Query(value = "select count(*) from non_mckesson_columns_mapping where is_active='Y' and is_mandatory='Y' and excel_column_name=?1",nativeQuery = true)
    Long isMandatoryColumn(String columnName);

    @Modifying
    @Query(value = "delete from file_upload where customer_id=?1",nativeQuery = true)
    void deleteFileByCustomer(long customerId);

    @Query(value = "select * from file_upload where customer_id=?1",nativeQuery = true)
    List<FileUpload> getLoadFileIdsByCustomer(long customerId);

    @Query(value = "select table_column_name, excel_column_name from non_mckesson_columns_mapping", nativeQuery = true)
    List<Object[]> getOtherVendorsMappingColumns();

    @Query(value = "select count(*) from era_user_permissions where account_id is not null and account_id*1=?1",nativeQuery = true)
    Long validateMcKessonAccount(String columnValue);

    @Query(value = "select count(*) from era_user_permissions where account_id*1=?1 and customer_id=?2", nativeQuery = true)
    Long validateMcKessonAccountByCustomer(String accountId, Long customerId);

    @Query(value = "select distinct account_id from era_user_permissions where account_id is not null and account_id*1 in ?1",nativeQuery = true)
    List<String> getValidAccounts(List<String> list);

    @Query(value = "select distinct account_id from era_user_permissions where account_id*1 in ?1 and customer_id=?2", nativeQuery = true)
    List<String> getValidAccountsForCustomer(List<String> list, Long customerId);

    @Query(value = "select distinct EM_ITEM_NUM from v_if_ra_dim_item_curr where EM_ITEM_NUM is not null and EM_ITEM_NUM in ?1",nativeQuery = true)
    List<String> getValidItemNumbers(List<String> list);
}