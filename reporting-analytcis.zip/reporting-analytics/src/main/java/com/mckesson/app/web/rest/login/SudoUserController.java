package com.mckesson.app.web.rest.login;

import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import main.java.com.mckesson.app.auth.permission.UserRole;
import main.java.com.mckesson.app.auth.permission.UserType;
import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.domain.user.UserProfile;
import main.java.com.mckesson.app.service.ApplicationLogService;
import main.java.com.mckesson.app.service.user.UserProfileService;
import main.java.com.mckesson.app.util.UserAuthentication;

/**
 * @author e4b71rl
 * Class used to drive Sudo user operations
 */

@RestController
@RequestMapping("/api/sudo")
public class SudoUserController {
    private static final Logger LOG = LoggerFactory.getLogger(SudoUserController.class);

    private final UserAuthentication userAuthentication;
    private final UserProfileService userProfileService;

    @Autowired
    public SudoUserController(UserAuthentication userAuthentication, UserProfileService userProfileService, ApplicationLogService applicationLogService) {
        this.userAuthentication = userAuthentication;
        this.userProfileService = userProfileService;
    }

    @GetMapping("/login-as/{username}")
    public String loginAs(@PathVariable("username") String username) {

        ReportUser loggedInUser = userAuthentication.getLoggedInUser();

        if(loggedInUser.getRole().getType().canSudo()) {
            UserProfile userProfile = userProfileService.getUserDetails(username);

            UserType userType = UserType.lookup(userProfile.getUserRole());
            loggedInUser.setSudoUser(true);
            loggedInUser.setSudoRole(new UserRole(userType));
            loggedInUser.setSudoUsername(userProfile.getUsername().trim().toLowerCase());
            loggedInUser.setSudoFirstName(userProfile.getFirstName() == null ? " " : userProfile.getFirstName().trim());
            loggedInUser.setSudoLastName(userProfile.getLastName() == null ? " " : userProfile.getLastName().trim());
            loggedInUser.setSudoEmailAddress(userProfile.getEmail() == null ? " " :userProfile.getEmail().trim());

            LOG.info("$$$$$$$$$$$$$$$$$$$$$$ Sudo user logging is started $$$$$$$$$$$$$$$$$$$$$$  ",userProfile.getUsername().trim().toLowerCase());
            return "success";
        } else {
            return "you are not authorized";
        }
    }

    @GetMapping("/logout")
    public String logout() {

        ReportUser loggedInUser = userAuthentication.getLoggedInUser();

            loggedInUser.setSudoUser(false);
            loggedInUser.setSudoRole(null);
            loggedInUser.setSudoUsername(null);
            loggedInUser.setSudoFirstName(null);
            loggedInUser.setSudoLastName(null);
            loggedInUser.setSudoEmailAddress(null);

            LOG.info("$$$$$$$$$$$$$$$$$$$$$$ Sudo user logging is ended $$$$$$$$$$$$$$$$$$$$$$  ",loggedInUser.getUsername().trim().toLowerCase());
            return "success";
    }

}
