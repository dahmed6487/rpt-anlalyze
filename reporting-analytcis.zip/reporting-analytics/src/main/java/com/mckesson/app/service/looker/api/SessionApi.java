package com.mckesson.app.service.looker.api;

import java.util.HashMap;

import org.springframework.stereotype.Component;

import com.mckesson.lib.rest.RestFactory;
import com.mckesson.lib.rest.engine.jaxrs.JAXRSRestFactory;

import main.java.com.mckesson.app.misc.ApiException;

@Component("SessionApi")
public class SessionApi extends ApiBase {

    private final RestFactory restFactory;

    public SessionApi() {
        this.restFactory = new JAXRSRestFactory();
    }

    /**
     * Changes the user active during a Looker API session.
     * Use this to run Looker API commands as a specific Looker user.
     *
     * @param userId the Looker user's <em>user id</em>
     * @return whether or not the Session change was successful
     */
    public String changeSessionUser(Integer userId, String auth) {
        String requestJson = "{" +
                "\"workspace_id\": \"production\"," +
                "\"sudo_user_id\": " + userId + "," +
                "\"can\": {}" +
                "}";
        try {
            // McKesson REST client does not support PATCH operations
            return com.mckesson.app.util.RestClient.performPATCHOperation(auth, lookerApiHost + "/session", requestJson, new HashMap<>());
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }
}
