package com.mckesson.app.vo.looker;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GroupVo {

    @JsonProperty("id")
    private Long id;
    @JsonProperty("name")
    private String name;
    @JsonProperty("user_count")
    private long userCount;

    public Long getId() {
        return id;
    }


    public void setId(Long id) {
        this.id = id;
    }


    public String getName() {
        return name;
    }


    public void setName(String name) {
        this.name = name;
    }


    public long getUserCount() {
        return userCount;
    }


    public void setUserCount(long userCount) {
        this.userCount = userCount;
    }


    public String toString() {
        return "id=>" + id + ", name=>" + name + ", userCount=>" + userCount;
    }
}
