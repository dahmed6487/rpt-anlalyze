package com.mckesson.app.auth.account;

import java.io.Serializable;
import java.util.Collection;

import com.mckesson.lib.model.customer.AccountId;
import com.mckesson.lib.model.platform.PlatformId;

import main.java.com.mckesson.app.domain.customer.Account;

public interface AccountAuthority extends Serializable {

    AccountAuthority NoAuthority = new StaticAccountAuthority();

    /**
     * Returns true if the user have access to this specific shipto.  If this method returns true, then isPartialAccess must return true for this sid.getAccount()
     *
     * @param sid
     * @return
     */
//    public boolean canAccessShipTo(ShipToId sid);

    /**
     * Returns true if the user can access every shipto under the account
     *
     * @param aid
     * @return
     */
    boolean isFullAccess(AccountId aid);

    /**
     * Returns true if the user can access at least one shipto under the account
     * <p>
     * This method returns true if isFullAccess is true.
     *
     * @param aid
     * @return
     */
    boolean isAnyAccess(AccountId aid);

    /**
     * returns an ordered collection of platforms that the user is allowed to access
     *
     * @return
     */
    Collection<PlatformId> getAccessiblePlatforms();

    boolean isFullAccessByAccount(Account account);
}
