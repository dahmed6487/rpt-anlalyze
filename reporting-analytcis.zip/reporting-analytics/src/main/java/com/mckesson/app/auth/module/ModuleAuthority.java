package com.mckesson.app.auth.module;

import java.io.Serializable;
import java.util.List;

import main.java.com.mckesson.app.domain.admin.Module;

public interface ModuleAuthority extends Serializable {

    ModuleAuthority NoAuthority = new StaticModuleAuthority();

    List<Module> getModules();

    boolean canAccessModule(Module module);

}
