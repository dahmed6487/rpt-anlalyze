package com.mckesson.app.repository.customer;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import main.java.com.mckesson.app.domain.customer.SecurityGroupAccounts;

public interface SecurityGroupAccountsRepository extends JpaRepository<SecurityGroupAccounts, Long>, JpaSpecificationExecutor<SecurityGroupAccounts> {

    @Transactional
    @Modifying
    @Query(value = "update #{#entityName} t set t.deletedDate= ?1 where t.securityGroupAccountId in ?2 ")
    void inActive(Date deletedDate, List<Long> list);

    @Transactional
    @Modifying
    @Query(value = "update security_group_accounts t set  deleted_date=null where t.security_account_id in ?1 ", nativeQuery = true)
    void active(List<Long> list);
}

