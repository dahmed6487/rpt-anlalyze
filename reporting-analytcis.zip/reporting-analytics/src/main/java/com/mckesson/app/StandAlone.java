package com.mckesson.app;

public class StandAlone {

    public static void main(String[] args) {

        try {
            System.out.println("Start");


            System.out.println("Fin.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
