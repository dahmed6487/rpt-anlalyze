package com.mckesson.app.repository.user;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import main.java.com.mckesson.app.auth.user.UserAuthorizationRule;

public interface UserAuthorizationRuleRepository extends JpaRepository<UserAuthorizationRule, Long>, JpaSpecificationExecutor<UserAuthorizationRule> {

    List<UserAuthorizationRule> findByUserId(String userId);

}
