package com.mckesson.app.util.crypto.legacy;

import java.io.Serializable;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import main.java.com.mckesson.app.util.Base64URL;

public class Crypto implements Serializable {

    // private final static Map<String, Crypto> cache = new LRUMap<String,
    // Crypto>(50);
    private final static LoadingCache<String, Crypto> cache = CacheBuilder.newBuilder().softValues()
            .build(new CacheLoader<String, Crypto>() {
                @Override
                public Crypto load(String key) throws Exception {
                    return new Crypto(key, default_algorithm, default_iterations);
                }
            });

    private final static int default_iterations = 100;
    private final static String default_algorithm = "PBEWithMD5AndDES";
    private final static String default_random = "SHA1PRNG";

    private final SecretKey secretKey;
    private final SecureRandom secureRandom;
    private final String algorithm;
    private final int iterations;

    public static Crypto create(String key) {
        return cache.getUnchecked(key);
    }

    // private static Crypto create(String key, String algorithm) {
    // String id = key + "," + algorithm;
    //
    // Crypto crypto = null;
    // synchronized (cache) {
    // crypto = cache.get(id);
    // if (crypto == null) {
    // crypto = new Crypto(key, algorithm);
    // cache.put(id, crypto);
    // }
    // }
    // return crypto;
    // }

    public Crypto(String key) {
        this(key, default_algorithm, default_iterations);
    }

    public Crypto(String key, String algorithm, int iterations) {
        this.algorithm = algorithm;
        this.iterations = iterations;
        try {
            PBEKeySpec keySpec = new PBEKeySpec(key.toCharArray());
            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(algorithm);
            this.secretKey = keyFactory.generateSecret(keySpec);
            this.secureRandom = SecureRandom.getInstance(default_random);
        } catch (Exception e) {
            throw new CryptoException(e);
        }
    }

    public String encrypt(String data) {
        String result = null;
        try {
            byte[] salt = this.secureRandom.generateSeed(8);

            PBEParameterSpec paramSpec = new PBEParameterSpec(salt, this.iterations);

            Cipher cipher = Cipher.getInstance(this.algorithm);
            cipher.init(Cipher.ENCRYPT_MODE, this.secretKey, paramSpec);

            byte[] cipherTxt = cipher.doFinal(data.getBytes());

            char[] saltString = Base64URL.encode(salt);
            char[] ciphertextString = Base64URL.encode(cipherTxt);

            result = new StringBuilder(saltString.length + ciphertextString.length).append(saltString)
                    .append(ciphertextString).toString();
        } catch (Exception e) {
            throw new CryptoException("Error encrypting", e);
        }

        return result;
    }

    public String decrypt(String data) {
        String result = null;

        try {
            String salt = data.substring(0, 12);
            String cipherText = data.substring(12);

            byte[] saltArray = Base64URL.decode(salt.toCharArray());
            byte[] ciphertextArray = Base64URL.decode(cipherText.toCharArray());

            PBEParameterSpec paramSpec = new PBEParameterSpec(saltArray, this.iterations);
            Cipher cipher = Cipher.getInstance(this.algorithm);
            cipher.init(Cipher.DECRYPT_MODE, this.secretKey, paramSpec);

            byte[] plainTextArray = cipher.doFinal(ciphertextArray);

            result = new String(plainTextArray);
        } catch (Exception e) {
            throw new CryptoException("Error decrypting", e);
        }

        return result;
    }

    // ITASCA-7450 (length = length in bits)
    public String getSecureToken(int length) {
        try {
            byte[] bytes = new byte[length];
            this.secureRandom.nextBytes(bytes);
            return this.encrypt(bytes.toString());
        } catch (Exception e) {
            throw new CryptoException(e);
        }
    }

    public static void main(String[] argv) throws Exception {
        String str1 = "Wound Closure Sutures Wound Closure Sutures Wound Closure Sutures Wound Closure Sutures with NeedlesBP";
        String str2 = "Wound Closure Sutures Wound Closure Sutures Wound Closure Sutures Wound Closure Sutures with NeedlesC1";
        String str3 = "Wound Closure Sutures with NeedlesC2";

        String[] foo = new String[]{str1, str2, str3, "456433", "456434"};
        for (String f : foo) {
            String code = Crypto.create("helloworld").encrypt(f);
            String out = Crypto.create("helloworld").decrypt(code);
            String enc = URLEncoder.encode(code, "UTF-8");
            String dec = URLDecoder.decode(enc, "UTF-8");
            System.out.println(code + "\t" + enc + "\t" + dec + "\t" + out);
        }

        Crypto crypto = Crypto.create("testpassword");
        String token = crypto.getSecureToken(16);
        System.out.println(token);
        token = crypto.getSecureToken(16);
        System.out.println(token);
        token = crypto.getSecureToken(16);
        System.out.println(token);
        System.out.println();
        System.out.println("**************************************");
        System.out.println(new Crypto("eDIwXV8vrRn5lQqO").decrypt("J38A9TFX1EZD50PKOI2C7ML4SYBNR6WGQVHU"));
//	System.out.println(
//		Jwts.parser().setSigningKey("eDIwXV8vrRn5lQqO").parseClaimsJws("J38A9TFX1EZD50PKOI2C7ML4SYBNR6WGQVHU"));

    }
}
