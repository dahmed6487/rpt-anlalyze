package com.mckesson.app.service.looker.api;

import java.io.IOException;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mckesson.lib.rest.RestFactory;
import com.mckesson.lib.rest.client.RestHeaders;
import com.mckesson.lib.rest.client.RestLocation;
import com.mckesson.lib.rest.client.RestResponse;
import com.mckesson.lib.rest.engine.jaxrs.JAXRSRestFactory;

import main.java.com.mckesson.app.util.RestClient;
import main.java.com.mckesson.app.vo.looker.ExploreDetailVo;
import main.java.com.mckesson.app.vo.looker.ExploresVo;

/**
 * Contains methods for interacting with the Looker API's <em>model</em> endpoints.
 */
@Component("ModelApi")
public class ModelApi extends ApiBase {

    private final RestFactory restFactory;

    public ModelApi() {
        this.restFactory = new JAXRSRestFactory();
    }

    /**
     * For a given model name, returns all explores within that model.
     *
     * @param model the name of a LookML model
     * @return a {@link ExploresVo} object containing all of the explores within the requested LookML model
     */
    public ExploresVo getExploresInModel(String model, String authToken) {
        RestClient client = restFactory.getRestClient(lookerApiHost);
        RestLocation restLocation = RestLocation.root()
                .path("lookml_models")
                .path(model)
                .queryParam("fields", "explores");
        RestHeaders headers = RestHeaders.withHeader("Authorization", "token " + authToken);
        try {
            RestResponse<String> response = client.get(restLocation, headers, String.class);
            String responseEntity = response.getEntity();
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(responseEntity, new TypeReference<ExploresVo>() {
            });
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * For a given model name and explore name, queries the Looker <em>model</em> API and returns a list of Dimensions
     * in the explore.
     *
     * @param model       the name of the LookML model that contains the {@param exploreName}
     * @param exploreName the name of the Looker explore
     * @return a {@link ExploreDetailVo} containing all <em>fields</em> in the requested LookML <em>model's</em>
     * <em>explore</em>
     */
    public ExploreDetailVo getDimensionsInExplore(String model, String exploreName, String authToken) {
        RestClient client = restFactory.getRestClient(lookerApiHost);
        RestLocation restLocation = RestLocation.root()
                .path("lookml_models")
                .path(model)
                .path("explores")
                .path(exploreName)
                .queryParam("fields", "fields");

        RestHeaders headers = RestHeaders.withHeader("Authorization", "token " + authToken);
        try {
            RestResponse<String> response = client.get(restLocation, headers, String.class);
            String responseEntity = response.getEntity();
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(responseEntity, new TypeReference<ExploreDetailVo>() {
            });
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;

    }
}
