package com.mckesson.app.domain.looker;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "looker_dyn_field_criteria")
public class FilterCriteria {

    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY,
            generator = "native"
    )
    @Column(name = "id")
    private Long id;

    private String name;

    @ManyToOne
    @JsonBackReference
    @JoinColumn(name = "criteria_group_id")
    private FilterCriteriaGroup group;

    @Column(name = "dimension")
    private String dimension;

    @Column(name = "relational_operator")
    private String relationalOperator;

    @Column(name = "value")
    private String value;

    @Column(name = "`default`")
    private Boolean defaultGrouping;

    @Column(name = "associated_dimension")
    private String associatedDimension;

    public FilterCriteria() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public FilterCriteriaGroup getGroup() {
        return group;
    }

    public void setGroup(FilterCriteriaGroup group) {
        this.group = group;
    }

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public String getRelationalOperator() {
        return relationalOperator;
    }

    public void setRelationalOperator(String relationalOperator) {
        this.relationalOperator = relationalOperator;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Boolean getDefaultGrouping() {
        return defaultGrouping;
    }

    public void setDefaultGrouping(Boolean defaultGrouping) {
        this.defaultGrouping = defaultGrouping;
    }

    public String getAssociatedDimension() {
        return associatedDimension;
    }

    public void setAssociatedDimension(String associatedDimension) {
        this.associatedDimension = associatedDimension;
    }
}
