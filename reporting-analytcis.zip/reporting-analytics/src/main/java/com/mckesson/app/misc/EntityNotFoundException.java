package com.mckesson.app.misc;

public class EntityNotFoundException extends RuntimeException {

    public EntityNotFoundException() {

    }

    public EntityNotFoundException(String msg) {
        super(msg);
    }

}
