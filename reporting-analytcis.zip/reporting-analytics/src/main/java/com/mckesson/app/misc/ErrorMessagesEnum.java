package com.mckesson.app.misc;

/**
 * Class to map error or exception messages
 */
public enum ErrorMessagesEnum {

    ALREADY_EXISTS("A report by this name already exist in these folders, do you want to overwrite all?"),
    ALREADY_EXISTS_SINGLE("A report by this name already exists in this folder. Do you want to overwrite?"),
    NOT_FOUND("You do not have rights to save to this folder. Please choose another destination."),
    UNKNOWN("Unknown error"),
    NO_ERA_ACCESS("You do not have access to Mckesson ERA. Please contact the McKesson ERA Support Line at 800-829-3444, between 8am-5pm M-F(CST). Error code:0003"),
    TEAMS_NOT_FOUND("You are not assigned to any Teams."),
    CUST_TEAMS_NOT_FOUND("You are not assigned to any Teams for this Customer."),
    SECURITY_GROUP_NOT_FOUND("You are not assigned to any SecurityGroup for this Customer."),
    FILE_UPLOAD_NO_COLUMNS("Uploaded file is empty or does not have mandatory columns."),
    FILE_UPLOAD_MISSING("Mandatory columns are missed in the uploaded file."),
    FILE_UPLOAD_DUPLICATE("Duplicate columns are contain in the uploaded file."),
    FILE_UPLOAD_INVALID_COLUMN_MISSING("Uploaded file contains following invalid columns."),
    FILE_UPLOAD_MANDATORY_COLUMN_MISSING("Following Mandatory columns are missing in the uploaded file.Please check "),
    FILE_UPLOAD_MANDATORY_DATA_MISSING("Mandatory columns data missed in the uploaded file."),
    DEFINE_CUSTOMER_ALREADY_EXISTS("A customer with same name present in ERA.Please create with a different name"),;


    private final String errorMsg;

    ErrorMessagesEnum(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getErrorMsg() {
        return errorMsg;
    }
}
