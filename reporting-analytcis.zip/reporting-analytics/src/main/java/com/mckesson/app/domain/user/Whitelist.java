package com.mckesson.app.domain.user;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_whitelist")
public class Whitelist {

    @Id
    @Column(name = "user_id")
    private String userId;

    @Column(name = "common_entity_name")
    private String commonEntityName;

    public Whitelist() {
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String username) {
        this.userId = userId;
    }

    public String getCommonEntityName() {
        return commonEntityName;
    }

    public void setCommonEntityName(String commonEntityName) {
        this.commonEntityName = commonEntityName;
    }
}
