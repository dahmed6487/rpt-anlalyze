package com.mckesson.app.service.looker.api;

import java.util.HashMap;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.util.MappingUtils;
import main.java.com.mckesson.app.util.RestClient;
import main.java.com.mckesson.app.vo.looker.UserVo;

@Component
public class UserApi extends ApiBase {

    public UserVo getUserByEmbed(String embedId, String authToken) {
        try {
            RestTemplate restTemplate = new RestTemplate();

            String requestUrl = this.lookerApiHost + "/users/credential/embed/" + embedId;
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(requestUrl).queryParam("fields", "id,first_name,last_name,personal_space_id,role_ids,group_ids");

            HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization", "Bearer " + authToken);
            HttpEntity<String> request = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate.exchange(builder.toUriString(), HttpMethod.GET, request, String.class);
            UserVo user = new UserVo();
            MappingUtils.populateFromJson(response.getBody(), user);
            return user;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public UserVo updateUser(UserVo user, String authToken) {
        String requestUrl = this.lookerApiHost + "/users/" + user.getId();

        String[] fields = {"id", "first_name", "last_name", "display_name"};

        try {
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String jsonBody = MappingUtils.serializeToJson(user);
            String jsonResponse = RestClient.performPUTOperation(authToken, requestUrl, jsonBody, params);
            MappingUtils.populateFromJson(jsonResponse, user);
            return user;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public void deleteEmbedUser(String embedUserId, String authToken) {

        String requestUrl = this.lookerApiHost + "/users/" + embedUserId;

        try {
            RestClient.performDELETEOperation(authToken, requestUrl);
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }
}
