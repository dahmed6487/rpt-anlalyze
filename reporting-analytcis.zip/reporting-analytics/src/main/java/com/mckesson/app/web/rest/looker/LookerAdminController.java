package com.mckesson.app.web.rest.looker;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.service.looker.LookerAdminService;
import main.java.com.mckesson.app.util.UserAuthentication;
import main.java.com.mckesson.app.vo.looker.UserVo;

@RestController
@RequestMapping("/looker/admin")
public class LookerAdminController {

    private final UserAuthentication userAuthentication;
    private final LookerAdminService lookerAdminService;
    private final HttpServletRequest request;

    @Autowired
    public LookerAdminController(UserAuthentication userAuthentication, LookerAdminService lookerAdminService, HttpServletRequest request) {
        this.userAuthentication = userAuthentication;
        this.lookerAdminService = lookerAdminService;
        this.request = request;
    }

    @PostMapping(value = "/users")
    public ResponseEntity createEmbedUser(@RequestBody UserVo user) {
        String embedDomain = request.getHeader("Referer");
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        UserVo newUser = lookerAdminService.createEmbedUser(reportUser, user, embedDomain);
        return new ResponseEntity(newUser, HttpStatus.CREATED);
    }

    @DeleteMapping(value = "/users/{id}")
    public ResponseEntity deleteEmbedUser(@PathVariable("id") String externaUserId) {
        lookerAdminService.deleteEmbedUser(externaUserId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @PutMapping(value = "/users")
    public ResponseEntity updateEmbedUser(UserVo user) {
        lookerAdminService.updateEmbedUser(user);
        return new ResponseEntity(HttpStatus.OK);
    }


    @GetMapping(value = "/users")
    public ResponseEntity getUsers() {
        return new ResponseEntity(lookerAdminService.getUsersByGroup(5L), HttpStatus.OK);
    }

    @GetMapping(value = "/roles")
    public ResponseEntity listRoles() {
        return new ResponseEntity(lookerAdminService.listRoles(), HttpStatus.OK);
    }

    @PostMapping(value = "/groups")
    public ResponseEntity createGroup(GroupVo group) {
        group = lookerAdminService.createGroup(group);
        return new ResponseEntity(group, HttpStatus.OK);
    }

    @GetMapping(value = "/groups")
    public ResponseEntity listGroups() {
        return new ResponseEntity(lookerAdminService.listGroups(), HttpStatus.OK);
    }

    @GetMapping(value = "/groups/{groupId}/users")
    public ResponseEntity getUsersByGroup(@PathVariable("groupId") Long groupId) {
        return new ResponseEntity(lookerAdminService.getUsersByGroup(groupId), HttpStatus.OK);
    }

    @PutMapping(value = "/groups")
    public ResponseEntity updateGroup(GroupVo group) {
        lookerAdminService.updateGroup(group);
        return new ResponseEntity(HttpStatus.OK);
    }

    @DeleteMapping(value = "/groups/{id}")
    public ResponseEntity deleteGroup(@PathVariable("id") Long groupId) {
        lookerAdminService.deleteGroup(groupId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @PutMapping(value = "/groups/{groupId}/users")
    public ResponseEntity addUserToGroup(@PathVariable("groupId") Long groupId, String externalUserId) {
        lookerAdminService.addUserToGroup(groupId, externalUserId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @DeleteMapping(value = "/groups/{groupId}/users")
    public ResponseEntity removeUserFromGroup(Long groupId, String externalUserId) {
        lookerAdminService.removeUserFromGroup(groupId, externalUserId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @GetMapping(value = "/users/{externalUserId}")
    public ResponseEntity getUserByExternalId(@PathVariable("externalUserId") String externalUserId) {
        UserVo user = lookerAdminService.getUserByExternalId(externalUserId);
        return new ResponseEntity(user, HttpStatus.OK);
    }

}

