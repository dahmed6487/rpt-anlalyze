package com.mckesson.app.domain.looker;

import java.util.List;

public class WhiteList {
    public List<String> data;

    public List<String> getData() {
        return data;
    }

    public void setData(List<String> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "WhiteList{" +
                "data=" + data +
                '}';
    }
}
