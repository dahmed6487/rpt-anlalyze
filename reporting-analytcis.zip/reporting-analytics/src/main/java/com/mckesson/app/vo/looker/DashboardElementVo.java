package com.mckesson.app.vo.looker;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DashboardElementVo {

    @JsonProperty("id")
    public String id;

    @JsonProperty("look")
    private LookVo look;

    @JsonProperty("query")
    public Query query;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public LookVo getLook() {
        return look;
    }

    public void setLook(LookVo look) {
        this.look = look;
    }

    public Query getQuery() {
        return query;
    }

    public void setQuery(Query query) {
        this.query = query;
    }
}
