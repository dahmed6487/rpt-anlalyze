package com.mckesson.app.service.admin;

import java.util.List;

import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.domain.admin.CommonEntity;
import main.java.com.mckesson.app.repository.customer.CommonEntityRepository;

@Service
public class CommonEntityService {
    private final CommonEntityRepository commonEntityRepo;

    public CommonEntityService(CommonEntityRepository commonEntityRepo) {
        this.commonEntityRepo = commonEntityRepo;
    }

    public List<CommonEntity> getById(String id) {
        return commonEntityRepo.getCommonEntityById(id);
    }

    public List<CommonEntity> getAllCommonEntities() {
        return commonEntityRepo.getAll();
    }
}
