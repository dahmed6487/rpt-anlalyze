package com.mckesson.app.service.looker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.vo.looker.UserVo;

@Service("UserAdminService")
public class UserAdminServiceImpl implements UserAdminService {

    private final LookerAdminService lookerAdminService;

    @Autowired
    public UserAdminServiceImpl(LookerAdminService lookerAdminService) {
        this.lookerAdminService = lookerAdminService;
    }

    public void createUser(ReportUser reportUser, UserVo user, String embedDomain) {

        //Perform operations to persist new user data in relational DB instance
        //TODO: Implement calls.

        //Perform operations to additionally persist new user data in Looker instance.
        lookerAdminService.createEmbedUser(reportUser, user, embedDomain); //User is created.

        Long[] groupIds = user.getGroupIds(); //User is updated.
        for (Long groupId : groupIds) {
            lookerAdminService.addUserToGroup(groupId, user.getId());
        }
    }


}