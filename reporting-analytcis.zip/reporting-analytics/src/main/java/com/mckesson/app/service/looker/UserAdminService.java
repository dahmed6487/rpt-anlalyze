package com.mckesson.app.service.looker;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.vo.looker.UserVo;

public interface UserAdminService {
    void createUser(ReportUser reportUser, UserVo user, String embedDomain);
}
