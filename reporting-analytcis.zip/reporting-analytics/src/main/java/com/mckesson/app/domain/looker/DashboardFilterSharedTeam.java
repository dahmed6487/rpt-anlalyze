package com.mckesson.app.domain.looker;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "looker_filter_team")
public class DashboardFilterSharedTeam {

    public DashboardFilterSharedTeam() {

    }

    public DashboardFilterSharedTeam(Integer teamId) {
        this.teamId = teamId;
    }

    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY,
            generator = "native"
    )
    @Column(name = "id")
    private Integer id;

    @Column(name = "team_id")
    private Integer teamId;

    @ManyToOne
    @JoinColumn(name = "looker_filter_id", nullable = false)
    private DashboardFilter filter;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTeamId() {
        return teamId;
    }

    public void setTeamId(Integer teamId) {
        this.teamId = teamId;
    }

    public DashboardFilter getFilter() {
        return filter;
    }

    public void setFilter(DashboardFilter filter) {
        this.filter = filter;
    }

    public String toString() {
        return "id=>" + this.id;
    }

}
