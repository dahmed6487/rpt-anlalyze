package com.mckesson.app.web.rest.looker;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import main.java.com.mckesson.app.repository.looker.CustomFilterProjection;
import main.java.com.mckesson.app.service.looker.CustomFilterService;

/**
 * Responsible for managing explore meta data
 * <p>
 * Note: Initial placeholder for functionality. Subject to future renamining, repurposing, or deletion...
 */
@RestController
@RequestMapping("/explores")
public class ExploreController {

    private final CustomFilterService customFilterService;

    @Autowired
    public ExploreController(CustomFilterService customFilterService) {
        this.customFilterService = customFilterService;
    }

    /**
     * Retrieve listing of explores.
     *
     * @return
     */
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity list() {
        return null;
    }

    /**
     * Retrieve listing of associated filters by
     *
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, value = "/{exploreId}/filters")
    public ResponseEntity listFiltersByExplore(@PathVariable("exploreId") Long exploreId) {
        List<CustomFilterProjection> filterRefs = customFilterService.getCustomListForUserAndExplore(exploreId);
        return new ResponseEntity(filterRefs, HttpStatus.OK);
    }

}
