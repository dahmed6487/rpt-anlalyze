package com.mckesson.app.domain.admin;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Where;

@Entity
@Table(name = "collaboration_team")
@Where(clause = "deleted_date is null")
public class CollaborationTeam implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "native")
    @Column(name = "collaboration_team_id")
    private Long collaborationTeamId;
    @Column(name = "platform")
    private String platformId;
    @Column(name = "customer_id")
    private Long customerId;
    private String name;
    @Column(name = "external_id")
    private Long externalId;
    @Column(name = "created_by")
    private String createdBy;
    @Column(name = "created_date")
    private Date createdDate;
    @Column(name = "updated_by")
    private String updatedBy;
    @Column(name = "updated_date")
    private Date updatedDate;
    @Column(name = "deleted_by")
    private String deletedBy;
    @Column(name = "deleted_date")
    private Date deletedDate;

    /*@ManyToMany(mappedBy = "collaborationTeam")
    @JsonIgnore
    private Collection<UserMapping> userMappingCollab;

    @ManyToMany
    @JoinTable(
            name = "collab_team_module_relation",
            joinColumns = @JoinColumn(name = "collaboration_team_id"),
            inverseJoinColumns = @JoinColumn(name = "module_id"))
    private Collection<Module> collaborationTeamModule;*/

    public CollaborationTeam() {
    }

    public String getPlatformId() {
        return platformId;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public Long getCollaborationTeamId() {
        return collaborationTeamId;
    }

    public void setCollaborationTeamId(Long collaborationTeamId) {
        this.collaborationTeamId = collaborationTeamId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

   /* public Collection<UserMapping> getUserMappingCollab() {
        return userMappingCollab;
    }

    public void setUserMappingCollab(Collection<UserMapping> userMappingCollab) {
        this.userMappingCollab = userMappingCollab;
    }

    public Collection<Module> getCollaborationTeamModule() {
        return collaborationTeamModule;
    }

    public void setCollaborationTeamModule(Collection<Module> collaborationTeamModule) {
        this.collaborationTeamModule = collaborationTeamModule;
    }*/

    public Long getExternalId() {
        return externalId;
    }

    public void setExternalId(Long externalId) {
        this.externalId = externalId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

}
