package com.mckesson.app.vo.auth;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mckesson.lib.model.customer.AccountId;
import com.mckesson.lib.model.platform.PlatformId;

public class AccountVo {

    @JsonProperty("platformId")
    private String platformId;
    @JsonProperty("accountId")
    private String accountId;

    public String getPlatformId() {
        return platformId;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public AccountId toAccountId() {
        return new AccountId(PlatformId.lookup(this.platformId), this.accountId);
    }
}
