package com.mckesson.app.service.looker;

import java.awt.PageAttributes.MediaType;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.mckesson.app.service.looker.api.*;
import com.mckesson.lib.rest.client.RestResponse;

import main.java.com.mckesson.app.auth.permission.UserType;
import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.domain.admin.Module;
import main.java.com.mckesson.app.domain.customer.Customer;
import main.java.com.mckesson.app.domain.looker.Dashboard;
import main.java.com.mckesson.app.domain.looker.DashboardDto;
import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.repository.admin.ModuleRepository;
import main.java.com.mckesson.app.repository.customer.CustomerRepository;
import main.java.com.mckesson.app.repository.looker.DashboardRepository;
import main.java.com.mckesson.app.service.admin.ModuleService;
import main.java.com.mckesson.app.service.customer.CustomerService;
import main.java.com.mckesson.app.service.customer.SecurityGroupService;
import main.java.com.mckesson.app.service.looker.api.DashboardApi;
import main.java.com.mckesson.app.service.looker.api.ModelApi;
import main.java.com.mckesson.app.service.looker.api.QueryApi;
import main.java.com.mckesson.app.service.looker.api.ScheduleApi;
import main.java.com.mckesson.app.service.looker.api.SpaceApi;
import main.java.com.mckesson.app.service.looker.api.UserApi;
import main.java.com.mckesson.app.service.user.UserProfileService;
import main.java.com.mckesson.app.util.MappingUtils;
import main.java.com.mckesson.app.util.RestClient;
import main.java.com.mckesson.app.util.StringUtils;
import main.java.com.mckesson.app.util.UserAuthentication;
import main.java.com.mckesson.app.vo.looker.DashboardVo;
import main.java.com.mckesson.app.vo.looker.UserVo;

@Service("LookerService")
public class LookerServiceImpl implements LookerService {
    @Value("${looker.apiHost}")
    String lookerApiHost;
    @Value("${dashboardids.accountConfigurationReport}")
    String accountConfigurationReport;
    @Value("${dashboardids.userAccountMappingReport}")
    String userAccountMappingReport;

    private static final Logger LOGGER = LoggerFactory.getLogger(LookerServiceImpl.class);

    private static final Joiner COMMA_JOINER = Joiner.on(",");

    private final LookerExploreService lookerExploreService;
    private final QueryApi queryApi;
    private final UserApi userApi;
    private final CustomerService customerService;
    private final UserProfileService userProfileService;
    private final DashboardApi dashboardApi;
    private final SpaceApi spaceApi;
    private final SecurityGroupService securityGroupService;
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;
    private final UserAuthentication userAuthentication;
    private final DashboardRepository dashboardRepository;
    private final ModuleRepository moduleRepository;
    private final ModuleService moduleService;
    private final ModelApi modelApi;
    private final SpaceManagementService spaceManagementService;
    private final CustomerRepository customerRepository;
    private final ScheduleApi scheduleApi;


    @Autowired
    public LookerServiceImpl(LookerExploreService lookerExploreService, QueryApi queryApi, UserApi userApi, CustomerService customerService, UserProfileService userProfileService, DashboardApi dashboardApi, SpaceApi spaceApi, SecurityGroupService securityGroupService, UserAuthentication userAuthentication, DashboardRepository dashboardRepository, ModuleRepository moduleRepository, ModuleService moduleService, ModelApi modelApi, SpaceManagementService spaceManagementService, CustomerRepository customerRepository, ScheduleApi scheduleApi) {
        this.lookerExploreService = lookerExploreService;
        this.queryApi = queryApi;
        this.userApi = userApi;
        this.customerService = customerService;
        this.userProfileService = userProfileService;
        this.dashboardApi = dashboardApi;
        this.spaceApi = spaceApi;
        this.securityGroupService = securityGroupService;
        this.userAuthentication = userAuthentication;
        this.dashboardRepository = dashboardRepository;
        this.moduleRepository = moduleRepository;
        this.moduleService = moduleService;
        this.modelApi = modelApi;
        this.spaceManagementService = spaceManagementService;
        this.customerRepository = customerRepository;
        this.scheduleApi = scheduleApi;
        this.restTemplate = new RestTemplate();
        this.objectMapper = new ObjectMapper();
    }

    @Override
    public String getDashboardEmbedUrlForCurrentUser(ReportUser reportUser, String dashboardId, String filters, String embedDomain, String customerId, String finalUserAttribute) throws Exception {

        if (checkCustomerAccess(reportUser.getUsername(), customerId)) {
            Integer dataHistoryMonths = null;
            String userType = null; //TODO: get from user when available
            //for testing demo we are sending customer name but we will send customerId
            String groupIdList = securityGroupService.getUserGroupIds(reportUser);
            String userAttributes = getUserAttributes(reportUser, customerId, dataHistoryMonths, userType, dashboardId,finalUserAttribute);
            return LookerEmbedUrlGenerator.getInstance().getDashboardEmbedUrl(reportUser.getFirstName(), reportUser.getLastName(), reportUser.getUsername(), dashboardId, filters, embedDomain, userAttributes, groupIdList);
        } else {
            return "Customer access denied.....";
        }
    }

    public String getLookEmbedUrlForCurrentUser(ReportUser reportUser, String lookId, String embedDomain, String customerId, String finalUserAttribute) throws Exception {
        Integer dataHistoryMonths = null;
        String userType = null; //TODO: get from user when available

        if (checkCustomerAccess(reportUser.getUsername(), customerId)) {
            String userAttributes = getUserAttributes(reportUser, customerId, dataHistoryMonths, userType,"0", finalUserAttribute);
            String groupIdList = securityGroupService.getUserGroupIds(reportUser);
            return LookerEmbedUrlGenerator.getInstance().getLookEmbedUrl(reportUser.getFirstName(), reportUser.getLastName(), reportUser.getUsername(), lookId, embedDomain, userAttributes, groupIdList);
        } else {
            return "Customer access denied.....";
        }
    }

    @Override
    public String getExploreEmbedUrlForCurrentUser(ReportUser reportUser, String modelName, String explore, String qid, String exploreType, String embedDomain, String customerId,String finalUserAttribute) throws Exception {
        Integer dataHistoryMonths = null;
        String userType = null; //TODO: get from user when available

        if (checkCustomerAccess(reportUser.getUsername(), customerId)) {
            String groupIdList = securityGroupService.getUserGroupIds(reportUser);
            String userAttributes = getUserAttributes(reportUser, customerId, dataHistoryMonths, userType, "0", finalUserAttribute);
            // If the qid wasn't explicitly passed in we need to construct one from the custom groupings stored in the
            // database
            if (qid == null) {
                try {
                    String shareUrl = lookerExploreService.getEmbedUrlWithCustomGroupsShortTerm(modelName, explore);
                    // The "share url" will be in a format similar to: https://looker.instance.com/explore/x/qid, and we only
                    // want the qid to embed
                    if (shareUrl != null) {
                        String[] urlComponents = shareUrl.split("/");
                        qid = urlComponents[urlComponents.length - 1];
                    } else
                        qid = null;
                } catch (ApiException e) {
                    // Just load the explore without any custom groups rather than failing completely.
                    qid = null;
                    LOGGER.warn("Error retrieving qid for custom groups for Explore embed!", e);
                }
            }
            return LookerEmbedUrlGenerator.getInstance().getExploreEmbedUrl(reportUser.getFirstName(), reportUser.getLastName(), reportUser.getUsername(), modelName, explore, qid, exploreType, embedDomain, userAttributes, groupIdList);
        } else {
            return "Customer access denied.....";
        }
    }

    @Override
    public String getDashboardExploreEmbedUrlForCurrentUser(ReportUser reportUser, String modelName, String explore, String qid, String exploreType, String embedDomain, String customerId, String finalUserAttribute) throws Exception {
        Integer dataHistoryMonths = null;
        String userType = null;

        if (checkCustomerAccess(reportUser.getUsername(), customerId)) {
            String groupIdList = securityGroupService.getUserGroupIds(reportUser);
            String userAttributes = getUserAttributes(reportUser, customerId, dataHistoryMonths, userType, "0",finalUserAttribute);
            try {
                String shareUrl = lookerExploreService.getUpdatedQidForDashboardExplore(reportUser.getUsername(), modelName, explore, qid);
                if (shareUrl != null) {
                    String[] urlComponents = shareUrl.split("/");
                    qid = urlComponents[urlComponents.length - 1];
                }
            } catch (ApiException e) {
                LOGGER.warn("Error occurred while getting qid for Drill into Dashboard Explore!", e);
            }
            return LookerEmbedUrlGenerator.getInstance().getExploreEmbedUrl(reportUser.getFirstName(), reportUser.getLastName(), reportUser.getUsername(), modelName, explore, qid, exploreType, embedDomain, userAttributes, groupIdList);
        } else {
            return "Customer access denied.....";
        }
    }

    @Override
    public String getDashboardEmbedUrlForEmbedUser(ReportUser reportUser, String dashboardId, String filters, String embedDomain) {
        Integer dataHistoryMonths = null;
        String userType = null; //TODO: get from user when available

        String userAttributes = getUserAttributesForEmbedUser(reportUser.getUsername(), reportUser.getMarketPartition(), reportUser.getBlaEligible());
        String groupIdList = securityGroupService.getUserGroupIds(reportUser);

        try {
            return LookerEmbedUrlGenerator.getInstance().getDashboardEmbedUrl(reportUser.getFirstName(), reportUser.getLastName(), reportUser.getUsername(), dashboardId, filters, embedDomain, userAttributes, groupIdList);
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    @Override
    public Optional<List<String>> getValuesForDimension(String view, String field, String userInput) {
        String url = this.lookerApiHost + "/queries/run/json";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        ReportUser loggedInUser = userAuthentication.getLoggedInUser();
        String authToken = spaceApi.getAuthToken();
        UserVo user = userApi.getUserByEmbed(loggedInUser.getUsername(), authToken);
        String userAuthToken = queryApi.getAuthTokenForUserId(authToken, user.getId());
        headers.add("Authorization", "Bearer " + userAuthToken);

        String body = "{" +
                "\"model\":\"r_a_connect\"," +
                "\"view\":\"" + view + "\"," +
                "\"fields\":[\"" + field + "\"]," +
                "\"filters\":{\"" + field + "\":\"" + userInput + "%\"}" +
                "}";

        HttpEntity<String> entity = new HttpEntity<>(body, headers);

        try {
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
            JsonNode jsonResponse = objectMapper.readTree(response.getBody());
            if (jsonResponse.isArray()) {
                List<String> values = new ArrayList<>();
                for (JsonNode node : jsonResponse) {
                    if (node.get(field) != null) {
                        values.add(node.get(field).textValue());
                    }
                }
                return Optional.of(values);
            } else {
                return Optional.empty();
            }
        } catch (RestClientException | IOException e) {
            LOGGER.error("Failed to execute inline query: " + e.getMessage());
            throw new ApiException("Failed to execute inline query: " + e.getMessage());
        }
    }

    public String getEmbedUrlForFullConfig(ReportUser reportUser, String embedUrl) throws Exception {
        UserVo embedUser = userApi.getUserByEmbed(reportUser.getUsername(), queryApi.getAuthToken());

        return LookerEmbedUrlGenerator.getInstance().getEmbedUrl(reportUser.getUsername(), embedUrl, embedUser.getFirstName(), embedUser.getLastName(), reportUser.getMarketPartition(), reportUser.getBlaEligible());
    }

    @Override
    public Optional<List<DashboardVo>> getDashboardDescriptions(String folderId) {
        String authToken = dashboardApi.getAuthToken();
        String[] dbFields = {"id", "title", "description"};

        List<DashboardVo> dashboards;
        try {
            dashboards = spaceApi.getDashboardsForFolder(folderId, dbFields, authToken);
        } catch (AccessDeniedException | ApiException e) {
            return Optional.empty();
        }
        return Optional.of(dashboards);
    }

    /**
     * SA and internal user always has access to all reports // Todo internal users access
     * CA has access only the customer they have assigned to
     * Normal users,
     * First check the access at the team level
     * if no team level access granted then customer level access granted automatically
     * If no access then will show all report (default access)
     *
     * @param customerName
     * @param reportUser
     * @return
     */
    @Override
    public Optional<List<DashboardDto>> getSolutions(String customerName, ReportUser reportUser) {
        List<Dashboard> dashboards;
        if (reportUser.isInternal())
            dashboards = dashboardRepository.getSolutions();
        else {
            List<Dashboard> dashboardsCustomer;
            List<Dashboard> dashboardsTeam;
            if (reportUser.getRole().isCustomerUser()){
                dashboardsCustomer = dashboardRepository.getSolutionForCustomerUser(customerName); // category='N' means reports not visible to CU
                dashboardsTeam = dashboardRepository.getSolutionsForCustomerUserTeam(reportUser.getUsername(), customerName);
            } else {
                dashboardsCustomer = dashboardRepository.getSolutionForCustomer(customerName);
                dashboardsTeam = dashboardRepository.getSolutionsForUser(reportUser.getUsername(), customerName);
            }
            if (dashboardsTeam.size() == 0 && dashboardsCustomer.size() == 0) {
                if (reportUser.getRole().isCustomerUser())
                    dashboards = dashboardRepository.getSolutionsForCustomerUser();
                    else
                    dashboards = dashboardRepository.getSolutionsForExternalUser();
            } else if(dashboardsTeam.size() == 0) {
                dashboards = dashboardsCustomer;
            } else{
                dashboards = dashboardsTeam;
            }
        }
        List<DashboardDto> dashboardDtoList = new ArrayList<>();
        if (dashboards.size() == 0) {
            return Optional.of(dashboardDtoList);
        } else {
            for (Dashboard dashboard : dashboards) {
                Optional<Module> moduleOptional = moduleRepository.findByModuleId(dashboard.getModuleId());

                if (moduleOptional.isPresent()) {
                    DashboardDto dashboardDto = new DashboardDto();
                    dashboardDto.setId(dashboard.getId());
                    dashboardDto.setModule(moduleOptional.get().getTitle());
                    dashboardDto.setName(dashboard.getName());
                    dashboardDto.setDescription(dashboard.getDescription());
                    dashboardDto.setColor(moduleOptional.get().getColor());

                    dashboardDtoList.add(dashboardDto);
                }
            }

            // List<DashboardDto> filteredDashboards = filterByUserAccess(dashboardDtoList, customerName);
            return Optional.of(dashboardDtoList);
        }
    }

    private List<DashboardDto> filterByUserAccess(List<DashboardDto> dashboardDtoList, String customerName) {
        Set<Module> userModules = moduleService.getModulesByUserAccess(customerName);

        List<DashboardDto> dashboards = new ArrayList<>();

        if (!userModules.isEmpty()) {
            for (DashboardDto dashboardDto : dashboardDtoList) {
                boolean userHasAccess = dashboardIsInList(dashboardDto, userModules);
                if (userHasAccess) {
                    dashboards.add(dashboardDto);
                }
            }
            return dashboards;
        } else {
            return Collections.emptyList();
        }
    }

    private boolean dashboardIsInList(DashboardDto dashboardDto, Set<Module> modulesUserHasAccessTo) {
        for (Module module : modulesUserHasAccessTo) {
            if (module.getTitle().equals(dashboardDto.getModule())) {
                return true;
            }
        }
        return false;
    }

    /**
     * build user attributes based on criteria
     * A value must be passed for both user attributes for all users.
     * A blank for either causes all queries to fail for that user.
     * If only passing user_id, then customer_id=%, NULL
     * If only passing customer_id, then user_id=%,NULL
     * If passing multiple values to either, pass strings in comma separated list. ie customer_id= '123','345','456'
     * For access to all accounts, user_id=%,NULL and customer_id=%, NULL
     *
     * @param customerId
     * @param dataHistoryMonths
     * @return
     */

    private static final String SEPARATOR = ",";
    private String getUserAttributes(ReportUser reportUser, String customerId, Integer dataHistoryMonths, String userType, String dashboardId, String finalUserAttribute) {

        StringBuilder userAttributesSb = new StringBuilder("{");
        List<String> userAttributeParts = Lists.newArrayList();

        if(reportUser.getRole().getType().equals(UserType.CustomerAdmin) && dashboardId.equals(userAccountMappingReport)){
            userAttributeParts.add("\"user_id\":\"%,NULL\"");
        } else {
            if (reportUser.getRole().isInternal()) {
                userAttributeParts.add("\"user_id\":\"%,NULL\"");
            } else {
                userAttributeParts.add("\"user_id\":\"" + reportUser.getUsername().toLowerCase() + "\"");
            }
        }

        if (customerId != null) {
            if (customerId.equals("All ACCOUNTS")) {
                userAttributeParts.add("\"customer_id\":\"%,NULL\"");
            } else if(customerId.equals("HEALTH SYSTEM 123")){
                userAttributeParts.add("\"customer_id\":\"'0000'\"");
            } else if( customerId.equalsIgnoreCase("all my accounts")){
                StringBuilder csvBuilder = new StringBuilder();
                String csv = null;
                List<Customer> customers = customerService.getCustomersForUser(reportUser);
                if (customers.size() > 0) {
                    for (Customer customer : customers) {
                        if(!customer.getAmdmEraOwnrName().equalsIgnoreCase("all my accounts")) {
                            csvBuilder.append("'").append(customer.getCustomerId()).append("'");
                            csvBuilder.append(SEPARATOR);
                        }
                    }
                    csv = csvBuilder.toString();
                    csv = csv.substring(0, csv.length() - SEPARATOR.length());
                }
                userAttributeParts.add("\"customer_id\":\"" + csv + "\"");
            }
            else {
                userAttributeParts.add("\"customer_id\":\"'" + getCustomerId(customerId) + "'\"");
            }
        } else {
            userAttributeParts.add("\"customer_id\":\"%,NULL\"");
        }

        if (dataHistoryMonths != null) {
            userAttributeParts.add("\"data_history_months\":\"" + dataHistoryMonths + "\"");
        }

        if (StringUtils.isNotBlank(reportUser.getMarketPartition())) {
            userAttributeParts.add("\"market_segment\":\"" + reportUser.getMarketPartition() + "\"");
        }

        if (StringUtils.isNotBlank(reportUser.getBlaEligible())) {
            userAttributeParts.add("\"bla_eligible\":\"" + reportUser.getBlaEligible() + "\"");
        }
        if (finalUserAttribute!=null) {
            LOGGER.info("finalUserAttribute ---> "+finalUserAttribute);
            userAttributeParts.add(finalUserAttribute);
        } else {
            userAttributeParts.add("\"cen\":\"%,NULL\"");
            userAttributeParts.add("\"cdn\":\"%,NULL\"");
            userAttributeParts.add("\"crn\":\"%,NULL\"");
            userAttributeParts.add("\"chi\":\"%,NULL\"");
            userAttributeParts.add("\"ngn\":\"%,NULL\"");
            userAttributeParts.add("\"ngc\":\"%,NULL\"");
            userAttributeParts.add("\"nsgn\":\"%,NULL\"");
            userAttributeParts.add("\"nsgc\":\"%,NULL\"");
            userAttributeParts.add("\"acd\":\"%,NULL\"");
            userAttributeParts.add("\"cfd\":\"%,NULL\"");
            userAttributeParts.add("\"catd\":\"%,NULL\"");
            userAttributeParts.add("\"dn\":\"%,NULL\"");
        }

        LOGGER.info("userAttributeParts userName" + reportUser.getUsername().toUpperCase() + " customerId---" + getCustomerId(customerId) + "  userAttributeParts " + userAttributeParts+"  reportUser.getRole().getType()"+reportUser.getRole().getType());

        return userAttributesSb.append(COMMA_JOINER.join(userAttributeParts)).append("}").toString();
    }

    private String getUserAttributesForEmbedUser(String externalUserId, String marketPartition, String blaEligible) {

        StringBuilder userAttributesSb = new StringBuilder("{");
        List<String> userAttributeParts = Lists.newArrayList();

        userAttributeParts.add("\"external_user_id\":\"" + externalUserId + "\"");

        if (StringUtils.isNotBlank(marketPartition)) {
            userAttributeParts.add("\"market_segment\":\"" + marketPartition + "\"");
        }

        if (StringUtils.isNotBlank(blaEligible)) {
            userAttributeParts.add("\"bla_eligible\":\"" + blaEligible + "\"");
        }

        LOGGER.info("  getUserAttributesForEmbedUser ---> userAttributeParts " + userAttributeParts);

        return userAttributesSb.append(COMMA_JOINER.join(userAttributeParts)).append("}").toString();
    }

    /**
     * flag to check a user has access to customer or not
     *
     * @param userId
     * @param customerId
     * @return
     */
    private boolean checkCustomerAccess(String userId, String customerId) {
        return true;//customerService.checkCustomerAccess(userId,customerId);
    }

    /**
     * it is for test only Demo customers and will be removed
     *
     * @param customerId
     * @return
     */
    private String getCustomerId(String customerId) {
        return customerService.getCustomerIdByCustomerName(customerId);
    }

    @Override
    public RestResponse<String> getAccountConfigurationReport(ReportUser reportUser, String customerName) throws Exception {
        String authToken = dashboardApi.getAuthToken();
        String[] fields = {"id", "name", "dashboard_elements"};
        DashboardVo dashboard;
        String customerId=customerRepository.getCustomerIdByCommonEntityName(customerName);
        try {
            dashboard = dashboardApi.getDashboard(accountConfigurationReport, fields, authToken);
        } catch (Exception e) {
            LOGGER.warn("error during dashboard meta data load **");
            throw new ApiException("Exception ocurred during dashboard meta data fetch");
        }
        DashboardVo dashboardUpdated = getUpdatedDashboardWithQueryId(dashboard.getDashboardElements().get(0).getQuery().getId(), authToken);
        return getAccountConfigurationReportWithQueryId(dashboardUpdated, authToken, customerId);
    }

    public RestResponse<String> getAccountConfigurationReportWithQueryId(DashboardVo dashboard, String authToken, String customerId) throws Exception {
        String body = MappingUtils.serializeToJson(getUpdatedDashboard(dashboard, customerId));
        String[] fields = {"id", "title", "slug", "share_url"};

        try {
            Query query = queryApi.createQuery(body, fields);
            RestResponse<String> response = queryApi.getResultFormatQueryId(query.getId(),"txt");
            return response;
        } catch (RestClientException e) {
            LOGGER.error("Failed to execute inline query: " + e.getMessage());
            throw new ApiException("Failed to execute inline query: " + e.getMessage());
        }
    }

    private DashboardVo getUpdatedDashboardWithQueryId(Long queryId, String authToken) {
        try {
            String requestUrl = this.lookerApiHost + "/queries/" + queryId;
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, null);
            DashboardVo dashboard = new DashboardVo();
            MappingUtils.populateFromJson(jsonResponse, dashboard);
            return dashboard;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public ResponseEntity<String> getAccountConfigurationReport(DashboardVo dashboard, String authToken, String customerId) throws Exception {
        String url = this.lookerApiHost + "/queries/run/txt";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.TEXT_PLAIN);

        ReportUser loggedInUser = userAuthentication.getLoggedInUser();
        UserVo user = userApi.getUserByEmbed(loggedInUser.getUsername(), authToken);
        String userAuthToken = queryApi.getAuthTokenForUserId(authToken, user.getId());
        headers.add("Authorization", "Bearer " + userAuthToken);

        String body = MappingUtils.serializeToJson(getUpdatedDashboard(dashboard, customerId));

        HttpEntity<String> entity = new HttpEntity<>(body, headers);

        try {
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
            return response;
        } catch (RestClientException e) {
            LOGGER.error("Failed to execute inline query: " + e.getMessage());
            throw new ApiException("Failed to execute inline query: " + e.getMessage());
        }
    }

    private DashboardVo getUpdatedDashboard(DashboardVo dashboard, String customerId) {
        Map<String, String> filters = new HashMap<>();
        DashboardVo updatedDashboardVo = new DashboardVo();
        filters.put("if_ra_dim_cust_acct.amdm_era_ownr_party_id", customerId);

        updatedDashboardVo.setCan(dashboard.getCan());
        updatedDashboardVo.setId(dashboard.getId());
        updatedDashboardVo.setModel(dashboard.getModel());
        updatedDashboardVo.setView(dashboard.getView());
        updatedDashboardVo.setFields(dashboard.getFields());
        updatedDashboardVo.setPivots(dashboard.getPivots());
        updatedDashboardVo.setFields(dashboard.getFields());
        updatedDashboardVo.setPivots(dashboard.getPivots());
        updatedDashboardVo.setFillFields(dashboard.getFillFields());
        updatedDashboardVo.setFilters(filters);
        updatedDashboardVo.setFilterExpression(dashboard.getFilterExpression());
        updatedDashboardVo.setSorts(dashboard.getSorts());
        updatedDashboardVo.setLimit(dashboard.getLimit());
        updatedDashboardVo.setColumnLimit(dashboard.getColumnLimit());
        updatedDashboardVo.setTotal(dashboard.getTotal());
        updatedDashboardVo.setRowTotal(dashboard.getRowTotal());
        updatedDashboardVo.setSubtotals(dashboard.getSubtotals());
        updatedDashboardVo.setVisConfig(dashboard.getVisConfig());
        updatedDashboardVo.setFilterConfig(dashboard.getFilterConfig());
        updatedDashboardVo.setVisibleUiSections(dashboard.getVisibleUiSections());
        updatedDashboardVo.setSlug(dashboard.getSlug());
        updatedDashboardVo.setDynamic_fields(dashboard.getDynamic_fields());
        updatedDashboardVo.setClientId("");
        updatedDashboardVo.setShareUrl(dashboard.getShareUrl());
        updatedDashboardVo.setExpandedShareUrl(dashboard.getExpandedShareUrl());
        updatedDashboardVo.setUrl(dashboard.getUrl());
        updatedDashboardVo.setQueryTimezone(dashboard.getQueryTimezone());
        updatedDashboardVo.setHasTableCalculations(dashboard.getHasTableCalculations());
        updatedDashboardVo.setRuntime(dashboard.getRuntime());
        return updatedDashboardVo;
    }

    @Override
    public ResponseEntity<String> getScheduledPlans(ReportUser reportUser) throws Exception {
        String[] fields = {"id","name","title","crontab","timezone","look_id","dashboard_id","last_run_at","updated_at","next_run_at","scheduled_plan_destination"};
        String authToken = queryApi.getAuthToken();
        UserVo embedUser = userApi.getUserByEmbed(reportUser.getUsername(), authToken);
        String lookerId = embedUser.getId();
        return scheduleApi.getScheduledPlans(fields, authToken, lookerId);
    }

    @Override
    public void deleteScheduledPlan(String scheduledPlanId) {
        String authToken = queryApi.getAuthToken();
        scheduleApi.deleteScheduledPlan(authToken, scheduledPlanId);
    }
}