package com.mckesson.app.auth.module;

import java.util.List;

import com.google.common.collect.Lists;

import main.java.com.mckesson.app.domain.admin.Module;

public class StaticModuleAuthority implements ModuleAuthority {

    @Override
    public List<Module> getModules() {
        return Lists.newArrayList();
    }

    @Override
    public boolean canAccessModule(Module module) {
        return false;
    }

}
