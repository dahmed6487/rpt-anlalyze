package com.mckesson.app.domain.customer;

import java.util.Objects;

public class ContentAccessDto {
    private String module;
    private boolean accessible;

    public String getModule() {
        return module;
    }

    public void setModule(String newModule) {
        module = newModule;
    }

    public boolean isAccessible() {
        return accessible;
    }

    public void setAccessible(boolean newAccess) {
        accessible = newAccess;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ContentAccessDto that = (ContentAccessDto) o;
        return accessible == that.accessible &&
                Objects.equals(module, that.module);
    }

    @Override
    public int hashCode() {
        return Objects.hash(module, accessible);
    }

    @Override
    public String toString() {
        return "ContentAccessDto{" +
                "module='" + module + '\'' +
                ", access=" + accessible +
                '}';
    }
}
