package com.mckesson.app.domain.customer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "custom_account_fields")
public class CustomAccountFields {
    @Id
    @Column(name = "id")
    private long Id;

    @Column(name = "account_id")
    private String accountId;

    @Column(name = "facility")
    private String facility;

    @Column(name = "account_type")
    private String accountType;

    @Column(name = "load_file_id")
    private long loadFileId;

    public long getId() {
        return Id;
    }

    public void setId(long id) {
        Id = id;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getFacility() {
        return facility;
    }

    public void setFacility(String facility) {
        this.facility = facility;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public long getLoadFileId() {
        return loadFileId;
    }

    public void setLoadFileId(long loadFileId) {
        this.loadFileId = loadFileId;
    }
}
