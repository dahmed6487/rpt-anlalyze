package com.mckesson.app.domain.user;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class UserProfilesDto {
    @SerializedName("userProfiles")
    private List<UserProfile> userProfiles;
    @SerializedName("totalPages")
    private int totalPages;

    public List<UserProfile> getUserProfiles() {
        return userProfiles;
    }

    public void setUserProfiles(List<UserProfile> newUserProfiles) {
        userProfiles = newUserProfiles;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int newTotalPages) {
        totalPages = newTotalPages;
    }
}
