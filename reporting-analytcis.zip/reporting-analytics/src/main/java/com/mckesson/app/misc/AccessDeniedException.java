package com.mckesson.app.misc;

public class AccessDeniedException extends RuntimeException {

    public AccessDeniedException() {

    }

    public AccessDeniedException(String msg) {
        super(msg);
    }

}
