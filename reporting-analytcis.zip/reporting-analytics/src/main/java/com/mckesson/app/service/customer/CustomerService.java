package com.mckesson.app.service.customer;

import java.awt.print.Pageable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import main.java.com.mckesson.app.auth.permission.UserType;
import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.domain.admin.Module;
import main.java.com.mckesson.app.domain.customer.ContentAccessDto;
import main.java.com.mckesson.app.domain.customer.Customer;
import main.java.com.mckesson.app.domain.customer.CustomerAccount;
import main.java.com.mckesson.app.domain.customer.SecurityGroup;
import main.java.com.mckesson.app.misc.EntityNotFoundException;
import main.java.com.mckesson.app.misc.ErrorMessagesEnum;
import main.java.com.mckesson.app.repository.admin.CollaborationTeamRepository;
import main.java.com.mckesson.app.repository.admin.ModuleRepository;
import main.java.com.mckesson.app.repository.customer.CustomerRepository;
import main.java.com.mckesson.app.repository.customer.SecurityGroupRepository;
import main.java.com.mckesson.app.service.looker.CollaborationTeamServiceLooker;
import main.java.com.mckesson.app.service.looker.LookerAdminService;
import main.java.com.mckesson.app.util.UserAuthentication;
import main.java.com.mckesson.app.vo.looker.ContentVo;
import main.java.com.mckesson.app.vo.looker.FolderVo;

@Service
@Transactional
public class CustomerService {

    private final CustomerRepository customerRepo;
    private final LookerAdminService lookerAdminService;
    private final ModuleRepository moduleRepo;
    private final UserAuthentication userAuthentication;
    private final CollaborationTeamRepository collaborationTeamRepository;
    private final CollaborationTeamServiceLooker collaborationTeamServiceLooker;
    private final SecurityGroupRepository securityGroupRepository;


    @Autowired
    public CustomerService(CustomerRepository customerRepo, LookerAdminService lookerAdminService, ModuleRepository moduleRepo, UserAuthentication userAuthentication, CollaborationTeamRepository collaborationTeamRepository, CollaborationTeamServiceLooker collaborationTeamServiceLooker, SecurityGroupRepository securityGroupRepository) {
        this.customerRepo = customerRepo;
        this.lookerAdminService = lookerAdminService;
        this.moduleRepo = moduleRepo;
        this.userAuthentication = userAuthentication;
        this.collaborationTeamRepository = collaborationTeamRepository;
        this.collaborationTeamServiceLooker = collaborationTeamServiceLooker;
        this.securityGroupRepository = securityGroupRepository;
    }

    public Page<Customer> getAllCustomers() {
        Pageable customers = PageRequest.of(0, Integer.MAX_VALUE);
        return customerRepo.findAll(customers);
    }

    public Page<Customer> getCustomerPage(int page) {
        Pageable twentyElementsPage = PageRequest.of(page, 20);
        return customerRepo.findByCommonEntityNameContainingIgnoreCasePageZero(twentyElementsPage);
    }

    public Page<Customer> searchCustomerPage(int page, String searchString) {
        Pageable twentyElementsPage = PageRequest.of(page, 20);
        return customerRepo.findByCommonEntityNameContainingIgnoreCase(searchString, twentyElementsPage);
    }

    public Optional<Customer> findCustomerByCommonEntityId(String commonEntityId) {
        return customerRepo.findByCommonEntityId(commonEntityId);
    }

    public boolean updateCustomer(Customer customer) {
        Optional<Customer> customerToUpdate = customerRepo.findByCommonEntityId(customer.getAmdmEraOwnrPartyId());

        if (customerToUpdate.isPresent()) {
            Customer updatedCustomer = customerToUpdate.get();
            updatedCustomer.setCustomerName(customer.getCustomerName());
            updatedCustomer.setUpdatedBy(userAuthentication.getLoggedInUser().getUsername());
            updatedCustomer.setUpdatedDate(new Date());
            customerRepo.save(updatedCustomer);
            return true;
        } else {
            return false;
        }
    }

    public ResponseEntity<String> deleteAll(List<Customer> customer) {
        ArrayList<Long> list = new ArrayList();
        customer.stream().forEach(c -> list.add(c.getCustomerId()));
        customerRepo.deleteCustomer(new Date(), list);
        // applicationLogService.insertApplicationLog(Collections.singletonList(customer),"customer:delete");
        return new ResponseEntity<String>("Your request has been completed successfully", HttpStatus.ACCEPTED);
    }

    public List<Customer> getCustomer() {
        return customerRepo.getCustomer();
    }

    public String getCustomerIdByCustomerName(String customerName) {
        return customerRepo.getCustomerIdByCustomerName(customerName);
    }

    public List<Customer> getCustomersForUser(ReportUser user) {
        try {
            List<Customer> list;

            list = user.isInternal() ?
                    user.getRole().getType().equals(UserType.InternalSales) ? customerRepo.getCustomerById(user.getOriginalUsername()) : user.getRole().getType().equals(UserType.InternalUser) ? customerRepo.getBetaCustomers() : customerRepo.getCustomer()
                    : customerRepo.getCustomerById(user.getOriginalUsername());
            if(!user.isInternal()){
                if (list.size() ==2)
                    list.remove(0);
            }
            if (list.size() > 0)
                return list;
            else
                throw new EntityNotFoundException("You do not have access to any Accounts/Customers. Please contact your administrator.");
        } catch (NullPointerException e) {
            throw new UsernameNotFoundException("You do not have access to Mckesson ERA. Please contact the McKesson ERA Support Line at 800-829-3444, between 8am-5pm M-F(CST). Error code:0001");
        }
    }

    public void insertUserProfiles() {
        customerRepo.insertUserProfiles(new Date());
    }

    public void updateUserFunctions() {
        customerRepo.updateUserFunctions();
    }

    public void insertCustomers() {
        customerRepo.insertCustomers(new Date());
    }

    public int mappingsCount() {
        return customerRepo.mappingsCount();
    }

    public void insertUserMappings() {
        customerRepo.insertUserMappings(new Date());
    }

    public Optional<List<String>> findContentAccessesByCommonEntityId(String commonEntityId, String moduleType) {
        ArrayList<String> foundModule =  moduleRepo.getModulesForCustomer(commonEntityId, moduleType);
        if (foundModule.size()==0 && moduleType.equals("canned report")) {
            return Optional.of(moduleRepo.getModules());
        } else if (foundModule.size()==0 && moduleType.equals("explore")) {
            return Optional.of(moduleRepo.getExplores());
        } else {
            return Optional.of(foundModule);
        }
    }

    public List<Module> getContentAccessByCustomer(String customerName) {
        List<Module> foundModule =  moduleRepo.getExploresByCustomer(customerName);
        // If no modules are mapped in customer_module_relation, return all explore modules
        if (foundModule.size()==0) {
            return moduleRepo.findByModuleType("explore");
        } else {
            return foundModule;
        }
    }

    public Optional<List<CustomerAccount>> findAccountsByCommonEntityId(String commonEntityId) {
        List<Object[]> customerAccounts = customerRepo.findAccountsByCommonEntityId(commonEntityId);
        List<CustomerAccount> customerAccounts1 = new ArrayList<>();
        for (Object[] customerAccount : customerAccounts) {
            String customerAccountId = (String) customerAccount[0];
            String customerAccountName = (String) customerAccount[1];
            String address = (String) customerAccount[2];
            String city = (String) customerAccount[3];
            String state = (String) customerAccount[4];
            String zip = (String) customerAccount[5];
            //String commonEntityId2 = (String) customerAccount[6];
           // String commonEntityName = (String) customerAccount[7];
            CustomerAccount newCustomerAccount = new CustomerAccount(customerAccountId, customerAccountName, address, city, state, zip, null, null);
            customerAccounts1.add(newCustomerAccount);
        }
        return Optional.of(customerAccounts1);
    }

    /**
     * content_metadata_id at the folder level and content_metadata_access_id is a group to folder access id which is used to remove the access
     * no looker api's for second level teams....?
     * @param commonEntityId
     * @param contentAccesses
     * @return
     */
    public Boolean updateCustomerContentAccesses(String commonEntityId, String moduleType, List<ContentAccessDto> contentAccesses) throws Exception {
        FolderVo folderVo;
        List<SecurityGroup> securityGroup=securityGroupRepository.getSecurityGroupByCustomerId(commonEntityId); // Get groups details based on customer
        if(securityGroup.size()>0) {
            ContentVo teamContent = new ContentVo();
            for (ContentAccessDto contentAccess : contentAccesses) {
                folderVo = collaborationTeamServiceLooker.searchFoldersByName(contentAccess.getModule()); // get content_metadata_id based on canned report child folder name
                teamContent.setContentMetadataId(folderVo.getContentMetadataId());
                teamContent.setInherits(false);

                if (contentAccess.isAccessible()) {
                    teamContent.setPermissionType("view");
                    teamContent.setGroupId(securityGroup.get(0).getExternalId().toString());
                    collaborationTeamServiceLooker.updateContentAccess(teamContent);
                    collaborationTeamServiceLooker.giveGroupAccess(teamContent); // assigned group to canned report child folder name
                    if (customerRepo.checkExistingAccess(commonEntityId, contentAccess.getModule(), moduleType).size() == 0) {
                        customerRepo.updateAccess(commonEntityId, contentAccess.getModule(), moduleType);
                    }
                } else {
                    List<CollaborationTeam> collaborationTeams=collaborationTeamRepository.getTeamsByCommonEntityId(commonEntityId);

                    List<ContentVo> contentVos = collaborationTeamServiceLooker.allContentAccess(teamContent);

                    String contentMetadataAccessId = null;
                    for (ContentVo content : contentVos) {
                        if (content.getGroupId().equals(securityGroup.get(0).getExternalId().toString())) {
                            contentMetadataAccessId = content.getId();
                            break;
                        }
                    }
                    if(contentMetadataAccessId!=null) {
                        ContentVo contentVo = new ContentVo();
                        contentVo.setId(contentMetadataAccessId);
                        collaborationTeamServiceLooker.updateContentAccess(teamContent);
                        collaborationTeamServiceLooker.removeContentAccess(contentVo);// delete group to canned report child folder name
                    }
                    customerRepo.removeAccess(commonEntityId, contentAccess.getModule(), moduleType);
                    if(collaborationTeams.size()>0) {
                        collaborationTeams.forEach(collaborationTeam ->
                                collaborationTeamRepository.removeAccess(collaborationTeam.getCollaborationTeamId(), contentAccess.getModule()) // delete second level user mapping
                        );
                    }
                }
            }
            return true;
        } else {
            return false;
        }
    }


    public Boolean updateExploreContentAccesses(String commonEntityId, String moduleType, List<ContentAccessDto> contentAccesses) throws Exception {
        for (ContentAccessDto contentAccess : contentAccesses) {
            if (contentAccess.isAccessible()) {
                if (customerRepo.checkExistingAccess(commonEntityId, contentAccess.getModule(), moduleType).size() == 0) {
                    customerRepo.updateAccess(commonEntityId, contentAccess.getModule(), moduleType);
                }
            } else {
                customerRepo.removeAccess(commonEntityId, contentAccess.getModule(), moduleType);
            }
        }
        return true;
    }

    public boolean getGroupAccessOfLookerFolder(long groupId, long moduleId) {
        try {
            ContentVo contentVo = new ContentVo();
            Optional<String> optionalFolderContentMetadataId = getFolderContentMetadataId(moduleId);

            if (optionalFolderContentMetadataId.isPresent()) {
                contentVo.setContentMetadataId(optionalFolderContentMetadataId.get());
            } else {
                return false;
            }

            List<ContentVo> contentVos = collaborationTeamServiceLooker.allContentAccess(contentVo);

            for (ContentVo content : contentVos) {
                if (content.getGroupId() != null && content.getPermissionType() != null) {
                    if (content.getGroupId().equals(String.valueOf(groupId)) && content.getPermissionType().equals("view")) {
                        return true;
                    }
                }
            }

            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean modifyAccessSoGroupHasAccessToLookerFolder(long groupId, long moduleId) {
        try {
            ContentVo newContentAccess = new ContentVo();
            Optional<String> optionalFolderContentMetadataId = getFolderContentMetadataId(moduleId);

            if (optionalFolderContentMetadataId.isPresent()) {
                newContentAccess.setContentMetadataId(optionalFolderContentMetadataId.get());
            } else {
                return false;
            }

            newContentAccess.setPermissionType("view");
            newContentAccess.setGroupId(String.valueOf(groupId));
            newContentAccess.setUserId("null");

            collaborationTeamServiceLooker.giveGroupAccess(newContentAccess);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private Optional<String> getFolderContentMetadataId(Long moduleId) {
        Optional<Module> moduleOptional = moduleRepo.findById(moduleId);

        if (moduleOptional.isPresent()) {
            Module module = moduleOptional.get();
            FolderVo folders;

            try {
                folders = collaborationTeamServiceLooker.getFolderByName(module.getTitle());
                if (module.getTitle().equals("Controlled Substances")) {
                    folders = collaborationTeamServiceLooker.getFolderByName("Controlled Substance");
                }
            } catch (Exception e) {
                return Optional.empty();
            }

            //FolderVo folder = folders.get(0);
            return Optional.of(folders.getContentMetadataId());
        } else {
            return Optional.empty();
        }
    }

    public boolean modifyAccessSoGroupDoesNotHaveAccessToLookerFolder(long groupId, long moduleId) throws Exception {
        Optional<String> optionalFolderContentMetadataId = getFolderContentMetadataId(moduleId);

        if (optionalFolderContentMetadataId.isPresent()) {
            String folderContentMetadataId = optionalFolderContentMetadataId.get();

            ContentVo contentVo = new ContentVo();
            contentVo.setContentMetadataId(folderContentMetadataId);
            List<ContentVo> contentVos = collaborationTeamServiceLooker.allContentAccess(contentVo);

            String contentMetadataAccessId = null;
            for (ContentVo content : contentVos) {
                if (content.getGroupId().equals(String.valueOf(groupId))) {
                    contentMetadataAccessId = content.getId();
                    break;
                }
            }
            contentVo.setId(contentMetadataAccessId);
            collaborationTeamServiceLooker.deleteContentAccess(contentVo);
            return true;
        } else {
            return false;
        }
    }

    /**
     * @param user
     * @param accountNumber
     * @return
     */
    public List<Customer> getCustomerByAccount(ReportUser user, String accountNumber) {
        return user.isInternal() ?
                user.getRole().getType().equals(UserType.InternalUser)? customerRepo.getBetaCustomersByAccounts(accountNumber) : customerRepo.getCustomerByAccounts(accountNumber)
                : customerRepo.getCustomerByIdByAccounts(user.getOriginalUsername(), accountNumber);
    }

    public Optional<Customer> findCustomerByCustomerName(String customerName) {
        return customerRepo.findByAmdmEraOwnrNameIgnoreCase(customerName);
    }

    public List<String> searchOwnerValue(String type, String searchText) {
        if (type.equalsIgnoreCase("OWNER_NAME"))
            return customerRepo.searchOwnerValue(searchText);
        else if (type.equalsIgnoreCase("OWNER_NUMBER"))
            return customerRepo.searchOwnerNum(searchText);
        else
        return Collections.emptyList();
    }

    public List<String> searchAccountCodeValue(String type, String searchText) {
        if (type.equalsIgnoreCase("ngn"))
            return customerRepo.searchNationalGroupNameValue(searchText);
        else if (type.equalsIgnoreCase("ngc"))
            return customerRepo.searchNationalGroupValue(searchText);
        else if (type.equalsIgnoreCase("nsgn"))
            return customerRepo.searchNationalSubGroupNameValue(searchText);
        else if (type.equalsIgnoreCase("nsgc"))
            return customerRepo.searchNationalSubGroupValue(searchText);
        else if (type.equalsIgnoreCase("crn"))
            return customerRepo.searchCustomerRegionValue(searchText);
        else if (type.equalsIgnoreCase("cdn"))
            return customerRepo.searchCustomerDistrictNameValue(searchText);
        else if (type.equalsIgnoreCase("cdc"))
            return customerRepo.searchCustomerDistrictValue(searchText);
        else if (type.equalsIgnoreCase("chi"))
            return customerRepo.searchChainValue(searchText);
        else if (type.equalsIgnoreCase("TERRITORY_ID"))
            return customerRepo.searchTerritoryValue(searchText);
        else if (type.equalsIgnoreCase("cen"))
            return customerRepo.searchCommonEntityNameValue(searchText);
        else if (type.equalsIgnoreCase("acd"))
            return customerRepo.searchAccountClassification(searchText);
        else if (type.equalsIgnoreCase("cfd"))
            return customerRepo.searchFacility(searchText);
        else if (type.equalsIgnoreCase("catd"))
            return customerRepo.searchAccountType(searchText);
        else if (type.equalsIgnoreCase("dn"))
            return customerRepo.searchDEANumber(searchText);
        else
            return Collections.emptyList();
    }

    public Customer createOrUpdateCustomerInfo(Customer customer) throws Exception {

       if(customerRepo.checkDefineCustomerExistsORNot(customer.getCustomerName())==0) {

           if(!customer.getNatlGrpName().isEmpty() || customer.getNatlGrpName()!=null)
               customer.setNatlGrpCd(customerRepo.getNationalGroupCode(customer.getNatlGrpName()));
           if(!customer.getNatlSubGrpName().isEmpty() || customer.getNatlSubGrpName()!=null)
               customer.setNatlSubGrpCd(customerRepo.getNationalSubGroupCode(customer.getNatlSubGrpName()));
           if(!customer.getCustDstrctName().isEmpty() || customer.getCustDstrctName()!=null)
               customer.setCustDstrctNum(customerRepo.getCustDstrctCode(customer.getCustDstrctName()));
           if(!customer.getCommonEntityName().isEmpty() || customer.getCommonEntityName()!=null)
               customer.setCommonEntityId(customerRepo.getCommonEntityNameCode(customer.getCommonEntityName()));
           if(!customer.getCommonGroupName().isEmpty() || customer.getCommonGroupName()!=null)
               customer.setCommonGroupId(customerRepo.getCommonGroupCode(customer.getCommonGroupName()));
           if(!customer.getOwnerName().isEmpty() || customer.getOwnerName()!=null)
               customer.setOwnerId(customerRepo.getOwnerCode(customer.getOwnerName()));

           Customer createdCustomer = customerRepo.saveAndFlush(customer);

           CollaborationTeam collaborationTeam = new CollaborationTeam();
           FolderVo folderId = collaborationTeamServiceLooker.createFolder("1", customer.getCustomerName());
           collaborationTeam.setPlatformId(customer.getPlatformId());
           collaborationTeam.setCustomerId(createdCustomer.getCustomerId());
           collaborationTeam.setName(folderId.getName());
           collaborationTeam.setExternalId(Long.parseLong(folderId.getId()));
           collaborationTeam.setCreatedBy(customer.getCreatedBy());
           collaborationTeam.setCreatedDate(customer.getCreatedDate());
           collaborationTeamRepository.save(collaborationTeam);

           GroupVo groupVo = new GroupVo();
           groupVo.setName(customer.getCustomerName());
           groupVo = lookerAdminService.createGroup(groupVo);
           SecurityGroup group = new SecurityGroup();
           group.setPlatformId(customer.getPlatformId());
           group.setCustomerId(createdCustomer.getCustomerId());
           group.setName(groupVo.getName());
           group.setExternalId(groupVo.getId());
           group.setCreatedBy(customer.getCreatedBy());
           group.setCreatedDate(customer.getCreatedDate());
           securityGroupRepository.save(group);

           return createdCustomer;
       } else {
           throw new EntityNotFoundException(ErrorMessagesEnum.valueOf("DEFINE_CUSTOMER_ALREADY_EXISTS").getErrorMsg());
       }
    }

    public List<String> searchCommonEntityGroupValue(String type, String searchText) {
        if (type.equalsIgnoreCase("COMMON_ENTITY_ID"))
            return customerRepo.searchCommonEntityIdValue(searchText);
        else if (type.equalsIgnoreCase("COMMON_ENTITY_NAME"))
            return customerRepo.searchCommonEntityNameValue(searchText);
        else if (type.equalsIgnoreCase("COMMON_GROUP_ID"))
            return customerRepo.searchCommonGroupIdValue(searchText);
        else if (type.equalsIgnoreCase("COMMON_GROUP_NAME"))
            return customerRepo.searchCommonGroupNameValue(searchText);
        else if (type.equalsIgnoreCase("BUYING_GROUP_ID"))
            return customerRepo.searchBuyingGroupIdvalue(searchText);
        else if (type.equalsIgnoreCase("BUYING_GROUP_NAME"))
            return customerRepo.searchBuyingGroupName(searchText);
        else
            return Collections.emptyList();
    }

    public List<String> getAccountDimensions(String accDimension, String accDimensionValue, String CustomerName, String userId) {
        if (CustomerName.equals("All ACCOUNTS")) {
            return searchAccountCodeValue(accDimension, accDimensionValue);
        } else if (CustomerName.equals("ALL MY ACCOUNTS")) {
            return getAccountDimensionsOthers(accDimension, accDimensionValue, CustomerName, userId);
        } else {
            return getAccountDimensionsInternals(accDimension, accDimensionValue, CustomerName);
        }
    }

    private List<String> getAccountDimensionsInternals(String accDimension, String accDimensionValue,String CustomerName) {
        if (accDimension.equalsIgnoreCase("ngn"))
            return customerRepo.searchNationalGroupNameValue(accDimensionValue, CustomerName);
        else if (accDimension.equalsIgnoreCase("ngc"))
            return customerRepo.searchNationalGroupValue(accDimensionValue, CustomerName);
        else if (accDimension.equalsIgnoreCase("nsgn"))
            return customerRepo.searchNationalSubGroupNameValue(accDimensionValue, CustomerName);
        else if (accDimension.equalsIgnoreCase("nsgc"))
            return customerRepo.searchNationalSubGroupValue(accDimensionValue, CustomerName);
        else if (accDimension.equalsIgnoreCase("crn"))
            return customerRepo.searchCustomerRegionValue(accDimensionValue, CustomerName);
        else if (accDimension.equalsIgnoreCase("cdn"))
            return customerRepo.searchCustomerDistrictNameValue(accDimensionValue, CustomerName);
        else if (accDimension.equalsIgnoreCase("cust_dstrct_num"))
            return customerRepo.searchCustomerDistrictValue(accDimensionValue, CustomerName);
        else if (accDimension.equalsIgnoreCase("chi"))
            return customerRepo.searchChainValue(accDimensionValue, CustomerName);
        else if (accDimension.equalsIgnoreCase("TERRITORY_ID"))
            return customerRepo.searchTerritoryValue(accDimensionValue, CustomerName);
        else if (accDimension.equalsIgnoreCase("cen"))
            return customerRepo.searchCommonEntityNameValue(accDimensionValue, CustomerName);
        else if (accDimension.equalsIgnoreCase("acd"))
            return customerRepo.searchAccountClassification(accDimensionValue, CustomerName);
        else if (accDimension.equalsIgnoreCase("cfd"))
            return customerRepo.searchFacility(accDimensionValue, CustomerName);
        else if (accDimension.equalsIgnoreCase("catd"))
            return customerRepo.searchAccountType(accDimensionValue, CustomerName);
        else if (accDimension.equalsIgnoreCase("dn"))
            return customerRepo.searchDEANumber(accDimensionValue, CustomerName);
        else
            return Collections.emptyList();
    }

    private List<String> getAccountDimensionsOthers(String accDimension, String accDimensionValue,String CustomerName, String userId) {
        if (accDimension.equalsIgnoreCase("ngn"))
            return customerRepo.searchNationalGroupNameValue(accDimensionValue, CustomerName, userId);
        else if (accDimension.equalsIgnoreCase("ngc"))
            return customerRepo.searchNationalGroupValue(accDimensionValue, CustomerName, userId);
        else if (accDimension.equalsIgnoreCase("nsgn"))
            return customerRepo.searchNationalSubGroupNameValue(accDimensionValue, CustomerName, userId);
        else if (accDimension.equalsIgnoreCase("nsgc"))
            return customerRepo.searchNationalSubGroupValue(accDimensionValue, CustomerName, userId);
        else if (accDimension.equalsIgnoreCase("crn"))
            return customerRepo.searchCustomerRegionValue(accDimensionValue, CustomerName, userId);
        else if (accDimension.equalsIgnoreCase("cdn"))
            return customerRepo.searchCustomerDistrictNameValue(accDimensionValue, CustomerName, userId);
        else if (accDimension.equalsIgnoreCase("cust_dstrct_num"))
            return customerRepo.searchCustomerDistrictValue(accDimensionValue, CustomerName, userId);
        else if (accDimension.equalsIgnoreCase("chi"))
            return customerRepo.searchChainValue(accDimensionValue, CustomerName, userId);
        else if (accDimension.equalsIgnoreCase("TERRITORY_ID"))
            return customerRepo.searchTerritoryValue(accDimensionValue, CustomerName, userId);
        else if (accDimension.equalsIgnoreCase("cen"))
            return customerRepo.searchCommonEntityNameValue(accDimensionValue, CustomerName, userId);
        else if (accDimension.equalsIgnoreCase("acd"))
            return customerRepo.searchAccountClassification(accDimensionValue, CustomerName, userId);
        else if (accDimension.equalsIgnoreCase("cfd"))
            return customerRepo.searchFacility(accDimensionValue, CustomerName, userId);
        else if (accDimension.equalsIgnoreCase("catd"))
            return customerRepo.searchAccountType(accDimensionValue, CustomerName, userId);
        else if (accDimension.equalsIgnoreCase("dn"))
            return customerRepo.searchDEANumber(accDimensionValue, CustomerName, userId);
        else
            return Collections.emptyList();
    }
}
