package com.mckesson.app.repository.looker;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import main.java.com.mckesson.app.domain.looker.FilterCriteriaGroup;
import main.java.com.mckesson.app.vo.CustomFilterGroupSummary;

public interface CustomFilterGroupRepository extends JpaRepository<FilterCriteriaGroup, Long> {

    @Query("select g.id as id, g.name as name FROM FilterCriteriaGroup g where g.filter.id = :filterId")
    CustomFilterGroupSummary getByFilterId(Long filterId);
}
