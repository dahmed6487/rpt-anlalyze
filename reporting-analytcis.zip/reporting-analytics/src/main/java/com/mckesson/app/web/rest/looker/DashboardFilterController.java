package com.mckesson.app.web.rest.looker;

import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import main.java.com.mckesson.app.service.looker.DashboardService;
import main.java.com.mckesson.app.util.UserAuthentication;
import main.java.com.mckesson.app.vo.looker.DashboardFilterConfigResponseVo;

/**
 * API endpoint used for managing 'dashboard filters'.
 */
@RequestMapping("/filters")
@RestController
public class DashboardFilterController {

    Logger logger = LoggerFactory.getLogger(CustomFilterController.class);

    private final UserAuthentication userAuthentication;
    private final DashboardService dashboardService;

    @Autowired
    public DashboardFilterController(UserAuthentication userAuthentication, DashboardService dashboardService) {
        this.userAuthentication = userAuthentication;
        this.dashboardService = dashboardService;
    }

    @RequestMapping(path = "/dashboard/{dashboardId}", method = RequestMethod.GET)
    ResponseEntity loadDashboardFilterConfig(@PathVariable String dashboardId) {
        //List<DashboardFilter> filters = dashboardService.getFiltersForDashboard(dashboardId);
        String userId = userAuthentication.getLoggedInUser().getUsername();
        DashboardFilterConfigResponseVo config = dashboardService.loadDashboardFilterConfig(userId, dashboardId);
        return new ResponseEntity(config, HttpStatus.OK);
    }

    @RequestMapping(path = "/dashboard/filters/{filterId}", method = RequestMethod.DELETE)
    ResponseEntity deleteFilter(@PathVariable String filterId) {

        dashboardService.deleteFilter(filterId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @RequestMapping(path = "/dashboard/filters", method = RequestMethod.POST)
    ResponseEntity createFilter(@RequestBody DashboardFilterVo filter) {
        String userId = userAuthentication.getLoggedInUser().getUsername();
        filter = dashboardService.createFilter(userId, filter);
        return new ResponseEntity(filter, HttpStatus.CREATED);
    }

    @RequestMapping(path = "/dashboard/filters/{filterId}", method = RequestMethod.PUT)
    ResponseEntity updateFilter(@RequestBody DashboardFilterVo filter, @PathVariable String filterId) {
        filter = dashboardService.updateFilter(filter);
        return new ResponseEntity(filter, HttpStatus.OK);
    }

    @RequestMapping(path = "/dashboard/filters/{filterId}/sharedTeams", method = RequestMethod.POST)
        //ResponseEntity updateFilterSharingConfig (@RequestBody DashboardFilter filter, @PathVariable String filterId) {
    ResponseEntity updateFilterSharingConfig(@RequestBody String[] sharedTeams, @PathVariable String filterId) {
        dashboardService.updateSharedGroups(filterId, sharedTeams);
        return new ResponseEntity(HttpStatus.OK);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity handleException(Exception e) {
        e.printStackTrace();
        return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(SecurityException.class)
    public ResponseEntity handleSecurityException(SecurityException e) {
        e.printStackTrace();
        return new ResponseEntity(HttpStatus.UNAUTHORIZED);
    }
}	
