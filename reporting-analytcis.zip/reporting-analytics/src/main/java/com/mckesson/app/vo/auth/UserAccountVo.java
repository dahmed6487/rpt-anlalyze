package com.mckesson.app.vo.auth;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserAccountVo {

    @JsonProperty("userId")
    private String userId;
    @JsonProperty("appId")
    private String appId;
    @JsonProperty("accounts")
    private List<AccountVo> accounts;
    @JsonProperty("groups")
    private List<GroupVo> groups;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public List<AccountVo> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<AccountVo> accounts) {
        this.accounts = accounts;
    }

    public List<GroupVo> getGroups() {
        return groups;
    }

    public void setGroups(List<GroupVo> groups) {
        this.groups = groups;
    }
}
