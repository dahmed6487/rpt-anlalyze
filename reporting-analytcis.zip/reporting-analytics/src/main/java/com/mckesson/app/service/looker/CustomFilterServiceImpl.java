package com.mckesson.app.service.looker;

import java.awt.print.Pageable;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import javax.transaction.Transactional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.domain.looker.CustomFilter;
import main.java.com.mckesson.app.domain.looker.FilterCriteria;
import main.java.com.mckesson.app.domain.looker.FilterCriteriaGroup;
import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.repository.looker.CustomFilterGroupCriteriaRepository;
import main.java.com.mckesson.app.repository.looker.CustomFilterGroupRepository;
import main.java.com.mckesson.app.repository.looker.CustomFilterProjection;
import main.java.com.mckesson.app.repository.looker.CustomFilterRepository;
import main.java.com.mckesson.app.util.StringUtils;
import main.java.com.mckesson.app.vo.CustomFilterCriteriaSummary;
import main.java.com.mckesson.app.vo.CustomFilterGroupSummary;
import main.java.com.mckesson.app.vo.CustomFilterSummary;

@Service("CustomFilterService")
public class CustomFilterServiceImpl implements CustomFilterService {

    private static final Logger logger = LoggerFactory.getLogger(CustomFilterServiceImpl.class);

    private final CustomFilterRepository customFilterRepo;
    private final CustomFilterGroupRepository customFilterGroupRepo;
    private final CustomFilterGroupCriteriaRepository customFilterCriteriaRepo;

    @Autowired
    public CustomFilterServiceImpl(CustomFilterRepository customFilterRepo, CustomFilterGroupRepository customFilterGroupRepo, CustomFilterGroupCriteriaRepository customFilterCriteriaRepo) {
        this.customFilterRepo = customFilterRepo;
        this.customFilterGroupRepo = customFilterGroupRepo;
        this.customFilterCriteriaRepo = customFilterCriteriaRepo;
    }

    @Transactional
    @Override
    public CustomFilter createCustomFilter(final CustomFilter customFilter, String userId) {
        // Set the "userid" to the customer's user id
        customFilter.setUserId(userId);

        customFilter.setAuthor(userId);
        customFilter.setCreationDate(new Date());

        if (StringUtils.isBlank(customFilter.getExplore()))
            customFilter.setExplore("if_ra_fact_invc_purch_hist");    // default value

        CustomFilter savedFilter = customFilterRepo.save(customFilter);
        logger.debug("Creating new custom filter: id=>" + savedFilter.getId());
        return savedFilter;
    }

    @Override
    public List<CustomFilterSummary> listCustomFilters(int start, int size) {
        return customFilterRepo.list();
    }

    @Override
    public Page<CustomFilter> searchCustomFilters(int page, String userId, String search) {
        Pageable twentyElementsPage = PageRequest.of(page, 20);
        return customFilterRepo.findByUserIdAndNameContainingIgnoreCase(userId, search, twentyElementsPage);
    }

    @Override
    public Collection<CustomFilter> getAll() {
        //TODO: Pagination
        return customFilterRepo.findAll();
    }

    @Override
    public Collection<CustomFilter> getByExploreType(String exploreName, String userId) {
        return customFilterRepo.getByExploreType(exploreName, userId);
    }

    @Override
    public CustomFilter findById(Long id) {
        Optional<CustomFilter> f = getCustomFilter(id);
        if (f.isPresent()) {
            return f.get();
        }
        return null;
    }

    @Override
    public Optional<CustomFilter> getCustomFilter(Long id) {
        return customFilterRepo.findById(id);
    }

    @Override
    public CustomFilterGroupSummary getCustomFilterGroupForFilter(Long filterId) {
        return customFilterGroupRepo.getByFilterId(filterId);
    }

    @Override
    public Collection<CustomFilterCriteriaSummary> getCustomFilterCriteriaForGroup(Long groupId) {
        return customFilterCriteriaRepo.getByGroupId(groupId);
    }

    public void delete(Long id) {
        CustomFilter selected = getCustomFilter(id).get();
		/*
		if(!selected.getUserId().equals(selected.getUserId())) {
			throw new SecurityException("User has no permission to delete selected custom filter.");
		}*/

        customFilterRepo.delete(selected);
    }

    @Transactional
    @Override
    public CustomFilter updateCriteriaGroup(CustomFilter customFilter) {
        CustomFilter existing = getCustomFilter(customFilter.getId())
                .orElseThrow(() -> new ApiException(String.format("No custom filter with id=%s found!", customFilter.getId())));

        if (existing.getCriteriaGroup() == null) {
            FilterCriteriaGroup criteriaGroup = new FilterCriteriaGroup();
            criteriaGroup.setName(existing.getName());
            criteriaGroup.setFilter(customFilter);

            customFilterGroupRepo.save(criteriaGroup);

            existing.setCriteriaGroup(criteriaGroup);
            customFilterRepo.save(existing);
        }

        return existing;
    }

    @Transactional
    public CustomFilter update(CustomFilter customFilter, String userId) {
        Long customFilterId = customFilter.getId();
        CustomFilter existing = getCustomFilter(customFilter.getId()).orElseThrow(() -> new ApiException(String.format("No custom filter with id=%s found!", customFilterId)));
        existing.setLastUpdateDate(new Date());
        existing.setName(customFilter.getName());
        existing.setExplore(customFilter.getExplore());
        existing.setUseOtherAsDefaultGroup(customFilter.isUseOtherAsDefaultGroup());

        if (customFilter.isUseOtherAsDefaultGroup()) {
            existing.setOtherDefinition(customFilter.getOtherDefinition());
        } else {
            existing.setOtherDefinition(null);
        }

        FilterCriteriaGroup filterCriteriaGroup = existing.getCriteriaGroup();
        filterCriteriaGroup.setName(customFilter.getName());
        customFilterGroupRepo.save(filterCriteriaGroup);

        return customFilterRepo.save(existing);
    }

    @Override
    public CustomFilter share(Long id, String[] teams, String userId) {
        CustomFilter existing = getCustomFilter(id).orElseThrow(() -> new ApiException(String.format("No custom filter with id=%s found!", id)));
        existing.setSharedTeams(teams);
        existing.setLastUpdateDate(new Date());
        existing.setUserId(userId);

        return customFilterRepo.save(existing);
    }

    @Transactional
    @Override
    public FilterCriteria createFilterCriteria(FilterCriteria filterCriteria, Long groupId) {
        FilterCriteriaGroup group = customFilterGroupRepo.findById(groupId).orElseThrow(() -> new ApiException(String.format("No group criteria with id=%s found!", groupId)));
        filterCriteria.setGroup(group);
        if (filterCriteria.getDefaultGrouping() == null)
            filterCriteria.setDefaultGrouping(false);

        Collection<FilterCriteria> existingCriteria = group.getFilterCriteria();
        if (existingCriteria == null)
            existingCriteria = new HashSet<>();
        existingCriteria.add(filterCriteria);

        customFilterGroupRepo.save(group);
        return filterCriteria;
    }

    @Transactional
    @Override
    public FilterCriteria updateFilterCriteria(FilterCriteria filterCriteria, Long criteriaId) {
        Long groupId = filterCriteria.getGroup().getId();
        FilterCriteriaGroup group = customFilterGroupRepo.findById(groupId).orElseThrow(() -> new ApiException(String.format("No group criteria with id=%s found!", groupId)));

        for (FilterCriteria criteria : group.getFilterCriteria()) {
            if (criteria.getId().equals(criteriaId)) {
                criteria.setAssociatedDimension(filterCriteria.getAssociatedDimension());
                criteria.setDefaultGrouping(filterCriteria.getDefaultGrouping());
                criteria.setDimension(filterCriteria.getDimension());
                criteria.setRelationalOperator(filterCriteria.getRelationalOperator());
                criteria.setName(filterCriteria.getName());
                criteria.setValue(filterCriteria.getValue());

                customFilterGroupRepo.save(group);
                return criteria;
            }
        }

        logger.error("No filter criteria found with id=%s", criteriaId);
        return null;
    }

    @Override
    public FilterCriteria getFilterCriteria(Long id) {
        FilterCriteria existing = customFilterCriteriaRepo.findById(id).orElseThrow(() -> new ApiException(String.format("No filter criteria with id=%s found!", id)));
        return existing;
    }

    @Transactional
    @Override
    public boolean deleteFilterCriteria(Long criteriaId) {
        try {
            customFilterCriteriaRepo.deleteById(criteriaId);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return false;
        }
        return true;
    }

    /**
     * Given an object representation of a 'custom filter', format the object into select criteria required by looker
     *
     * @param customGroup
     * @return
     */
    public String formatCustomGroupToDynamicFilterSyntax(CustomFilter customGroup) {
        String rawGroup = formatCustomFilterToDynamicFieldSyntaxInternal(customGroup);
        String jsonFmt = delimitJson(rawGroup);
        jsonFmt = stripCarriageReturns(jsonFmt);
        return jsonFmt;
    }

    /**
     * Internal method for formating custom group with special character placeholders.
     */
    String formatCustomFilterToDynamicFieldSyntaxInternal(CustomFilter customGroup) {
        StringBuilder sb = new StringBuilder();
        FilterCriteriaGroup group = customGroup.getCriteriaGroup();
        //Format all groups into parent child structures in preparation for creating nested statements.
        LinkedList<FilterCriteria> criteria = group == null ? new LinkedList<>() : new LinkedList<>(group.getFilterCriteria());

        //Now create value for the 'expression' attribute of the filter definition.
        String expression;
        if (group == null || criteria.isEmpty()) {
            expression = "";
        } else if (group.getCustomFormula() != null && !group.getCustomFormula().trim().isEmpty()) {
            //In the event that a hard coded custom formula is present, this value will take precedence.
            return group.getCustomFormula();
        } else {
            String defaultLabel = null;
            Optional<FilterCriteria> defaultCriteria = criteria.stream()
                    .filter(FilterCriteria::getDefaultGrouping)
                    .findAny();
            if (defaultCriteria.isPresent()) {
                defaultLabel = defaultCriteria.get().getName();
                criteria.remove(defaultCriteria.get());
            }
            if (customGroup.isUseOtherAsDefaultGroup())
                expression = formatCustomGroup(criteria, customGroup.getOtherDefinition());
            else
                expression = formatCustomGroup(criteria, defaultLabel);
        }

        sb.append("{\n");
        sb.append("\tSINGLE_DELIMlabelSINGLE_DELIM : SINGLE_DELIM").append(group == null ? "" : group.getFilter().getName()).append("SINGLE_DELIM,\n");
        sb.append("\tSINGLE_DELIMdimensionSINGLE_DELIM : SINGLE_DELIM").append(formatDimensionName(group == null ? "" : group.getName())).append("SINGLE_DELIM,\n");
        sb.append("\tSINGLE_DELIMexpressionSINGLE_DELIM : SINGLE_DELIM").append(expression).append("SINGLE_DELIM,\n");
        sb.append("\tSINGLE_DELIMvalue_formatSINGLE_DELIM : null,\n");
        sb.append("\tSINGLE_DELIMvalue_format_nameSINGLE_DELIM : null\n");
        sb.append("}\n");

        return sb.toString();
    }

    /**
     * Given a filter group which has been formatted into a parent-child structure, create the LookML syntax representing the statement. In order to support
     * multiple groups, which are modeled as parent child relations, this method will recurse for each child in the object graph in order to create
     * the nested statement.
     *
     * @param criteriaList Reference to a group and corresponding criteria to generate LookML statement for. In the event that child groups are present, method will recurse until
     *                     LookML for all filter groups in chain have been generated.
     * @param defaultValue Display value that will be presented when a no match condition is present for a given record. Note: this is only applied when no child groups are
     *                     present in the chain, as this value will contain nested statements if children are present.
     * @return
     */
    String formatCustomGroup(LinkedList<FilterCriteria> criteriaList, String defaultValue) {

        String defaultCriteriaFmt;
        if (defaultValue == null) {
            defaultCriteriaFmt = "null";
        } else {
            defaultCriteriaFmt = CustomFilterService.TRIPLE_DELIM + defaultValue + CustomFilterService.TRIPLE_DELIM;
        }


        if (criteriaList.size() < 2) {
            FilterCriteria criteria = criteriaList.get(0);
            String formattedCriteriaValue = formatCriteria(criteria.getValue().split(","));
            //Basic format: matches_filter(${billing.invoice_date}, `30 days`)
            return "if(matches_filter(${" + criteria.getDimension() + "}, " + formattedCriteriaValue + ")=yes," + CustomFilterService.TRIPLE_DELIM + criteria.getName() + CustomFilterService.TRIPLE_DELIM + "," + defaultCriteriaFmt + ")";
        } else {
            //Nested format: Non-match condition will be populated with the result of the recursive call.
            FilterCriteria criteria = criteriaList.poll();
            if (criteria == null) {
                return defaultCriteriaFmt;
            }
            String formattedCriteriaValue = formatCriteria(criteria.getValue().split(","));
            String nonMatchCriteria = formatCustomGroup(criteriaList, defaultValue);
            return "if(matches_filter(${" + criteria.getDimension() + "}, " + formattedCriteriaValue + ")=yes," + CustomFilterService.TRIPLE_DELIM + criteria.getName() + CustomFilterService.TRIPLE_DELIM + "," + nonMatchCriteria + ")";
        }
    }

    /**
     * Given a user friendly label for a custom dimension, translate to Looker specific format. Example:
     * a user friendly label such as 'Bay Area Hospitals' with 'bay_area_hospitals'.
     *
     * @param label
     * @return
     */
    public String formatDimensionName(String label) {
        // Replace all non alphabetic/space/_ characters with _
        return label.replaceAll("[^a-zA-Z_ ]+", "_")
                // trim whitespace
                .trim()
                // replace all whitespace with _
                .replace(" ", "_")
                // remove any trailing non-alphabetic characters
                .replaceAll("[^a-zA-Z]+$", "")
                //remove any leading non-alphabetic characters
                .replaceAll("^[^a-zA-Z]+", "")
                .toLowerCase();
    }

    /**
     * Given a collection of criteria elements, format them into a comma delimited list.
     *
     * @param criteriaValues
     * @return
     */
    String formatCriteria(String[] criteriaValues) {

        if (criteriaValues == null || criteriaValues.length < 1) {
            return null;
        }

        final StringBuilder criteriaSb = new StringBuilder("`");
        Arrays.stream(criteriaValues).forEach(
                criteriaValue -> criteriaSb
                        .append(CustomFilterService.TRIPLE_DELIM)
                        .append(criteriaValue)
                        .append(CustomFilterService.TRIPLE_DELIM)
                        .append(","));
        // Remove trailing comma
        criteriaSb.deleteCharAt(criteriaSb.length() - 1);
        return criteriaSb.append("`").toString();
    }

    /**
     * Given a string containing placeholders for special characters, convert characters into format 'required' by Looker.
     *
     * @param source
     * @return
     */
    String delimitJson(String source) {
        source = source.replace(SINGLE_DELIM, "\\\"");
        source = source.replace(TRIPLE_DELIM, "\\\\\\\"");
        return source;
    }

    String stripCarriageReturns(String source) {
        return source.replace("\n", "");
    }

    public List<CustomFilterProjection> getCustomListForUserAndExplore(Long exploreId) {
        return customFilterRepo.listForExplore(exploreId);
    }
}
