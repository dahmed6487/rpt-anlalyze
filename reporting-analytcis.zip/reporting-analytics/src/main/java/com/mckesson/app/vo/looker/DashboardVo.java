package com.mckesson.app.vo.looker;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DashboardVo {

    @JsonProperty("id")
    private String id;
    @JsonProperty("title")
    private String title;
    @JsonProperty("description")
    private String description;
    @JsonProperty("created_at")
    public String createdAt;
    @JsonProperty("space_id")
    String spaceId;
    @JsonProperty("favorite_count")
    int favoriteCount;
    @JsonProperty("deleted")
    private boolean deleted;
    @JsonProperty("last_viewed_at")
    public String lastViewedAt;
    @JsonProperty("view_count")
    private int viewCount;
    @JsonProperty("can")
    public Map<String, String> can;
    @JsonProperty("user_id")
    public String userId;

    @JsonProperty("model")
    public String model;
    @JsonProperty("view")
    public String view;
    @JsonProperty("fields")
    public ArrayList<String> fields;
    @JsonProperty("pivots")
    public String pivots;
    @JsonProperty("fill_fields")
    public String fillFields;
    @JsonProperty("filters")
    public Map<String, String> filters;
    @JsonProperty("filter_expression")
    public String filterExpression;
    @JsonProperty("sorts")
    public ArrayList<String> sorts;
    @JsonProperty("limit")
    public String limit;
    @JsonProperty("column_limit")
    public String columnLimit;
    @JsonProperty("total")
    public String total;
    @JsonProperty("row_total")
    public String rowTotal;
    @JsonProperty("subtotals")
    public String subtotals;


    /**
     * Note: This is not natively an attribute of the dashboard entity, but used to store the most recent date
     * that any of the looks contained within the dashboard were updated.
     */
    private String lastUpdated;

    @JsonProperty("dashboard_elements")
    private List<DashboardElementVo> dashboardElements;
    @JsonProperty("dashboard_filters")
    private List<DashboardFilterVo> dashboardFilters;
    @JsonProperty("vis_config")
    private Object visConfig;
    @JsonProperty("filter_config")
    private Object filterConfig;
    @JsonProperty("visible_ui_sections")
    public String visibleUiSections;
    @JsonProperty("slug")
    public String slug;
    @JsonProperty("dynamic_fields")
    public Object dynamic_fields;
    @JsonProperty("client_id")
    public String clientId;
    @JsonProperty("share_url")
    public String shareUrl;
    @JsonProperty("expanded_share_url")
    public String expandedShareUrl;
    @JsonProperty("url")
    public String url;
    @JsonProperty("query_timezone")
    public String queryTimezone;
    @JsonProperty("has_table_calculations")
    public String hasTableCalculations;
    @JsonProperty("runtime")
    public String runtime;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSpaceId() {
        return spaceId;
    }

    public void setSpaceId(String spaceId) {
        this.spaceId = spaceId;
    }

    public int getFavoriteCount() {
        return favoriteCount;
    }

    public void setFavoriteCount(int favoriteCount) {
        this.favoriteCount = favoriteCount;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public String getLastViewedAt() {
        return lastViewedAt;
    }

    public void setLastViewedAt(String lastViewedAt) {
        this.lastViewedAt = lastViewedAt;
    }

    public int getViewCount() {
        return viewCount;
    }

    public void setViewCount(int viewCount) {
        this.viewCount = viewCount;
    }

    public List<DashboardElementVo> getDashboardElements() {
        return dashboardElements;
    }

    public void setDashboardElements(List<DashboardElementVo> dashboardElements) {
        this.dashboardElements = dashboardElements;
    }

    public String getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public List<DashboardFilterVo> getDashboardFilters() {
        return dashboardFilters;
    }

    public void setDashboardFilters(List<DashboardFilterVo> dashboardFilters) {
        this.dashboardFilters = dashboardFilters;
    }
    public Map<String, String> getCan() {
        return can;
    }

    public void setCan(Map<String, String> can) {
        this.can = can;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getView() {
        return view;
    }

    public void setView(String view) {
        this.view = view;
    }

    public ArrayList<String> getFields() {
        return fields;
    }

    public void setFields(ArrayList<String> fields) {
        this.fields = fields;
    }

    public String getPivots() {
        return pivots;
    }

    public void setPivots(String pivots) {
        this.pivots = pivots;
    }

    public String getFillFields() {
        return fillFields;
    }

    public void setFillFields(String fillFields) {
        this.fillFields = fillFields;
    }

    public Map<String, String> getFilters() {
        return filters;
    }

    public void setFilters(Map<String, String> filters) {
        this.filters = filters;
    }

    public String getFilterExpression() {
        return filterExpression;
    }

    public void setFilterExpression(String filterExpression) {
        this.filterExpression = filterExpression;
    }

    public ArrayList<String> getSorts() {
        return sorts;
    }

    public void setSorts(ArrayList<String> sorts) {
        this.sorts = sorts;
    }

    public String getLimit() {
        return limit;
    }

    public void setLimit(String limit) {
        this.limit = limit;
    }

    public String getColumnLimit() {
        return columnLimit;
    }

    public void setColumnLimit(String columnLimit) {
        this.columnLimit = columnLimit;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getRowTotal() {
        return rowTotal;
    }

    public void setRowTotal(String rowTotal) {
        this.rowTotal = rowTotal;
    }

    public String getSubtotals() {
        return subtotals;
    }

    public void setSubtotals(String subtotals) {
        this.subtotals = subtotals;
    }

    public Object getVisConfig() {
        return visConfig;
    }

    public void setVisConfig(Object visConfig) {
        this.visConfig = visConfig;
    }

    public Object getFilterConfig() {
        return filterConfig;
    }

    public void setFilterConfig(Object filterConfig) {
        this.filterConfig = filterConfig;
    }

    public String getVisibleUiSections() {
        return visibleUiSections;
    }

    public void setVisibleUiSections(String visibleUiSections) {
        this.visibleUiSections = visibleUiSections;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public Object getDynamic_fields() {
        return dynamic_fields;
    }

    public void setDynamic_fields(Object dynamic_fields) {
        this.dynamic_fields = dynamic_fields;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getShareUrl() {
        return shareUrl;
    }

    public void setShareUrl(String shareUrl) {
        this.shareUrl = shareUrl;
    }

    public String getExpandedShareUrl() {
        return expandedShareUrl;
    }

    public void setExpandedShareUrl(String expandedShareUrl) {
        this.expandedShareUrl = expandedShareUrl;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getQueryTimezone() {
        return queryTimezone;
    }

    public void setQueryTimezone(String queryTimezone) {
        this.queryTimezone = queryTimezone;
    }

    public String getHasTableCalculations() {
        return hasTableCalculations;
    }

    public void setHasTableCalculations(String hasTableCalculations) {
        this.hasTableCalculations = hasTableCalculations;
    }

    public String getRuntime() {
        return runtime;
    }

    public void setRuntime(String runtime) {
        this.runtime = runtime;
    }
}
