package com.mckesson.app.domain.looker;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import main.java.com.mckesson.app.util.StringArrayConverter;

/**
 * CustomFilter.java
 * Top level structure used to represent a custom filter definition.
 */
@Entity
@Table(name = "looker_dyn_field")
public class CustomFilter {

    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY,
            generator = "native"
    )
    @Column(name = "LDF_ID")
    private Long id;

    /**
     * User defined name.
     */
    @NotNull(message = "Filter name must be supplied")
    @Column(name = "LDF_NAME")
    private String name;

    /**
     * Reference to author.
     */
    @Column(name = "USER_ID")
    private String userId;

    @Column(name = "LDF_IS_SHARED")
    private boolean shared;

    /**
     * The overall grouping for the custom filter.
     */
    @JsonManagedReference
    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "filter")
    private FilterCriteriaGroup criteriaGroup;

    /**
     * When value is present, then any records which do not match criteria for any given group will adopt the label 'Other'
     */
    @Column(name = "LDF_DEFAULT_OTHER")
    private boolean useOtherAsDefaultGroup;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Column(name = "LDF_CREATION_DATE")
    private Date creationDate;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'")
    @Column(name = "LDF_LAST_UPDATE")
    private Date lastUpdateDate;

    @Column(name = "LDF_AUTHOR")
    private String author;

    @Column(name = "SHARED_TEAMS")
    @Convert(converter = StringArrayConverter.class)
    private String[] sharedTeams;

    @Column(name = "LDF_EXPLORE")
    private String explore;

    @Column(name = "LDF_OTHER_DEFINITION")
    private String otherDefinition;

    public CustomFilter() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public boolean isShared() {
        return shared;
    }

    public void setShared(boolean shared) {
        this.shared = shared;
    }

    public FilterCriteriaGroup getCriteriaGroup() {
        return criteriaGroup;
    }

    public void setCriteriaGroup(FilterCriteriaGroup criteriaGroup) {
        this.criteriaGroup = criteriaGroup;
    }

    public boolean isUseOtherAsDefaultGroup() {
        return useOtherAsDefaultGroup;
    }

    public void setUseOtherAsDefaultGroup(boolean useOtherAsDefaultGroup) {
        this.useOtherAsDefaultGroup = useOtherAsDefaultGroup;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String[] getSharedTeams() {
        return sharedTeams;
    }

    public void setSharedTeams(String[] sharedTeams) {
        this.sharedTeams = sharedTeams;
    }

    public String getExplore() {
        return explore;
    }

    public void setExplore(String explore) {
        this.explore = explore;
    }

    public String getOtherDefinition() {
        return otherDefinition;
    }

    public void setOtherDefinition(String otherDefinition) {
        this.otherDefinition = otherDefinition;
    }
}
