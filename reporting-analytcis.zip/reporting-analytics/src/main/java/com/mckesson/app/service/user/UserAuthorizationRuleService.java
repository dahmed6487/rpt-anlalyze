package com.mckesson.app.service.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.auth.user.UserAuthorizationRule;
import main.java.com.mckesson.app.repository.user.UserAuthorizationRuleRepository;

@Service
public class UserAuthorizationRuleService {

    private final UserAuthorizationRuleRepository userAuthRuleRepo;

    @Autowired
    public UserAuthorizationRuleService(UserAuthorizationRuleRepository userAuthRuleRepo) {
        this.userAuthRuleRepo = userAuthRuleRepo;
    }

    public List<UserAuthorizationRule> findRules(String userId) {
        return userAuthRuleRepo.findByUserId(userId);
    }

    public void saveRules(List<UserAuthorizationRule> rules) {
        userAuthRuleRepo.saveAll(rules);
    }

    public void deleteRules(List<UserAuthorizationRule> rules) {
        userAuthRuleRepo.deleteAll(rules);
    }
}
