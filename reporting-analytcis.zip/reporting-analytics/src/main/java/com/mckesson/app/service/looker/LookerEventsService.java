package com.mckesson.app.service.looker;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.domain.looker.LookerEvent;
import main.java.com.mckesson.app.repository.looker.LookerEventsRepository;

@Service
public class LookerEventsService {

    private final LookerEventsRepository lookerEventsRepo;

    @Autowired
    public LookerEventsService(LookerEventsRepository lookerEventsRepo) {
        this.lookerEventsRepo = lookerEventsRepo;
    }

    @Transactional
    public LookerEvent insertLookerEvent(LookerEvent event) {
        return lookerEventsRepo.saveAndFlush(event);
    }
}
