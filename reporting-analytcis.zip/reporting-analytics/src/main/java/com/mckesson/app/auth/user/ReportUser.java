package com.mckesson.app.auth.user;

import java.io.Serializable;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.oauth2.core.user.OAuth2User;

import main.java.com.mckesson.app.auth.permission.UserRole;

public interface ReportUser extends OAuth2User, UserDetails, Serializable {

    String USER = "ROLE_USER";
    String ADMIN = "ROLE_ADMIN";

    String getUserDisplayName();

    String getUsername();

    String getOriginalUsername();

    String getFirstName();

    String getLastName();

    String getUserEmail();

    String getMarketPartition();

    String getBlaEligible();

    boolean isSuperAdmin();

    boolean isInternal();

    boolean isCustomer();

    boolean isCustomerUser();

    boolean canSudo();

    boolean canAccessAllAccounts();

    boolean hasHealthSystem123Access();

    boolean canCreateCustomGroups();

    boolean canShareToTeams();

    boolean canManageRoles();

//  public List<BusinessAccessType> getBusinessAccess(); // Implement for existing implementations to use only MMS

    UserRole getRole();
    String getOriginalUserSudoFlag();

//  public boolean isMMSAccess();

//  public boolean isPharmaAccess();

    UserAccessModel getUserAccessModel();

    String getSudoFirstName();
    String getSudoLastName();
    String getSudoUsername();
    String getSudoEmailAddress();
    boolean isSudoUser();
    UserRole getSudoRole();

    void setSudoRole(UserRole sudoRole);

    void setSudoFirstName(String sudoFirstName);

    void setSudoLastName(String sudoLastName);

    void setSudoUsername(String sudoUsername);

    void setSudoEmailAddress(String sudoEmailAddress);

    void setSudoUser(boolean sudoUser);

    void setUsername(String username);

    void setRole(UserRole role);

    void setOriginalUserSudoFlag(String getOriginalUserSudoFlag);

    void setFirstName(String firstName);

    void setLastName(String lastName);

    void setEmailAddress(String emailAddress);

}
