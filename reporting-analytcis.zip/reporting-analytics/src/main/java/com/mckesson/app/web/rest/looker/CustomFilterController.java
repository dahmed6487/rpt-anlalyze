package com.mckesson.app.web.rest.looker;

import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.APPLICATION_JSON_UTF8_VALUE;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Sets;

import main.java.com.mckesson.app.domain.looker.CustomFilter;
import main.java.com.mckesson.app.domain.looker.FilterCriteria;
import main.java.com.mckesson.app.service.admin.CollaborationTeamService;
import main.java.com.mckesson.app.service.looker.CustomFilterService;
import main.java.com.mckesson.app.util.UserAuthentication;
import main.java.com.mckesson.app.vo.CustomFilterGroupSummary;
import main.java.com.mckesson.app.vo.CustomFilterSummary;

/**
 * API endpoint for custom dimension/custom grouping definition management.
 */
@RestController
@RequestMapping("/custom-filters")
public class CustomFilterController {

    private final UserAuthentication userAuthentication;
    private final CollaborationTeamService collaborationTeamService;
    private final CustomFilterService customFilterService;

    @Autowired
    public CustomFilterController(UserAuthentication userAuthentication, CollaborationTeamService collaborationTeamService, CustomFilterService customFilterService) {
        this.userAuthentication = userAuthentication;
        this.collaborationTeamService = collaborationTeamService;
        this.customFilterService = customFilterService;
    }

    private final Logger logger = LoggerFactory.getLogger(CustomFilterController.class);

    @RequestMapping(method = RequestMethod.POST, produces = APPLICATION_JSON, consumes = APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity createCustomFilter(@RequestBody CustomFilter customFilter) {
        // The "author" of the custom group will be the logged in user that created the group
        String userId = userAuthentication.getLoggedInUser().getUsername();

        // Persist the top level CustomFilter
        CustomFilter newCustomFilter = customFilterService.createCustomFilter(customFilter, userId);

        // Update the CustomFilter with a FilterCriteriaGroup
        newCustomFilter = customFilterService.updateCriteriaGroup(newCustomFilter);

        return new ResponseEntity(newCustomFilter, HttpStatus.CREATED);
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity listCustomFilters() {
        // Get the Okta user that is logged into the app as well as the customer user picked from the dropdown
        String userID = userAuthentication.getLoggedInUser().getUsername();

        // Build a list of customer names and a list of team ids to filter on
        HashSet<String> teamIdsForUser = Sets.newHashSet(collaborationTeamService.getTeamIdsForCurrentUser(userID));
        List<CustomFilterSummary> filters = customFilterService.listCustomFilters(0, 100);
        // Security
        // If the logged in user created the group they can see it.
        // If the logged in user is viewing the application as the customer that created the group they can see it.
        // If the customer is mapped to a team that the group has been shared with they can see it.
        List<CustomFilterSummary> filtersForUser = filters.stream()
                .filter(filter -> {
                    List<String> teams = Arrays.asList(filter.getSharedTeams());
                    return userID.equalsIgnoreCase(filter.getAuthor())
                            || userID.equalsIgnoreCase(filter.getUserId())
                            || teamIdsForUser.stream().anyMatch(teams::contains);
                })
                .collect(Collectors.toList());
        logger.debug("Returning " + filtersForUser.size() + " filters");
        return new ResponseEntity(filtersForUser, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/search")
    public ResponseEntity searchCustomFilters(@RequestParam String page, @RequestParam String search) {
        String userID = userAuthentication.getLoggedInUser().getUsername();
        Page<CustomFilter> filters = customFilterService.searchCustomFilters(Integer.parseInt(page), userID, search);
        return new ResponseEntity(filters.getContent(), HttpStatus.OK);
    }

    /**
     * For a given custom group identifier, returns the Group containing the name of the group and a link to
     * the groupings.
     *
     * @param filterId the identifier for the custom group
     * @return The {@link CustomFilterGroupSummary} linking the groupings to the overall filter
     */
    @RequestMapping(method = RequestMethod.GET, value = "groups/{filterId}")
    public ResponseEntity getCustomFilterGroup(@PathVariable("filterId") Long filterId) {
        CustomFilterGroupSummary filterGroup = customFilterService.getCustomFilterGroupForFilter(filterId);
        return new ResponseEntity(filterGroup, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET, value = "criteria/{id}")
    public ResponseEntity getFilterCriteria(@PathVariable("id") Long criteriaId) {
        FilterCriteria filterCriteria = customFilterService.getFilterCriteria(criteriaId);
        return new ResponseEntity(filterCriteria, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "criteria/{id}")
    public ResponseEntity deleteFilterCriteria(@PathVariable("id") Long criteriaId) {
        boolean successful = customFilterService.deleteFilterCriteria(criteriaId);
        return new ResponseEntity(successful, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.POST, value = "criteria")
    public ResponseEntity createFilterCriteria(@RequestParam("groupId") Long groupId, @RequestBody FilterCriteria filterCriteria) {
        FilterCriteria newCriteria = customFilterService.createFilterCriteria(filterCriteria, groupId);
        return new ResponseEntity(newCriteria, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "criteria/{id}")
    public ResponseEntity updateFilterCriteria(@PathVariable("id") Long criteriaId, @RequestBody FilterCriteria filterCriteria) {
        FilterCriteria existingCriteria = customFilterService.updateFilterCriteria(filterCriteria, criteriaId);
        return new ResponseEntity(existingCriteria, HttpStatus.OK);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public ResponseEntity getCustomFilter(@PathVariable Long id) {
        return new ResponseEntity(customFilterService.getCustomFilter(id), HttpStatus.OK);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.PUT, consumes = "application/json")
    public ResponseEntity update(@RequestBody CustomFilter customFilter) {
        String userID = userAuthentication.getLoggedInUser().getUsername();
        return new ResponseEntity(customFilterService.update(customFilter, userID), HttpStatus.OK);
    }

    @RequestMapping(value = "/share/{id}", method = RequestMethod.PUT, consumes = "application/json")
    public ResponseEntity share(@PathVariable Long id, @RequestBody String[] teams) {
        String userID = userAuthentication.getLoggedInUser().getUsername();
        return new ResponseEntity(customFilterService.share(id, teams, userID), HttpStatus.OK);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public ResponseEntity delete(@PathVariable Long id) {
        customFilterService.delete(id);
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity handleException(Exception e) {
        e.printStackTrace();
        return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(SecurityException.class)
    public ResponseEntity handleSecurityException(SecurityException e) {
        e.printStackTrace();
        return new ResponseEntity(HttpStatus.UNAUTHORIZED);
    }
}
