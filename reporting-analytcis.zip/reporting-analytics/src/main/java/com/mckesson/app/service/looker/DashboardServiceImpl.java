package com.mckesson.app.service.looker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import main.java.com.mckesson.app.domain.looker.DashboardFilter;
import main.java.com.mckesson.app.domain.looker.DashboardFilterSharedTeam;
import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.repository.looker.DashboardFilterRepository;
import main.java.com.mckesson.app.service.admin.CollaborationTeamService;
import main.java.com.mckesson.app.service.looker.api.DashboardApi;
import main.java.com.mckesson.app.vo.looker.DashboardFilterConfigResponseVo;
import main.java.com.mckesson.app.vo.looker.DashboardVo;

@Service("DashboardService")
public class DashboardServiceImpl implements DashboardService {

    Logger logger = LoggerFactory.getLogger(DashboardServiceImpl.class);

    private final DashboardFilterRepository dashboardFilterRepo;
    private final DashboardApi dashboardApi;
    private final CollaborationTeamService teamService;

    @Autowired
    public DashboardServiceImpl(DashboardApi dashboardApi, DashboardFilterRepository dashboardFilterRepo, CollaborationTeamService teamService) {
        this.dashboardApi = dashboardApi;
        this.dashboardFilterRepo = dashboardFilterRepo;
        this.teamService = teamService;
    }

    @Value("${looker.host}")
    private String lookerHost;

    @Override
    public void deleteFilter(String filterId) {
        this.dashboardFilterRepo.deleteById(new Integer(filterId));
    }

    public DashboardFilterVo createFilter(String userId, DashboardFilterVo filterVo) {
        DashboardFilter filter = convertVoToBo(filterVo);
        filter.setAuthorId(userId);
        filter = this.dashboardFilterRepo.save(filter);
        return convertBoToDto(filter);
    }

    public DashboardFilterVo updateFilter(DashboardFilterVo filterVo) {
        Optional<DashboardFilter> filter = this.dashboardFilterRepo.findById(filterVo.getId());
        DashboardFilter existing = filter.get();
        existing.setName(filterVo.getName());
        existing.setCriteriaValue(filterVo.getCriteriaValue());
        this.dashboardFilterRepo.save(existing);
        return filterVo;
    }

    HashMap<String, String> getUniqueModelRefs(List<DashboardFilterVo> filters) {
        HashMap<String, String> uniqueModelRefs = new HashMap();
        for (DashboardFilterVo dbFilter : filters) {
            uniqueModelRefs.put(dbFilter.getModel() + "-->" + dbFilter.getExplore() + "-->" + dbFilter.getDimension(), "");
        }
        return uniqueModelRefs;
    }

    DashboardVo getLookerDashboardById(String dashboardId) {
        String authToken = dashboardApi.getAuthToken();
        String[] fields = {"id", "name", "dashboard_filters"};
        DashboardVo dashboard;
        try {
            dashboard = dashboardApi.getDashboard(dashboardId, fields, authToken);
        } catch (Exception e) {
            logger.warn("error during dashboard meta data load **");
            throw new ApiException("Exception ocurred during dashboard meta data fetch");
        }
        return dashboard;
    }

    List<DashboardFilterVo> getSavedFilters(String model, String explore, String dimension, String currentUserId) {
        List<DashboardFilter> filterBos;
        List<DashboardFilterVo> filterVos;
        filterBos = dashboardFilterRepo.findSharedFiltersByAttributes(model, explore, dimension, currentUserId);
        filterVos = convertBosToDtos(filterBos);
        for (DashboardFilterVo filter : filterVos) {
            filter.setEditable(true);
        }
        return filterVos;
    }

    List<Integer> getTeamIdsForCurrentUser(String userId) {
        HashSet<String> teamsForCurrentUser = teamService.getTeamIdsForCurrentUser(userId);
        List<Integer> teamIds = new ArrayList();
        Iterator<String> i = teamsForCurrentUser.iterator();
        while (i.hasNext()) {
            teamIds.add(new Integer(i.next()));
        }
        return teamIds;
    }

    public DashboardFilterConfigResponseVo loadDashboardFilterConfig(String userId, String dashboardId) {
        //String currentUserId = SecurityUtils.getCurrentCustomer().getUsername();

        logger.debug("Retrieving filters cur user " + userId);

        //Dashboard information is retrieved from the Looker API. This is performed in order to obtain meta information about
        //the dashboard related filters, and associations to model/explore/dimension for each.
        DashboardVo dashboard = getLookerDashboardById(dashboardId);

        //All unique model/explore/dimension combinations are identified
        HashMap<String, String> uniqueModelRefs = getUniqueModelRefs(dashboard.getDashboardFilters());

        //All saved filters for each unique model/explore/dimension are retrieved from the database.
        Iterator<String> i = uniqueModelRefs.keySet().iterator();
        String ref;
        String[] tokens;
        List<DashboardFilterVo> applicableFilters = new ArrayList();
        List<Integer> teamIds = getTeamIdsForCurrentUser(userId);

        while (i.hasNext()) {
            ref = i.next();
            tokens = ref.split("-->");
            logger.debug("Retrieving saved folders: model=>'" + tokens[0] + "' explore=>'" + tokens[1] + "' dimension=>'" + tokens[2] + "'");

            if (userId == "%") {
                userId = "ALL";
            }

            //Retrieve all filters saved via previous sessions.
            List<DashboardFilterVo> savedFilters = getSavedFilters(tokens[0], tokens[1], tokens[2], userId);
            for (DashboardFilterVo filter : savedFilters) {
                filter.setEditable(true);
            }
            applicableFilters.addAll(savedFilters);

            List<DashboardFilterVo> sharedFilters = getSharedFilters(teamIds, tokens[0], tokens[1], tokens[2], userId);
            for (DashboardFilterVo f : sharedFilters) {
                f.setSharedWithUser(true);
            }
            applicableFilters.addAll(sharedFilters);
        }

        DashboardFilterConfigResponseVo response = new DashboardFilterConfigResponseVo(applicableFilters, dashboard.getDashboardFilters());

        //Reference to looker host set; this is env specific property is required as required to broadcast filter change events from saved filters
        //to the emed iframe.
        response.setLookerHost(lookerHost);
        return response;
    }

    List<DashboardFilterVo> getSharedFilters(List<Integer> teamIds, String model, String explore, String dimension, String currentUser) {
        List<DashboardFilterVo> sharedFilters = new ArrayList();
        if (currentUser == "%") {
            currentUser = "ALL";
        }

        if (!teamIds.isEmpty()) {
            List<DashboardFilter> sharedFilterBos = dashboardFilterRepo.findFiltersBySharedTeams(teamIds, model, explore, dimension, currentUser);
            sharedFilters.addAll(convertBosToDtos(sharedFilterBos));
        }
        return sharedFilters;
    }

    List<DashboardFilterVo> convertBosToDtos(List<DashboardFilter> bos) {
        List<DashboardFilterVo> results = new ArrayList();

        for (DashboardFilter bo : bos) {
            results.add(convertBoToDto(bo));
        }

        return results;
    }

    DashboardFilterVo convertBoToDto(DashboardFilter bo) {
        DashboardFilterVo dto = new DashboardFilterVo();

        dto.setId(bo.getId());
        dto.setAuthorId(bo.getAuthorId());
        dto.setModel(bo.getModel());
        dto.setCriteriaValue(bo.getCriteriaValue());
        dto.setExplore(bo.getExplore());
        dto.setDimension(bo.getDimension());
        dto.setTitle(bo.getTitle());
        dto.setName(bo.getName());

        String[] teams = new String[bo.getSharedTeams().size()];

        //for(DashboardFilterSharedTeam team:teams.length) {
        for (int x = 0; x < bo.getSharedTeams().size(); x++) {
            teams[x] = bo.getSharedTeams().get(x).getTeamId().toString();
        }

        dto.setSharedTeams(teams);

        return dto;
    }

    List<DashboardFilter> convertVosToBos(List<DashboardFilterVo> vos) {
        List<DashboardFilter> bos = new ArrayList();
        for (DashboardFilterVo vo : vos) {
            bos.add(convertVoToBo(vo));
        }
        return bos;
    }

    /**
     * Convert vo representations from vo to bo (persistent) format. Screen will represent shared teams as a simple
     * string array, whereas the persistence model will require the teams to be represented as a collection of objects.
     *
     * @param vo
     * @return
     */
    DashboardFilter convertVoToBo(DashboardFilterVo vo) {
        DashboardFilter filter = new DashboardFilter();

        filter.setAuthorId(vo.getAuthorId());
        filter.setModel(vo.getModel());
        filter.setCriteriaValue(vo.getCriteriaValue());
        filter.setExplore(vo.getExplore());
        filter.setDimension(vo.getDimension());
        filter.setTitle(vo.getTitle());
        filter.setName(vo.getName());

        DashboardFilterSharedTeam team;
        if (vo.getSharedTeams() != null) {
            for (int x = 0; x < vo.getSharedTeams().length; x++) {
                team = new DashboardFilterSharedTeam(new Integer(vo.getSharedTeams()[x]));
                filter.getSharedTeams().add(team);
            }
        }

        return filter;
    }

    @Transactional
    public void updateSharedGroups(String filterId, String[] sharedTeams) {
        DashboardFilter existing = this.dashboardFilterRepo.getOne(new Integer(filterId));

        logger.debug("Existing number of teams: " + existing.getSharedTeams().size());

        List<Integer> deletedIds = getDeletedTeams(existing.getSharedTeams(), sharedTeams);

        for (Integer sharedRecordId : deletedIds) {
            for (int x = 0; x < existing.getSharedTeams().size(); x++) {
                if (existing.getSharedTeams().get(x).getId().intValue() == sharedRecordId) {
                    existing.getSharedTeams().remove(x);
                    break;
                }
            }
        }

        List<Integer> newIds = getNewTeams(existing.getSharedTeams(), sharedTeams);
        DashboardFilterSharedTeam team;
        for (Integer newTeamId : newIds) {
            team = new DashboardFilterSharedTeam(newTeamId);
            team.setFilter(existing);
            existing.getSharedTeams().add(team);
        }

        logger.debug("Updated number of teams: " + existing.getSharedTeams().size());

        this.dashboardFilterRepo.save(existing);
    }

    List<Integer> getDeletedTeams(List<DashboardFilterSharedTeam> existing, String[] newTeamState) {
        List<Integer> ids = new ArrayList();
        if (existing == null | existing.size() == 0) {
            return ids;
        }

        if (newTeamState.length == 0) {
            for (DashboardFilterSharedTeam team : existing) {
                ids.add(team.getId());
                return ids;
            }
        }

        //Any existing id 'not present' in the new state is considered deleted...
        Integer[] newTeamStateIds = convertStringToIntegerArray(newTeamState);

        for (DashboardFilterSharedTeam team : existing) {
            boolean exists = false;
            for (Integer newStateId : newTeamStateIds) {
                if (team.getTeamId().compareTo(newStateId) == 0) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                ids.add(team.getId());
            }
        }

        return ids;
    }

    List<Integer> getNewTeams(List<DashboardFilterSharedTeam> existing, String[] newTeamState) {
        List<Integer> ids = new ArrayList();
        if (existing == null) {
            return ids;
        }

        if (newTeamState.length == 0) {
            return ids;
        }

        Integer[] newTeamStateIds = convertStringToIntegerArray(newTeamState);
        if (existing == null || existing.size() == 0) {
            for (Integer id : newTeamStateIds) {
                ids.add(id);
            }
            return ids;
        }

        //Any id present in the 'new state' that is not present in the existing set is considered 'new'
        for (Integer newStateId : newTeamStateIds) {
            boolean exists = false;
            for (DashboardFilterSharedTeam team : existing) {
                if (team.getTeamId().compareTo(newStateId) == 0) {
                    exists = true;
                    break;
                }
            }
            if (!exists) {
                ids.add(newStateId);
            }
        }

        return ids;
    }

    Integer[] convertStringToIntegerArray(String[] stringArray) {
        Integer[] result = new Integer[stringArray.length];

        for (int x = 0; x < stringArray.length; x++) {
            result[x] = new Integer(stringArray[x]);
        }

        return result;
    }
}
