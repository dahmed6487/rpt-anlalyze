package com.mckesson.app.domain.looker;

import java.beans.Transient;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "looker_filter")
public class DashboardFilter {

    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY,
            generator = "native"
    )
    @Column(name = "id")
    private Integer id;

    //Column reference
    @Column(name = "dimension")
    private String dimension;

    @Column(name = "model")
    private String model;

    @Column(name = "criteria_value")
    private String criteriaValue;

    @Column(name = "explore")
    private String explore;

    //User assigned name for saved filter.
    @Column(name = "name")
    private String name;

    @Column(name = "title")
    private String title;

    @Transient
    private boolean applied = false;

    @Column(name = "author_id")
    private String authorId;

    @OneToMany(cascade = CascadeType.ALL,
            mappedBy = "filter",
            orphanRemoval = true)
    //@JoinColumn(name="looker_filter_id")
    private List<DashboardFilterSharedTeam> sharedTeams = new ArrayList();

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getExplore() {
        return explore;
    }

    public void setExplore(String explore) {
        this.explore = explore;
    }

    public String getCriteriaValue() {
        return criteriaValue;
    }

    public void setCriteria(String criteriaValue) {
        this.criteriaValue = criteriaValue;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isApplied() {
        return applied;
    }

    public void setApplied(boolean applied) {
        this.applied = applied;
    }

    public String getAuthorId() {
        return authorId;
    }

    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }

    public void setCriteriaValue(String criteriaValue) {
        this.criteriaValue = criteriaValue;
    }

    public List<DashboardFilterSharedTeam> getSharedTeams() {
        return sharedTeams;
    }

    public void setSharedTeams(List<DashboardFilterSharedTeam> sharedTeams) {
        this.sharedTeams = sharedTeams;
    }

    public String toString() {
        return "id=> " + this.id + " name=>" + this.name + " this.title=>" + this.title;
    }
}
