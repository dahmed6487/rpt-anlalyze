package com.mckesson.app.util;

public class SecurityException extends RuntimeException {
    public SecurityException(String msg) {
        super(msg);
    }
}
