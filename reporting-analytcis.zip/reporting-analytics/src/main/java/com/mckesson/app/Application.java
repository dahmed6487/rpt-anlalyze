package com.mckesson.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;

import com.mckesson.lib.spring.config.annotation.EnableMCK;
import com.mckesson.lib.spring.config.annotation.EnableMCKAppSecurity;

@EnableRetry
@SpringBootApplication
@EnableMCK
@EnableMCKAppSecurity
public class Application {
    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
