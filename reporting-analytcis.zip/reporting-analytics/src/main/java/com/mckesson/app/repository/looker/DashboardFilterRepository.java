package com.mckesson.app.repository.looker;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import main.java.com.mckesson.app.domain.looker.DashboardFilter;

public interface DashboardFilterRepository extends JpaRepository<DashboardFilter, Integer> {

    /** Retrieve all applicable filters that have been shared with a given set of groups that do not belong to the current user. */
    //@Query("select f from DashboardFilter f where f.model = ?1 and f.explore = ?2 and f.dimension = ?3 and f.sharedTeams.contains(?4) and f.authorId!= ?5")
    //public List<DashboardFilter> findSharedFilterByAttributes(String model, String explore, String dimension, String teamId, String userId);

    /**
     * Retrieve all applicable filters for current user.
     */
    @Query("select f from DashboardFilter f where f.model = ?1 and f.explore = ?2 and f.dimension = ?3 and author_id = ?4")
    List<DashboardFilter> findSharedFiltersByAttributes(String model, String explore, String dimension, String authorId);

    /**
     * Retrieve pks of all filters that have been shared with the specified set of criteria.
     */
    @Query("select fg.filter from DashboardFilterSharedTeam fg where fg.teamId in ?1 and fg.filter.model = ?2 and fg.filter.explore = ?3 and fg.filter.dimension = ?4 and fg.filter.authorId != ?5")
    List<DashboardFilter> findFiltersBySharedTeams(List<Integer> teamIds, String model, String explore, String dimension, String authorId);

}
