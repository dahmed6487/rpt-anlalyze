package com.mckesson.app.domain.customer;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Where;

import main.java.com.mckesson.app.domain.admin.Module;

@Entity
@Table(name = "user_mapping")
@Where(clause = "deleted_date is null")
public class UserMapping {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "native")
    @Column(name = "user_mapping_id")
    private Long userMappingId;
    @Column(name = "customer_id")
    private Long customerId;
    @Column(name = "platform")
    private String platformId;
    @Column(name = "user_id")
    private String username;
    @Column(name = "user_type")
    private String userType;
    @Column(name = "created_by")
    private String createdBy;
    @Column(name = "created_date")
    private Date createdDate;
    @Column(name = "updated_by")
    private String updatedBy;
    @Column(name = "updated_date")
    private Date updatedDate;
    @Column(name = "deleted_by")
    private String deletedBy;
    @Column(name = "deleted_date")
    private Date deletedDate;

    public UserMapping() {
    }

  /*  @ManyToOne(fetch=FetchType.LAZY)
    @NotFound(action = NotFoundAction.IGNORE)// Handy to throw exception
    @JoinColumn(name = "customer_id", referencedColumnName = "customer_id",insertable = false,updatable = false)
    private Customer customerUserMapping;*/

   /* @ManyToMany(fetch=FetchType.LAZY)
    @JoinTable(
            name = "user_map_collab_team_relation",
            joinColumns = @JoinColumn(name = "user_mapping_id"),
            inverseJoinColumns = @JoinColumn(name = "collaboration_team_id"))
    private Collection<CollaborationTeam> collaborationTeam;*/

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "user_map_security_group_relation",
            joinColumns = @JoinColumn(name = "user_mapping_id"),
            inverseJoinColumns = @JoinColumn(name = "security_group_id"))
    private Collection<SecurityGroup> securityGroup;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(
            name = "user_map_module_relation",
            joinColumns = @JoinColumn(name = "user_mapping_id"),
            inverseJoinColumns = @JoinColumn(name = "module_id"))
    private Collection<Module> module;

  /*  public Customer getCustomerUserMapping() {
        return customerUserMapping;
    }

    public void setCustomerUserMapping(Customer customerUserMapping) {
        this.customerUserMapping = customerUserMapping;
    }

    public Collection<CollaborationTeam> getCollaborationTeam() {
        return collaborationTeam;
    }

    public void setCollaborationTeam(Collection<CollaborationTeam> collaborationTeam) {
        this.collaborationTeam = collaborationTeam;
    }*/

    public Collection<SecurityGroup> getSecurityGroup() {
        return securityGroup;
    }

    public void setSecurityGroup(Collection<SecurityGroup> securityGroup) {
        this.securityGroup = securityGroup;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Collection<Module> getModule() {
        return module;
    }

    public void setModule(Collection<Module> module) {
        this.module = module;
    }

    public Long getUserMappingId() {
        return userMappingId;
    }

    public void setUserMappingId(Long userMappingId) {
        this.userMappingId = userMappingId;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public String getPlatformId() {
        return platformId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

}
