package com.mckesson.app.service.looker;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.auth.user.ConnectUser;
import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.misc.EntityNotFoundException;
import main.java.com.mckesson.app.misc.ErrorMessagesEnum;
import main.java.com.mckesson.app.service.ApplicationLogService;
import main.java.com.mckesson.app.service.looker.api.ContentApi;
import main.java.com.mckesson.app.service.looker.api.DashboardApi;
import main.java.com.mckesson.app.service.looker.api.FolderApi;
import main.java.com.mckesson.app.service.looker.api.GroupApi;
import main.java.com.mckesson.app.service.looker.api.LookApi;
import main.java.com.mckesson.app.service.looker.api.QueryApi;
import main.java.com.mckesson.app.service.looker.api.SpaceApi;
import main.java.com.mckesson.app.service.looker.api.UserApi;
import main.java.com.mckesson.app.vo.ReportItemVo;
import main.java.com.mckesson.app.vo.looker.DashboardElementVo;
import main.java.com.mckesson.app.vo.looker.DashboardVo;
import main.java.com.mckesson.app.vo.looker.FolderVo;
import main.java.com.mckesson.app.vo.looker.LookVo;
import main.java.com.mckesson.app.vo.looker.UserVo;

@Service("SpaceManagementService")
public class SpaceManagementServiceImpl extends BaseSpaceManagementService implements SpaceManagementService {

    Logger logger = LoggerFactory.getLogger(SpaceManagementServiceImpl.class);

    private final ApplicationLogService applicationLogService;
    private final QueryApi queryApi;

    @Autowired
    public SpaceManagementServiceImpl(
            SpaceApi spaceApi,
            UserApi userApi,
            DashboardApi dashboardApi,
            LookApi lookApi,
            FolderApi folderApi,
            ContentApi contentApi, ApplicationLogService applicationLogService, QueryApi queryApi, GroupApi groupApi) {

        super(spaceApi, userApi, dashboardApi, lookApi, folderApi, contentApi, queryApi, groupApi);
        this.applicationLogService = applicationLogService;
        this.queryApi = queryApi;
    }

    @Override
    public ReportItemVo getFolderStructureForCurrentUser(ReportUser reportUser) {
        String authToken = spaceApi.getAuthToken();
        if (reportUser.getUsername() == null) {
            logger.warn("Cannot identitify connect user");
            throw new AccessDeniedException("Cannot identify connect user!");
        }
        UserVo user = userApi.getUserByEmbed(reportUser.getUsername(), authToken);

        long startTime = System.currentTimeMillis();

        ReportItemVo results = getFolderStructure(user, authToken);

        logger.debug("Total time for retrieving folder structure for current user " + (System.currentTimeMillis() - startTime) + "ms");

        return results;
    }

    ReportItemVo getFolderStructure(UserVo user, String authToken) {
        //Note: data type mismatch between folder id (string) and reference on user object (string).
        return getFolderStructure(Long.toString(user.getPersonalSpaceId()), authToken);
    }

    /**
     * Retrieve contents of a user's directory. In order to retrieve the entire structure of user's directory, this call would be initially placed
     * for the user's 'root' folder, and then recursively made for each child folder in order to build the entire structure.
     * <p>
     * The process of identifying information for a given directory, and all folders and dashboards appearing under this directory requires multiple calls.
     */
    public ReportItemVo getFolderStructure(String parentFolderId, String authToken) {

        //Basic information for the current dashboard is retrieved.
        String[] folderFields = {"id", "name", "created_at", "parent_id"};
        FolderVo userFolder = spaceApi.getFolder(parentFolderId, folderFields, authToken);
        ReportItemVo rootItem = convertFolderToVo(userFolder);

        //Next we retrieve all dashboards belonging to the current folder.
        String[] dbFields = {"id", "title", "name", "description", "favorite_count", "created_at", "last_viewed_at", "deleted", "parent_id", "dashboard_elements"};
        String[] dbSummaryFields = {"id"};
        //Initial fetch to retrieve ids (minimal attributes) of dashboard appearing in the selected space; this may optionally
        List<DashboardVo> dashboards = spaceApi.getDashboardsForFolder(parentFolderId, dbSummaryFields, authToken);

        //In order to reflect the date the dashboard was last updated, we need to traverse down to the tile element, comparing the 'last updated' attribute
        //of each individual tile.
        HashMap<String, String> existingLookTitles = new HashMap();
        DashboardVo dbDetail;
        for (DashboardVo dashboard : dashboards) {
            dbDetail = dashboardApi.getDashboard(dashboard.getId(), dbFields, authToken);
            dashboard.setLastUpdated(getMostRecentUpdatedDate(dbDetail));
            rootItem.getChildren().add(convertDashboardToVo(dbDetail,true,null));

            if (dashboard.getDashboardElements() != null) {
                for (DashboardElementVo dbElement : dashboard.getDashboardElements()) {
                    if (dbElement.getLook() != null) {
                        existingLookTitles.put(dbElement.getLook().getTitle(), null);
                    }
                }
            }

        }

        String[] lookFields = {"id", "title", "description", "updated_at","query"};
        List<LookVo> looks = spaceApi.getLooksForFolder(parentFolderId, lookFields, authToken);
        for (LookVo look : looks) {
            //Ensure that if a dashboard has been loaded from the previous operation, that...?
            if (look.isDeleted() || existingLookTitles.containsKey(look.getTitle())) {
                continue;
            }
            rootItem.getChildren().add(convertLookToVo(look,true,null));
        }

        //Finally, any child folders are identified, and the entire process is recursively performed for each. Whereas collections of dashboards and looks
        //may be retrieved by the fetch operation for a given dashboard, information about child folders is not immediately available, so a search operation is
        //then performed in order to retrieve this data.
        List<FolderVo> childFolders = spaceApi.getChildFolders(parentFolderId, authToken);
        for (FolderVo child : childFolders) {
            rootItem.getChildren().add(getFolderStructure(child.getId(), authToken));
        }

        return rootItem;
    }

    /**
     * @param dashboard
     * @return
     */
    String getMostRecentUpdatedDate(DashboardVo dashboard) {
        List<String> updateDates = new ArrayList();
        List<DashboardElementVo> elements = dashboard.getDashboardElements();
        String dateFmt;
        for (DashboardElementVo e : elements) {
            if (e.getLook() != null && e.getLook().getUpdatedAt() != null) {
                updateDates.add(getDateFormatted(e.getLook().getUpdatedAt()));
            }
        }

        if (updateDates.isEmpty() == false) {
            Collections.sort(updateDates);
            return updateDates.get(0);
        }

        return "";
    }
	
	
	/*
	public ReportItemVo getFolderStructure(String parentFolderId, String authToken) {

		ConnectUser currentUser = SecurityUtils.getCurrentConnectUser();
		
		if(authToken==null) {
			authToken = spaceApi.getAuthToken();
		}
		
		long startTime = System.currentTimeMillis(); 
		
		//Get root level folder
		String[] folderFields = {"id", "name", "created_at","parent_id"};
		FolderVo userFolder = spaceApi.getFolder(parentFolderId, folderFields, authToken);
		
		ReportItemVo rootItem = convertFolderToVo(userFolder);
		
		String[] fields = {"id","title","name", "description","favorite_count", "created_at", "last_viewed_at", "deleted","parent_id","dashboard_elements"};

		//List<LookVo> looks = spaceApi.getLooksForFolder(parentFolderId, fields, authToken);
		//rootItem.getChildren().addAll(convertLooksToVos(looks));
		
		List<DashboardVo> dashboards = spaceApi.getDashboardsForFolder(parentFolderId, fields, authToken);
		rootItem.getChildren().addAll(convertDashboardsToVos(dashboards));
		
		List<FolderVo> childFolders = spaceApi.getChildFolders(parentFolderId, authToken);
		for(FolderVo child:childFolders) {
			rootItem.getChildren().add(getFolderStructure(child.getId(), authToken));
		}
		
		formatTimestamps(rootItem);
		
		logger.debug("Total time in milliseconds for folder fetch operation '"+ userFolder.getName() +"' "+ userFolder.getId() +" is "+ (System.currentTimeMillis() - startTime) +"ms");
		
		return rootItem;
	}*/


    @Override
    public ReportItemVo createFolder(ReportUser reportUser, String name, String parentId) {

        String authToken = spaceApi.getAuthToken();


        if (reportUser.getUsername() == null) {
            logger.warn("Cannot identitify connect user");
            throw new AccessDeniedException("Cannot identify connect user!");
        }

        //String[] userFields = {"id","first_name","last_name","display_name","personal_space_id"};
        UserVo user = userApi.getUserByEmbed(reportUser.getUsername(), authToken);

        //If no parent folder is referenced, then we are adding the new folder to the user's root folder.
        if (parentId == null) {
            //Note: data type mismatch between folder id (string) and reference on user object (string).
            parentId = Long.toString(user.getPersonalSpaceId());
        }

        if (!doesFolderBelongToUser(reportUser, parentId, user, authToken)) {
            throw new ApiException("Requested action to create folder '" + name + "' for user id " + user.getId() + " under parent folder " + parentId);
        }

        FolderVo folder = new FolderVo();
        folder.setParentId(parentId);
        folder.setName(name);

        folder = spaceApi.createFolder(folder, authToken);

        ReportItemVo item = new ReportItemVo();
        item.setId(folder.getId());
        item.setName(name);
        item.setType(ReportItemVo.ITEM_TYPE_FOLDER);
        setDate(item);
        item.setLastActionType("Created");
        item.setLastActionAuthor(getCurrentUserNameFormatted(reportUser));

        return item;
    }

    @Override
    public void deleteFolder(ReportUser reportUser, String folderId) {

        String authToken = spaceApi.getAuthToken();
        String userID = reportUser.getUsername();
        if (userID == null) {
            logger.warn("Cannot identitify connect user");
            throw new AccessDeniedException("Cannot identify connect user!");
        }

        UserVo user = userApi.getUserByEmbed(userID, authToken);

        //Ensure selected folder belongs to the current embed user.
        if (!doesFolderBelongToUser(reportUser, folderId, user, authToken)) {
            logger.warn("Request to delete folder id=>" + folderId + " for user '" + user.getDisplayName() + "' failed; folder does not belong to current user.");
            throw new AccessDeniedException("User does not have access to delete the selected folder");
        }

        //Ensure selected folder is not the embed user's root folder.
        if (Long.parseLong(folderId) == user.getPersonalSpaceId()) {
            logger.warn("Request to delete folder id=>" + folderId + " for user '" + user.getDisplayName() + "' failed; target folder is user's embed space.");
            throw new AccessDeniedException("Cannot delete the selected user's root folder");
        }

        //Folder must be empty as well.
		/*
		List<ReportItemVo>targetFolderContents = listReportItems(folderId, authToken);
		if(!targetFolderContents.isEmpty()) {
			throw new AccessDeniedException("Cannot support request to delete folder '"+ folderId +"': Folder is not empty");
		}*/

        spaceApi.deleteFolder(folderId, authToken);
    }

    @Override
    public void deleteReport(ReportUser reportUser, String lookId) {
        String userID = reportUser.getUsername();
        if (userID == null) {
            logger.warn("Cannot identitify connect user");
            throw new AccessDeniedException("Cannot identify connect user!");
        }

        String authToken = spaceApi.getAuthToken();
        UserVo user = userApi.getUserByEmbed(userID, authToken);

        String[] fields = {"id", "name", "created_at"};
        FolderVo rootFolder = spaceApi.getFolder(Long.toString(user.getPersonalSpaceId()), fields, authToken);

        if (!doesLookBelongToUser(reportUser, lookId, user, authToken)) {
            throw new AccessDeniedException("Attempt to delete look for user failed (user does not have rights to manage");
        }

        lookApi.deleteLook(lookId, authToken);
    }


    @Override
    public void deleteDashboard(ReportUser reportUser, String dashboardId) {
        String userID = reportUser.getUsername();
        if (userID == null) {
            logger.warn("Cannot identitify connect user");
            throw new AccessDeniedException("Cannot identify connect user!");
        }

        String authToken = spaceApi.getAuthToken();
        UserVo user = userApi.getUserByEmbed(userID, authToken);

        String userAuthToken = userApi.getAuthTokenForUserId(authToken, user.getId());

        String[] fields = {"id", "name", "created_at"};
        FolderVo rootFolder = spaceApi.getFolder(Long.toString(user.getPersonalSpaceId()), fields, userAuthToken);

        if (!doesDashboardBelongToUser(reportUser, dashboardId, userApi.getUserByEmbed(userID, authToken), authToken)) {
            throw new AccessDeniedException("Attempt to delete look for user failed (user does not have rights to manage");
        }

        dashboardApi.deleteDashboard(dashboardId, userAuthToken);
    }


    /**
     * Embed users do not have the ability to create folders, so they are created under the system account. This
     * means that we cannot simply check the owner of the folder under which the new folder will be created.
     * <p>
     * Given a reference to a folder, if it the current user's root directory then by default is may be managed by the
     * current user. If a folder is a descendant of the current user's folder, it may also be managed by the user.
     *
     * @return
     */
    boolean doesFolderBelongToUser(ReportUser reportUser, String folderId, UserVo user, String authToken) {

        String[] fields = {"id", "name", "created_at"};
        //FolderVo selectedFolder;
        //selectedFolder = spaceApi.getFolder(folderId, fields, authToken);

        FolderVo rootFolder = getUsersRootFolder(reportUser, authToken);

        //If selected folder is reference to the user's root folder, then by default folder matches.
        if (rootFolder.getId().contentEquals(folderId)) {
            return true;
        }

        //Check to see if any of the folder's ancestor is the user's root folder...
        List<FolderVo> folders = spaceApi.getAncestors(folderId, authToken);

        for (FolderVo folder : folders) {
            if (folder.getId().equals(rootFolder.getId())) {
                return true;
            }
        }

        return false;
    }

    public boolean doesDashboardBelongToUser(ReportUser reportUser, String dashboardId, UserVo user, String authToken) {

        String[] dashboardFields = {"id", "space_id"};
        DashboardVo target = dashboardApi.getDashboard(dashboardId, dashboardFields, authToken);

        if (target == null) {
            String msg = "Cannot locate selected dashboard with id '" + dashboardId + "'";
            logger.warn(msg);
            throw new EntityNotFoundException(msg);
        }

        String dashboardFolderId = target.getSpaceId();

        if (!doesFolderBelongToUser(reportUser, dashboardFolderId, user, authToken)) {
            throw new AccessDeniedException("Attempt to delete look for user failed (user does not have rights to manage");
        }

        return true;
    }

    public boolean doesLookBelongToUser(ReportUser reportUser, String lookId, UserVo user, String authToken) {

        String[] lookFields = {"id", "space_id"};

        LookVo look = lookApi.getLook(lookId, lookFields, authToken);

        if (look == null) {
            String msg = "Cannot locate selected dashboard with id '" + lookId + "'";
            logger.warn(msg);
            throw new EntityNotFoundException(msg);
        }

        String lookFolderId = look.getSpaceId();

        if (!doesFolderBelongToUser(reportUser, lookFolderId, user, authToken)) {
            throw new AccessDeniedException("Attempt to delete look for user failed (user does not have rights to manage");
        }

        return true;
    }

    FolderVo getUsersRootFolder(ReportUser reportUser, String authToken) {
        String userID = reportUser.getUsername();
        UserVo user = userApi.getUserByEmbed(userID, authToken);
        String[] fields = {"id"};
        //Note: Data type for folder id is 'Long', however reference to space for a given user is type 'String'
        return spaceApi.getFolder(Long.toString(user.getPersonalSpaceId()), fields, authToken);
    }

    /**
     * Apply security related attributes based on the current user's roles.
     *
     * @param items
     */
    void setAuthPerms(List<ReportItemVo> items, ConnectUser currentUser) {
        for (ReportItemVo item : items) {
            item.setCurrentUserMayEdit(true);
        }
    }

    /**
     * @param folderId
     * @return
     */
    boolean isFolderEmpty(String folderId, String authToken) {
        FolderVo target = spaceApi.getFolderWithContents(folderId, authToken);
        if (!target.getDashboards().isEmpty() || !target.getLooks().isEmpty()) {
            return false;
        }

        List<FolderVo> childFolders = spaceApi.getChildFolders(folderId, authToken);
        return childFolders.isEmpty();
    }

    /**
     * @param reportId
     * @param currentUser
     * @return
     */
    boolean userHasDeletePermissionsForReport(String reportId, ConnectUser currentUser, String authToken) {
        /**
         * TODO: Implement check:
         * 	1) Locate folder for item
         * 	2) Locate root folder for current user
         *  3) Determine if folder containing target object for operation is an ancestor of the folder containing the target.
         */

        //doesFolderBelongToUser(Long parentFolderId, UserVo user, String authToken)

        return true;
    }

    /**
     * @param DashboardId
     * @param currentUser
     * @return
     */
    boolean userHasDeletePermissionsForDashboard(String DashboardId, ConnectUser currentUser, String authToken) {
        /**
         * TODO: Implement check:
         * 	1) Locate folder for item
         * 	2) Locate root folder for current user
         *  3) Determine if folder containing target object for operation is an ancestor of the folder containing the target.
         *
         */

        //doesFolderBelongToUser(Long parentFolderId, UserVo user, String authToken)
        String[] dashboardFields = {"id", "title", "space_id"};

        return true;
    }

    ReportItemVo cloneDashboard(String sourceId, String targetFolderId, String name, String description, ConnectUser connectUser) {

        //TODO: Validate selected folder belongs to current user.
        //doesFolderBelongToUser(Long parentFolderId, UserVo user, String authToken)

        String[] dashboardFields = {"id", "title", "space_id"};


        return null;
    }


    ReportItemVo cloneLook(String sourceId, String targetFolderId, String name, String description, ConnectUser connectUser) {
        //TODO: Validate selected folder belongs to current user.
        //doesFolderBelongToUser(Long parentFolderId, UserVo user, String authToken)
        return null;
    }

    public void updateSpace(FolderVo space) {
        String authToken = spaceApi.getAuthToken();
        this.spaceApi.updateSpace(space, authToken);
    }

    /**
     * List dashboards for a selected folder:
     * <p>
     * Intitial call is made to obtain an 'authorization token'. This is required to retrieve information about the current
     * user, and to make a secondary login attempt as that user. Next, a final call is made to retrieve dashboards for the
     * selected folder. This call is perform as the current logged in user, which creates a requirement that the current
     * user has permissions to actually view the specified folder.
     */
    public List<ReportItemVo> listDashboardsForFolder(ReportUser reportUser, String parentFolderId) {

        String userID = reportUser.getUsername();

        String authToken = spaceApi.getAuthToken();

        UserVo userVo = null;


        String userAuthToken;
        if (userID.equalsIgnoreCase("%")) {
            userAuthToken = authToken;
        } else {
            try {
                userVo = userApi.getUserByEmbed(userID, authToken);
            } catch (ApiException e) {
                logger.warn("Unable to locate account associated with embed id '" + userID + "': " + e.getMessage());
                throw new AccessDeniedException("Unable to locate account associated with embed id '" + userID + "'");
            }
            userAuthToken = userApi.getAuthTokenForUserId(authToken, userVo.getId());
        }

        String[] fields = {"id", "title"};

        if (parentFolderId.equalsIgnoreCase("undefined")) {
            parentFolderId = userVo.getPersonalSpaceId() + "";
        }

        List<DashboardVo> dashboards = null;
        try {
            dashboards = spaceApi.getDashboardsForFolder(parentFolderId, fields, userAuthToken);
        } catch (AccessDeniedException a) {
            logger.warn("User " + userID + " does not have permissions to access folder with id '" + parentFolderId + "': " + a.getMessage());
            throw new AccessDeniedException("User " + userID + " does not have permissions to access folder with id '" + parentFolderId + "'");
        }

        List<ReportItemVo> dashboardVos = convertDashboardsToVos(dashboards,true,null);

        return dashboardVos;
    }


    public List<ReportItemVo> listDashboardsForFolderDashboardJobService(String parentFolderId) {
        String authToken = lookApi.getAuthToken();

        String[] fields = {"id", "title"};

        List<DashboardVo> dashboards;
        try {
            dashboards = spaceApi.getDashboardsForFolder(parentFolderId, fields, authToken);
        } catch (AccessDeniedException a) {
            logger.warn("authToken " + authToken + " does not have permissions to access folder with id '" + parentFolderId + "': " + a.getMessage());
            throw new AccessDeniedException("authToken " + authToken + " does not have permissions to access folder with id '" + parentFolderId + "'");
        }

        List<ReportItemVo> dashboardVos = convertDashboardsToVos(dashboards,true,null);

        return dashboardVos;
    }


    /**
     * Get the children of a folder
     * <p>
     * Intitial call is made to obtain an 'authorization token'. This is required to retrieve information about the current
     * user, and to make a secondary login attempt as that user. Next, a final call is made to retrieve childrens of the
     * selected folder. This call is perform as the current logged in user, which creates a requirement that the current
     * user has permissions to actually view the specified folder.
     */
    public List<FolderVo> listChildrenForFolder(ReportUser reportUser, String parentFolderId) {

        String authToken = spaceApi.getAuthToken();

        UserVo userVo = null;


        String userAuthToken;
        if (reportUser.getUsername().equalsIgnoreCase("%")) {
            userAuthToken = authToken;
        } else {
            try {
                userVo = userApi.getUserByEmbed(reportUser.getUsername(), authToken);
            } catch (ApiException e) {
                throw new AccessDeniedException("Unable to locate account associated with embed id '" + reportUser.getUsername() + "'");
            }
            userAuthToken = userApi.getAuthTokenForUserId(authToken, userVo.getId());
        }

        String[] fields = {"id", "name", "parent_id", "created_at", "space_id"};

        if (parentFolderId.equalsIgnoreCase("undefined")) {
            parentFolderId = userVo.getPersonalSpaceId() + "";
        }

        List<FolderVo> folders = null;
        try {
            folders = folderApi.listChildrenForFolder(parentFolderId, fields, userAuthToken);
        } catch (AccessDeniedException a) {
            throw new AccessDeniedException("User " + reportUser.getFirstName() + " " + reportUser.getLastName() + " " + reportUser.getUsername() + " does not have permissions to access folder with id '" + parentFolderId + "'");
        }
        return folders;
    }

    @Override
    public List<FolderVo> getFoldersByName(String parentFolderId, String folderName) throws Exception {
        String authToken = spaceApi.getAuthToken();
        return folderApi.searchSharedFoldersByName(folderName, authToken);
    }

    @Override
    public List<FolderVo> getFolderChildren(String folderId) throws Exception {
        String authToken = getAuthToken();
        return folderApi.getFolderChildren(folderId, authToken);
    }

    @Override
    public void updateDashboard(DashboardVo dashboard) {
        String[] fields = {"id"};
        String authToken = dashboardApi.getAuthToken();
        dashboardApi.updateDashboard(dashboard, fields, authToken);
    }

    @Override
    public void updateLook(LookVo look) {
        String[] fields = {"id"};
        String authToken = lookApi.getAuthToken();
        lookApi.updateLook(look, fields, authToken);

    }

    @Override
    public Map<String, List<List<String>>> shareReport(ReportUser reportUser, LookVo look, List<List<String>> teams, List<List<Integer>> teamIds,Boolean overWriteFlag) {
        String validationResponse = null, errorResponse = null;
        Boolean successFlag = false;
        HashMap<String, List<List<String>>> returnMap = new HashMap<>();
        List<List<String>> remainTeams = teams;

        String userID = reportUser.getUsername();
        if (userID == null) {
            logger.warn("Cannot identitify connect user");
            throw new AccessDeniedException("Cannot identify connect user!");
        }

        String authToken = spaceApi.getAuthToken();
        UserVo user = userApi.getUserByEmbed(userID, authToken);
        String userAuthToken = queryApi.getAuthTokenForUserId(authToken, user.getId());

        String[] fields = {"id", "title", "description", "created_at", "updated_at", "last_viewed_at", "space_id", "space_id", "favorite_count", "deleted", "view_count", "query_id", "message", "documentation_url", "errors", "folder_id"};
        String[] lookFields = {"id", "space_id", "query_id"};

        for (int i = 0; i < teams.size(); i++) {
            successFlag = false;

            if (overWriteFlag) {
                Long deleteLookId = lookApi.searchLook(look, teams.get(i).get(0), userAuthToken);
                lookApi.deleteLook(deleteLookId.toString(), userAuthToken);
            }

            LookVo getLook = lookApi.getLook(look.getId().toString(), lookFields, userAuthToken);
            look.setQueryId(getLook.getQueryId());
            LookVo returnLook = lookApi.shareReport(teams.get(i).get(0), look, fields, userAuthToken);
            if (returnLook.getMessage() == null) {
                applicationLogService.insertOrUpdateRecentSearchLog("MY_REPORTS_RECENT", reportUser.getUsername(), teamIds.get(i).get(0));
                remainTeams.remove(i);
                successFlag = true;
            } else {
                if (returnLook.getMessage().contains("Validation Failed"))
                    validationResponse = buildDialogErrorMsg(returnLook, teams.size(), teams.get(i).get(1), validationResponse);
                else
                    errorResponse = buildDialogErrorMsg(returnLook, teams.size(), teams.get(i).get(1), validationResponse);
            }
        }
        if (successFlag)
            return null;
        else {
            String resTemp = validationResponse == null ? errorResponse : validationResponse;
            ArrayList<String> temp2 = new ArrayList<>();
            temp2.add(resTemp);
            temp2.add(errorResponse);
            List<List<String>> temp = new ArrayList<>();
            temp.add(temp2);
            returnMap.put("FAILED_TEAMS", remainTeams);
            returnMap.put("VALIDATION_MSG", temp);
            returnMap.put("ERROR_MSG", temp);
            return returnMap;

        }
    }

    private String buildDialogErrorMsg(LookVo returnLook, int teamSize, String teamName, String validationResponse) {

        if (returnLook.getMessage().contains("Validation Failed")) {
            if (teamSize == 1) {
                validationResponse = ErrorMessagesEnum.valueOf("ALREADY_EXISTS_SINGLE").getErrorMsg();
            } else {
                if (validationResponse == null)
                    validationResponse = ErrorMessagesEnum.valueOf(returnLook.getErrors().get(0).get("code").toUpperCase()).getErrorMsg() + "<br><br>";
                validationResponse = validationResponse + teamName + "<br>";
            }
            return validationResponse;
        } else {
            if (returnLook.getMessage().contains("Not found"))
                return ErrorMessagesEnum.valueOf("NOT_FOUND").getErrorMsg() + "<br><br>" + teamName + "<br>";
            else
                return ErrorMessagesEnum.valueOf("UNKNOWN").getErrorMsg() + " " + returnLook.getMessage() + "<br><br>" + teamName + "<br>";
        }
    }
}

