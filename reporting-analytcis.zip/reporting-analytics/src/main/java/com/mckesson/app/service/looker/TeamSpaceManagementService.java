package com.mckesson.app.service.looker;

import java.util.List;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.vo.ReportItemVo;
import main.java.com.mckesson.app.vo.looker.FolderVo;

public interface TeamSpaceManagementService {

    /**
     * Retrieve shared team space for the current user.
     *
     * @return
     */
    ReportItemVo getTeamFolderStructure(ReportUser reportUser, String customerName);

    /**
     * Retrieve the selected shared team space. This operation provide the ability to view a specific space for a user with 'super user' privelidges.
     */
    List<ReportItemVo> getFolderStructure(String scope);

    ReportItemVo createFolder(ReportUser reportUser, String name, String parentId, String customerName);

    void deleteFolder(String userID, String id);

    void deleteReport(String userID, String id);

    void deleteDashboard(String userID, String id);

    void updateSpace(FolderVo folder);
}
