package com.mckesson.app.vo.looker;

import java.util.HashMap;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserVo {

    @JsonProperty("id")
    private String id;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("last_name")
    private String lastName;
    @JsonProperty("display_name")
    private String displayName;
    @JsonProperty("personal_space_id")
    private long personalSpaceId;
    private String externalUserId;
    @JsonProperty("group_ids")
    private Long[] groupIds;
    @JsonProperty("role_ids")
    private Long[] roleIds;

    private HashMap<Long, String> groups = new HashMap();
    private HashMap<Long, String> roles = new HashMap();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public long getPersonalSpaceId() {
        return personalSpaceId;
    }

    public void setPersonalSpaceId(long personalSpaceId) {
        this.personalSpaceId = personalSpaceId;
    }

    public String getExternalUserId() {
        return externalUserId;
    }

    public void setExternalUserId(String externalUserId) {
        this.externalUserId = externalUserId;
    }

    public String toString() {
        return "id=>" + this.id + ", name=>" + this.displayName;
    }

    public Long[] getGroupIds() {
        return groupIds;
    }

    public void setGroupIds(Long[] groupIds) {
        this.groupIds = groupIds;
    }

    public Long[] getRoleIds() {
        return roleIds;
    }

    public void setRoleIds(Long[] roleIds) {
        this.roleIds = roleIds;
    }

    public HashMap<Long, String> getGroups() {
        return groups;
    }

    public void setGroups(HashMap<Long, String> groups) {
        this.groups = groups;
    }

    public HashMap<Long, String> getRoles() {
        return roles;
    }

    public void setRoles(HashMap<Long, String> roles) {
        this.roles = roles;
    }

}
