package com.mckesson.app.domain.user;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_profile")
public class UserProfile {
    @Id
    @Column(name = "user_id")
    private String username;
    @Column(name = "user_role")
    private String userRole;
    private String active;
    @Column(name = "firstname")
    private String firstName;
    @Column(name = "lastname")
    private String lastName;
    private String email;
    private String internal;
    @Column(name = "last_login_date")
    private Date lastLoginDate;
    @Column(name = "function_code")
    private String functionCode;
    @Column(name = "external_id")
    private Long externalId;
    @Column(name = "is_sql_visible")
    private Boolean isSqlVisible;
    @Column(name = "created_by")
    private String createdBy;
    @Column(name = "created_date")
    private Date createdDate;
    @Column(name = "updated_by")
    private String updatedBy;
    @Column(name = "updated_date")
    private Date updatedDate;
    @Column(name = "data_history_months")
    private String dataHistoryMonths;
    @Column(name = "is_sudo_enabled")
    private String isSudoEnabled;
    @Column(name = "market_partition")
    private String marketPartition;
    @Column(name = "bla_eligible")
    private String blaEligible;

    public UserProfile() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserRole() {
        return userRole;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getInternal() {
        return internal;
    }

    public void setInternal(String internal) {
        this.internal = internal;
    }

    public Date getLastLoginDate() {
        return lastLoginDate;
    }

    public void setLastLoginDate(Date lastLoginDate) {
        this.lastLoginDate = lastLoginDate;
    }

    public String getFunctionCode() {
        return functionCode;
    }

    public void setFunctionCode(String functionCode) {
        this.functionCode = functionCode;
    }

    public Long getExternalId() {
        return externalId;
    }

    public void setExternalId(Long externalId) {
        this.externalId = externalId;
    }

    public Boolean getSqlVisible() {
        return isSqlVisible;
    }

    public void setSqlVisible(Boolean SqlVisible) {
        isSqlVisible = SqlVisible;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    @Override
    public String toString() {
        return "UserProfile{" +
                "username='" + username + '\'' +
                ", userRole='" + userRole + '\'' +
                ", active='" + active + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", internal='" + internal + '\'' +
                ", lastLoginDate=" + lastLoginDate +
                ", functionCode='" + functionCode + '\'' +
                ", externalId=" + externalId +
                ", isSqlVisible=" + isSqlVisible +
                ", createdBy='" + createdBy + '\'' +
                ", createdDate=" + createdDate +
                ", updatedBy='" + updatedBy + '\'' +
                ", updatedDate=" + updatedDate +
                '}';
    }

    public String getDataHistoryMonths() {
        return dataHistoryMonths;
    }

    public void setDataHistoryMonths(String dataHistoryMonths) {
        this.dataHistoryMonths = dataHistoryMonths;
    }

    public String getIsSudoEnabled() {
        return isSudoEnabled;
    }

    public void setIsSudoEnabled(String isSudoEnabled) {
        this.isSudoEnabled = isSudoEnabled;
    }

    public String getMarketPartition() {
        return marketPartition;
    }

    public void setMarketPartition(String marketPartition) {
        this.marketPartition = marketPartition;
    }

    public String getBlaEligible() { return blaEligible; }

    public void setBlaEligible(String blaEligible) { this.blaEligible = blaEligible; }
}