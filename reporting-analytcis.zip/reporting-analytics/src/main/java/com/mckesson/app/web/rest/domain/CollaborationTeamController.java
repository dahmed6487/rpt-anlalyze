package com.mckesson.app.web.rest.domain;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.domain.customer.ContentAccessDto;
import main.java.com.mckesson.app.domain.customer.Customer;
import main.java.com.mckesson.app.domain.user.UserProfile;
import main.java.com.mckesson.app.service.admin.CollaborationTeamService;
import main.java.com.mckesson.app.service.customer.CustomerService;
import main.java.com.mckesson.app.util.UserAuthentication;

/**
 * Class used to drive CollaborationTeam operations for data display on Admin/Domain screen
 */
@RestController
@RequestMapping("/api/teams")
public class CollaborationTeamController {

    private final UserAuthentication userAuthentication;
    private final CollaborationTeamService collaborationTeamService;
    private final CustomerService customerService;
    private final ObjectMapper objectMapper;

    @Autowired
    public CollaborationTeamController(UserAuthentication userAuthentication, CollaborationTeamService collaborationTeamService, CustomerService customerService) {
        this.userAuthentication = userAuthentication;
        this.collaborationTeamService = collaborationTeamService;
        this.customerService = customerService;
        this.objectMapper = new ObjectMapper();
    }

    @PostMapping()
    public ResponseEntity<CollaborationTeam> createTeam(@RequestBody CollaborationTeam team) {
        CollaborationTeam savedTeam = collaborationTeamService.createTeam(team);
        if (savedTeam != null) {
            return new ResponseEntity<>(savedTeam, HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/get")
    public ResponseEntity<List<CollaborationTeam>> get() {
        return new ResponseEntity<>(collaborationTeamService.getAllTeams(), HttpStatus.OK);
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<CollaborationTeam> getTeam(@PathVariable String id) {
        Optional<CollaborationTeam> team = collaborationTeamService.getTeams(id);

        if (team.isPresent()) {
            return new ResponseEntity<>(team.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping(value = "/get", params = "commonEntityId")
    public ResponseEntity<List<CollaborationTeam>> getTeamsByCommonEntityId(@RequestParam String commonEntityId) {
        Optional<Customer> customer = customerService.findCustomerByCommonEntityId(commonEntityId);

        if (customer.isPresent()) {
            Optional<List<CollaborationTeam>> teams = collaborationTeamService.getTeamsByCustomerId(customer.get().getCustomerId());

            if (teams.isPresent()) {
                return new ResponseEntity<>(teams.get(), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    /**
     * @return
     */
    @GetMapping("/get/page")
    public List<CollaborationTeam> getTeams() {
        return collaborationTeamService.getTeams(userAuthentication.getLoggedInUser(), null, null);
    }

    /**
     * @return
     */
    @GetMapping("/search/{searchVal}")
    public List<CollaborationTeam> searchTeamsForUser(@PathVariable String searchVal) {
        return collaborationTeamService.searchTeamsForUser(userAuthentication.getLoggedInUser(), searchVal);
    }

    @PutMapping("/update")
    public ResponseEntity<String> updateTeam(@RequestBody CollaborationTeam team) {
        if (collaborationTeamService.updateTeam(team)) {
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Delete from collab_team_module_relation
     * and Update the Delete date CollaborationTeam
     *
     * @param collaborationTeam
     * @return
     */
    @PostMapping("/delete")
    public ResponseEntity<String> deleteTeams(@RequestBody List<CollaborationTeam> collaborationTeam) {
        return collaborationTeamService.deleteTeams(collaborationTeam);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteTeam(@PathVariable Long id) {
        if (collaborationTeamService.deleteTeam(id)) {
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Add users to Teams
     * TODO improve efficiency
     *
     * @return
     */
    @PostMapping("/users")
    public ResponseEntity<String> addUsersToTeam(@RequestParam Long teamId, @RequestParam Long customerId, @RequestBody List<UserProfile> users) {
        return collaborationTeamService.insertOrUpdateRelation(teamId, customerId, users);
    }

    /**
     * Delete users from Teams
     * TODO improve efficiency
     *
     * @return
     */
    @DeleteMapping("/users")
    public ResponseEntity deleteUserFromTeam(@RequestParam Long teamId, @RequestParam Long customerId, @RequestParam String userId) {
        if (collaborationTeamService.removeTeamFromUser(teamId, customerId, userId)) {
            return new ResponseEntity<>("Success", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Failed", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Delete mapping into Teams
     *
     * @param list
     * @return
     */
    @PostMapping("/delete/relation")
    public ResponseEntity<String> deleteRelationById(@RequestBody List<Integer> list) {
        return collaborationTeamService.deleteRelationById(list);
    }

    @GetMapping("/get/{id}/members")
    public ResponseEntity<List<UserProfile>> getMembersByCollabTeamId(@PathVariable String id) {
        Optional<List<UserProfile>> users = collaborationTeamService.getMembersByCollabTeamId(id);

        if (users.isPresent()) {
            return new ResponseEntity<>(users.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/get/content-accesses")
    public ResponseEntity<String> findContentAccessesByTeamId(@RequestParam Long id) throws JsonProcessingException {
        Optional<List<String>> contentAccesses = collaborationTeamService.findContentAccessesByTeamId(id);

        if (contentAccesses.isPresent()) {
            return new ResponseEntity<>(objectMapper.writeValueAsString(contentAccesses.get()), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(null,HttpStatus.OK);
        }
    }

    @PutMapping("/update/content-accesses")
    public ResponseEntity<String> updateCustomerContentAccesses(@RequestParam String id, @RequestBody List<ContentAccessDto> contentAccesses) throws JsonProcessingException {
        return collaborationTeamService.updateTeamContentAccesses(Long.parseLong(id), contentAccesses);
    }
}
