package com.mckesson.app.vo.looker;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * A VO mapping the fields returned for an <em>Explore</em> JSON array from the Looker API.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExploreDetailVo {

    @JsonProperty("fields")
    public FieldVo fields;

    public FieldVo getFields() {
        return fields;
    }

    public void setFields(FieldVo fields) {
        this.fields = fields;
    }
}
