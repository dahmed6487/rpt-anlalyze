package com.mckesson.app.service.customer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.domain.customer.UserMapping;
import main.java.com.mckesson.app.repository.admin.CollaborationTeamRepository;
import main.java.com.mckesson.app.repository.customer.UserMappingRepository;
import main.java.com.mckesson.app.service.user.UserProfileService;

@Service
public class UserMappingService {

    private final UserMappingRepository userMappingRepository;
    private final UserProfileService userProfileService;
    private final CollaborationTeamRepository collaborationTeamRepository;

    @Autowired
    public UserMappingService(UserMappingRepository userMappingRepository, UserProfileService userProfileService, CollaborationTeamRepository collaborationTeamRepository) {
        this.userMappingRepository = userMappingRepository;
        this.userProfileService = userProfileService;
        this.collaborationTeamRepository = collaborationTeamRepository;
    }

    public List<UserMapping> getUserMapping() {
        return userMappingRepository.findAll();
    }

    public List<UserMapping> updateUserMapping(List<UserMapping> userMapping) {
        List<Long> list = new ArrayList<>();
        userMapping.stream().forEach(c -> list.add(c.getUserMappingId()));
        userMappingRepository.active(list);
        return userMapping;
    }

    public ResponseEntity<String> deleteUserMapping(List<UserMapping> userMapping) {
        List<Long> list = new ArrayList<>();
        Date deletedDate = new Date();
        userMapping.stream().forEach(c -> list.add(c.getUserMappingId()));
        userMappingRepository.deleteUserMapCollabTeamRelation(list);
        userMappingRepository.deleteUserMapCollabModuleRelation(list);
        userMappingRepository.deleteUserMapSecurityGroupRelation(list);
        userMappingRepository.inActive(deletedDate, list);
        return new ResponseEntity<>("Your request has been completed successfully", HttpStatus.ACCEPTED);
    }

    public List<CollaborationTeam> getTeamsForUser(String username) {
        return collaborationTeamRepository.getCollaborationTeams(username);
    }

    public List<CollaborationTeam> getTeamsByUserAndCustomer(String username, String customerName) {
        return collaborationTeamRepository.getTeamsByUserAndSelectedCustomer(username, customerName);
    }

    public List<UserMapping> findCustomerMappings(String username) {
        return userMappingRepository.findByusername(username);
    }

    public UserMapping findCustomerMapping(String username, Long customerId) {
        return userMappingRepository.getUserMappingByCustomerId(username, customerId);
    }

    public ResponseEntity<String> insertOrUpdateRelation(Map<String, String> map) {
        switch (map.get("mappingType")) {
            case "team":
                userMappingRepository.insertOrUpdateTeamsRelation(map.get("collaborationTeamId"), map.get("userMappingId"));
                break;
            case "module":
                userMappingRepository.insertOrUpdateModuleRelation(map.get("moduleId"), map.get("userMappingId"));
                break;
            case "securityGroup":
                userMappingRepository.insertOrUpdateSecurityGroupRelation(map.get("securityGroupId"), map.get("userMappingId"));
                break;
        }
        return new ResponseEntity<>("Your request has been completed successfully", HttpStatus.ACCEPTED);
    }

    public ResponseEntity<String> deleteModuleRelationById(List<Integer> list) {
        userMappingRepository.deleteModuleRelationById(list);
        return new ResponseEntity<>("Your request has been completed successfully", HttpStatus.ACCEPTED);
    }

    public ResponseEntity<String> deleteSecurityGroupRelationById(List<Integer> list) {
        userMappingRepository.deleteSecurityGroupRelationById(list);
        return new ResponseEntity<>("Your request has been completed successfully", HttpStatus.ACCEPTED);
    }

    public boolean softDeleteUserFromTeam(String userId, String teamId) {
        List<UserMapping> userMappings = userMappingRepository.findByusername(userId);

        List<String> userMappingIds = new ArrayList<>();
        for (UserMapping userMapping : userMappings) {
            userMappingIds.add(String.valueOf(userMapping.getUserMappingId()));
        }

        int numRowsUpdated = userMappingRepository.softDeleteUserFromTeam(new Date(), userMappingIds, teamId);
        return numRowsUpdated > 0;
    }
}