package com.mckesson.app.repository.looker;

public interface CustomFilterProjection {
    Long getId();

    String getName();
}
