package com.mckesson.app.web.rest.domain;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import com.mckesson.lib.model.platform.PlatformId;

import main.java.com.mckesson.app.domain.admin.Module;
import main.java.com.mckesson.app.domain.customer.ContentAccessDto;
import main.java.com.mckesson.app.domain.customer.Customer;
import main.java.com.mckesson.app.domain.customer.CustomerAccount;
import main.java.com.mckesson.app.domain.customer.CustomersDto;
import main.java.com.mckesson.app.service.customer.CustomerService;
import main.java.com.mckesson.app.util.UserAuthentication;

/**
 * Class used to drive Customer operations for Admin/Domain screen
 */
@RestController
@RequestMapping("/api/customer")
public class CustomerController {

    private final UserAuthentication userAuthentication;
    private final CustomerService customerService;

    @Autowired
    public CustomerController(UserAuthentication userAuthentication, CustomerService customerService) {
        this.userAuthentication = userAuthentication;
        this.customerService = customerService;
    }

    @GetMapping(value = "/get")
    public ResponseEntity<CustomersDto> getAllCustomers() {
        Page<Customer> customers = customerService.getAllCustomers();

        CustomersDto customersDto = new CustomersDto();
        customersDto.setCustomers(customers.getContent());
        customersDto.setTotalPages(customers.getTotalPages());

        return new ResponseEntity<>(customersDto, HttpStatus.OK);
    }

    @GetMapping(value = "/get", params = "page")
    public ResponseEntity<CustomersDto> getCustomerPage(@RequestParam String page) {
        Page<Customer> customerPage = customerService.getCustomerPage(Integer.parseInt(page));

        CustomersDto customersDto = new CustomersDto();
        customersDto.setCustomers(customerPage.getContent());
        customersDto.setTotalPages(customerPage.getTotalPages());

        return new ResponseEntity<>(customersDto, HttpStatus.OK);
    }

    @GetMapping(value = "/get", params = "customerName")
    public ResponseEntity<Customer> findCommonEntityIdByCustomerName(@RequestParam String customerName) {
        Optional<Customer> customer = customerService.findCustomerByCustomerName(customerName);

        if (customer.isPresent()) {
            return new ResponseEntity<>(customer.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/search")
    public ResponseEntity<CustomersDto> searchCustomerPage(@RequestParam String page, @RequestParam String search) {
        Page<Customer> customerPage = customerService.searchCustomerPage(Integer.parseInt(page), search);

        CustomersDto customersDto = new CustomersDto();
        customersDto.setCustomers(customerPage.getContent());
        customersDto.setTotalPages(customerPage.getTotalPages());

        return new ResponseEntity<>(customersDto, HttpStatus.OK);
    }

    @GetMapping("/get/user")
    public ResponseEntity<List<Customer>> getCustomersOfUser(@RequestParam(required = false) String accountNumber) {
//        String userId = userAuthentication.getLoggedInUser().getOriginalUsername();
        List<Customer> customers;
        if (accountNumber == null) {
            try {
                customers = customerService.getCustomersForUser(userAuthentication.getLoggedInUser());
                return new ResponseEntity<>(customers, HttpStatus.OK);
            } catch (UsernameNotFoundException e) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } else {
            customers = customerService.getCustomerByAccount(userAuthentication.getLoggedInUser(), accountNumber);
            return new ResponseEntity<>(customers, HttpStatus.OK);
        }
    }

    @GetMapping("/get/customer")
    public ResponseEntity<Customer> findCustomerByCommonEntityId(@RequestParam String id) {
        Optional<Customer> customer = customerService.findCustomerByCommonEntityId(id);

        if (customer.isPresent()) {
            return new ResponseEntity<>(customer.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/update")
    public ResponseEntity<String> updateCustomer(@RequestBody Customer customer) {
        if (customerService.updateCustomer(customer)) {
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/get/content-accesses")
    public ResponseEntity<List<String>> findContentAccessesByCommonEntityId(@RequestParam String id, @RequestParam String moduleType) {
        Optional<List<String>> contentAccesses = customerService.findContentAccessesByCommonEntityId(id, moduleType);
        return new ResponseEntity<>(contentAccesses.get(), HttpStatus.OK);
    }

    @GetMapping("/get/content-accesses/{customerName}")
    public List<Module>  getContentAccessByCustomer(@PathVariable String customerName) {
        List<Module> contentAccesses = customerService.getContentAccessByCustomer(customerName);
        return contentAccesses;
    }

    @PutMapping("/update/content-accesses")
    public ResponseEntity<String> updateCustomerContentAccesses(@RequestParam String id, @RequestParam String moduleType, @RequestBody List<ContentAccessDto> contentAccesses) throws Exception {
        Boolean response = false;
        if (moduleType.equals("canned report")) {
            response=customerService.updateCustomerContentAccesses(id, moduleType, contentAccesses);
        }
        else if (moduleType.equals("explore")) {
            response=customerService.updateExploreContentAccesses(id, moduleType, contentAccesses);
        }
        if (response) {
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/get/accounts")
    public ResponseEntity<List<CustomerAccount>> findAccountsByCommonEntityId(@RequestParam String id) {
        Optional<List<CustomerAccount>> accounts = customerService.findAccountsByCommonEntityId(id);

        if (accounts.isPresent()) {
            return new ResponseEntity<>(accounts.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    /**
     * It will delete related child mapping also
     *
     * @param customer
     * @return
     */
    @PostMapping("/delete")
    public ResponseEntity<String> deleteAll(@RequestBody List<Customer> customer) {
        return customerService.deleteAll(customer);
    }


    /**
     * search by OwnerValue
     * @param searchText
     * @return
     */
    @GetMapping("/search/owner/{type}")
    public List<String> searchOwnerValue(@PathVariable("type") String type, @RequestParam String searchText) {
        return customerService.searchOwnerValue(type, searchText);
    }

    /**
     * search by account code value
     * @param type
     * @param searchText
     * @return
     */
    @GetMapping("/search/account/code/{type}")
    public List<String> searchAccountCodeValue(@PathVariable("type") String type, @RequestParam String searchText) {
        return customerService.searchAccountCodeValue(type, searchText.toLowerCase());
    }

    /**
     * search by Common Entity Group value
     * @param type
     * @param searchText
     * @return
     */
    @GetMapping("/search/common/{type}")
    public List<String> searchCommonEntityGroupValue(@PathVariable("type") String type, @RequestParam String searchText) {
        return customerService.searchCommonEntityGroupValue(type, searchText.toLowerCase());
    }


    /*
     * Generic method to create a customer
     */
    @PostMapping("/create/customer")
    public ResponseEntity<Customer> createOrUpdateCustomerInfo(@RequestBody Customer customer) throws Exception {
        customer.setCreatedBy(userAuthentication.getLoggedInUser().getUsername());
        customer.setCreatedDate(new Date());
        customer.setPlatformId(PlatformId.SAP.getCodeAsString());
        customer.setTotalAccounts("0");
        Customer returnCustomerInfo= customerService.createOrUpdateCustomerInfo(customer);
        return new ResponseEntity<>(returnCustomerInfo, HttpStatus.OK);
    }

    /**
     * getAccountDimensions
     * @param
     * @param
     * @return
     */
    @PostMapping("/get/account/dimensions")
    public List<String> getAccountDimensions( @RequestParam("accDimension") String accDimension, @RequestParam("accDimensionValue") String accDimensionValue, @RequestParam("customerName") String customerName) {
        return customerService.getAccountDimensions(accDimension, accDimensionValue.toLowerCase(), customerName, userAuthentication.getLoggedInUser().getUsername());
    }
}
