package com.mckesson.app.vo.looker;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * A VO mapping the fields returned for a <em>Dimension</em> JSON object from the Looker API.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class DimensionVo implements Serializable {

    @JsonProperty("label")
    public String label;
    @JsonProperty("label_short")
    public String labelShort;
    @JsonProperty("name")
    public String name;
    @JsonProperty("hidden")
    public Boolean hidden;
    @JsonProperty("view_label")
    public String viewLabel;
    @JsonProperty("type")
    public String type;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getLabelShort() {
        return labelShort;
    }

    public void setLabelShort(String labelShort) {
        this.labelShort = labelShort;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getHidden() {
        return hidden;
    }

    public void setHidden(Boolean hidden) {
        this.hidden = hidden;
    }

    public String getViewLabel() {
        return viewLabel;
    }

    public void setViewLabel(String viewLabel) {
        this.viewLabel = viewLabel;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


}
