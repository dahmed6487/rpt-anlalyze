package com.mckesson.app.web.rest.login;

import java.awt.PageAttributes.MediaType;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.omg.CORBA.Environment;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.OAuth2AuthorizationRequestRedirectFilter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class LoginController {

    private static final Logger LOG = LoggerFactory.getLogger(LoginController.class);

    private final Environment env;
    private final ClientRegistrationRepository registry;

    @Autowired
    public LoginController(Environment env, ClientRegistrationRepository registry) {
        this.env = env;
        this.registry = registry;
    }

    public static final String CLIENT_REGISTRATION_ID = "okta";

    @RequestMapping(value = "/api/okta", method = RequestMethod.GET)
    @ResponseBody
    public Map<String, String> getOktaDetails() {
        Map<String, String> map = new HashMap<String, String>();

        ClientRegistration client = registry.findByRegistrationId(CLIENT_REGISTRATION_ID);
        //OKTA SETUP

        map.put("LOGOUT_URL", env.getProperty("spring.security.oauth2.client.provider.okta.signout-uri"));
        // map.put("BASE_URL", env.getProperty("spring.security.oauth2.client.registration.okta.provider"));
        map.put("CLIENT_ID", client.getClientId());
        map.put("REDIRECT_URI", env.getProperty("spring.security.oauth2.client.provider.okta.redirect-uri"));
        map.put("ISSUER", client.getClientName());
        map.put("FORGOTPASSWORDLINK", env.getProperty("appconfig.forgotpasswordlink"));
        map.put("SCOPES", env.getProperty("spring.security.oauth2.client.registration.okta.scopes"));

        return map;
    }

    @RequestMapping("/initiate-state")
    public String initState() {
//		if (request.getSession(false) != null) {
//			request.getSession().invalidate();
//		}

        return "redirect:" + OAuth2AuthorizationRequestRedirectFilter.DEFAULT_AUTHORIZATION_REQUEST_BASE_URI + "/" + CLIENT_REGISTRATION_ID;
    }

    @RequestMapping(path = "state", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Map<String, String> getState(@RequestParam(name = "redirect_uri", required = true) String redirect,
                                        @RequestParam(name = "state", required = true) String state) {

        Map<String, String> map = new HashMap<String, String>();
        map.put("redirect_uri", redirect);
        map.put("state", state);

        return map;
    }
}