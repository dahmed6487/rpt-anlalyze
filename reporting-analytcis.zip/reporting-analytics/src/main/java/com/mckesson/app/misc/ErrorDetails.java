package com.mckesson.app.misc;

public class ErrorDetails {
    private String error_desc;
    private String error_id;

    public ErrorDetails(String error_id, String error_desc) {
        super();
        this.error_desc = error_desc;
        this.error_id = error_id;
    }

    public String getError_desc() {
        return error_desc;
    }

    public void setError_desc(String error_desc) {
        this.error_desc = error_desc;
    }

    public String getError_id() {
        return error_id;
    }

    public void setError_id(String error_id) {
        this.error_id = error_id;
    }
}
