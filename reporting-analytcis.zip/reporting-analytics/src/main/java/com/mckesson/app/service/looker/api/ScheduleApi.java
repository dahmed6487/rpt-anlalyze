package com.mckesson.app.service.looker.api;

import java.util.HashMap;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.util.RestClient;

@Component
public class ScheduleApi extends ApiBase {

    public ResponseEntity<String> getScheduledPlans(String[] fields, String authToken, String lookerId) {
        try {
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/scheduled_plans?user_id=" + lookerId;
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, params);
            return new ResponseEntity(jsonResponse, HttpStatus.OK);
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public void deleteScheduledPlan(String authToken, String scheduleId) {

        try {
            String requestUrl = this.lookerApiHost + "/scheduled_plans/" + scheduleId;
            RestClient.performDELETEOperation(authToken, requestUrl);
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

}
