package com.mckesson.app.service.looker;

public interface SharedCustomFilterService {

}
