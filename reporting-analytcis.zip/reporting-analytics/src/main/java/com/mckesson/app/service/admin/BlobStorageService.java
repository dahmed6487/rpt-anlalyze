package com.mckesson.app.service.admin;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.logging.Logger;

import org.omg.CORBA.Environment;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.common.StorageSharedKeyCredential;

@Service
@Transactional
public class BlobStorageService {

    private final Environment env;
    private static final Logger logger = LoggerFactory.getLogger(BlobStorageService.class);

    @Autowired
    public BlobStorageService(Environment env) {
        this.env = env;
    }

    public void putBlob(String jsonFile, String uploadType) {

        // Get a reference to a blob
        StorageSharedKeyCredential credential = new StorageSharedKeyCredential(env.getProperty("othervendorpurchases.account-name"), env.getProperty("othervendorpurchases.account-key"));
        BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().endpoint(env.getProperty("othervendorpurchases.url")).credential(credential).buildClient();
        BlobContainerClient containerClient = blobServiceClient.getBlobContainerClient(env.getProperty("othervendorpurchases.container"));

        // Create the container and return a container client object
        String fileName = env.getProperty("othervendorpurchases.file-path");
        if (uploadType.equals("ACCOUNT_SEGMENTATION")) {
            fileName = fileName + "Account_Segmentation_(Facility_Acct_Type)_" + new Timestamp(System.currentTimeMillis()) + ".json";
        }
        else {
            fileName = fileName + "Non-McKesson_Purchases_" + new Timestamp(System.currentTimeMillis()) + ".json";
        }
        BlobClient blobClient = containerClient.getBlobClient(fileName);

        // Upload the blob
        InputStream is = new ByteArrayInputStream(jsonFile.getBytes());
        try {
            blobClient.upload(is, is.available());
        } catch (IOException e) {
            logger.error("Error occurred while uploading the file to blobClient "+e.getMessage());
            e.printStackTrace();
        }
    }
}
