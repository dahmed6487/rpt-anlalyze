package com.mckesson.app.service.looker;

import java.util.List;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.vo.looker.RoleVo;
import main.java.com.mckesson.app.vo.looker.UserVo;

public interface LookerAdminService {

    UserVo createEmbedUser(ReportUser reportUser, UserVo user, String embedDomain);

    void deleteEmbedUser(String externaUserId);

    void updateEmbedUser(UserVo user);

    GroupVo createGroup(GroupVo group);

    void updateGroup(GroupVo group);

    void deleteGroup(Long groupId);

    GroupVo getGroupByName(String groupName) throws Exception;

    void addUserToGroup(Long groupId, String userId);

    List<UserVo> getUsersByGroup(Long groupId);

    void removeUserFromGroup(Long groupId, String externalUserId);

    UserVo getUserByExternalId(String externalUserId);

    List<GroupVo> listGroups();

    List<GroupVo> listGroups(String authToken);

    List<RoleVo> listRoles();

    List<RoleVo> listRoles(String authToken);

    GroupVo renameGroupName(Long externalId, String commonEntityName);
}
