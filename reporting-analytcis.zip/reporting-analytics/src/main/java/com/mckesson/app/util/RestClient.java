package com.mckesson.app.util;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Logger;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.LoggerFactory;

import main.java.com.mckesson.app.misc.ApiException;

public class RestClient {
    static final int[] SUCCESS_RESPONSE_CODE_CRITERIA = {200};

    Logger logger = LoggerFactory.getLogger(RestClient.class);

    public static String performPOSTOperation(String authToken, String apiEndpoint, HashMap<String, String> params) {
        return performPOSTOperation(authToken, apiEndpoint, null, params);
    }

    public static String performPOSTOperation(String authToken, String apiEndpoint, String jsonPostBody,
                                              HashMap<String, String> params) {

        long startTime = System.currentTimeMillis();

        URL url;
        HttpURLConnection conn = null;
        StringBuffer response;
        BufferedReader br;
        String output;
        String requestUrl = null;
        try {
            requestUrl = getUrl(apiEndpoint, params);
            url = new URL(requestUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            if (authToken != null) {
                conn.setDoInput(true);
                conn.setRequestProperty("Authorization", "token " + authToken);
            } else {
                conn.setDoInput(true);
            }

            if (jsonPostBody != null) {

                conn.setRequestProperty("Content-Type", "application/json");

                conn.setDoOutput(true);
                OutputStream outputStream = conn.getOutputStream();
                outputStream.write(jsonPostBody.getBytes(StandardCharsets.UTF_8));
                outputStream.flush();
            }

            conn.connect();
            response = new StringBuffer();

            //logger.debug("Response code"+ conn.getResponseCode());

            if (conn.getResponseCode() != 200 && conn.getResponseCode() != 201) {
                br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            } else {
                br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            }

            while ((output = br.readLine()) != null) {
                response.append(output);
            }

            conn.disconnect();

            System.out.println("Elapsed time for POST operation (" + apiEndpoint + ")  was "
                    + (System.currentTimeMillis() - startTime) + ")ms");
            return response.toString();
        } catch (MalformedURLException m) {
            throw new ApiException("Unable to connect to malformed url..." + "......" + m.toString());
        } catch (ProtocolException p) {
            throw new ApiException("Unable to connect to specified url (protocol exception)..." + "......" + p.toString());
        } catch (IOException io) {
            throw new ApiException("Unable to connect to specified url (io exception)..." + requestUrl + "......" + io.toString());
        } catch (Exception ex) {
            throw new ApiException(
                    "Unable to connect to specified url (exception)..." + requestUrl + jsonPostBody + ex.toString());
        }
    }

    public static String performGETOperation(String authToken, String apiEndpoint) {
        return performGETOperation(authToken, apiEndpoint, new HashMap());
    }

    public static String performSimpleGETOperation(String endpoint, HashMap<String, String> params,
                                                   int[] expectedResponseCodes) {

        long startTime = System.currentTimeMillis();

        URL url;
        HttpURLConnection conn = null;
        OutputStream os;
        StringBuffer response;
        BufferedReader br;
        String output;

        try {
            String requestUrl = getUrl(endpoint, params);
            url = new URL(requestUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            conn.connect();
            response = new StringBuffer();

            boolean expectedResponseCode = false;
            for (int x = 0; x < expectedResponseCodes.length; x++) {
                if (conn.getResponseCode() == expectedResponseCodes[x]) {
                    expectedResponseCode = true;
                    break;
                }
            }

            if (!expectedResponseCode) {
                String expCodes = "";
                for (int x = 0; x < expectedResponseCodes.length; x++) {
                    expCodes += "," + expectedResponseCodes;
                }
                throw new RuntimeException("Failed : HTTP response code: " + conn.getResponseCode()
                        + " did not match expected (" + expCodes + ")");
            }

            if (conn.getResponseCode() == 401) {
                return null;
            }

            br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            while ((output = br.readLine()) != null) {
                response.append(output);
            }

            conn.disconnect();

            return response.toString();

        } catch (Exception ex) {
            throw new ApiException("Unable to connect to specified url (exception)...");
        }

    }

    static String getUrl(String apiEndpoint, HashMap<String, String> params) throws Exception {
        if (params == null) {
            return apiEndpoint;
        }

        URIBuilder ub = new URIBuilder(apiEndpoint);
        if (params != null) {
            Iterator<String> i = params.keySet().iterator();
            String key;
            while (i.hasNext()) {
                key = i.next();
                ub.addParameter(key, params.get(key));
            }
        }

        return ub.toString().replaceAll("\\+", "%20");
    }

    public static String performConnectGETOperation(String authorization, String apiEndpoint, HashMap<String, String> params) {
        int[] validResponseCodes = {200, 404};
        return performGETOperation(null, apiEndpoint, params, authorization, validResponseCodes,null);
    }

    public static String performGETOperation(String authToken, String apiEndpoint, HashMap<String, String> params) {
        int[] validResponseCodes = {200, 404};
        return performGETOperation(authToken, apiEndpoint, params, null, validResponseCodes,null);
    }

    public static String performGETOperation(String authToken, String apiEndpoint, HashMap<String, String> params, String tokenType) {
        int[] validResponseCodes = {200, 404};
        return performGETOperation(authToken, apiEndpoint, params, null, validResponseCodes,tokenType);
    }

    public static String performGETOperation(String authToken, String apiEndpoint, HashMap<String, String> params,
                                             String authentication, int[] expectedResponseCodes,String tokenType) {
        long startTime = System.currentTimeMillis();

        URL url;
        HttpURLConnection conn = null;
        OutputStream os;
        StringBuffer response;
        BufferedReader br;
        String output;
        try {

            String requestUrl = getUrl(apiEndpoint, params);

            // System.out.println("Performing GET operation for '"+ requestUrl
            // +"'");

            url = new URL(requestUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            if (authToken != null) {
                String key = StringUtils.isNotBlank(tokenType)?tokenType:"token ";
                conn.setRequestProperty("Authorization", key+ authToken);
            }
            if (authentication != null) {
                conn.setRequestProperty("authentication", authentication);
            }

            conn.connect();
            response = new StringBuffer();
            boolean expectedResponseCode = false;
            for (int x = 0; x < expectedResponseCodes.length; x++) {
                if (conn.getResponseCode() == expectedResponseCodes[x]) {
                    expectedResponseCode = true;
                    break;
                }
            }
            System.out.println("response code: " + conn.getResponseCode());

            int responseCode = conn.getResponseCode();
            if (responseCode == 200) {

            }

            if (!expectedResponseCode) {
                String expCodes = "";
                for (int x = 0; x < expectedResponseCodes.length; x++) {
                    expCodes += "," + expectedResponseCodes;
                }
                throw new RuntimeException("Failed : HTTP response code: " + conn.getResponseCode()
                        + " did not match expected (" + expCodes + ")");
            }

            if (conn.getResponseCode() != 200) {
                return null;
            }
            Map headers = conn.getHeaderFields();
            br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
            while ((output = br.readLine()) != null) {
                response.append(output + "\n");
            }

            conn.disconnect();
            System.out.println("Elapsed time for GET operation (" + apiEndpoint + ")  was "
                    + (System.currentTimeMillis() - startTime) + ")ms");
            return response.toString();
        } catch (URISyntaxException u) {
            throw new ApiException("Unable to connect to malformed url...");
        } catch (MalformedURLException m) {
            throw new ApiException("Unable to connect to malformed url...");
        } catch (ProtocolException p) {
            throw new ApiException("Unable to connect to specified url (protocol exception)...");
        } catch (IOException io) {
            throw new ApiException("Unable to connect to specified url (io exception)...");
        } catch (Exception ex) {
            throw new ApiException("Unable to connect to specified url (exception)...");
        }
    }


    public static String[] performGETOperationWithResponseCode(String authToken, String apiEndpoint, HashMap<String, String> params
    ) {

        String[] responseSummary = new String[2];

        long startTime = System.currentTimeMillis();

        URL url;
        HttpURLConnection conn = null;
        OutputStream os;
        StringBuffer response;
        BufferedReader br;
        String output;
        try {

            String requestUrl = getUrl(apiEndpoint, params);

            // System.out.println("Performing GET operation for '"+ requestUrl
            // +"'");

            url = new URL(requestUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            if (authToken != null) {
                conn.setRequestProperty("Authorization", "token " + authToken);
            }

            conn.connect();
            response = new StringBuffer();

            if (conn.getResponseCode() == 401) {
                responseSummary[0] = "401";
                return responseSummary;
            }

            if (conn.getResponseCode() == 404) {
                responseSummary[0] = "404";
                return responseSummary;
            }

            if (conn.getResponseCode() == 500) {
                responseSummary[0] = "500";
                return responseSummary;
            }

            Map headers = conn.getHeaderFields();
            br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
            while ((output = br.readLine()) != null) {
                response.append(output + "\n");
            }

            responseSummary[0] = conn.getResponseCode() + "";
            responseSummary[1] = response.toString();

            conn.disconnect();

            System.out.println("Elapsed time for GET operation (" + apiEndpoint + ")  was "
                    + (System.currentTimeMillis() - startTime) + ")ms");
            return responseSummary;

        } catch (URISyntaxException u) {
            throw new ApiException("Unable to connect to malformed url...");
        } catch (MalformedURLException m) {
            throw new ApiException("Unable to connect to malformed url...");
        } catch (ProtocolException p) {
            throw new ApiException("Unable to connect to specified url (protocol exception)...");
        } catch (IOException io) {
            throw new ApiException("Unable to connect to specified url (io exception)...");
        } catch (Exception ex) {
            throw new ApiException("Unable to connect to specified url (exception)...");
        }
    }

    public static byte[] performBinaryGETOperation(String authToken, String apiEndpoint) {

        long startTime = System.currentTimeMillis();

        URL url;
        HttpURLConnection conn = null;
        OutputStream os;
        StringBuffer response;
        BufferedInputStream inputStream;
        String output;
        try {
            url = new URL(apiEndpoint);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            conn.setRequestProperty("Authorization", "token " + authToken);

            conn.connect();
            response = new StringBuffer();

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }

            InputStream is = conn.getInputStream();
            ByteArrayOutputStream buffer = new ByteArrayOutputStream();

            int nRead;
            byte[] data = new byte[16384];

            while ((nRead = is.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, nRead);
            }

            conn.disconnect();
            System.out.println("Elapsed time for GET operation (" + apiEndpoint + ")  was "
                    + (System.currentTimeMillis() - startTime) + ")ms");
            return buffer.toByteArray();

        } catch (MalformedURLException m) {
            throw new ApiException("Unable to connect to malformed url...");
        } catch (ProtocolException p) {
            throw new ApiException("Unable to connect to specified url (protocol exception)...");
        } catch (IOException io) {
            throw new ApiException("Unable to connect to specified url (io exception)...");
        }
    }

    public static void performDELETEOperation(String authToken, String apiEndpoint) {

        long startTime = System.currentTimeMillis();

        URL url;
        HttpURLConnection conn = null;
        OutputStream os;
        StringBuffer response;
        BufferedReader br;
        String output;
        try {
            url = new URL(apiEndpoint);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("DELETE");
            conn.setDoInput(true);
            conn.setRequestProperty("Authorization", "token " + authToken);

            conn.connect();
            response = new StringBuffer();

            if (conn.getResponseCode() == 401)
                throw new ApiException("401 Unauthorized");

            if (conn.getResponseCode() != 200 && conn.getResponseCode() != 204) {
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode() + " for url '" + apiEndpoint + "'");
            }

            br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            while ((output = br.readLine()) != null) {
                response.append(output);
            }

            conn.disconnect();
            System.out.println("Elapsed time for DELETE operation (" + apiEndpoint + ")  was "
                    + (System.currentTimeMillis() - startTime) + ")ms");
        } catch (MalformedURLException m) {
            throw new ApiException("Unable to connect to malformed url...");
        } catch (ProtocolException p) {
            throw new ApiException("Unable to connect to specified url (protocol exception)...");
        } catch (IOException io) {
            throw new ApiException("Unable to connect to specified url (io exception)...");
        }
    }

    public static String performPUTOperation(String authToken, String apiEndpoint, String jsonPostBody,
                                             HashMap<String, String> params) {
        long startTime = System.currentTimeMillis();

        URL url;
        HttpURLConnection conn = null;
        StringBuffer response;
        BufferedReader br;
        String output;
        String requestUrl = null;
        try {
            requestUrl = getUrl(apiEndpoint, params);
            url = new URL(requestUrl);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PUT");
            if (authToken != null) {
                conn.setDoInput(true);
                conn.setRequestProperty("Authorization", "token " + authToken);
            } else {
                conn.setDoInput(true);
            }

            if (jsonPostBody != null) {

                conn.setRequestProperty("Content-Type", "application/json");

                conn.setDoOutput(true);
                OutputStream outputStream = conn.getOutputStream();
                outputStream.write(jsonPostBody.getBytes(StandardCharsets.UTF_8));
                outputStream.flush();
            }

            conn.connect();
            response = new StringBuffer();

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
            }

            br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
            while ((output = br.readLine()) != null) {
                response.append(output);
            }

            conn.disconnect();
            System.out.println("Elapsed time for PUT operation (" + apiEndpoint + ")  was "
                    + (System.currentTimeMillis() - startTime) + ")ms");
            return response.toString();
        } catch (MalformedURLException m) {
            throw new ApiException("Unable to connect to malformed url...");
        } catch (ProtocolException p) {
            throw new ApiException("Unable to connect to specified url (protocol exception)...");
        } catch (IOException io) {
            throw new ApiException("Unable to connect to specified url (io exception)..." + requestUrl);
        } catch (Exception ex) {
            throw new ApiException(
                    "Unable to connect to specified url (exception)..." + requestUrl + jsonPostBody + ex.toString());
        }
    }

    public static String performPATCHOperation(String authToken, String apiEndpoint, String jsonBody,
                                               HashMap<String, String> params) {
        long startTime = System.currentTimeMillis();

        try {
            HttpClient client;
            client = HttpClientBuilder.create().build();
            HttpPatch request = new HttpPatch(apiEndpoint);

            request.setEntity(new StringEntity(jsonBody));
            request.addHeader("Accept", "application/json");
            request.addHeader("Content-Type", "application/json");
            request.addHeader("Authorization", "token " + authToken);

            HttpResponse response = client.execute(request);

            BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));

            StringBuffer result = new StringBuffer();
            String line = "";
            while ((line = rd.readLine()) != null) {
                result.append(line);
            }
            System.out.println("Elapsed time for PATCH operation (" + apiEndpoint + ")  was "
                    + (System.currentTimeMillis() - startTime) + ")ms");
            return result.toString();

        } catch (MalformedURLException m) {
            throw new ApiException("Unable to connect to malformed url...");
        } catch (ProtocolException p) {
            throw new ApiException("Unable to connect to specified url (protocol exception)...");
        } catch (IOException io) {
            throw new ApiException("Unable to connect to specified url (io exception)..." + apiEndpoint);
        } catch (Exception ex) {
            throw new ApiException("Unable to connect to specified url (exception)..." + apiEndpoint);
        }
    }
}
