package com.mckesson.app.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.google.common.collect.Maps;

public class ParameterUtil {

    public final static Collection<String[]> toSequence(Map<String, String> m, String[] names) {
        if (m == null || m.isEmpty() || names == null || names.length == 0)
            return Collections.emptyList();

        Collection<String[]> results = new ArrayList<String[]>(m.size() / names.length);
        String prefix = names[0];
        String suffix;
        String[] v;
        for (String pn : m.keySet()) {
            if (pn.startsWith(prefix)) {
                suffix = pn.substring(prefix.length());
                v = new String[names.length];
                for (int i = 0; i < names.length; i++) {
                    v[i] = m.get(names[i].concat(suffix));
                }
                results.add(v);
            }
        }

        return results;
    }

    public final static Map<String, String[]> toParameterMap(Map<String, String> m) {
        Map<String, String[]> result = Maps.newHashMap();
        for (Map.Entry<String, String> e : m.entrySet()) {
            result.put(e.getKey(), new String[]{e.getValue()});
        }
        return result;
    }

    public final static Map<String, String> toSingleParameterMap(Map<String, String[]> params) {
        Map<String, String> result = Maps.newHashMap();
        for (Map.Entry<String, String[]> e : params.entrySet()) {
            result.put(e.getKey(), get(e.getValue()));
        }
        return result;
    }

    private static String get(String[] values) {
        if (values == null || values.length == 0)
            return null;
        return values[0];
    }

    public final static Map<String, String[]> toMap(String queryInfo) {
        Map<String, String[]> m = new HashMap<String, String[]>();
        if (StringUtils.isNotBlank(queryInfo)) {
            String[] s = queryInfo.split("&");
            String[] v = null;

            for (int i = 0; i < s.length; i++) {
                v = s[i].split("=");
                if (v.length == 2 && StringUtils.isNotBlank(v[1])) {

                    // Yes I know this is overwriting the other parameters, but this is what the
                    // behavior was before I added the parameters to the generics
                    m.put(v[0], new String[]{v[1]});
                }
            }
        }
        return m;
    }

    public final static Map<String, String[]> toParameterMap(String queryInfo) {
        return toParameterMap(queryInfo, false);
    }

    public final static Map<String, String[]> toParameterMap(String queryInfo, boolean decode) {
        Map<String, String[]> m = new HashMap<String, String[]>();
        Map<String, List<String>> tmp = new HashMap<String, List<String>>();

        if (StringUtils.isNotBlank(queryInfo)) {
            String[] s = queryInfo.split("&");
            String[] v = null;

            for (int i = 0; i < s.length; i++) {
                v = s[i].split("=");
                if (v.length == 2 && StringUtils.isNotBlank(v[1])) {
                    v[1] = v[1].replace('+', ' ');
                    List<String> tmpList = tmp.get(v[0]);
                    if (tmpList == null) {
                        tmpList = new ArrayList<String>();
                        try {
                            tmp.put(decode ? URLDecoder.decode(v[0], "UTF-8") : v[0], tmpList);
                        } catch (UnsupportedEncodingException e) {
                            tmp.put(v[0], tmpList);
                        }

                    }
                    try {
                        tmpList.add(decode ? URLDecoder.decode(v[1], "UTF-8") : v[1]);
                    } catch (UnsupportedEncodingException e) {
                        tmpList.add(v[1]);
                    }
                }
            }
            for (Entry<String, List<String>> entry : tmp.entrySet()) {
                m.put(entry.getKey(), entry.getValue().toArray(new String[0]));
            }
        }
        return m;
    }

    public final static String remove(Map<String, String[]> params, String[] less) {
        Map<String, String[]> m = new HashMap<String, String[]>(params);
        if (less != null) {
            for (int i = 0; i < less.length; i++) {
                m.remove(less[i]);
            }
        }
        return toQueryString(m);
    }

    public final static void appendQueryString(StringBuffer sb, Map<String, String[]> m) {
        if (m != null && !m.isEmpty()) {
            sb.append('?');
            for (Entry<String, String[]> e : m.entrySet()) {
                for (int i = 0; i < e.getValue().length; i++) {
                    try {
                        sb.append(e.getKey()).append('=').append(URLEncoder.encode(e.getValue()[i], "UTF-8"))
                                .append('&');
                    } catch (UnsupportedEncodingException exc) {
                        // do nothing
                    }
                }
            }
            sb.setLength(sb.length() - 1);
        }
    }

    public final static String toQueryString(Map<String, String[]> m, boolean encode) {
        if (m != null && m.size() > 0) {
            StringBuffer sb = new StringBuffer(32);

            for (Entry<String, String[]> e : m.entrySet()) {
                for (int i = 0; i < e.getValue().length; i++) {
                    try {
                        if (encode) {
                            sb.append(URLEncoder.encode(e.getKey(), "UTF-8")).append('=');
                            sb.append(URLEncoder.encode(e.getValue()[i], "UTF-8"));
                        } else {
                            sb.append(e.getKey()).append('=');
                            sb.append(e.getValue()[i]);
                        }
                        sb.append('&');
                    } catch (UnsupportedEncodingException exc) {
                        // do nothing
                    }
                }
            }
            if (sb.length() > 0) {
                sb.setLength(sb.length() - 1);
            }
            return sb.toString();
        }
        return "";
    }

    public final static String toQueryString(Map<String, String[]> m) {
        return toQueryString(m, true);
    }

    /*
     * Removes begining and end '/' from each piece and concatenates them with a
     * single '/' between each piece.
     */
    public final static String toPath(String... pieces) {
        if (pieces == null || pieces.length == 0)
            return null;

        String[] cleaned = new String[pieces.length];
        for (int i = 0; i < cleaned.length; i++) {
            cleaned[i] = StringUtils.removeEnd(StringUtils.removeStart(pieces[i], "/"), "/");
        }

        return StringUtils.combine(cleaned, "/");
    }
}