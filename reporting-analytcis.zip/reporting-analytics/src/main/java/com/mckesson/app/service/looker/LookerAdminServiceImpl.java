package com.mckesson.app.service.looker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.service.looker.api.GroupApi;
import main.java.com.mckesson.app.service.looker.api.RoleApi;
import main.java.com.mckesson.app.service.looker.api.UserApi;
import main.java.com.mckesson.app.util.RestClient;
import main.java.com.mckesson.app.vo.looker.RoleVo;
import main.java.com.mckesson.app.vo.looker.UserVo;

@Service("LookerAdminService")
public class LookerAdminServiceImpl implements LookerAdminService{

	@Autowired
	private GroupApi groupApi;
	
	@Autowired 
	private RoleApi roleApi;
	
	@Autowired 
	UserApi userApi;
	
	@Autowired
	LookerEmbedUrlGenerator embedUrlGenerator;
	
	@Autowired
	private LookerService lookerService;
	
	@Value("${looker.apiKey}")
	private String lookerApiKey;
	
	@Value("${looker.apiSecret}")
	private String lookerApiSecret;
	
	@Value("${looker.host}")
	String lookerHost;
	
	@Value("${looker.embedkey}")
	private String lookerEmbedKey;
		
	private String[] lookerModels = {""};
	
	@Value("${dashboardids.home}")
	private String defaultDashboardId;
	
	/**
	 * Create new embed user. There is no direct API call provided by looker that allows the creation of 'embed' type users, 
	 * they do exist for 'normal' user accounts, however 'embed' type users must be created via the act of performing a request 
	 * for an embed url. Once the call is made, looker will create the embed account automatically. 
	 * 
	 */
	@Override
	public UserVo createEmbedUser(ReportUser reportUser,UserVo user, String embedDomain) {
		
		String requestUrl = lookerService.getDashboardEmbedUrlForEmbedUser(reportUser,defaultDashboardId, null, embedDomain);
		String authToken = groupApi.getAuthToken();
		RestClient.performGETOperation(authToken, requestUrl); //Call made on behalf of the client to create the 'embed' account
		UserVo newUser = userApi.getUserByEmbed(user.getExternalUserId(), authToken);
		return newUser;
	}

	@Override
	public void deleteEmbedUser(String externaUserId) {
		String authToken = groupApi.getAuthToken();
		userApi.deleteEmbedUser(externaUserId, authToken);
	}

	@Override
	public void updateEmbedUser(UserVo user) {
		String authToken = groupApi.getAuthToken();
		
		userApi.updateUser(user, authToken);
	}

	@Override
	public GroupVo createGroup(GroupVo group) {
		String authToken = groupApi.getAuthToken();
		return groupApi.createGroup(group, authToken);
	}

	@Override
	public GroupVo getGroupByName(String groupName) throws Exception {
		String authToken = groupApi.getAuthToken();
		return groupApi.getGroupByName(groupName, authToken);
	}

	@Override
	public void updateGroup(GroupVo group) {
		String authToken = groupApi.getAuthToken();
		String[] fields = {"id","names"};
		groupApi.updateGroup(group, fields, authToken);
	}

	@Override
	public GroupVo renameGroupName(Long groupId,String groupName) {
		String authToken = groupApi.getAuthToken();
		return groupApi.renameGroupName(groupId.toString(), groupName, authToken);
	}

	@Override
	public void deleteGroup(Long groupId) {
		String authToken = groupApi.getAuthToken();
		groupApi.deleteGroup(groupId, authToken);
	}

	@Override
	public void addUserToGroup(Long groupId, String userId) {
		String authToken = groupApi.getAuthToken();
		String[] fields = {"id","names"};
		groupApi.addUserToGroup(groupId, userId, fields, authToken);
	}

	@Override
	public void removeUserFromGroup(Long groupId, String userId) {
		String authToken = groupApi.getAuthToken();
		groupApi.deleteUserFromGroup(groupId, userId, authToken);
	}

	@Override
	public UserVo getUserByExternalId(String externalUserId) {
		String authToken = groupApi.getAuthToken();
		UserVo user = userApi.getUserByEmbed(externalUserId, authToken); 
		if(user.getRoleIds()!=null) {
			List<RoleVo> roles = listRoles(authToken);
			HashMap<Long,String> roleMaps = new HashMap();
			for(RoleVo role:roles) {
				roleMaps.put(role.getId(), role.getName());
			}
			Long roleId;
			for( int x=0;x<user.getRoleIds().length;x++ ) {
				roleId = user.getRoleIds()[x];
				user.getRoles().put(roleId, roleMaps.get(roleId));
			}
		}
		
		if(user.getGroupIds()!=null) {
			List<GroupVo>groups = listGroups(authToken);
			HashMap<Long,String> groupMaps = new HashMap();
			for(GroupVo group:groups) {
				groupMaps.put(group.getId(), group.getName());
			}
			Long groupId;
			for( int x=0;x<user.getGroupIds().length;x++ ) {
				groupId = user.getGroupIds()[x];
				user.getGroups().put(groupId, groupMaps.get(groupId));
			}
		}
		
		return user;
	}
	
	public List<GroupVo> listGroups() {
		String authToken = groupApi.getAuthToken();
		return listGroups(authToken);
	}
	
	public List<GroupVo> listGroups(String authToken) {
		 return groupApi.listGroups(authToken);
	}
	
	public List<UserVo> getUsersByGroup(Long groupId) {
		String[] fields = {"id","first_name","last_name", "display_name", "external_user_id"};
		String authToken = groupApi.getAuthToken();
		 return groupApi.getUsersByGroup(groupId, fields, authToken);
	}
	
	public List<RoleVo> listRoles() {
		String authToken = roleApi.getAuthToken();
		return listRoles(authToken);
	}
	
	public List<RoleVo> listRoles(String authToken) {
		String[] fields = {"id","name"};
		return roleApi.listGroups(fields, authToken);
	}

	public void assignToGroupsToUser(UserVo user, List<Long> groupIds){
		List<Long> newGroups; 
		newGroups = new ArrayList();
		String authToken = groupApi.getAuthToken(); 
		
		String[] fields = {"id"};
		for(Long id : newGroups) {
			groupApi.addUserToGroup(id, user.getId(), fields, authToken);
		}
	}

}

