package com.mckesson.app.auth.account;

import java.util.Collection;
import java.util.List;

import com.google.common.collect.Lists;
import com.mckesson.lib.model.customer.AccountId;
import com.mckesson.lib.model.platform.PlatformId;

import main.java.com.mckesson.app.auth.user.UserAccessModel;
import main.java.com.mckesson.app.domain.customer.Account;

public class StaticAccountAuthority implements AccountAuthority {

    private UserAccessModel uam = null;
    private final List<PlatformId> platforms = Lists.newArrayList();

    public StaticAccountAuthority() {
    }

    public StaticAccountAuthority(UserAccessModel uam) {
        this.uam = uam;
        for (PlatformId plat : PlatformId.values()) {
            if (uam.filter(plat).isValid()) {
                this.platforms.add(plat);
            }
        }
    }

    @Override
    public boolean isFullAccess(AccountId aid) {
        return this.uam.isFullAccess(aid);
    }

    @Override
    public boolean isFullAccessByAccount(Account account) {
        return isFullAccess(account.getId());
    }

    @Override
    public boolean isAnyAccess(AccountId aid) {
        return this.uam.isAnyAccess(aid);
    }

    @Override
    public Collection<PlatformId> getAccessiblePlatforms() {
        return platforms;
    }

}
