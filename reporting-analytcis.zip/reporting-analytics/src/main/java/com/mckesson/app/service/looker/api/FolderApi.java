package com.mckesson.app.service.looker.api;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.util.MappingUtils;
import main.java.com.mckesson.app.util.RestClient;
import main.java.com.mckesson.app.vo.looker.FolderVo;
import main.java.com.mckesson.app.vo.looker.LookVo;

@Component
public class FolderApi extends ApiBase {

    @Value("${looker.sharedFolderId}")
    String sharedFolderId;

    private final Logger logger = LoggerFactory.getLogger(FolderApi.class);

    public String getAllFolders(String authToken) {
        String requestUrl = null;
        try {
            requestUrl = this.lookerApiHost + "/folders";
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl);
            return jsonResponse;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public FolderVo getFolder(String authToken, String folderId) {
        String requestUrl;
        FolderVo folder = new FolderVo();
        try {
            requestUrl = this.lookerApiHost + "/folders/" + folderId;
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl);
            MappingUtils.populateFromJson(jsonResponse, folder);
            return folder;
        }
        catch(Exception e) {
            logger.error("Error occurred while updating the folder"+folderId+ " getMessage " +e.getMessage());
            return null;
        }
    }

    public String getlooks(String authToken, String folderId) {
        String requestUrl = null;
        try {
            requestUrl = this.lookerApiHost + "/folders/" + folderId + "/looks";
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl);
            return jsonResponse;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public List<FolderVo> getFolderChildren(String folderId, String authToken) throws Exception {
        try {
            String requestUrl = this.lookerApiHost + "/folders/" + folderId + "/children";
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl);
            return MappingUtils.getCollectionFromJson(jsonResponse, FolderVo.class);
        } catch (Exception e) {
            logger.error("Error occurred while getFolderChildren"+folderId+ " getMessage " +e.getMessage());
            return MappingUtils.getCollectionFromJson(null, FolderVo.class);
        }
    }

    public List<FolderVo> searchSharedFoldersByName(String folderName, String authToken) throws Exception {
        try {
            String requestUrl = this.lookerApiHost + "/folders/search?name=" + URLEncoder.encode(folderName, "UTF-8").replace("+", "%20") + "&parent_id=" + sharedFolderId;
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, null);
            return MappingUtils.getCollectionFromJson(jsonResponse, FolderVo.class);
        } catch (Exception e) {
            return MappingUtils.getCollectionFromJson(null, FolderVo.class);
        }
    }

    public List<FolderVo> searchSharedFoldersByNameInParent(String folderName, String authToken, String parentId) throws Exception {
        try {
            String requestUrl = this.lookerApiHost + "/folders/search?name=" + URLEncoder.encode(folderName, "UTF-8").replace("+", "%20") + "&parent_id="+parentId;
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, null);
            return MappingUtils.getCollectionFromJson(jsonResponse, FolderVo.class);
        } catch (Exception e) {
            logger.error("Error occurred while updating the folder"+folderName+ " getMessage " +e.getMessage());
            return MappingUtils.getCollectionFromJson(null, FolderVo.class);
        }
    }

    public List<FolderVo> searchFoldersByName(String folderName, String authToken) throws Exception {
        try {
            String requestUrl = this.lookerApiHost + "/folders/search?name=" + URLEncoder.encode(folderName, "UTF-8").replace("+", "%20");
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, null);
            return MappingUtils.getCollectionFromJson(jsonResponse, FolderVo.class);
        } catch (Exception e) {
            throw new Exception(e);
        }
    }

    public FolderVo createFolder(String parentId, String folderName, String authToken){
        FolderVo folder = new FolderVo();
        String jsonBody = "{ \"name\" : \"" + folderName + "\",\"parent_id\" : \"" + parentId + "\" }";

        try {
            String requestUrl = this.lookerApiHost + "/folders";
            String jsonResponse = RestClient.performPOSTOperation(authToken, requestUrl, jsonBody, null);
            MappingUtils.populateFromJson(jsonResponse, folder);
            return folder;
        } catch (Exception e) {
            logger.error("Error occurred while updating the folder"+folderName+ " getMessage " +e.getMessage());
            return null;
        }
    }

    public boolean updateFolder(String parentId, String folderId, String authToken) {
        FolderVo folder = new FolderVo();
        String jsonBody = "{\n" +
                "  \"parent_id\": \""+parentId+"\"\n" +
                "}", jsonResponse, requestUrl;

        try {
            requestUrl = this.lookerApiHost + "/folders/" + folderId;
            jsonResponse = RestClient.performPATCHOperation(authToken, requestUrl, jsonBody, null);
            MappingUtils.populateFromJson(jsonResponse, folder);
            return true;
        } catch (Exception e) {
            logger.error("Error occurred while updating the folder"+folderId+ " getMessage " +e.getMessage());
            return false;
        }
    }


    public LookVo updateLook(LookVo look, String[] fields, String authToken) {
        try {
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/looks/" + look.getId();
            //String jsonBody = MappingUtils.serializeToJson(look);

            String jsonBody = "{ \"title\":\"" + look.getTitle() + "\",\"description\":\"" + look.getDescription() + "\" }";

            String jsonResponse = RestClient.performPATCHOperation(authToken, requestUrl, jsonBody, null);
            MappingUtils.populateFromJson(jsonResponse, look);
            return look;

        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public List<FolderVo> listChildrenForFolder(String parentFolderId, String[] fields, String authToken) {
        try {
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());

            String requestUrl = this.lookerApiHost + "/folders/" + parentFolderId + "/children";
            String[] responseSummary = RestClient.performGETOperationWithResponseCode(authToken, requestUrl, params);

            if (responseSummary[0].equals("401") || responseSummary[0].equals("404")) {
                throw new AccessDeniedException("User is unable to access selected folder id '" + parentFolderId + "'");
            }

            String jsonResponse = responseSummary[1];
            System.out.println(jsonResponse);
            return MappingUtils.getCollectionFromJson(jsonResponse, FolderVo.class);
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public FolderVo renameFolderName(String folderId, String folderNewName, String authToken) {

        FolderVo folder = new FolderVo();
        String jsonBody = "{\n" +
                "  \"name\": \""+folderNewName+"\"\n" +
                "}";

        try {
            String requestUrl = this.lookerApiHost + "/folders/"+folderId;
            String jsonResponse = RestClient.performPATCHOperation(authToken, requestUrl, jsonBody, null);
            MappingUtils.populateFromJson(jsonResponse, folder);
            return folder;
        } catch (Exception e) {
            logger.error("Error occurred while rename the folderId  "+folderId+ " getMessage " +e.getMessage());
            return null;
        }
    }


    public List<FolderVo> searchDashboardContent(String folderId, String authToken) throws Exception {
        try {
            String requestUrl = this.lookerApiHost + "/folders/"+folderId+"/dashboards";
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, null);
            return MappingUtils.getCollectionFromJson(jsonResponse, FolderVo.class);
        } catch (Exception e) {
            return null;
        }
    }

    public List<FolderVo> searchReportContent(String folderId, String authToken) throws Exception {
        try {
            String requestUrl = this.lookerApiHost + "/folders/"+folderId+"/looks";
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, null);
            return MappingUtils.getCollectionFromJson(jsonResponse, FolderVo.class);
        } catch (Exception e) {
            return null;

        }
    }

}
