package com.mckesson.app.service.looker.config;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "teamspacemanagement")
public class TeamSpaceManagementConfiguration {
    private Map<String, String> teambasefolderids;

    public Map<String, String> getTeamBaseFolderIds() {
        return teambasefolderids;
    }

    public void setTeamBaseFolderIds(Map<String, String> teamBaseFolderIds) {
        this.teambasefolderids = teamBaseFolderIds;
    }
}
