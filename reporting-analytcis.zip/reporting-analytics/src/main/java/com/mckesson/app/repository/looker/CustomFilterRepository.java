package com.mckesson.app.repository.looker;

import java.awt.print.Pageable;
import java.util.Collection;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import main.java.com.mckesson.app.domain.looker.CustomFilter;
import main.java.com.mckesson.app.vo.CustomFilterSummary;


public interface CustomFilterRepository extends JpaRepository<CustomFilter, Long>, JpaSpecificationExecutor<CustomFilter> {

    @Query(value = "Select new com.mckesson.app.vo.CustomFilterSummary(f.id, f.name, f.userId, function('date_format', f.creationDate, '%Y-%m-%dT%TZ'), function('date_format', f.lastUpdateDate, '%Y-%m-%dT%TZ'), f.author, f.sharedTeams, f.explore, f.otherDefinition) from com.mckesson.app.domain.looker.CustomFilter f")
    List<CustomFilterSummary> list(); // TODO: pagination

    @Query(value = "select filter.LDF_ID id, filter.LDF_NAME name from looker_dyn_field filter where filter.ldf_id in(select looker_dyn_field_id from looker_dyn_field_to_explore where looker_dyn_field_explore_id=?1)", nativeQuery = true)
    List<CustomFilterProjection> listForExplore(Long exploreId);

    Page<CustomFilter> findByUserIdAndNameContainingIgnoreCase(String userId, String name, Pageable pageable);

    @Query(value = " from CustomFilter where explore=?1 and userId=?2")
    Collection<CustomFilter> getByExploreType(String exploreName, String userId);
}
