package com.mckesson.app.config;

import javax.inject.Inject;

import org.omg.CORBA.Environment;
import org.springframework.context.annotation.Configuration;

import main.java.com.mckesson.app.service.looker.LookerEmbedUrlGenerator;
import main.java.com.mckesson.app.service.looker.config.QidConfiguration;

/**
 * configure and initialize utilities with environment properties
 */
@Configuration
public class InitializeApplicationConfig {

    private final Environment env;
    private final QidConfiguration qidConfiguration;

    @Inject
    public InitializeApplicationConfig(Environment env, QidConfiguration qidConfiguration) {
        this.env = env;
        this.qidConfiguration = qidConfiguration;
        initializeUtilities();
    }

    /**
     * triggers initialization
     *
     * @param env
     */
    private void initializeUtilities() {
        prepareLookerEmbedUrlGenerator();
    }

    /**
     * prepare looker embed URL generator utility class
     *
     * @param env
     */
    private void prepareLookerEmbedUrlGenerator() {
        String lookerHost = env.getProperty("looker.host");
        String lookerModels = env.getProperty("looker.models");
        String lookerEmbedKey = env.getProperty("looker.embedkey");
        String groupIds = env.getProperty("looker.groupIds");
        LookerEmbedUrlGenerator.getInstance().initialize(lookerHost, lookerModels, lookerEmbedKey, groupIds, qidConfiguration);
    }
}