package com.mckesson.app.repository.customer;

import java.awt.print.Pageable;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import main.java.com.mckesson.app.domain.customer.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long>, JpaSpecificationExecutor<Customer> {

    @Modifying
    @Query(value = "update Customer t set  t.deletedDate=?1  where t.customerId in ?2")
    void deleteCustomer(Date deletedDate, List<Long> customer);

    @Modifying
    @Query(value = "update customer t set  deleted_date=null where t.customerId in ?1 ", nativeQuery = true)
    void active(List<Long> list);

    @Query(value = "select distinct c.* from customer c where c.amdm_era_ownr_party_id is not null and c.amdm_era_ownr_name is not null and c.deleted_date is null and c.amdm_era_ownr_name!='All My Accounts' and c.amdm_era_ownr_name not in ('BetaUsers','InternalUsers')",nativeQuery = true)
    List<Customer> getCustomer();

    @Query(value = "select distinct c.* from customer c where c.amdm_era_ownr_party_id is not null and c.amdm_era_ownr_name is not null and c.deleted_date is null and c.settings='beta' and c.amdm_era_ownr_name!='All My Accounts' and c.amdm_era_ownr_name not in ('BetaUsers','InternalUsers')",nativeQuery = true)
    List<Customer> getBetaCustomers();

    @Query(value = "select distinct c.* from customer c where c.amdm_era_ownr_name='All My Accounts' and c.settings='external' and c.deleted_date is null and c.amdm_era_ownr_name not in ('BetaUsers','InternalUsers')\n" +
            "union \n" +
            "SELECT distinct c.* FROM Customer c JOIN user_mapping um on c.customer_id = um.customer_id JOIN user_profile up on um.user_id = up.user_id\n" +
            "WHERE c.amdm_era_ownr_party_id is not null and c.deleted_date is null and c.amdm_era_ownr_name is not null and um.deleted_date is null and c.amdm_era_ownr_name not in ('BetaUsers','InternalUsers') and up.user_id = ?1",nativeQuery = true)
    List<Customer> getCustomerById(String userId);

    @Query(value = "select distinct c.* from Customer c where amdm_era_ownr_party_id is not null and amdm_era_ownr_name is not null and amdm_era_ownr_name not in ('BetaUsers','InternalUsers') and deleted_date is null order by amdm_era_ownr_name",nativeQuery = true)
    List<Customer> getCustomerForAdminTool();

    @Query(value = "select distinct commonEntityId,commonEntityName,totalAccounts from Customer where commonEntityId is not null and commonEntityName is not null and deletedDate is null and settings='beta'")
    List<Customer> getBetaCustomersForAdminTool();

    @Query(value = "SELECT distinct c.* FROM Customer c JOIN user_mapping um on c.customer_id = um.customer_id JOIN user_profile up on um.user_id = up.user_id\n" +
            "WHERE c.amdm_era_ownr_party_id is not null and c.amdm_era_ownr_name is not null and um.deleted_date is null and up.user_id =?1", nativeQuery = true)
    List<Customer> getCustomerByIdForAdminTool(String userId);

    @Query(value = "select count(*) from customer cs,user_mapping um where cs.customer_id=um.customer_id and um.user_id = ?1 and cs.common_entity_id=?2", nativeQuery = true)
    int checkCustomerAccess(String userId, String commonEntityId);

    @Query(value = "select distinct customer_id as CustomerId from customer where amdm_era_ownr_name=?1 and deleted_date is null", nativeQuery = true)
    String getCustomerIdByCustomerName(String commonEntityName);

    @Query(value = "select distinct amdm_era_ownr_party_id as CustomerId from customer where amdm_era_ownr_name=?1 and deleted_date is null", nativeQuery = true)
    String getCustomerIdByCommonEntityName(String commonEntityName);

    @Query(value = "select distinct amdm_era_ownr_party_id as CustomerId from customer where amdm_era_ownr_name=?1 and deleted_date is null and settings='beta'", nativeQuery = true)
    String getCustomerIdByCustomerNameForBeta(String commonEntityName);

    /* user permission job queries*/
    @Query(value = "SELECT count(user_id) FROM s_iw_user_access c WHERE NOT EXISTS (SELECT user_id FROM user_profile WHERE user_id = c.user_id) and c.sys_id='STK2'", nativeQuery = true)
    int usersToCreateCount();

    @Modifying
    @Query(value = "INSERT INTO user_profile (user_id,user_role,internal,created_by,created_date) SELECT DISTINCT user_id,'CU','false','SYSTEM',?1 FROM s_iw_user_access c WHERE NOT EXISTS (SELECT user_id FROM user_profile WHERE user_id = c.user_id ) AND c.sys_id='STK2'", nativeQuery = true)
    void insertUserProfiles(Date createdDate);

    @Modifying
    @Query(value = "UPDATE user_profile up join (select u.func_nam, p.func_cd from s_user_func u left join s_prvg_func p on u.appl_cd = p.func_cd) spf on up.user_id=spf.func_nam set up.function_code=spf.func_cd ", nativeQuery = true)
    void updateUserFunctions();

    @Modifying
    @Query(value = "UPDATE user_profile up join (select user_id, group_concat(distinct MRKT_SEG_NAM order by MRKT_SEG_NAM asc separator '|') market_segment\n" +
            "from (select a.USER_ID, b.MRKT_SEG_NAM from (select distinct user_id, ACCOUNT_ID from era_user_permissions where user_id != 'system_generated') a\n" +
            "  join v_if_ra_dim_cust_acct_curr b on a.ACCOUNT_ID=b.cust_acct_id ) x group by user_id) spf on up.user_id = spf.user_id set up.market_partition = spf.market_segment", nativeQuery = true)
    void updateUserMarketPartition();

    @Modifying
    @Query(value = "UPDATE user_profile up join (select user_id, case when bla_sum > 0 then 'Y' else 'N' end bla_eligible\n" +
            "from (select a.user_id, sum(case when d.bla_acct = 'Y' then 1 else 0 end) bla_sum from era_user_permissions a\n" +
            "join (select cust_acct_id, case when bla_sum > 0 then 'Y' else 'N' end bla_acct from (select cust_acct_id,\n" +
            "sum(case when SPCLTY_DIFFRNTL_PRC_ELGBL_TYPE_DSCR in ('BLA') then 1 else 0 end) bla_sum from v_if_ra_dim_cust_acct_curr b\n" +
            "group by 1) c ) d on a.account_id = d.cust_acct_id group by 1) e) f on up.user_id = f.user_id set up.bla_eligible = f.bla_eligible", nativeQuery = true)
    void updateUserBlaEligible();

    @Query(value = "SELECT count(distinct(c.amdm_era_ownr_party_id)) FROM v_if_ra_dim_cust_acct_curr c where c.amdm_era_ownr_party_id is not null and c.amdm_era_ownr_party_id not in (SELECT cs.amdm_era_ownr_party_id FROM customer cs where cs.amdm_era_ownr_party_id is not null)", nativeQuery = true)
    int customersToCreateCount();

    @Modifying
    @Query(value = "INSERT INTO customer (amdm_era_ownr_party_id, amdm_era_ownr_name, platform,created_by,created_date)\n" +
            "  SELECT c.amdm_era_ownr_party_id, c.amdm_era_ownr_name, 'P','SYSTEM',current_timestamp FROM v_if_ra_dim_cust_acct_curr c where c.amdm_era_ownr_party_id is not null and c.amdm_era_ownr_name is not null\n" +
            "   and amdm_era_ownr_party_id!=0 and c.amdm_era_ownr_party_id not in (SELECT cs.amdm_era_ownr_party_id FROM customer cs where cs.amdm_era_ownr_party_id is not null) group by c.amdm_era_ownr_party_id\n", nativeQuery = true)
    void insertCustomers(Date createdDate);

    @Modifying
    @Query(value = "UPDATE customer up join (SELECT amdm_era_ownr_party_id, count(*) as total_accounts FROM  v_if_ra_dim_cust_acct_curr where amdm_era_ownr_party_id is not null GROUP BY amdm_era_ownr_party_id) spf on up.amdm_era_ownr_party_id=spf.amdm_era_ownr_party_id set up.total_accounts=spf.total_accounts", nativeQuery = true)
    void updateAccountsCount();

    @Query(value = "select distinct c.common_entity_name common_entity_name,c.common_entity_id common_entity_id,cs.customer_id customer_id, cs.platform, c.common_grp_id, c.common_grp_name, cs.settings, cs.updated_by,\n" +
            "  cs.updated_date, cs.deleted_by, cs.deleted_date, cs.created_by, cs.created_date,cs.customer_name, cs.total_accounts, c.byng_grp_id as  byng_grp_id, c.byng_grp_name as byng_grp_name from customer cs,v_if_ra_dim_cust_acct_curr c\n" +
            "where  c.common_entity_id=cs.common_entity_id and c.common_entity_id is not null and cs.common_entity_name is not null ", nativeQuery = true)
    List<Customer> getUpdateCustomerInfo();

    @Query(value = "select count(*) from (\n" +
            "select distinct up.user_id,cs.common_entity_id from user_profile up,customer cs,era_user_permissions eup where\n" +
            " up.user_id=eup.user_id and cs.customer_id=eup.customer_id and eup.user_id is not null and eup.customer_id is not null\n" +
            "and not exists(select 1 from user_mapping um where up.user_id=um.user_id and cs.customer_id=um.customer_id and um.updated_date is null)) a", nativeQuery = true)
    int mappingsCount();

    @Modifying
    @Query(value = "insert into user_mapping (platform, customer_id, user_id, created_by, created_date)\n" +
            "select distinct eup.platform_id,cs.common_entity_id,up.user_id,'SYSTEM',?1 from user_profile up,customer cs,era_user_permissions eup where\n" +
            " up.user_id=eup.user_id and cs.customer_id=eup.customer_id and eup.user_id is not null and eup.customer_id is not null ", nativeQuery = true)
    void insertUserMappings(Date createdDate);

    @Query(value = "select cs.* from customer cs where cs.customer_id not in (select distinct customer_id from collaboration_team) and cs.amdm_era_ownr_name is not null and cs.deleted_date is null",nativeQuery = true)
    List<Customer> getCustomersToCreate();

    @Query(value = "select customer_id, platform, common_grp_id, common_grp_name, coalesce(common_entity_id,'') common_entity_id, coalesce(customer_name,common_entity_name) common_entity_name, settings, updated_by, updated_date, deleted_by, deleted_date, created_by, created_date, customer_name, total_accounts, byng_grp_id, byng_grp_name, natl_grp_cd,natl_grp_name, natl_sub_grp_cd,natl_sub_grp_name, acct_chn_id, acct_chn_name, sls_terr_id, cust_rgn_num, cust_dstrct_num, acct_chn_name, amdm_ownr_num, pri_sec_flag, era_contact, `340b_flag`, customer_type, cust_dstrct_name,alt_payer_id,owner_name,amdm_era_ownr_party_id,amdm_era_ownr_name from customer where deleted_date is null and ((amdm_era_ownr_name like ?1%) or (customer_name like ?1%))",
            countQuery = "select count(customer_id) from customer where  deleted_date is null and ((common_entity_name like ?1%) or (customer_name like ?1%))",nativeQuery = true)
    Page<Customer> findByCommonEntityNameContainingIgnoreCase(String name, Pageable pageable);

    @Query(value = "select customer_id, platform, common_grp_id, common_grp_name, coalesce(common_entity_id,'') common_entity_id, coalesce(customer_name,common_entity_name) common_entity_name, settings, updated_by, updated_date, deleted_by, deleted_date, created_by, created_date, customer_name, total_accounts, byng_grp_id, byng_grp_name, natl_grp_cd,natl_grp_name, natl_sub_grp_cd, natl_sub_grp_name,acct_chn_id, acct_chn_name, sls_terr_id, cust_rgn_num, cust_dstrct_num, acct_chn_name, amdm_ownr_num, pri_sec_flag, era_contact, `340b_flag`, customer_type, cust_dstrct_name,alt_payer_id,owner_name,amdm_era_ownr_party_id,amdm_era_ownr_name from customer where amdm_era_ownr_name not in ('BetaUsers','InternalUsers') and amdm_era_ownr_name is not null and deleted_date is null",
            countQuery = "select count(customer_id) from customer where amdm_era_ownr_name not in ('BetaUsers','InternalUsers') and amdm_era_ownr_name is not null and (deleted_date is null)",nativeQuery = true)
    Page<Customer> findByCommonEntityNameContainingIgnoreCasePageZero(Pageable pageable);

    @Query("from Customer where amdmEraOwnrPartyId=?1 and amdm_era_ownr_name not in ('BetaUsers','InternalUsers')")
    Optional<Customer> findByCommonEntityId(String id);

    @Query(value = "SELECT c.cust_acct_id, c.cust_acct_nam, c.acct_dlvry_addr, c.acct_dlvry_cty_nam, c.acct_dlvry_st_abrv, c.acct_dlvry_zip, c.amdm_era_ownr_party_id, c.amdm_era_ownr_name FROM v_if_ra_dim_cust_acct_curr c WHERE c.amdm_era_ownr_party_id = ?1", nativeQuery = true)
    List<Object[]> findAccountsByCommonEntityId(String commonEntityId);

    @Query(value = "select cs.* from customer cs where cs.customer_id not in (select distinct customer_id from  security_group)  and cs.amdm_era_ownr_party_id is not null and cs.deleted_date is null",nativeQuery = true)
    List<Customer> getCustomerSecurityGroupsToCreate();

    @Query(value = "select DISTINCT cs.* from customer cs where cs.amdm_era_ownr_name= ?1", nativeQuery = true)
    List<Customer> getCustomerByName(String commonEntityName);

    Optional<Customer> findByAmdmEraOwnrNameIgnoreCase(String amdmEraOwnrName);

    @Query(value = "select distinct cs.* from v_if_ra_dim_cust_acct_curr c, customer cs where cs.amdm_era_ownr_party_id=c.amdm_era_ownr_party_id and cs.amdm_era_ownr_party_id is not null and cs.amdm_era_ownr_name is not null and deleted_date is null and c.cust_acct_id =?1", nativeQuery = true)
    List<Customer> getCustomerByAccounts(String accountNumber);

    @Query(value = "select distinct cs.* from v_if_ra_dim_cust_acct_curr c, customer cs  where cs.amdm_era_ownr_party_id=c.amdm_era_ownr_party_id and cs.amdm_era_ownr_party_id is not null and cs.amdm_era_ownr_name is not null and deleted_date is null and settings='beta' and c.cust_acct_id  =?1", nativeQuery = true)
    List<Customer> getBetaCustomersByAccounts(String accountNumber);

    @Query(value = "SELECT distinct cs.* FROM Customer cs JOIN user_mapping um on cs.customer_id = um.customer_id JOIN user_profile up on um.user_id = up.user_id   JOIN v_if_ra_dim_cust_acct_curr c on cs.amdm_era_ownr_party_id=c.amdm_era_ownr_party_id " +
            " WHERE cs.amdm_era_ownr_party_id is not null and cs.amdm_era_ownr_name is not null and um.deleted_date is null and up.user_id = ?1 and c.cust_acct_id =?2", nativeQuery = true)
    List<Customer> getCustomerByIdByAccounts(String userId, String accountNumber);

    Optional<Customer> findByCustomerId(long customerId);

    @Query(value = "select distinct customer_id as CustomerId from customer where common_entity_name=?1 and deleted_date is null", nativeQuery = true)
    Long getCustomerIdForCustomerName(String commonEntityName);

    @Modifying
    @Query(value = "insert into customer_module_relation (customer_id, module_id) values  ((select customer_id from customer where amdm_era_ownr_party_id=?1) ,\n" +
            "     (select module_id from module where title=?2 and module_type=?3))", nativeQuery = true)
    void updateAccess(String commonEntityId, String module, String moduleType);

    @Query(value = "select cs.* from customer_module_relation cmr,customer cs,module s where  cs.customer_id=cmr.customer_id and cmr.module_id=s.module_id and cs.amdm_era_ownr_party_id=?1  and s.title=?2 and s.module_type=?3", nativeQuery = true)
    List<Customer> checkExistingAccess(String commonEntityId, String module, String moduleType);

    @Modifying
    @Query(value = "delete from customer_module_relation  where customer_id in (select customer_id from customer where amdm_era_ownr_party_id=?1) and module_id in (select module.module_id from module where title=?2 and module_type=?3)", nativeQuery = true)
    void removeAccess(String commonEntityId, String module, String moduleType);


    @Transactional
    @Modifying
    @Query(value = "update customer set common_grp_id=?1,common_grp_name=?2,byng_grp_id=?4,byng_grp_name=?5 where customer_id=?3", nativeQuery = true)
    void updateGroupInfo(String commonGroupId,String commonGroupName,long customerId, String buyingGrpId,String buyingGrpName);

    @Query(value = "select exists (select c.* from v_if_ra_dim_cust_acct_curr ct, customer c where trim(c.amdm_era_ownr_party_id)=trim(ct.amdm_era_ownr_party_id) and c.amdm_era_ownr_party_id = ?1 and cust_acct_id=?2)", nativeQuery = true)
    int checkAccountExists(String amdmEraOwnrPartyId, String accountId);

    @Query(value = "select cs.* from customer cs where cs.amdm_era_ownr_party_id not in (select distinct cs.amdm_era_ownr_party_id from customer cs , v_if_ra_dim_cust_acct_curr curr where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id\n" +
            "and curr.amdm_era_ownr_party_id is not null and curr.amdm_era_ownr_name is not null) and cs.amdm_era_ownr_party_id not in ('0')\n" +
            "and cs.amdm_era_ownr_name not in ('ALL MY ACCOUNTS','All ACCOUNTS','InternalUsers','BetaUsers')\n" +
            "and cs.settings is null and cs.customer_name is null and cs.created_by='SYSTEM'", nativeQuery = true)
    List<Customer> getInvalidCustomers();

    @Query(value = "select distinct cs.* from customer cs,user_mapping um where cs.customer_id=um.customer_id and amdm_era_ownr_party_id not in (select distinct amdm_era_ownr_party_id from customer_whitelist)\n" +
            " and amdm_era_ownr_party_id not in ('0') and amdm_era_ownr_name not in ('ALL MY ACCOUNTS','All ACCOUNTS','InternalUsers','BetaUsers')\n" +
            " and cs.settings is null and cs.customer_name is null and cs.created_by='SYSTEM' and cs.customer_id not in (select customer_id from user_mapping umm,user_profile upp where umm.user_id=upp.user_id\n" +
            " and upp.user_role='ISA')", nativeQuery = true)
    List<Customer> getInvalidUserMapping();

    @Query(value = "select distinct top_ownr_nm from v_amdm_ent_src_trace where top_ownr_nm is not null and top_ownr_nm like ?1%\n",nativeQuery = true)
    List<String> searchOwnerValue(String searchText);

    @Query(value = "select distinct top_ownr_party_id from v_amdm_ent_src_trace where top_ownr_party_id is not null and top_ownr_party_id like ?1%\n",nativeQuery = true)
    List<String> searchOwnerNum(String searchText);

    @Query(value = "select distinct natl_grp_cd from v_if_ra_dim_cust_acct_curr where natl_grp_cd is not null and natl_grp_cd like ?1%\n",nativeQuery = true)
    List<String> searchNationalGroupValue(String searchText);

    @Query(value = "select distinct natl_sub_grp_cd from v_if_ra_dim_cust_acct_curr where natl_sub_grp_cd is not null and natl_sub_grp_cd like ?1%\n",nativeQuery = true)
    List<String> searchNationalSubGroupValue(String searchText);

    @Query(value = "select distinct cust_rgn_num from v_if_ra_dim_cust_acct_curr where cust_rgn_num is not null and cust_rgn_num like ?1%\n",nativeQuery = true)
    List<String> searchCustomerRegionValue(String searchText);

    @Query(value = "select distinct cust_dstrct_num from v_if_ra_dim_cust_acct_curr where cust_dstrct_num is not null and cust_dstrct_num like ?1%\n",nativeQuery = true)
    List<String> searchCustomerDistrictValue(String searchText);

    @Query(value = "select distinct acct_chn_id from v_if_ra_dim_cust_acct_curr where acct_chn_id is not null and acct_chn_id like ?1%",nativeQuery = true)
    List<String> searchChainValue(String searchText);

    @Query(value = "select distinct sls_terr_id from v_if_ra_dim_cust_acct_curr where sls_terr_id is not null and sls_terr_id like ?1%",nativeQuery = true)
    List<String> searchTerritoryValue(String searchText);

    @Query(value = "select distinct natl_grp_nam from v_if_ra_dim_cust_acct_curr where natl_grp_nam is not null and natl_grp_nam like ?1%",nativeQuery = true)
    List<String> searchNationalGroupNameValue(String searchText);

    @Query(value = "select distinct natl_sub_grp_nam from v_if_ra_dim_cust_acct_curr where natl_sub_grp_nam is not null and natl_sub_grp_nam like ?1%",nativeQuery = true)
    List<String> searchNationalSubGroupNameValue(String searchText);

    @Query(value = "select distinct cust_dstrct_name from v_if_ra_dim_cust_acct_curr where cust_dstrct_name is not null and cust_dstrct_name like ?1%\n",nativeQuery = true)
    List<String> searchCustomerDistrictNameValue(String searchText);

    @Modifying
    @Query(value = "delete from customer where customer_id=?1", nativeQuery = true)
    void deleteCustomerById(long customerId);

    @Modifying
    @Query(value = "UPDATE customer up join (SELECT common_entity_id, common_grp_id,common_grp_name,byng_grp_name,byng_grp_id FROM  v_if_ra_dim_cust_acct_curr\n" +
            "            where common_entity_id is not null GROUP BY common_entity_id) spf on up.common_entity_id=spf.common_entity_id set up.common_grp_id=spf.common_grp_id,\n" +
            "            up.common_grp_name=spf.common_grp_name,up.byng_grp_id=spf.byng_grp_id, up.byng_grp_name=spf.byng_grp_name", nativeQuery = true)
    void updateGroupInfo();

    @Query(value = "select count(*) from customer where (common_entity_name=?1 or customer_name=?1)", nativeQuery = true)
    int checkDefineCustomerExistsORNot(String name);

    @Query(value = "select count(*) from v_if_ra_dim_cust_acct_curr",nativeQuery = true)
    int getTotalCountOfDimCustAcctCurr();

    @Query(value ="select * from customer where deleted_date is null and created_by='SYSTEM' and updated_date > DATE_SUB(NOW(), INTERVAL 8 HOUR) order by customer_id", nativeQuery = true)
    List<Customer> getNameChangedCustomerList();

    @Query(value = "select distinct natl_grp_cd from v_if_ra_dim_cust_acct_curr where natl_grp_nam is not null and natl_grp_nam=?1",nativeQuery = true)
    String getNationalGroupCode(String getNatlGrpName);

    @Query(value = "select distinct natl_sub_grp_cd from v_if_ra_dim_cust_acct_curr where natl_sub_grp_nam is not null and natl_sub_grp_nam=?1",nativeQuery = true)
    String getNationalSubGroupCode(String natlSubGrpNam);

    @Query(value = "select distinct cust_dstrct_num from v_if_ra_dim_cust_acct_curr where cust_dstrct_name is not null and cust_dstrct_name=?1",nativeQuery = true)
    String getCustDstrctCode(String custDstrctName);

    @Query(value = "select distinct common_entity_id from v_if_ra_dim_cust_acct_curr where common_entity_name is not null and common_entity_name=?1",nativeQuery = true)
    String getCommonEntityNameCode(String commonEntityName);

    @Query(value = "select distinct common_grp_id from v_if_ra_dim_cust_acct_curr where common_grp_name is not null and common_grp_name=?1",nativeQuery = true)
    String getCommonGroupCode(String commonGroupName);

    @Query(value = "select distinct TOP_OWNR_PARTY_ID from v_amdm_ent_src_trace where top_ownr_nm is not null and top_ownr_nm=?1",nativeQuery = true)
    String getOwnerCode(String ownerName);

    @Query(value = "select distinct common_entity_id from v_if_ra_dim_cust_acct_curr where common_entity_id is not null and common_entity_id like ?1%",nativeQuery = true)
    List<String> searchCommonEntityIdValue(String searchText);

    @Query(value = "select distinct common_entity_name from v_if_ra_dim_cust_acct_curr where common_entity_name is not null and common_entity_name like ?1%",nativeQuery = true)
    List<String> searchCommonEntityNameValue(String searchText);

    @Query(value = "select distinct common_grp_id from v_if_ra_dim_cust_acct_curr where common_grp_id is not null and common_grp_id like ?1%",nativeQuery = true)
    List<String> searchCommonGroupIdValue(String searchText);

    @Query(value = "select distinct common_grp_name from v_if_ra_dim_cust_acct_curr where common_grp_name is not null and common_grp_name like ?1%",nativeQuery = true)
    List<String> searchCommonGroupNameValue(String searchText);

    @Query(value = "select distinct byng_grp_id from v_if_ra_dim_cust_acct_curr where byng_grp_id is not null and byng_grp_id like ?1%",nativeQuery = true)
    List<String> searchBuyingGroupIdvalue(String searchText);

    @Query(value = "select distinct byng_grp_name from v_if_ra_dim_cust_acct_curr where byng_grp_name is not null and byng_grp_name like ?1%",nativeQuery = true)
    List<String> searchBuyingGroupName(String searchText);

    @Modifying
    @Query(value = "INSERT INTO user_profile (email,user_id,user_role,internal,created_by,created_date) SELECT DISTINCT EMAIL_ADDR, EMAIL_ADDR,'ISA','true','SYSTEM',?1 FROM psas_sales_team_permissions c WHERE NOT EXISTS (SELECT user_id FROM user_profile WHERE user_id = c.EMAIL_ADDR )", nativeQuery = true)
    void insertSalesUserProfiles(Date createdDate);

    @Modifying
    @Query(value = "UPDATE user_profile up join (select EMAIL_ADDR from psas_sales_team_permissions p, user_profile up where p.EMAIL_ADDR=up.user_id)\n" +
            " spf on up.user_id=spf.EMAIL_ADDR set up.user_role='ISA',updated_by='SYSTEM',updated_date=?1 , up.email=spf.EMAIL_ADDR where updated_by is null", nativeQuery = true)
    void updateUserProfilesRoleToSalesUser(Date date);

    @Query(value = "select distinct acct_clas_dscr from v_if_ra_dim_cust_acct_curr where acct_clas_dscr is not null and acct_clas_dscr like ?1%",nativeQuery = true)
    List<String> searchAccountClassification(String searchText);

    @Query(value = "select distinct CUST_FCLITY_DSCR from v_if_ra_dim_cust_acct_curr where CUST_FCLITY_DSCR is not null and CUST_FCLITY_DSCR like ?1%",nativeQuery = true)
    List<String> searchFacility(String searchText); //todo

    @Query(value = "select distinct CUST_ACCT_TYPE_DSCR from v_if_ra_dim_cust_acct_curr where CUST_ACCT_TYPE_DSCR is not null and CUST_ACCT_TYPE_DSCR like ?1%",nativeQuery = true)
    List<String> searchAccountType(String searchText);//todo

    @Query(value = "select distinct dea_num from v_if_ra_dim_cust_acct_curr where dea_num is not null and dea_num like ?1%",nativeQuery = true)
    List<String> searchDEANumber(String searchText);

    @Query(value = "select distinct common_entity_name from v_if_ra_dim_cust_acct_curr where common_entity_name=?2 and common_entity_name is not null and common_entity_name like ?1%",nativeQuery = true)
    List<String> searchCommonEntityNameValue(String accDimensionValue,String customerName);

    @Query(value = "select distinct acct_clas_dscr from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and acct_clas_dscr is not null and acct_clas_dscr like ?1%",nativeQuery = true)
    List<String> searchAccountClassification(String accDimensionValue, String customerName);

    @Query(value = "select distinct CUST_FCLITY_DSCR from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and CUST_FCLITY_DSCR is not null and CUST_FCLITY_DSCR like ?1%",nativeQuery = true)
    List<String> searchFacility(String accDimensionValue, String customerName); //todo

    @Query(value = "select distinct CUST_ACCT_TYPE_DSCR from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and CUST_ACCT_TYPE_DSCR is not null and CUST_ACCT_TYPE_DSCR like ?1%",nativeQuery = true)
    List<String> searchAccountType(String accDimensionValue, String customerName);//todo

    @Query(value = "select distinct dea_num from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and dea_num is not null and dea_num like ?1%",nativeQuery = true)
    List<String> searchDEANumber(String accDimensionValue, String customerName);

    @Query(value = "select distinct top_ownr_nm from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and top_ownr_nm is not null and top_ownr_nm like ?1%\n",nativeQuery = true)
    List<String> searchOwnerValue(String searchText, String customerName);

    @Query(value = "select distinct top_ownr_party_id from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and top_ownr_party_id is not null and top_ownr_party_id like ?1%\n",nativeQuery = true)
    List<String> searchOwnerNum(String searchText, String customerName);

    @Query(value = "select distinct natl_grp_cd from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and natl_grp_cd is not null and natl_grp_cd like ?1%\n",nativeQuery = true)
    List<String> searchNationalGroupValue(String searchText, String customerName);

    @Query(value = "select distinct natl_sub_grp_cd from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and natl_sub_grp_cd is not null and natl_sub_grp_cd like ?1%\n",nativeQuery = true)
    List<String> searchNationalSubGroupValue(String searchText, String customerName);

    @Query(value = "select distinct cust_rgn_num from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and  cust_rgn_num is not null and cust_rgn_num like ?1%\n",nativeQuery = true)
    List<String> searchCustomerRegionValue(String searchText, String customerName);

    @Query(value = "select distinct cust_dstrct_num from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and  cust_dstrct_num is not null and cust_dstrct_num like ?1%\n",nativeQuery = true)
    List<String> searchCustomerDistrictValue(String searchText, String customerName);

    @Query(value = "select distinct acct_chn_id from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and  acct_chn_id is not null and acct_chn_id like ?1%",nativeQuery = true)
    List<String> searchChainValue(String searchText, String customerName);

    @Query(value = "select distinct sls_terr_id from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and  sls_terr_id is not null and sls_terr_id like ?1%",nativeQuery = true)
    List<String> searchTerritoryValue(String searchText, String customerName);

    @Query(value = "select distinct natl_grp_nam from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and  natl_grp_nam is not null and natl_grp_nam like ?1%",nativeQuery = true)
    List<String> searchNationalGroupNameValue(String searchText, String customerName);

    @Query(value = "select distinct natl_sub_grp_nam from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and natl_sub_grp_nam is not null and natl_sub_grp_nam like ?1%",nativeQuery = true)
    List<String> searchNationalSubGroupNameValue(String searchText, String customerName);

    @Query(value = "select distinct cust_dstrct_name from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_name=?2 and cust_dstrct_name is not null and cust_dstrct_name like ?1%\n",nativeQuery = true)
    List<String> searchCustomerDistrictNameValue(String searchText, String customerName);

    // Externals and sales users

    @Query(value = "select distinct common_entity_name from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and common_entity_name is not null and common_entity_name like ?1%",nativeQuery = true)
    List<String> searchCommonEntityNameValue(String accDimensionValue, String customerName, String UserId);

    @Query(value = "select distinct acct_clas_dscr from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and acct_clas_dscr is not null and acct_clas_dscr like ?1%",nativeQuery = true)
    List<String> searchAccountClassification(String accDimensionValue, String customerName, String UserId);

    @Query(value = "select distinct CUST_FCLITY_DSCR from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and CUST_FCLITY_DSCR is not null and CUST_FCLITY_DSCR like ?1%",nativeQuery = true)
    List<String> searchFacility(String accDimensionValue, String customerName, String UserId); //todo

    @Query(value = "select distinct CUST_ACCT_TYPE_DSCR from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and CUST_ACCT_TYPE_DSCR is not null and CUST_ACCT_TYPE_DSCR like ?1%",nativeQuery = true)
    List<String> searchAccountType(String accDimensionValue, String customerName, String UserId);//todo

    @Query(value = "select distinct dea_num from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and dea_num is not null and dea_num like ?1%",nativeQuery = true)
    List<String> searchDEANumber(String accDimensionValue, String customerName, String UserId);

    @Query(value = "select distinct top_ownr_nm from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and top_ownr_nm is not null and top_ownr_nm like ?1%\n",nativeQuery = true)
    List<String> searchOwnerValue(String accDimensionValue, String customerName, String UserId);

    @Query(value = "select distinct top_ownr_party_id from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and top_ownr_party_id is not null and top_ownr_party_id like ?1%\n",nativeQuery = true)
    List<String> searchOwnerNum(String accDimensionValue, String customerName, String UserId);

    @Query(value = "select distinct natl_grp_cd from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and natl_grp_cd is not null and natl_grp_cd like ?1%\n",nativeQuery = true)
    List<String> searchNationalGroupValue(String accDimensionValue, String customerName, String UserId);

    @Query(value = "select distinct natl_sub_grp_cd from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and natl_sub_grp_cd is not null and natl_sub_grp_cd like ?1%\n",nativeQuery = true)
    List<String> searchNationalSubGroupValue(String accDimensionValue, String customerName, String UserId);

    @Query(value = "select distinct cust_rgn_num from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and  cust_rgn_num is not null and cust_rgn_num like ?1%\n",nativeQuery = true)
    List<String> searchCustomerRegionValue(String accDimensionValue, String customerName, String UserId);

    @Query(value = "select distinct cust_dstrct_num from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and  cust_dstrct_num is not null and cust_dstrct_num like ?1%\n",nativeQuery = true)
    List<String> searchCustomerDistrictValue(String accDimensionValue, String customerName, String UserId);

    @Query(value = "select distinct acct_chn_id from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and  acct_chn_id is not null and acct_chn_id like ?1%",nativeQuery = true)
    List<String> searchChainValue(String accDimensionValue, String customerName, String UserId);

    @Query(value = "select distinct sls_terr_id from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and  sls_terr_id is not null and sls_terr_id like ?1%",nativeQuery = true)
    List<String> searchTerritoryValue(String accDimensionValue, String customerName, String UserId);

    @Query(value = "select distinct natl_grp_nam from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and  natl_grp_nam is not null and natl_grp_nam like ?1%",nativeQuery = true)
    List<String> searchNationalGroupNameValue(String accDimensionValue, String customerName, String UserId);

    @Query(value = "select distinct natl_sub_grp_nam from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and natl_sub_grp_nam is not null and natl_sub_grp_nam like ?1%",nativeQuery = true)
    List<String> searchNationalSubGroupNameValue(String accDimensionValue, String customerName, String UserId);

    @Query(value = "select distinct cust_dstrct_name from v_if_ra_dim_cust_acct_curr curr, customer cs, user_mapping um where cs.amdm_era_ownr_party_id=curr.amdm_era_ownr_party_id and cs.deleted_date is null and um.deleted_date is null and um.customer_id=cs.customer_id and um.user_id=?3 and  amdm_era_ownr_name=?2 and cust_dstrct_name is not null and cust_dstrct_name like ?1%\n",nativeQuery = true)
    List<String> searchCustomerDistrictNameValue(String accDimensionValue, String customerName, String UserId);

    @Modifying
    @Query(value = "UPDATE customer up join (SELECT common_entity_id,amdm_era_ownr_party_id,amdm_era_ownr_name FROM  v_if_ra_dim_cust_acct_curr\n" +
            "where amdm_era_ownr_name!='null' and amdm_era_ownr_name is not null and amdm_era_ownr_party_id is not null GROUP BY common_entity_id)\n" +
            "    spf on trim(up.common_entity_id)=trim(spf.common_entity_id)\n" +
            "                                set up.amdm_era_ownr_party_id=trim(spf.amdm_era_ownr_party_id)\n" +
            "                                , up.amdm_era_ownr_name=trim(spf.amdm_era_ownr_name)\n" +
            "                                , up.updated_by='AMDM_SYSTEM'\n" +
            "                                , up.updated_date=current_timestamp\n" +
            "                            where created_by='SYSTEM' and deleted_date is null and up.amdm_era_ownr_party_id is null ", nativeQuery = true)
    void getUpdateCustomersToAMDMOwnerId();

    @Query(value = "select cs.* from customer cs where created_by='SYSTEM' and amdm_era_ownr_name is not null and amdm_era_ownr_party_id is not null and common_entity_id!='null' and common_entity_id is not null\n" +
            "  and amdm_era_ownr_name not in (select name from collaboration_team where updated_by='AMDM_SYSTEM')\n" +
            "union\n" +
            "select cs.* from customer cs where created_by='SYSTEM' and amdm_era_ownr_name is not null and amdm_era_ownr_party_id is not null and common_entity_id!='null' and common_entity_id is not null\n" +
            "  and amdm_era_ownr_name not in (select name from security_group where updated_by='AMDM_SYSTEM')",nativeQuery = true)
    List<Customer> getTeamsForRename();

    @Query(value = "select cs.*  from customer cs where amdm_era_ownr_name=?1",nativeQuery = true)
    List<Customer> getCommonEntityList(String amdmEraOwnrName);

    @Query(value = "select cs.* from customer cs where  amdm_era_ownr_party_id is not null and amdm_era_ownr_name is not null and updated_by='AMDM_SYSTEM' and amdm_era_ownr_name not in (select name from security_group where updated_by='AMDM_SYSTEM')",nativeQuery = true)
    List<Customer> getAMDMCustomersListForGroups();

    @Query(value = "select distinct amdm_era_ownr_party_id from v_if_ra_dim_cust_acct_curr where amdm_era_ownr_party_id is not null and amdm_era_ownr_party_id!='null' and amdm_era_ownr_party_id!=0\n" +
            "             and amdm_era_ownr_party_id not in (select distinct amdm_era_ownr_party_id from customer cr where amdm_era_ownr_party_id is not null and amdm_era_ownr_party_id!=0)",nativeQuery = true)
    List<String> getAMDMCustomersList();

    @Modifying
    @Query(value = "INSERT INTO customer (amdm_era_ownr_party_id, amdm_era_ownr_name, platform,created_by,created_date,total_accounts)\n" +
            "SELECT DISTINCT(c.amdm_era_ownr_party_id), c.amdm_era_ownr_name, 'P','SYSTEM',?1, count(distinct c.cust_acct_id) FROM v_if_ra_dim_cust_acct_curr c where c.amdm_era_ownr_party_id is not null\n" +
            "and amdm_era_ownr_party_id=?2 and c.amdm_era_ownr_party_id not in (SELECT cs.amdm_era_ownr_party_id FROM customer cs where cs.amdm_era_ownr_party_id is not null) group by c.amdm_era_ownr_party_id", nativeQuery = true)
    void insertAMDMCustomers(Date createdDate, String amdmEraOwnrId);

    @Modifying
    @Query(value = "UPDATE customer up join (SELECT distinct amdm_era_ownr_party_id,common_entity_id,amdm_era_ownr_name FROM  v_if_ra_dim_cust_acct_curr\n" +
            "where amdm_era_ownr_party_id=?1)\n" +
            "    spf on trim(up.common_entity_id)=trim(spf.common_entity_id)\n" +
            "                                set up.amdm_era_ownr_party_id=trim(spf.amdm_era_ownr_party_id)\n" +
            "                                , up.amdm_era_ownr_name=trim(spf.amdm_era_ownr_name)\n" +
            "                                , up.updated_by='AMDM_SYSTEM'\n" +
            "                                , up.updated_date=current_timestamp\n" +
            "                            where spf.amdm_era_ownr_party_id=?1 ", nativeQuery = true)
    void updateAMDMCustomer(String amdmEraOwnrId);

    @Query(value = "select distinct common_entity_id from v_if_ra_dim_cust_acct_curr cr where amdm_era_ownr_party_id=?1",nativeQuery = true)
    List<String> getCommonEntityCount(String amdmEraOwnrPartyId);

    @Query(value = "select * from customer where common_entity_name is null and created_by='SYSTEM' and deleted_date is null",nativeQuery = true)
    List<Customer> getMultipleList();

    @Query(value = "select distinct trim(common_entity_name) common_entity_name from v_if_ra_dim_cust_acct_curr cs where amdm_era_ownr_party_id=?1",nativeQuery = true)
    List<String> getMultipleCommonEntityList(String amdmEraOwnrPartyId);

    @Modifying
    @Query(value = " update customer set deleted_date=current_timestamp where customer_id in (select customer_id from collaboration_team where external_id=?1)", nativeQuery = true)
    void updateMovedCustomer(String id);

    @Query(value = "select distinct customer_id from customer_module_relation where customer_id in (select customer_id from customer where created_by='SYSTEM'  and amdm_era_ownr_name is null)",nativeQuery = true)
    List<String> getModuleRelationCustomerIds();

    @Query(value = "select * from customer where amdm_era_ownr_party_id in (select cr.amdm_era_ownr_party_id from customer cs, v_if_ra_dim_cust_acct_curr cr\n" +
            "where cs.common_entity_id=cr.common_entity_id and cs.customer_id=?1)",nativeQuery = true)
    Customer getAMDMCustomersForModuleRelation(String customerId);

    @Modifying
    @Query(value = "update customer_module_relation set customer_id=?2 where customer_id=?1", nativeQuery = true)
    void updateModuleRelationCustomerId(String customerId, long customerId1);

    @Query(value = "select distinct customer_id from file_upload where customer_id in\n" +
            "(select customer_id from customer where created_by='SYSTEM'  and amdm_era_ownr_name is null)",nativeQuery = true)
    List<String> getfileUploadCustomerIds();

    @Modifying
    @Query(value = "update file_upload set customer_id=?2 where customer_id=?1", nativeQuery = true)
    void updatefileUploadCustomerId(String customerId, long customerId1);
}
