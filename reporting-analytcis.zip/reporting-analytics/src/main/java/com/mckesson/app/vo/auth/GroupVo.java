package com.mckesson.app.vo.auth;

import com.fasterxml.jackson.annotation.JsonProperty;

import main.java.com.mckesson.app.domain.customer.AccountGroup;

public class GroupVo {

    @JsonProperty("platformId")
    private String platformId;
    @JsonProperty("type")
    private String type;
    @JsonProperty("id")
    private String id;
    @JsonProperty("description")
    private String description;

    public String getPlatformId() {
        return platformId;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public AccountGroup toAccountGroup() {
        AccountGroup group = new AccountGroup();

        // TODO translate

        return group;
    }
}
