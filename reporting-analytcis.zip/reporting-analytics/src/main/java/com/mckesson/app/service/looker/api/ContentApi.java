package com.mckesson.app.service.looker.api;

import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.util.MappingUtils;
import main.java.com.mckesson.app.util.RestClient;
import main.java.com.mckesson.app.vo.looker.ContentVo;

@Component
public class ContentApi extends ApiBase {

    private static final Logger LOG = LoggerFactory.getLogger(ContentApi.class);

    @Autowired
    public ContentApi() {
    }

    /**
     * Update content access
     * @param contentVo
     * @param authToken
     * @return
     */
    public ContentVo updateContentAccess(ContentVo contentVo, String authToken) throws Exception {
        try {
            String jsonBody = MappingUtils.serializeToJson(contentVo);
            String requestUrl = this.lookerApiHost + "/content_metadata/" + contentVo.getContentMetadataId();
            String jsonResponse = RestClient.performPATCHOperation(authToken, requestUrl, jsonBody, null);
            MappingUtils.populateFromJson(jsonResponse, contentVo);
            return contentVo;
        } catch (Exception e) {
            LOG.error("Error occurred while updateContentAccess for content_metadata_access_id:" + contentVo.getId() + "getMessage--> " + e.getMessage());
            return null;
        }
    }

    /**
     * Remove  access to folders for all Groups.because newly created folders
     * got parent groups so we need to remove access explicitly
     *
     * @param contentVo
     * @param authToken
     */
    public void deleteContentAccess(ContentVo contentVo, String authToken) throws Exception {
        List<ContentVo> contents = allContentAccess(contentVo, authToken);
        for (ContentVo content : contents) {
            try {
                String requestUrl = this.lookerApiHost + "/content_metadata_access/" + content.getId();
                RestClient.performDELETEOperation(authToken, requestUrl);
            } catch (ApiException e) {
                if (e.getMessage().equals("401 Unauthorized")) {
                    LOG.info("Received 401 error, refreshing auth token and retrying...");
                    authToken = getAuthToken();
                    RestClient.performDELETEOperation(authToken, this.lookerApiHost + "/content_metadata_access/" + content.getId());
                } else {
                    e.printStackTrace();
                    LOG.error("Error occurred while deleting content_metadata_access for content_metadata_access_id:" + content.getId() + "getMessage--> " + e.getMessage());
                }
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error("Error occurred while deleting content_metadata_access for content_metadata_access_id:" + content.getId() + "getMessage--> " + e.getMessage());
            }
        }
    }

    public void giveGroupAccess(String authToken, ContentVo contentVo) {
        try {
            String jsonBody = MappingUtils.serializeToJson(contentVo);
            String requestUrl = this.lookerApiHost + "/content_metadata_access";
            RestClient.performPOSTOperation(authToken, requestUrl, jsonBody, null);
        } catch (Exception e) {
            LOG.error("Failed to give group " + contentVo.getGroupId() + " access to content_metadata_id " + contentVo.getContentMetadataId());
        }
    }

    /**
     * before we assign a group to newly created folder first we need to assigned to parent folder (shared)
     * other we get access denied error
     *
     * @param authToken
     * @param groupId
     */
    public void giveGroupAccessParent(String authToken, String groupId, String permissionType) {
        try {
            ContentVo contentVo = new ContentVo();
            contentVo.setContentMetadataId("1");
            contentVo.setGroupId(groupId);
            contentVo.setPermissionType(permissionType);

            String jsonBody = MappingUtils.serializeToJson(contentVo);
            String requestUrl = this.lookerApiHost + "/content_metadata_access";
            RestClient.performPOSTOperation(authToken, requestUrl, jsonBody, null);
        } catch (Exception e) {
            LOG.error("Error occurred while giveGroupAccessParent" + groupId+ " getMessage--> "+e.getMessage());
        }
    }

    /**
     * get all content_metadata_access_id based on content_metadata_id to folder.
     *
     * @param contentVo
     * @param authToken
     * @return
     */
    public List<ContentVo> allContentAccess(ContentVo contentVo, String authToken) throws Exception {
        try {
            LOG.info("allContentAccess$$$$$$$$$$$$$$..."+contentVo.getContentMetadataId());
            String requestUrl = this.lookerApiHost + "/content_metadata_access?content_metadata_id=" + contentVo.getContentMetadataId();
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl,null);
            return MappingUtils.getCollectionFromJson(jsonResponse,ContentVo.class);
        } catch (Exception e) {
            LOG.error("e.getMessage() ========="+e.getMessage());
            return MappingUtils.getCollectionFromJson(null,ContentVo.class);
        }
    }

    /**
     * get content_metadata_id based on id
     *
     * @param contentVo
     * @param authToken
     * @return
     */
    public ContentVo getContentAccess(ContentVo contentVo, String authToken) {
        try {
            String[] fields = {"id", "inherits"};

            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/content_metadata/" + contentVo.getContentMetadataId();
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, params);
            MappingUtils.populateFromJson(jsonResponse, contentVo);
            return contentVo;
        } catch (Exception e) {
            LOG.error("Error occurred while getContentAccess for content_metadata_access_id:" + contentVo.getId() + "getMessage--> " + e.getMessage());
            return null;
        }
    }

    public void removeContentAccess(ContentVo contentVo, String authToken) {
            try {
                String requestUrl = this.lookerApiHost + "/content_metadata_access/" + contentVo.getId();
                RestClient.performDELETEOperation(authToken, requestUrl);
            } catch (ApiException e) {
                if (e.getMessage().equals("401 Unauthorized")) {
                    LOG.info("Received 401 error, refreshing auth token and retrying...");
                    authToken = getAuthToken();
                    RestClient.performDELETEOperation(authToken, this.lookerApiHost + "/content_metadata_access/" + contentVo.getId());
                } else {
                    e.printStackTrace();
                    LOG.error("Error occurred while deleting content_metadata_access for content_metadata_access_id:" + contentVo.getId() + "getMessage--> " + e.getMessage());
                }
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error("Error occurred while deleting content_metadata_access for content_metadata_access_id:" + contentVo.getId() + "getMessage--> " + e.getMessage());
        }
    }
}
