package com.mckesson.app.service.looker;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringEscapeUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.cache.EnvironmentSpecificKeyGenerator;
import main.java.com.mckesson.app.domain.looker.CustomFilter;
import main.java.com.mckesson.app.domain.looker.FilterCriteria;
import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.service.looker.api.ModelApi;
import main.java.com.mckesson.app.service.looker.api.QueryApi;
import main.java.com.mckesson.app.service.looker.api.UserApi;
import main.java.com.mckesson.app.util.StringUtils;
import main.java.com.mckesson.app.util.UserAuthentication;
import main.java.com.mckesson.app.vo.looker.DimensionVo;
import main.java.com.mckesson.app.vo.looker.ExploreDetailVo;
import main.java.com.mckesson.app.vo.looker.ExploresVo;
import main.java.com.mckesson.app.vo.looker.FieldVo;
import main.java.com.mckesson.app.vo.looker.UserVo;

@Service("LookerExploreService")
public class LookerExploreServiceImpl implements LookerExploreService {

    private static final Logger log = LoggerFactory.getLogger(LookerExploreServiceImpl.class);

    private final QueryApi queryApi;
    private final ModelApi modelApi;
    private final UserApi userApi;
    private final CustomFilterService customFilterService;
    private final UserAuthentication userAuthentication;

    @Autowired
    public LookerExploreServiceImpl(QueryApi queryApi, ModelApi modelApi, UserApi userApi, CustomFilterService customFilterService, UserAuthentication userAuthentication) {
        this.queryApi = queryApi;
        this.modelApi = modelApi;
        this.userApi = userApi;
        this.customFilterService = customFilterService;
        this.userAuthentication = userAuthentication;
    }

    @Value("${looker.host}")
    private String lookerHost;

    /**
     * Create JSON payload for query creation request.
     * Note: 'tabs' and 'line brakes' must be removed, or JSON validation will fail.
     *
     * @param modelRef      the name of the model to pass into the query
     * @param viewRef       the name of the view (the explore that is being embedded) to pass into the query
     * @param dynamicFields the formatted Custom Groups in the Looker "Dynamic Fields" format
     * @return
     */
    private String createQueryJson(String modelRef, String viewRef, String dynamicFields) {

        String result = "{" +
                "\"model\":\"" + modelRef + "\"," +
                "\"view\":\"" + viewRef + "\"," + // Needs to be set to explore name
                "\"dynamic_fields\":\"" + dynamicFields + "\"" +
                "}";

        return result.replace("\t", "");
    }

    /**
     * Create a query entity within Looker for a given 'dynamic field' attribute.
     * Returns 'slug' for new query.
     */
    private String getQueryShareUrlForDynamicFields(String modelRef, String explore, String dynamicFields, Boolean isDashBoardExplore, String qid, String result) throws ApiException {

        String queryJson = null;
        //Get JSON payload to submit to API
        if (isDashBoardExplore)
            queryJson = createQueryJsonDrillDown(dynamicFields, qid, result);
        else
            queryJson = createQueryJson(modelRef, explore, dynamicFields);

        //Create new query entity
        String[] fields = {"id", "title", "slug", "share_url"};
        Query query = queryApi.createQuery(queryJson, fields);

        log.debug("Created query for explore embed operation: id=>" + query.getId() + ", slug=>" + query.getSlug() + ", share url: " + query.getShareUrl());

        return query.getShareUrl();
    }

    /**
     * For a collection of Custom Groups, get all dynamic fields to pass into the Looker Query to be generated.
     */
    private String getDynamicFieldsFromSource(Collection<CustomFilter> customGroups, StringBuilder dynamicFieldsFromAPI) {

        final StringBuilder sb = new StringBuilder();

        customGroups.forEach(customGroup -> {
            if (customGroup != null) {
                if(customGroup.getCriteriaGroup().getFilterCriteria().size()>0)
                sb.append(customFilterService.formatCustomGroupToDynamicFilterSyntax(customGroup)).append(",");
            }
        });

        String criteria = sb.toString();
        if (criteria.endsWith(",")) {
            criteria = criteria.substring(0, criteria.length() - 1);
        }
        if (dynamicFieldsFromAPI == null)
            return "[" + criteria + "]";
        else
            return "[" + criteria + "," + dynamicFieldsFromAPI.toString() + "]";
    }

    private String getEmbedUrlWithCustomFilters(String model, String exploreName, String userId) throws ApiException {

        Collection<CustomFilter> groups = customFilterService.getByExploreType(exploreName, userId);
        if (groups.isEmpty())
            return null;
        else {
            String dynamicFields = getDynamicFieldsFromSource(groups, null);
            return getQueryShareUrlForDynamicFields(model, exploreName, dynamicFields, false, null, null);
        }
    }

    /**
     * {@inheritDoc}
     */
    public String getEmbedUrlWithCustomGroupsShortTerm(String model, String exploreRef) throws ApiException {
        String userID = userAuthentication.getLoggedInUser().getUsername();


        // Qid is derived from previously saved custom groupings. Delegate process of identifying applicable filters
        // and generating the correct qid to what will be the long term production method.
        return getEmbedUrlWithCustomFilters(model, exploreRef, userID);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Boolean showCustomGroupOnExplore(String model, String exploreName, Collection<FilterCriteria> criteria) {
        List<String> dimensionsInFilter = criteria.stream()
                .filter(filterCriteria -> filterCriteria.getDefaultGrouping() == null || !filterCriteria.getDefaultGrouping())
                .map(FilterCriteria::getDimension)
                .collect(Collectors.toList());

        String authToken = modelApi.getAuthToken();
        String userID = userAuthentication.getLoggedInUser().getUsername();
        UserVo user = userApi.getUserByEmbed(userID, authToken);
        String userAuthToken = queryApi.getAuthTokenForUserId(authToken, user.getId());

        ExploreDetailVo exploreDetail = modelApi.getDimensionsInExplore(model, exploreName, userAuthToken);
        FieldVo fields = exploreDetail.getFields();
        return fields.getDimensions()
                .stream()
                .filter(dimension -> !dimension.hidden)
                .map(DimensionVo::getName)
                .collect(Collectors.toList())
                .containsAll(dimensionsInFilter);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @Cacheable(value = "visibleDimensions", keyGenerator = EnvironmentSpecificKeyGenerator.NAME)
    public Collection<DimensionVo> getAllVisibleDimensions(String userId) {
        // Get the user-specific auth token
//		String authToken = modelApi.getAuthTokenForUserId(modelApi.getAuthToken(), userId); //??

        String authToken = modelApi.getAuthToken();

        UserVo user = userApi.getUserByEmbed(userId, authToken);
        String userAuthToken = queryApi.getAuthTokenForUserId(authToken, user.getId());

        final ExploresVo models = modelApi.getExploresInModel("r_a_connect", userAuthToken);
        final Set<DimensionVo> dimensions = new HashSet<>();
        if (models.getExplores() != null) {
            models.getExplores().forEach(explore -> {
                ExploreDetailVo dimensionsInExplore = modelApi.getDimensionsInExplore("r_a_connect", explore.getName(), userAuthToken);
                if (dimensionsInExplore != null && !dimensionsInExplore.getFields().getDimensions().isEmpty()) {
                    dimensions.addAll(
                            dimensionsInExplore.getFields()
                                    .getDimensions()
                                    .stream()
                                    .filter(dimension -> !dimension.getHidden())
                                    .collect(Collectors.toSet())
                    );
                } else {
                    log.error("No dimensions returned for explore [r_a_connect]");
                }
            });
        }

        return dimensions;
    }

    @Override
    public Collection<DimensionVo> getVisibleDimensionsByExplore(String userId, String explore) {
        String authToken = modelApi.getAuthToken();

        UserVo user = userApi.getUserByEmbed(userId, authToken);
        String userAuthToken = queryApi.getAuthTokenForUserId(authToken, user.getId());

        final ExploresVo models = modelApi.getExploresInModel("r_a_connect", userAuthToken);
        final Set<DimensionVo> dimensions = new HashSet<>();
        if (models.getExplores() != null) {
            models.getExplores().forEach(exp -> {
                if (StringUtils.equals(exp.getName(), explore)) {
                    ExploreDetailVo dimensionsInExplore = modelApi.getDimensionsInExplore("r_a_connect", exp.getName(), userAuthToken);
                    if (dimensionsInExplore != null && !dimensionsInExplore.getFields().getDimensions().isEmpty()) {
                        dimensions.addAll(
                                dimensionsInExplore.getFields()
                                        .getDimensions()
                                        .stream()
                                        .filter(dimension -> !dimension.getHidden())
                                        .collect(Collectors.toSet())
                        );
                    } else {
                        log.error("No dimensions returned for explore [r_a_connect]");
                    }
                }
            });
        }

        return dimensions;
    }

    @Override
    public String getUpdatedQidForDashboardExplore(String userId, String model, String exploreName, String qid) throws Exception {

        Collection<CustomFilter> groups = customFilterService.getByExploreType(exploreName, userId);
        if (groups.isEmpty())
            return null;
        else {
            String result = queryApi.getQuery(qid);

            JSONObject jsonObj = new JSONObject(result);
            StringBuilder dynamicFieldsFromAPI;
            String temp=jsonObj.get("dynamic_fields").toString();
            if (temp.equals("[]") || temp=="null") {
                dynamicFieldsFromAPI = null;
            } else {
                dynamicFieldsFromAPI = new StringBuilder(jsonObj.get("dynamic_fields").toString());
                char[] c = jsonObj.get("dynamic_fields").toString().toCharArray();
                dynamicFieldsFromAPI.deleteCharAt(c.length - 1);
                dynamicFieldsFromAPI.deleteCharAt(0);
            }
            String dynamicFields = getDynamicFieldsFromSource(groups, dynamicFieldsFromAPI);
            System.out.println("dynamicFields"+dynamicFields);
            return getQueryShareUrlForDynamicFields(model, exploreName, dynamicFields, true, qid, result);
        }
    }

    private String createQueryJsonDrillDown(String dynamicFields, String qid, String result) throws JSONException {

        JSONObject jsonObj = new JSONObject(result);
        jsonObj.put("dynamic_fields", StringEscapeUtils.unescapeJava(dynamicFields));
        jsonObj.put("slug", "");
        jsonObj.put("client_id", "");
        jsonObj.put("share_url", "");
        jsonObj.put("url", "");
        jsonObj.put("expanded_share_url", "");
        jsonObj.put("id", "");

        return jsonObj.toString();

    }
}
