package com.mckesson.app.auth.user;

import java.util.Collection;
import java.util.Map;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.user.OAuth2User;

import com.google.common.collect.Lists;

import main.java.com.mckesson.app.auth.permission.UserRole;
import main.java.com.mckesson.app.auth.permission.UserType;
import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.domain.customer.UserMapping;
import main.java.com.mckesson.app.util.StringUtils;

public class ConnectUser implements ReportUser {

    // OidcUser fields
//   private Map<String, Object> claims;
    private Map<String, Object> attributes;
//    private OidcUserInfo oidcUserInfo;
//    private OidcIdToken oidcIdToken;

    private final String firstName;
    private final String lastName;
    private final String username;
    private final String emailAddress;
    private final String originalUserSudoFlag;
    private final String marketPartition;
    private final String blaEligible;

    private UserRole role;
    private final UserAccessModel uam;

    private  String sudoFirstName;
    private  String sudoLastName;
    private  String sudoUsername;
    private  String sudoEmailAddress;
    private  boolean isSudoUser;
    private UserRole sudoRole;

    public ConnectUser(String username, String firstName, String lastName, String emailAddress, UserRole role, String originalUserSudoFlag, String marketPartition, String blaEligible)  {
        this.username = username;
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailAddress = emailAddress;
        this.originalUserSudoFlag = originalUserSudoFlag;
        this.marketPartition = marketPartition;
        this.blaEligible = blaEligible;

        if (this.role != null) {
            this.role = role;
        } else {
            this.role = new UserRole(UserType.CustomerUser);
        }

        this.uam = new UserAccessModel();
    }
/*
    public ConnectUser(OidcUser oidcUser, UserRole role, UserAccessModel uam, String originalUserSudoFlag, String marketPartition) {
        this.oidcUserInfo = oidcUser.getUserInfo();
        this.oidcIdToken = oidcUser.getIdToken();
        this.attributes = oidcUser.getAttributes();
        this.claims = oidcUser.getClaims();

        this.username = StringUtils.stringOrBlank(this.claims.get("preferred_username"));
        this.firstName = StringUtils.stringOrBlank(this.claims.get("given_name"));
        this.lastName = StringUtils.stringOrBlank(this.claims.get("family_name"));
        this.emailAddress = StringUtils.stringOrBlank(this.claims.get("email"));
        this.role = role;
        this.originalUserSudoFlag = originalUserSudoFlag;
        this.marketPartition = marketPartition;

        if (this.role != null) {
            this.role = role;
        } else {
            this.role = new UserRole(UserType.CustomerUser);
        }

        this.uam = uam;
    }
*/
    public ConnectUser(OAuth2User oAuth2User, UserRole role, UserAccessModel uam, String originalUserSudoFlag, String marketPartition, String blaEligible) {
        this.attributes = oAuth2User.getAttributes();

        this.username = StringUtils.stringOrBlank(oAuth2User.getAttribute("preferred_username"));
        this.firstName = StringUtils.stringOrBlank(oAuth2User.getAttribute("given_name"));
        this.lastName = StringUtils.stringOrBlank(oAuth2User.getAttribute("family_name"));
        this.emailAddress = StringUtils.stringOrBlank(oAuth2User.getAttribute("email"));
        this.role = role;
        this.originalUserSudoFlag = originalUserSudoFlag;
        this.marketPartition = marketPartition;
        this.blaEligible = blaEligible;

        if (this.role != null) {
            this.role = role;
        } else {
            this.role = new UserRole(UserType.CustomerUser);
        }

        this.uam = uam;
    }


    // Users can have access to multiple Customers, this grabs the active CustomerMapping
    public UserMapping getActiveCustomer() {
        if (this.uam != null)
            return this.uam.getActiveUserMapping();

        return null;
    }

    // Gets Teams the User has access to in the active CustomerMapping
    public Collection<CollaborationTeam> getActiveTeams() {
        if (this.uam != null)
            return this.uam.getActiveTeams();

        return Lists.newArrayList();
    }

    public boolean setActiveUser(String userId) {
        if (this.uam != null)
            return this.uam.setActiveUserMapping(userId);

        return false;
    }

    @Override
    public String getFirstName() {
        if(this.isSudoUser)
            return this.sudoFirstName;
        else
        return this.firstName;
    }

    @Override
    public String getLastName() {
        if(this.isSudoUser)
            return this.sudoLastName;
        else
        return this.lastName;
    }

    @Override
    public String getUserDisplayName() {
        return this.firstName + " " + this.lastName;
    }

    @Override
    public String getUserEmail() {
        if(this.isSudoUser)
            return this.sudoEmailAddress;
        else
        return this.emailAddress;
    }

    @Override
    public boolean isSuperAdmin() {
        if (this.isSudoUser)
           return UserType.SuperAdmin.equals(sudoRole.getType());
        else
            return UserType.SuperAdmin.equals(role.getType());
    }

    @Override
    public boolean isInternal() {
        if (this.isSudoUser)
            return sudoRole.isInternal();
        else
           return role.isInternal();
    }

    @Override
    public boolean isCustomer() {
        if (this.isSudoUser)
            return sudoRole.isCustomer();
        else
            return role.isCustomer();
    }

    @Override
    public boolean isCustomerUser() {
        if (this.isSudoUser)
            return sudoRole.isCustomerUser();
        else
            return role.isCustomerUser();
    }

    @Override
    public boolean canSudo() {
        if (this.isSudoUser)
            return sudoRole.canSudo();
        else
            return role.canSudo();
    }

    @Override
    public boolean canAccessAllAccounts() {
        if (this.isSudoUser)
            return sudoRole.canAccessAllAccounts();
        else
            return role.canAccessAllAccounts();
    }

    @Override
    public boolean hasHealthSystem123Access() {
        if (this.isSudoUser)
            return sudoRole.hasHealthSystem123Access();
        else
            return role.hasHealthSystem123Access();
    }

    @Override
    public boolean canCreateCustomGroups() {
        if (this.isSudoUser)
            return sudoRole.canCreateCustomGroups();
        else
            return role.canCreateCustomGroups();
    }

    @Override
    public boolean canShareToTeams() {
        if (this.isSudoUser)
            return sudoRole.canShareToTeams();
        else
            return role.canShareToTeams();
    }

    @Override
    public boolean canManageRoles() {
        if (this.isSudoUser)
            return sudoRole.canManageRoles();
        else
            return role.canManageRoles();
    }

    @Override
    public UserRole getRole() {
         if (this.isSudoUser)
            return this.sudoRole;
        else
            return this.role;
    }

    // Returns sudoUsername if sudo user isn't a Customer Admin, else returns original username
    @Override
    public String getOriginalUsername() {
        if (this.isSudoUser && !this.role.getType().getCode().equals("CA"))
            return this.sudoUsername;
        else
            return this.username;
    }

    @Override
    public String getOriginalUserSudoFlag() {
        return this.originalUserSudoFlag;
    }

    @Override
    public UserAccessModel getUserAccessModel() {
        return this.uam;
    }

    @Override
    public String getSudoFirstName() {
        return this.sudoFirstName;
    }

    @Override
    public String getSudoLastName() {
        return this.sudoLastName;
    }

    @Override
    public String getSudoUsername() {
        return this.sudoUsername;
    }

    @Override
    public String getSudoEmailAddress() {
        return this.sudoEmailAddress;
    }

    @Override
    public boolean isSudoUser() {
        return this.isSudoUser;
    }

    @Override
    public UserRole getSudoRole() {
        return this.sudoRole;
    }

    @Override
    public void setSudoRole(UserRole sudoRole) {
        this.sudoRole=sudoRole;
    }

    @Override
    public void setSudoFirstName(String sudoFirstName) {
        this.sudoFirstName=sudoFirstName;
    }

    @Override
    public void setSudoLastName(String sudoLastName) {
        this.sudoLastName=sudoLastName;
    }

    @Override
    public void setSudoUsername(String sudoUsername) {
        this.sudoUsername=sudoUsername;
    }

    @Override
    public void setSudoEmailAddress(String sudoEmailAddress) {
        this.sudoEmailAddress=sudoEmailAddress;
    }

    @Override
    public void setSudoUser(boolean sudoUser) {
        this.isSudoUser=sudoUser;
    }

    @Override
    public void setUsername(String username) {  }

    @Override
    public void setRole(UserRole role) {    }

    @Override
    public void setOriginalUserSudoFlag(String getOriginalUserSudoFlag) {    }

    @Override
    public void setFirstName(String firstName) {    }

    @Override
    public void setLastName(String lastName) {    }

    @Override
    public void setEmailAddress(String emailAddress) {    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return Lists.newArrayList(new SimpleGrantedAuthority(this.USER));   // TODO
    }
/*
    @Override
    public Map<String, Object> getClaims() {
        return this.claims;
    }

    @Override
    public OidcUserInfo getUserInfo() {
        return this.oidcUserInfo;
    }

    @Override
    public OidcIdToken getIdToken() {
        return this.oidcIdToken;
    }
*/
    @Override
    public String getName() {
        return this.username;
    }

    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public Map<String, Object> getAttributes() {
        return this.attributes;
    }

    public String getUsername() {
        if(this.isSudoUser)
            return this.sudoUsername;
            else
        return this.username;
    }   //TODO

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Override
    public String getMarketPartition() {
        return marketPartition;
    }

    @Override
    public String getBlaEligible() { return blaEligible; }
}
