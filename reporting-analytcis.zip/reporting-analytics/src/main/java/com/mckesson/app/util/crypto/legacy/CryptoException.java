/*
 * Created on Dec 16, 2003
 */
package com.mckesson.app.util.crypto.legacy;

/**
 * Description
 * <p>
 * <p/>
 * (c) 2003 Copyright - McKesson Medical-Surgical Minnesota Supply Inc. All
 * Rights Reserved
 *
 * @author <a href="mailto:jacob.hookom@redline.mckhboc.com">Jacob Hookom</a>
 * @version $Id: CryptoException.java,v 1.1 2009/06/18 19:09:05 dbod Exp $
 */
public class CryptoException extends RuntimeException {

    /**
     *
     */
    public CryptoException() {
        super();
    }

    /**
     * @param arg0
     */
    public CryptoException(String arg0) {
        super(arg0);
    }

    /**
     * @param arg0
     * @param arg1
     */
    public CryptoException(String arg0, Throwable arg1) {
        super(arg0, arg1);
    }

    /**
     * @param arg0
     */
    public CryptoException(Throwable arg0) {
        super(arg0);
    }

}