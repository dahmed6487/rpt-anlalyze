package com.mckesson.app.service.customer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.auth.permission.UserType;
import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.domain.customer.SecurityGroup;
import main.java.com.mckesson.app.misc.EntityNotFoundException;
import main.java.com.mckesson.app.misc.ErrorMessagesEnum;
import main.java.com.mckesson.app.repository.customer.SecurityGroupAccountsRepository;
import main.java.com.mckesson.app.repository.customer.SecurityGroupRepository;
import main.java.com.mckesson.app.service.user.UserProfileService;

@Service
public class SecurityGroupService {

    private final SecurityGroupRepository securityGroupRepository;
    private final SecurityGroupAccountsRepository securityGroupAccountsRepository;
    private final UserProfileService userProfileService;

    @Autowired
    public SecurityGroupService(SecurityGroupRepository securityGroupRepository, SecurityGroupAccountsRepository securityGroupAccountsRepository, UserProfileService userProfileService) {
        this.securityGroupRepository = securityGroupRepository;
        this.securityGroupAccountsRepository = securityGroupAccountsRepository;
        this.userProfileService = userProfileService;
    }

    private static final String SEPARATOR = ",";


    public List<SecurityGroup> getAll() {
        return securityGroupRepository.findAll();
    }

    public List<SecurityGroup> updateAll(List<SecurityGroup> securityGroup) {
        List<Long> list = new ArrayList();
        securityGroup.stream().forEach(c -> list.add(c.getSecurityGroupId()));
        securityGroupRepository.active(list);
        return securityGroup;
    }

    public ResponseEntity<String> deleteAll(List<SecurityGroup> securityGroup) {
        List<Long> list = new ArrayList();
        Date deletedDate = new Date();
        securityGroup.stream().forEach(c -> list.add(c.getSecurityGroupId()));
        securityGroupAccountsRepository.inActive(deletedDate, list);
        securityGroupRepository.inActive(deletedDate, list);
        return new ResponseEntity<String>("Your request has been completed successfully", HttpStatus.ACCEPTED);
    }

    public String getUserGroupIds(ReportUser reportUser) {
        try {
            List<SecurityGroup> securityGroup;
            StringBuilder csvBuilder = new StringBuilder();
            String csv;

            if (reportUser.isInternal()) {
                securityGroup = reportUser.getRole().getType().equals(UserType.InternalUser) ?
                        securityGroupRepository.getSecurityGroup("BetaUsers") : securityGroupRepository.getSecurityGroup("InternalUsers");
            }
            else
                securityGroup = securityGroupRepository.getUserGroupIds(reportUser.getUsername());

            if (securityGroup.size() > 0) {
                for (SecurityGroup id : securityGroup) {
                    csvBuilder.append(id.getExternalId());
                    csvBuilder.append(SEPARATOR);
                }
                csv = csvBuilder.toString();
                csv = csv.substring(0, csv.length() - SEPARATOR.length());
                return csv;
            } else
                throw new EntityNotFoundException(ErrorMessagesEnum.valueOf("SECURITY_GROUP_NOT_FOUND").getErrorMsg());
        } catch (NullPointerException e) {
            throw new UsernameNotFoundException(ErrorMessagesEnum.valueOf("NOT_FOUND").getErrorMsg());
        }

    }
}
