package com.mckesson.app.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import main.java.com.mckesson.app.domain.ApplicationLog;

public interface ApplicationLogRepository extends JpaRepository<ApplicationLog, Long>, JpaSpecificationExecutor<ApplicationLog> {

    @Modifying
    @Query(value = "replace  into recent_search_log (search_criteria, search_criteria_id, created_by, created_date, updated_by, updated_date) " +
                    " values (?1, ?2, ?3, ?4, ?3, ?4)", nativeQuery = true)
    void insertOrUpdateRecentSearchLog(String searchCriteria, long criteriaId, String userId, Date date);
}
