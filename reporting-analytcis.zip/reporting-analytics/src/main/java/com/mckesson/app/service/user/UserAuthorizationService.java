package com.mckesson.app.service.user;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.mckesson.lib.model.customer.AccountId;

import main.java.com.mckesson.app.auth.user.UserAuthorizationRule;
import main.java.com.mckesson.app.domain.customer.UserMapping;
import main.java.com.mckesson.app.domain.user.UserProfile;
import main.java.com.mckesson.app.service.customer.UserMappingService;

@Service
public class UserAuthorizationService {

    private final UserMappingService userMappingService;
    private final UserProfileService userProfileService;
    private final UserAuthorizationRuleService userRuleService;

    @Autowired
    public UserAuthorizationService(UserMappingService userMappingService, UserProfileService userProfileService, UserAuthorizationRuleService userRuleService) {
        this.userMappingService = userMappingService;
        this.userProfileService = userProfileService;
        this.userRuleService = userRuleService;
    }

    public List<UserAuthorizationRule> findRules(String userId) {
        return userRuleService.findRules(userId);
    }

    public List<UserMapping> findCustomerMappings(String username) {
        return userMappingService.findCustomerMappings(username);
    }

    public Set<AccountId> getAllAccountIds(String userId) {
        Set<AccountId> accountIds = Sets.newHashSet();
        this.findRules(userId).forEach(rule -> accountIds.add(rule.toAccountId()));
        return accountIds;
    }

    public void updateRules(String userId, List<AccountId> accountIds) {
        List<UserAuthorizationRule> sourceRules = Lists.newArrayList();

        for (AccountId aid : accountIds) {
            sourceRules.add(new UserAuthorizationRule(userId, aid));
        }

        List<UserAuthorizationRule> storedRules = this.findRules(userId);
        if (storedRules != null && storedRules.isEmpty()) {
            userRuleService.saveRules(sourceRules);
            return;
        } else {
            // First, save only the accounts that do not already exist in DB
            List<UserAuthorizationRule> txSet = Lists.newArrayList(sourceRules);
            txSet.removeAll(storedRules);
            if (txSet.size() > 0)
                userRuleService.saveRules(txSet);

            // Next, remove any stored accounts that no longer exist in source
            storedRules.removeAll(sourceRules);
            if (txSet.size() > 0)
                userRuleService.deleteRules(storedRules);
        }
    }

    public UserProfile getUserDetails(String username) {
        return userProfileService.getUserDetails(username);
    }

}
