package com.mckesson.app.domain.looker;

import java.util.Objects;

public class DashboardDto {
    private int id;
    private String name;
    private String module;
    private String description;
    private String color;

    public int getId() {
        return id;
    }

    public void setId(int newId) {
        id = newId;
    }

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        name = newName;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String newModule) {
        module = newModule;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String newDescription) {
        description = newDescription;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String newColor) {
        color = newColor;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DashboardDto that = (DashboardDto) o;
        return id == that.id && Objects.equals(name, that.name) && Objects.equals(module, that.module) && Objects.equals(description, that.description) && Objects.equals(color, that.color);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, module, description, color);
    }

    @Override
    public String toString() {
        return "DashboardDto{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", module='" + module + '\'' +
                ", description='" + description + '\'' +
                ", color='" + color + '\'' +
                '}';
    }
}
