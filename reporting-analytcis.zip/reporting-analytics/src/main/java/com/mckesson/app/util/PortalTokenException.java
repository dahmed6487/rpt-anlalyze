package com.mckesson.app.util;

public class PortalTokenException extends Exception {

    public PortalTokenException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public PortalTokenException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public PortalTokenException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public PortalTokenException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

}