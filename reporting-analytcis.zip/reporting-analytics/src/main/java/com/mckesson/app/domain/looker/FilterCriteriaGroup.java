package com.mckesson.app.domain.looker;

import java.util.Collection;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "looker_dyn_field_criteria_group")
public class FilterCriteriaGroup {

    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY,
            generator = "native"
    )
    @Column(name = "id")
    private Long id;

    /**
     * Name of group, which also serves the value that will be displayed when a match is present for a particular record.
     */
    @Column(name = "name")
    private String name;

    /**
     * As an alternative to defining values which constitute a match, the user may simply define a custom formula,
     * which will be applied in place of the criteria.
     */
    @Column(name = "LDF_CUSTOM_FORMULA")
    private String customFormula;

    @ManyToOne
    @JsonBackReference
    @JoinColumn(name = "looker_dyn_field_id")
    private CustomFilter filter;

    @JsonManagedReference
    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "group")
    private Collection<FilterCriteria> filterCriteria;

    public FilterCriteriaGroup() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCustomFormula() {
        return customFormula;
    }

    public void setCustomFormula(String customFormula) {
        this.customFormula = customFormula;
    }

    public CustomFilter getFilter() {
        return filter;
    }

    public void setFilter(CustomFilter filter) {
        this.filter = filter;
    }

    public Collection<FilterCriteria> getFilterCriteria() {
        return filterCriteria;
    }

    public void setFilterCriteria(Collection<FilterCriteria> filterCriteria) {
        this.filterCriteria = filterCriteria;
    }
}
