package com.mckesson.app.web.rest.domain;

import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import main.java.com.mckesson.app.service.UserPermissionJobService;

@Component
public class UserPermissionJobController {

    private static final Logger LOG = LoggerFactory.getLogger(UserPermissionJobController.class);

    private final UserPermissionJobService userPermissionJobService;
    @Value("${appconfig.teamsCleanMode}")
    boolean teamsCleanMode;

    @Autowired
    public UserPermissionJobController(UserPermissionJobService userPermissionJobService) {
        this.userPermissionJobService = userPermissionJobService;
    }

    /**
     * 1. insert userprofile from s_iw_user_access based sys_id='STK2' condition
     * 2. insert customer from v_if_ra_dim_cust_acct_curr
     * 3. insert user_mapping from userprofile and customer based on era_user_permissions table on userid and customerid(common entity id)
     * 4. before running each insert there is select count if new data available or not to avoid unnecessary inserts running
     * 5. update function codes from s_prvg_func to user_profile based on conditions
     * 6. create collaboration teams in both Looker and ERA
     * 7. insert relation for collab and user to give default access to top level customer team folder
     * 8. create looker objects and update permissions
     * 0 0 11 * * ? - At 7:00:00am every day  (0 * * ? * *--every min)
     1. Create user profile with sales user role SU..?
     Insert new sale user profiles
     * Updating existing users roles to sales user.
    2. update era user permission table

     *
     */

    @Modifying
    @Scheduled(cron = "${appconfig.userPermissionJobCron}") // 11 is equal to 7 AM EST due to Azure timezone
    public void job() {

        try {
            LOG.info("AMDM migration started");
            switchToAMDMOwnerId();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while doing AMDM migration  " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while doing AMDM migration" + e.getMessage(), "insertAMDMCustomers");
        }

        LOG.info("$$$$$$$$$$$$$$$$$$$$$$ User Permission Job Started $$$$$$$$$$$$$$$$$$$$$$");
        try {
            LOG.info("Customer and user mapping clean started");
            userPermissionJobService.cleanInvalidUserMapping();
            userPermissionJobService.cleanInvalidCustomers();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while cleaning the Customer and user mapping  " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while cleaning the Customer and user mapping  " + e.getMessage(), "cleanInvalidCustomers");
        }
        try {
            LOG.info("Checking for Users to create");
            if(userPermissionJobService.usersToCreateCount() == 0)
                LOG.info("No updated user info available");
            else
                userPermissionJobService.insertUserProfiles();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while inserting user "+  e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while inserting user " + e.getMessage(), "insertUserProfiles");
        }

        try {
                userPermissionJobService.insertSalesUserProfiles();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while inserting SalesUserProfiles "+  e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while inserting user " + e.getMessage(), "insertSalesUserProfiles");
        }

       try {
            LOG.info("Checking for Customers to create");
            if(userPermissionJobService.customersToCreateCount() == 0)
                LOG.info("No updated customer info available");
            else
                userPermissionJobService.insertCustomers();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while inserting customer info " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while inserting customer info " + e.getMessage(), "insertCustomers");
        }

        try {
            LOG.info("Checking for Teams to create");
            userPermissionJobService.insertCollaborationTeam();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while insertCollaborationTeam " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while insertCollaborationTeam " + e.getMessage(), "insertCollaborationTeam");
        }

        try {
            LOG.info("Updating UserMappings");
            userPermissionJobService.insertUserMappings();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while insertUserMappings " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while insertUserMappings " + e.getMessage(), "insertUserMappings");
        }

        try {
            LOG.info("Updating UserMappings for Internals sales"); // Todo this can be removed once whitelisting removed for all other customers.
            userPermissionJobService.insertSalesUserMappings();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while insert Internals sales " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while insert Internals sales " + e.getMessage(), "insertSalesUserMappings");
        }

        try {
            LOG.info("Mapping UserMappings to Teams");
            userPermissionJobService.insertUserMapCollabTeamRelation();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while insert UserMapCollabTeamRelation " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while insert UserMapCollabTeamRelation " + e.getMessage(), "insertUserMapCollabTeamRelation");
        }

        try {
            LOG.info("Checking for InternalUsers/BetaUsers SecurityGroup to create");
            userPermissionJobService.createInternalUserSecurityGroups();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while createInternalUser SecurityGroup " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while createInternalUser SecurityGroup " + e.getMessage(), "createInternalUserSecurityGroups");
        }

        try {
            LOG.info("Checking for Customer SecurityGroups to create");
             userPermissionJobService.insertSecurityGroups();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while inserting SecurityGroups " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while inserting SecurityGroups " + e.getMessage(), "insertSecurityGroups");
        }

        try {
            LOG.info("Mapping UserMappings to SecurityGroups");
            userPermissionJobService.insertUserMapSecurityGroupRelation();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while insert UserMapSecurity GroupRelation " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while insert UserMapSecurity GroupRelation " + e.getMessage(), "insertCollaborationTeam");
        }

        try {
            LOG.info("Checking for Customer Team folders to update permissions");
            userPermissionJobService.collaborationTeamToGroupRelation();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while collaborationTeam To GroupRelation " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while collaborationTeam To GroupRelation" + e.getMessage(), "collaborationTeamToGroupRelation");
        }

        try {
            LOG.info("Checking for Canned Reports access updates");
            userPermissionJobService.updateAccessCannedReports();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while updating Access CannedReports  " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while updating Access CannedReports  " + e.getMessage(), "updateAccessCannedReports");
        }

        try {
            LOG.info("Updating function codes and market_partition for users");
            userPermissionJobService.updateUserFunctions();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while updating UserFunctions  " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while updating UserFunctions " + e.getMessage(), "updateUserFunctions");
        }

        try {
            LOG.info("Checking for updateCustomerInfo to update");
            userPermissionJobService.updateCustomerInfo();
        } catch (Exception e) {
            e.printStackTrace();
            LOG.error("Error occurred while updateCustomerInfo " + e.getMessage());
            userPermissionJobService.insertErrorMsg("Error occurred while updateCustomerInfo info " + e.getMessage(), "updateCustomerInfo");
        }

        LOG.info("$$$$$$$$$$$$$$$$$$$$$$ User Permission Job Ended $$$$$$$$$$$$$$$$$$$$$$");
    }

    @Modifying
    @Scheduled(cron = "0 * * ? * *")
    void teamsCleanRun(){
        if(teamsCleanMode) {
            LOG.info("$$$$$$$$$$$$$$$$$$$$$$ User Permission teamsCleanRun Job Started $$$$$$$$$$$$$$$$$$$$$$");
            try {
                userPermissionJobService.collaborationTeamToGroupRelation();
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error("Error occurred while collaborationTeam To GroupRelation in teamsCleanRun" + e.getMessage());
            }
            LOG.info("$$$$$$$$$$$$$$$$$$$$$$ User Permission teamsCleanRun Job Ended $$$$$$$$$$$$$$$$$$$$$$");
        }
    }

    @Modifying
    //@Scheduled(cron = "0 * * ? * *")
    void switchToAMDMOwnerId(){
            LOG.info("$$$$$$$$$$$$$$$$$$$$$$ User Permission switchToAMDMOwnerId Job Started $$$$$$$$$$$$$$$$$$$$$$");
            try {
                 userPermissionJobService.switchToAMDMOwnerId();
                 userPermissionJobService.updateLookerFolderGroupNames();
                 userPermissionJobService.moveContentFromMultipleFolders();
                 userPermissionJobService.updateModuleRelation();
                 userPermissionJobService.fileUploadCustomerIds();
                 userPermissionJobService.removeUnknowns();
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error("Error occurred while switchToAMDMOwnerId" + e.getMessage());
            }
            LOG.info("$$$$$$$$$$$$$$$$$$$$$$ User Permission switchToAMDMOwnerId Job Ended $$$$$$$$$$$$$$$$$$$$$$");

    }
}