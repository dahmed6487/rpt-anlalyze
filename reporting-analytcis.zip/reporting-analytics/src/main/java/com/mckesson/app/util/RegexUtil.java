package com.mckesson.app.util;

/**
 * <p/>
 * (c) 2005 Copyright - McKesson Medical-Surgical Minnesota Supply Inc. All
 * Rights Reserved
 *
 * @author <a href="mailto:Sean.Kleinjung@redline.mckhboc.com">Sean
 * Kleinjung</a>
 */
public class RegexUtil {
    public static String escapeRegexSpecialChars(String in) {
        /*
         * \ Turns metacharacters into literal characters, and literal characters into
         * metacharacters. Because this is also the Java escape character in strings, it
         * must be doubled. [ Starts character class definition. ( Starts a group. {
         * Encloses repetition count. {min, max} ^ Matches boundary at beginning. Class
         * negation when immediately after [. . Matches any single character. ?
         * Preceding element must match zero or one time. Preceding element must match
         * zero or more times. + Preceding element must match one or more times. |
         * Either preceding or following element must match.
         */

        String out = in.replaceAll("\\\\", "\\\\\\\\");
        out = out.replaceAll("\\[", "\\\\[");
        out = out.replaceAll("\\(", "\\\\(");
        out = out.replaceAll("\\{", "\\\\{");
        out = out.replaceAll("\\^", "\\\\^");
        out = out.replaceAll("\\.", "\\\\.");
        out = out.replaceAll("\\?", "\\\\?");
        out = out.replaceAll("\\*", "\\\\*");
        out = out.replaceAll("\\+", "\\\\+");
        out = out.replaceAll("\\|", "\\\\|");
        return out;
    }
}