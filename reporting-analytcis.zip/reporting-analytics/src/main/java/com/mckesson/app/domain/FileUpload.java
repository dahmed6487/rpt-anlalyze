package com.mckesson.app.domain;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "file_upload")
public class FileUpload {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "native")
    @Column(name = "load_file_id")
    private long loadFileId;

    @Column(name = "customer_id")
    private long customerId;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "created_date_time")
    private Date createdDateTime;

    @Column(name = "created_by")
    private String createdDy;

    @Column(name = "upload_status")
    private String uploadStatus;

    @Column(name = "upload_type")
    private String uploadType;

    @Column(name = "uploaded_date_time")
    private Date uploadedDateTime;

    public long getLoadFileId() {
        return loadFileId;
    }

    public void setLoadFileId(long loadFileId) {
        this.loadFileId = loadFileId;
    }

    public long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(long customerId) {
        this.customerId = customerId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Date getCreatedDateTime() {
        return createdDateTime;
    }

    public void setCreatedDateTime(Date createdDateTime) {
        this.createdDateTime = createdDateTime;
    }

    public String getCreatedDy() {
        return createdDy;
    }

    public void setCreatedDy(String createdDy) {
        this.createdDy = createdDy;
    }

    public String getUploadStatus() {
        return uploadStatus;
    }

    public void setUploadStatus(String uploadStatus) {
        this.uploadStatus = uploadStatus;
    }

    public String getUploadType() {
        return uploadType;
    }

    public void setUploadType(String uploadType) {
        this.uploadType = uploadType;
    }

    public Date getUploadedDateTime() {
        return uploadedDateTime;
    }

    public void setUploadedDateTime(Date uploadedDateTime) {
        this.uploadedDateTime = uploadedDateTime;
    }
}
