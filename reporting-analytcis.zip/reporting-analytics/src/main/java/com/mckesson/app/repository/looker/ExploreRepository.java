package com.mckesson.app.repository.looker;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import main.java.com.mckesson.app.domain.looker.ExploreRef;

public interface ExploreRepository extends JpaRepository<ExploreRef, Long> {
    Optional<ExploreRef> findDistinctByName(String name);
}
