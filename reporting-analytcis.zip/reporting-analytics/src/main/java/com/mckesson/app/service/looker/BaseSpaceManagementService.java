package com.mckesson.app.service.looker;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import main.java.com.mckesson.app.auth.user.ConnectUser;
import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.service.looker.api.ContentApi;
import main.java.com.mckesson.app.service.looker.api.DashboardApi;
import main.java.com.mckesson.app.service.looker.api.FolderApi;
import main.java.com.mckesson.app.service.looker.api.GroupApi;
import main.java.com.mckesson.app.service.looker.api.LookApi;
import main.java.com.mckesson.app.service.looker.api.QueryApi;
import main.java.com.mckesson.app.service.looker.api.SpaceApi;
import main.java.com.mckesson.app.service.looker.api.UserApi;
import main.java.com.mckesson.app.vo.ReportItemVo;
import main.java.com.mckesson.app.vo.looker.DashboardVo;
import main.java.com.mckesson.app.vo.looker.FolderVo;
import main.java.com.mckesson.app.vo.looker.LookVo;

public class BaseSpaceManagementService {

    public SpaceApi spaceApi;
    public UserApi userApi;
    public DashboardApi dashboardApi;
    public LookApi lookApi;
    public FolderApi folderApi;
    public ContentApi contentApi;
    public QueryApi queryApi;
    public GroupApi groupApi;

    public BaseSpaceManagementService(
            SpaceApi spaceApi,
            UserApi userApi,
            DashboardApi dashboardApi,
            LookApi lookApi,
            FolderApi folderApi,
            ContentApi contentApi,
            QueryApi queryApi, GroupApi groupApi) {
        this.spaceApi = spaceApi;
        this.userApi = userApi;
        this.dashboardApi = dashboardApi;
        this.lookApi = lookApi;
        this.folderApi = folderApi;
        this.contentApi = contentApi;
        this.queryApi = queryApi;
        this.groupApi=groupApi;
    }

    public ReportItemVo getFolderStructure(String parentFolderId, String authToken, String userId) {

        if (authToken == null) {
            authToken = spaceApi.getAuthToken();
        }

        //Get root level folder
        String[] folderFields = {"id", "name", "created_at","parent_id"};
        FolderVo userFolder = spaceApi.getFolder(parentFolderId, folderFields, authToken);

        ReportItemVo rootItem = convertFolderToVo(userFolder);

        String[] fields = {"id", "title", "name", "description", "favorite_count", "created_at", "last_viewed_at", "deleted","user_id","query","parent_id"};
        String[] dbFields = {"id", "title", "name", "description", "favorite_count", "created_at", "last_viewed_at", "deleted", "user_id", "dashboard_elements","parent_id"};

        List<LookVo> looks = spaceApi.getLooksForFolder(parentFolderId, fields, authToken);
        rootItem.getChildren().addAll(convertLooksToVos(looks,false,userId));

        List<DashboardVo> dashboards = spaceApi.getDashboardsForFolder(parentFolderId, dbFields, authToken);
        rootItem.getChildren().addAll(convertDashboardsToVos(dashboards,false,userId));

        List<FolderVo> childFolders = spaceApi.getChildFolders(parentFolderId, authToken);
        for (FolderVo child : childFolders) {
            rootItem.getChildren().add(getFolderStructure(child.getId(), authToken, userId));
        }

        return rootItem;
    }

    public String getAuthToken() {
        return spaceApi.getAuthToken();
    }

    public List<ReportItemVo> convertFoldersToVos(List<FolderVo> folders) {
        List<ReportItemVo> reportItems = new ArrayList();
        ReportItemVo reportItem;
        for (FolderVo folder : folders) {
            reportItems.add(convertFolderToVo(folder));
        }
       // formatTimestamps(reportItems);
        return reportItems;
    }

    public ReportItemVo convertFolderToVo(FolderVo folder) {
        ReportItemVo reportItem;
        reportItem = new ReportItemVo();
        reportItem.setId(folder.getId());
        reportItem.setName(folder.getName());
        reportItem.setType("folder");
        reportItem.setParentId(folder.getParentId());
        if (folder.getCreatedAt() != null) {
            reportItem.setCreatedAt(folder.getCreatedAt());
        }
        reportItem.setType(ReportItemVo.ITEM_TYPE_FOLDER);
        reportItem.setViewCount(folder.getViewCount());
       // formatTimestamps(reportItem);
        return reportItem;
    }

    public List<ReportItemVo> convertDashboardsToVos(List<DashboardVo> dashboards,Boolean isNotTeam,String userId) {
        List<ReportItemVo> reportItems = new ArrayList();
        ReportItemVo reportItem;
        for (DashboardVo dashboard : dashboards) {
            reportItems.add(convertDashboardToVo(dashboard,isNotTeam,userId));
        }
        //formatTimestamps(reportItems);
        return reportItems;
    }

    public ReportItemVo convertDashboardToVo(DashboardVo dashboard,Boolean isNotTeam,String userId) {
        List<ReportItemVo> reportItems = new ArrayList();
        ReportItemVo reportItem;
        reportItem = new ReportItemVo();
        reportItem.setId(dashboard.getId());
        reportItem.setName(dashboard.getTitle());
        reportItem.setDescription(dashboard.getDescription());
        reportItem.setType("dashboard");
        reportItem.setCreatedAt(dashboard.getCreatedAt());
        reportItem.setType(ReportItemVo.ITEM_TYPE_DASHBOARD);
        reportItem.setFavoriteCount(dashboard.getFavoriteCount());
        reportItem.setLastViewed(dashboard.getLastViewedAt());
        reportItem.setViewCount(dashboard.getViewCount());
        reportItem.setLastUpdated(dashboard.getLastUpdated());
        if(dashboard.getDashboardElements()!=null){
            if(dashboard.getDashboardElements().size()!=0) {
                reportItem.setView(dashboard.getDashboardElements().get(0).getQuery().getView());
                reportItem.setClientId(dashboard.getDashboardElements().get(0).getQuery().getClientId());
            }
        }
        if(isNotTeam)
            reportItem.setCurrentUserMayEdit(true);
        else {
            if(userId.equals(dashboard.getUserId()))
                reportItem.setCurrentUserMayEdit(true);
            else
                reportItem.setCurrentUserMayEdit(false);
        }
        reportItems.add(reportItem);
       // formatTimestamps(reportItems);
        return reportItem;
    }

    public List<ReportItemVo> convertLooksToVos(List<LookVo> looks,Boolean isNotTeam,String userId) {
        List<ReportItemVo> reportItems = new ArrayList();
        ReportItemVo reportItem;
        for (LookVo look : looks) {
            reportItems.add(convertLookToVo(look,isNotTeam,userId));
        }

        return reportItems;
    }

    public ReportItemVo convertLookToVo(LookVo look,Boolean isNotTeam,String userId) {
        ReportItemVo reportItem;
        reportItem = new ReportItemVo();
        reportItem.setId(Long.toString(look.getId()));
        reportItem.setName(look.getTitle());
        reportItem.setDescription(look.getDescription());
        reportItem.setType("look");
        reportItem.setCreatedAt(look.getCreatedAt());
        reportItem.setType(ReportItemVo.ITEM_TYPE_REPORT);
        reportItem.setFavoriteCount(look.getFavoriteCount());
        reportItem.setLastViewed(look.getLastViewedAt());
        reportItem.setLastUpdated(look.getUpdatedAt());
        reportItem.setViewCount(look.getViewCount());
        if(look.getQuery()!=null){
            reportItem.setView(look.getQuery().getView());
            reportItem.setClientId(look.getQuery().getClientId());
        }
        if(isNotTeam)
        reportItem.setCurrentUserMayEdit(true);
        else {
            if(userId.equals(look.getUserId()))
            reportItem.setCurrentUserMayEdit(true);
            else
             reportItem.setCurrentUserMayEdit(false);
        }
       // formatTimestamps(reportItem);
        return reportItem;
    }

    public void setDate(ReportItemVo item) {
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            item.setLastAction(f.format(Calendar.getInstance().getTime()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getCurrentUserNameFormatted(ReportUser reportUser) {
        return reportUser.getFirstName() + " " + reportUser.getLastName();
    }

    public String getCurrentUserNameFormatted(ConnectUser user) {
        return user.getFirstName() + " " + user.getLastName();
    }

    public void formatTimestamps2(ReportItemVo parent) {
        Date refDate;
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
        try {
            if (parent.getCreatedAt() != null) {
                refDate = javax.xml.bind.DatatypeConverter.parseDateTime(parent.getCreatedAt()).getTime();
                parent.setCreatedAt(formatter.format(refDate));
            }
            if (parent.getLastUpdated() != null) {
                refDate = javax.xml.bind.DatatypeConverter.parseDateTime(parent.getLastUpdated()).getTime();
                parent.setLastUpdated(formatter.format(refDate));
            }
        } catch (Exception e) {
        }
        if (parent.getChildren() != null) {
            for (ReportItemVo item : parent.getChildren()) {
                formatTimestamps2(item);
            }
        }
    }

    public void formatTimestamps2(List<ReportItemVo> reportItems) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
            Date refDate;
            for (ReportItemVo item : reportItems) {
                if (item.getCreatedAt() != null && !item.getCreatedAt().trim().isEmpty()) {
                    refDate = javax.xml.bind.DatatypeConverter.parseDateTime(item.getCreatedAt()).getTime();
                    item.setCreatedAt(formatter.format(refDate));
                }

                if (item.getLastUpdated() != null && !item.getCreatedAt().trim().isEmpty()) {
                    refDate = javax.xml.bind.DatatypeConverter.parseDateTime(item.getLastUpdated()).getTime();
                    item.setLastUpdated(formatter.format(refDate));
                }
            }
        } catch (Exception e) {
        }
    }

    public String getDateFormatted(String date) {
        try {
            SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm a");
            Date refDate;
            refDate = javax.xml.bind.DatatypeConverter.parseDateTime(date).getTime();
            return formatter.format(refDate);
        } catch (Exception e) {
            return "";
        }
    }
}
