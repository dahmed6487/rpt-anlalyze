package com.mckesson.app.vo.looker;

import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

/**
 * A VO mapping the {@link ExploreVo} object returned for a <em>Explores</em> JSON array from the Looker API.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ExploresVo {

    @JsonProperty("explores")
    List<ExploreVo> explores;

    @JsonProperty("message")
    String message;

    public List<ExploreVo> getExplores() {
        return explores;
    }

    public void setExplores(List<ExploreVo> explores) {
        this.explores = explores;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
