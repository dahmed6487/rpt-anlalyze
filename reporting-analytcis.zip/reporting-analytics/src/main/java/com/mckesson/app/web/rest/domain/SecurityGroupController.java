package com.mckesson.app.web.rest.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import main.java.com.mckesson.app.domain.customer.SecurityGroup;
import main.java.com.mckesson.app.service.customer.SecurityGroupService;

/**
 * Class used to drive SecurityGroup operations for data display on Admin/Domain screen
 */
@RestController
@RequestMapping("/api/security-group")
public class SecurityGroupController {

    private final SecurityGroupService securityGroupService;

    @Autowired
    public SecurityGroupController(SecurityGroupService securityGroupService) {
        this.securityGroupService = securityGroupService;
    }

    /**
     * @return
     */
    @GetMapping("/get")
    public List<SecurityGroup> getAll() {
        return securityGroupService.getAll();
    }

    /**
     * @param securityGroup
     * @return
     */
    @PostMapping("/update")
    public List<SecurityGroup> updateAll(@RequestBody List<SecurityGroup> securityGroup) {
        return securityGroupService.updateAll(securityGroup);
    }

    /**
     * It update the Delete date in securityGroup/Accounts
     *
     * @param securityGroup
     * @return
     */
    @PostMapping("/delete")
    public ResponseEntity<String> deleteAll(@RequestBody List<SecurityGroup> securityGroup) {
        return securityGroupService.deleteAll(securityGroup);
    }

    /*
     * 1.Remove Group account mapping
     * 2.RemoveMapping from Cutomer
     * 3.Update Group account mapping
     * 4.Update Mapping into Customer
     * 5.Insert Group account mapping
     * 6.Insert Mapping into Customer
     * */
}
