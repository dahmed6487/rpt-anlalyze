package com.mckesson.app.web.rest;

public class HeartbeatController {

}
