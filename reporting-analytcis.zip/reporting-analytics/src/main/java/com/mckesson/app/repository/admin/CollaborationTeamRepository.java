package com.mckesson.app.repository.admin;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import main.java.com.mckesson.app.domain.admin.CollaborationTeam;

public interface CollaborationTeamRepository extends JpaRepository<CollaborationTeam, Long>, JpaSpecificationExecutor<CollaborationTeam> {

    List<CollaborationTeam> save(Iterable<? extends CollaborationTeam> entities);

    @Transactional
    @Modifying
    @Query(value = "delete t from collab_team_module_relation t where t.collaboration_team_id in ?1 ", nativeQuery = true)
    void deleteRelation(List<Long> list);

    @Transactional
    @Modifying
    @Query(value = "delete t from user_map_collab_team_relation t where t.collaboration_team_id = ?1 and t.user_mapping_id = ?2", nativeQuery = true)
    void deleteRelationByTeamAndUser(Long teamId, Long mappingId);

    @Transactional
    @Modifying
    @Query(value = "delete t from user_map_collab_team_relation t where t.collaboration_team_id = ?1", nativeQuery = true)
    int deleteUserMapTeamRelation(Long teamId);

    @Transactional
    @Modifying
    @Query(value = "delete t from collab_team_module_relation t where t.collaboration_team_id = ?1", nativeQuery = true)
    int deleteModuleTeamRelation(Long teamId);

    @Transactional
    @Modifying
    @Query("update #{#entityName} t set t.deletedDate= ?1 where t.collaborationTeamId in ?2 ")
    void inActive(Date deletedDate, List<Long> list);

    @Transactional
    @Modifying
    @Query(value = "insert into user_map_collab_team_relation (collaboration_team_id, user_mapping_id) values(?1, ?2)", nativeQuery = true)
    void insertOrUpdateRelation(Long collaborationTeamId, Long userMappingId);

    @Transactional
    @Modifying
    @Query(value = "delete t from collab_team_module_relation t where t.relation_id in ?1 ", nativeQuery = true)
    void deleteRelationById(List<Integer> list);

    @Transactional
    @Modifying
    @Query(value = "update collaboration_team t set  deleted_date=null where t.collaboration_team_id in ?1 ", nativeQuery = true)
    void active(List<Long> list);

    @Query(value = "select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by, " +
            "ct.updated_date, ct.deleted_by, ct.deleted_date from user_mapping t,collaboration_team ct,user_map_collab_team_relation r\n" +
            "where ct.collaboration_team_id=r.collaboration_team_id and t.user_mapping_id=r.user_mapping_id and t.user_id= ?1 ", nativeQuery = true)
    List<CollaborationTeam> getTeamIdsForCurrentUser(String username);

    /**
     * get all active teams for super admin
     *
     * @param userId
     * @return
     */
    @Query(value = "select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by, " +
            "ct.updated_date, cs.common_entity_name deleted_by, ct.deleted_date from collaboration_team ct,customer cs where  ct.customer_id=cs.customer_id and ct.external_id is not null and cs.deleted_date is null", nativeQuery = true)
    List<CollaborationTeam> getSuperAdminCollTeams(String userId);

    /**
     * get all teams for customer admin based on customer id
     */
    @Query(value = "select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by, " +
            "ct.updated_date, cs.amdm_era_ownr_name deleted_by, ct.deleted_date from collaboration_team ct,customer cs where  ct.created_by='SYSTEM' and ct.customer_id=cs.customer_id and ct.external_id is not null and cs.amdm_era_ownr_name = ?1 and cs.deleted_date is null", nativeQuery = true)
    List<CollaborationTeam> getCustAdminCollTeams(String customerName);

    @Query(value = "select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by, " +
            "ct.updated_date, cs.amdm_era_ownr_name deleted_by, ct.deleted_date from user_mapping t,collaboration_team ct,user_map_collab_team_relation r,customer cs\n" +
            "where ct.collaboration_team_id=r.collaboration_team_id and t.user_mapping_id=r.user_mapping_id and t.customer_id=ct.customer_id and cs.customer_id=ct.customer_id and ct.external_id is not null and t.user_id= ?1 and cs.deleted_date is null and r.deleted_date is null ", nativeQuery = true)
    List<CollaborationTeam> getTeamsForUser(String username);

    @Query(value = "select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by, " +
            "ct.updated_date, cs.amdm_era_ownr_name deleted_by, ct.deleted_date from user_mapping t,collaboration_team ct,user_map_collab_team_relation r,customer cs\n" +
            "where ct.collaboration_team_id=r.collaboration_team_id and t.user_mapping_id=r.user_mapping_id and cs.customer_id=ct.customer_id and ct.external_id is not null and t.user_id= ?1 and cs.amdm_era_ownr_name = ?2", nativeQuery = true)
    List<CollaborationTeam> getTeamIdForCustomer(String username, String customerName);

    /**
     * Userpermission Job SQL
     * get all teams for user based on userid and mapping from user_map_collab_team_relation table
     *
     * @param userId
     * @return
     */
    @Query(value = "select ct.* from collaboration_team ct,user_map_collab_team_relation cr ,user_mapping um\n" +
            "where um.user_mapping_id=cr.user_mapping_id and cr.collaboration_team_id=ct.collaboration_team_id and um.user_id = ?1", nativeQuery = true)
    List<CollaborationTeam> getCollaborationTeams(String userId);

    @Query(value = "select ct.* from collaboration_team ct, user_map_collab_team_relation umctr, user_mapping um, customer c\n" +
            "where um.user_mapping_id = umctr.user_mapping_id and umctr.collaboration_team_id = ct.collaboration_team_id and um.user_id = ?1 and c.customer_id = ct.customer_id and c.common_entity_name = ?2", nativeQuery = true)
    List<CollaborationTeam> getTeamsByUserAndSelectedCustomer(String username, String customerName);

    @Query(value = "select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by, " +
            "ct.updated_date, cs.amdm_era_ownr_name deleted_by, ct.deleted_date from collaboration_team ct,customer cs where  ct.customer_id=cs.customer_id and ct.external_id is not null and cs.deleted_date is null and ct.name like ?1% order by ct.name asc LIMIT 6", nativeQuery = true)
    List<CollaborationTeam> searchTeamsForInternalUser(String searchString);

    @Query(value = "select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by, " +
            "ct.updated_date, cs.amdm_era_ownr_name deleted_by, ct.deleted_date from collaboration_team ct,customer cs where  ct.customer_id=cs.customer_id and ct.external_id is not null and cs.deleted_date is null and settings='beta' and ct.name like ?1% order by ct.name asc LIMIT 6", nativeQuery = true)
    List<CollaborationTeam> searchTeamsForBetaUser(String searchString);

    @Query(value = "select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by,\n" +
            "ct.updated_date, cs.amdm_era_ownr_name deleted_by, ct.deleted_date from user_mapping t,collaboration_team ct,user_map_collab_team_relation r,customer cs\n" +
            "where ct.collaboration_team_id=r.collaboration_team_id and t.user_mapping_id=r.user_mapping_id and t.customer_id=ct.customer_id and cs.customer_id=ct.customer_id and ct.external_id is not null and t.user_id= ?1 and ct.name like ?2% and cs.deleted_date is null and r.deleted_date is null order by ct.name asc LIMIT 6", nativeQuery = true)
    List<CollaborationTeam> searchTeamsForUser(String userId, String searchString);

    @Query(value = "  select coalesce(a.collaboration_team_id, b.collaboration_team_id) collaboration_team_id, coalesce(a.platform, b.platform) platform, coalesce(a.customer_id, b.customer_id) customer_id , coalesce(a.name, b.name) name, coalesce(a.external_id, b.external_id) external_id, coalesce(a.created_by, b.created_by) created_by, coalesce(a.created_date, b.created_date) created_date, coalesce(a.updated_by, b.updated_by) updated_by, coalesce(a.deleted_by, b.deleted_by) deleted_by,coalesce(a.deleted_date, b.deleted_date)  deleted_date, coalesce(a.updated_date, b.updated_date)  updated_date\n from (select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by, cs.amdm_era_ownr_name deleted_by, ct.deleted_date, null updated_date from\n" +
            "collaboration_team ct,customer cs where ct.customer_id=cs.customer_id and ct.external_id is not null and cs.deleted_date is null) a\n" +
            "LEFT JOIN  (select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by, cs.amdm_era_ownr_name deleted_by, ct.deleted_date, up.updated_date updated_date from\n" +
            "collaboration_team ct,customer cs,recent_search_log up where up.updated_by=?1 and up.search_criteria='MY_REPORTS_RECENT' and ct.collaboration_team_id=up.search_criteria_id and ct.customer_id=cs.customer_id\n" +
            "and ct.external_id is not null and cs.deleted_date is null) b on a.collaboration_team_id=b.collaboration_team_id  order by b.updated_date desc LIMIT 6", nativeQuery = true)
    List<CollaborationTeam> getSuperAdminCollTeamsBypage(String userId);

    @Query(value = "select coalesce(a.collaboration_team_id, b.collaboration_team_id) collaboration_team_id, coalesce(a.platform, b.platform) platform, coalesce(a.customer_id, b.customer_id) customer_id , coalesce(a.name, b.name) name, coalesce(a.external_id, b.external_id) external_id, coalesce(a.created_by, b.created_by) created_by, coalesce(a.created_date, b.created_date) created_date, coalesce(a.updated_by, b.updated_by) updated_by, coalesce(a.deleted_by, b.deleted_by) deleted_by,coalesce(a.deleted_date, b.deleted_date)  deleted_date, coalesce(a.updated_date, b.updated_date)  updated_date\n from (select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by,\n" +
            "            cs.amdm_era_ownr_name deleted_by, ct.deleted_date ,null updated_date from collaboration_team ct,customer cs where  ct.customer_id=cs.customer_id and ct.external_id is not null and cs.deleted_date is null and settings='beta'\n" +
            ") a LEFT JOIN  (select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by, cs.amdm_era_ownr_name deleted_by, ct.deleted_date, up.updated_date updated_date from\n" +
            "collaboration_team ct,customer cs,recent_search_log up where up.updated_by=?1 and up.search_criteria='MY_REPORTS_RECENT' and ct.collaboration_team_id=up.search_criteria_id and ct.customer_id=cs.customer_id\n" +
            "and ct.external_id is not null and cs.deleted_date is null) b on a.collaboration_team_id=b.collaboration_team_id  order by b.updated_date desc LIMIT 6", nativeQuery = true)
    List<CollaborationTeam> getBetaCollTeamsBypage(String userId);

    @Query(value = "select coalesce(a.collaboration_team_id, b.collaboration_team_id) collaboration_team_id, coalesce(a.platform, b.platform) platform, coalesce(a.customer_id, b.customer_id) customer_id , coalesce(a.name, b.name) name, coalesce(a.external_id, b.external_id) external_id, coalesce(a.created_by, b.created_by) created_by, coalesce(a.created_date, b.created_date) created_date, coalesce(a.updated_by, b.updated_by) updated_by, coalesce(a.deleted_by, b.deleted_by) deleted_by,coalesce(a.deleted_date, b.deleted_date)  deleted_date, coalesce(a.updated_date, b.updated_date)  updated_date\n from ( select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by,\n" +
            "             cs.amdm_era_ownr_name deleted_by, ct.deleted_date,null updated_date from user_mapping t,collaboration_team ct,user_map_collab_team_relation r,customer cs\n" +
            "            where ct.collaboration_team_id=r.collaboration_team_id and t.user_mapping_id=r.user_mapping_id and t.customer_id=ct.customer_id and cs.customer_id=ct.customer_id and ct.external_id is not null and t.user_id= ?1 and cs.deleted_date is null and r.deleted_date is null\n" +
            ") a LEFT JOIN   (select ct.collaboration_team_id, ct.platform, ct.customer_id , ct.name, ct.external_id, ct.created_by, ct.created_date, ct.updated_by, cs.amdm_era_ownr_name deleted_by, ct.deleted_date, up.updated_date updated_date from\n" +
            "collaboration_team ct,customer cs,recent_search_log up where up.updated_by=?1 and up.search_criteria='MY_REPORTS_RECENT' and ct.collaboration_team_id=up.search_criteria_id and ct.customer_id=cs.customer_id\n" +
            "and ct.external_id is not null and cs.deleted_date is null) b on a.collaboration_team_id=b.collaboration_team_id  order by b.updated_date desc LIMIT 6", nativeQuery = true)
    List<CollaborationTeam> getTeamsForUseBypage(String username);

    @Query(value = "select * from collaboration_team where deleted_date is null and created_by='SYSTEM' and created_date > DATE_SUB(NOW(), INTERVAL 8 HOUR) order by customer_id asc", nativeQuery = true)
    List<CollaborationTeam> getNewCollabTeams();

    @Query(value = "select * from collaboration_team where deleted_date is null and created_by='SYSTEM' order by customer_id asc", nativeQuery = true)
    List<CollaborationTeam> getAllCollabTeams();

    Optional<List<CollaborationTeam>> findByCustomerId(Long customerId);

    @Query(value = "select * from collaboration_team ct, customer c where ct.customer_id = ?1 and c.common_entity_name = ct.name and ct.external_id is not null and ct.created_by='SYSTEM'", nativeQuery = true)
    CollaborationTeam getTopLevelCustomerTeam(Long customerId);

    Optional<CollaborationTeam> findByCollaborationTeamId(long teamId);

    @Query(value = "select collaboration_team_id from collab_team_module_relation ctr,module m where m.module_id=ctr.module_id and collaboration_team_id=?1 and m.module_id in (select module.module_id from module where title=?2)", nativeQuery = true)
    ArrayList<String> checkExistingAccess(Long teamId, String module);

    @Modifying
    @Query(value = "insert into collab_team_module_relation (collaboration_team_id, module_id) values ( ?1, (select module_id from module where title=?2 and module_type = 'canned report'))", nativeQuery = true)
    void updateAccess(long teamId, String module);

    @Modifying
    @Query(value = "delete from collab_team_module_relation  where collaboration_team_id=?1 and module_id in (select module.module_id from module where title=?2 and module_type = 'canned report')", nativeQuery = true)
    void removeAccess(long teamId, String module);

    @Modifying
    @Query(value = "delete from collab_team_module_relation  where collaboration_team_id=?1", nativeQuery = true)
    void removeTeamAccess(long teamId);

    @Query(value = "select * from security_group where name=?1",nativeQuery = true)
    ArrayList<String> isSecuirtyGroupCreatedforTeam(String teamName);

    @Query(value = "select * from collaboration_team ct, customer c where c.common_entity_id = ?1 and c.customer_id = ct.customer_id and c.deleted_date is null and ct.created_by!='SYSTEM'", nativeQuery = true)
    List<CollaborationTeam> getTeamsByCommonEntityId(String commonEntityId);

    @Query(value = "select module_id from customer_module_relation where module_id in( select module_id from module where title=?2 )  and customer_id in (select collaboration_team.customer_id from collaboration_team where collaboration_team_id=?1)", nativeQuery = true)
    ArrayList<String> checkTopLevelAccess(long teamId, String module);

    @Modifying
    @Query(value = "delete from user_map_collab_team_relation where created_by='SYSTEM' and user_mapping_id in (select user_mapping_id from user_mapping where customer_id=?1)", nativeQuery = true)
    void deleteColabTeamMapping(long customerId);

    @Modifying
    @Query(value = "delete from collaboration_team where  created_by='SYSTEM' and customer_id=?1", nativeQuery = true)
    void deleteColabTeam(long customerId);

    @Query(value = "select external_id from collaboration_team where created_by='SYSTEM' and customer_id=?1",nativeQuery = true)
    Integer getFolderId(long customerId);

    @Query(value = "select * from collaboration_team where external_id is null",nativeQuery = true)
    List<CollaborationTeam> getMissingCollaborationTeam();

    @Query(value = "select * from collaboration_team where created_by='SYSTEM' and customer_id=?1",nativeQuery = true)
    CollaborationTeam getTeamByCustomerId(long customerId);

    @Modifying
    @Query(value = "update collaboration_team  set updated_by=?1,deleted_date=current_timestamp where external_id=?2", nativeQuery = true)
    void updateMovedFolder(String updatedBy,String id);

    @Modifying
    @Query(value = "update collaboration_team  set updated_by=?1,deleted_date=current_timestamp where  name=?2", nativeQuery = true)
    void updateMovedFolderWithName(String updatedBy,String name);

    @Query(value = "select * from collaboration_team where updated_by='UNKOWN'",nativeQuery = true)
    List<CollaborationTeam> getUnknownsTeams();
}
