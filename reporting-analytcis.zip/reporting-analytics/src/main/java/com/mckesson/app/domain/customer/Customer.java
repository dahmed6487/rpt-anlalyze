package com.mckesson.app.domain.customer;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Where;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "customer")
@Where(clause = "deleted_date is null")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "native")
    @Column(name = "customer_id")
    private long customerId;
    @Column(name = "platform")
    private String platformId;
    @Column(name = "common_grp_id")
    private String commonGroupId;
    @Column(name = "common_grp_name")
    private String commonGroupName;
    @Column(name = "common_entity_id", unique = true)
    private String commonEntityId;
    @Column(name = "common_entity_name")
    private String commonEntityName;
    @Column(name = "customer_name")
    private String customerName;
    private String settings;
    @Column(name = "created_by")
    private String createdBy;
    @Column(name = "created_date")
    private Date createdDate;
    @Column(name = "updated_by")
    private String updatedBy;
    @Column(name = "updated_date")
    private Date updatedDate;
    @Column(name = "deleted_by")
    private String deletedBy;
    @Column(name = "deleted_date")
    private Date deletedDate;
    @Column(name = "total_accounts")
    private String totalAccounts;
    @Column(name = "byng_grp_id")
    private String buyingGroupId;
    @Column(name = "byng_grp_name")
    private String buyingGroupName;
    @Column(name = "natl_grp_cd")
    private String natlGrpCd;
    @Column(name = "natl_grp_name")
    private String natlGrpName;
    @Column(name = "natl_sub_grp_cd")
    private String natlSubGrpCd;
    @Column(name = "acct_chn_id")
    private String custChnId;
    @Column(name = "acct_chn_name")
    private String custChnName;
    @Column(name = "natl_sub_grp_name")
    private String natlSubGrpName;
    @Column(name = "sls_terr_id")
    private String slsTerrId;
    @Column(name = "cust_rgn_num")
    private String custRgnNum;
    @Column(name = "cust_dstrct_num")
    private String custDstrctNum;
    @Column(name = "alt_payer_id")
    private String natlAcctId;
    @Column(name = "amdm_ownr_num")
    private String ownerId;
    @Column(name = "pri_sec_flag")
    private String priSecFlag;
    @Column(name = "era_contact")
    private String eraContact;
    @Column(name = "340b_flag")
    private String bFlag;
    @Column(name = "customer_type")
    private String customerType;
    @Column(name = "cust_dstrct_name")
    private String custDstrctName;
    @Column(name = "owner_name")
    private String ownerName;
    @Column(name = "amdm_era_ownr_party_id")
    private String amdmEraOwnrPartyId;
    @Column(name = "amdm_era_ownr_name")
    private String amdmEraOwnrName;


    public Customer() {
    }

/*    @OneToMany(mappedBy = "customerUserMapping", cascade = CascadeType.ALL)
    @JsonIgnore
    private Collection<UserMapping> customerUserMapping;*/

    @OneToMany(mappedBy = "customerSecurityGroup")
    @JsonIgnore
    private Collection<SecurityGroup> customerSecurityGroup;

    /*  public Collection<UserMapping> getCustomerUserMapping() {
        return customerUserMapping;
    }

    public void setCustomerUserMapping(Collection<UserMapping> customerUserMapping) {
        this.customerUserMapping = customerUserMapping;
    }*/

    public Collection<SecurityGroup> getCustomerSecurityGroup() {
        return customerSecurityGroup;
    }

    public void setCustomerSecurityGroup(Collection<SecurityGroup> customerSecurityGroup) {
        this.customerSecurityGroup = customerSecurityGroup;
    }

    public long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(long customerId) {
        this.customerId = customerId;
    }

    public String getCommonGroupId() {
        return commonGroupId;
    }

    public void setCommonGroupId(String commonGroupId) {
        this.commonGroupId = commonGroupId;
    }

    public String getCommonGroupName() {
        return commonGroupName;
    }

    public void setCommonGroupName(String commonGroupName) {
        this.commonGroupName = commonGroupName;
    }

    public String getCommonEntityId() {
        return commonEntityId;
    }

    public void setCommonEntityId(String commonEntityId) {
        this.commonEntityId = commonEntityId;
    }

    public String getCommonEntityName() {
        return commonEntityName;
    }

    public void setCommonEntityName(String commonEntityName) {
        this.commonEntityName = commonEntityName;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getSettings() {
        return settings;
    }

    public void setSettings(String settings) {
        this.settings = settings;
    }

    public String getPlatformId() {
        return platformId;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

    public String getTotalAccounts() {
        return totalAccounts;
    }

    public void setTotalAccounts(String totalAccounts) {
        this.totalAccounts = totalAccounts;
    }

    public String getBuyingGroupId() {
        return buyingGroupId;
    }

    public void setBuyingGroupId(String buyingGroupId) {
        this.buyingGroupId = buyingGroupId;
    }

    public String getBuyingGroupName() {
        return buyingGroupName;
    }

    public void setBuyingGroupName(String buyingGroupName) {
        this.buyingGroupName = buyingGroupName;
    }

    public String getNatlGrpCd() {
        return natlGrpCd;
    }

    public void setNatlGrpCd(String natlGrpCd) {
        this.natlGrpCd = natlGrpCd;
    }

    public String getNatlSubGrpCd() {
        return natlSubGrpCd;
    }

    public void setNatlSubGrpCd(String natlSubGrpCd) {
        this.natlSubGrpCd = natlSubGrpCd;
    }

    public String getCustChnId() {
        return custChnId;
    }

    public void setCustChnId(String custChnId) {
        this.custChnId = custChnId;
    }

    public String getCustChnName() {
        return custChnName;
    }

    public void setCustChnName(String custChnName) {
        this.custChnName = custChnName;
    }

    public String getSlsTerrId() {
        return slsTerrId;
    }

    public void setSlsTerrId(String slsTerrId) {
        this.slsTerrId = slsTerrId;
    }

    public String getCustRgnNum() {
        return custRgnNum;
    }

    public void setCustRgnNum(String custRgnNum) {
        this.custRgnNum = custRgnNum;
    }

    public String getCustDstrctNum() {
        return custDstrctNum;
    }

    public void setCustDstrctNum(String custDstrctNum) {
        this.custDstrctNum = custDstrctNum;
    }

    public String getNatlAcctId() {
        return natlAcctId;
    }

    public void setNatlAcctId(String natlAcctId) {
        this.natlAcctId = natlAcctId;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    public String getPriSecFlag() {
        return priSecFlag;
    }

    public void setPriSecFlag(String priSecFlag) {
        this.priSecFlag = priSecFlag;
    }

    public String getEraContact() {
        return eraContact;
    }

    public void setEraContact(String eraContact) {
        this.eraContact = eraContact;
    }

    public String getbFlag() {
        return bFlag;
    }

    public void setbFlag(String bFlag) {
        this.bFlag = bFlag;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getCustDstrctName() {
        return custDstrctName;
    }

    public void setCustDstrctName(String custDstrctName) {
        this.custDstrctName = custDstrctName;
    }

    public String getNatlGrpName() {
        return natlGrpName;
    }

    public void setNatlGrpName(String natlGrpName) {
        this.natlGrpName = natlGrpName;
    }

    public String getNatlSubGrpName() {
        return natlSubGrpName;
    }

    public void setNatlSubGrpName(String natlSubGrpName) {
        this.natlSubGrpName = natlSubGrpName;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getAmdmEraOwnrPartyId() {
        return amdmEraOwnrPartyId;
    }

    public void setAmdmEraOwnrPartyId(String amdmEraOwnrPartyId) {
        this.amdmEraOwnrPartyId = amdmEraOwnrPartyId;
    }

    public String getAmdmEraOwnrName() {
        return amdmEraOwnrName;
    }

    public void setAmdmEraOwnrName(String amdmEraOwnrName) {
        this.amdmEraOwnrName = amdmEraOwnrName;
    }
}