package com.mckesson.app.misc;

public class ApiException extends RuntimeException {

    public ApiException() {

    }

    public ApiException(String msg) {
        super(msg);
    }

    public ApiException(String msg, Exception e) {
        super(msg, e);
    }
}
