package com.mckesson.app.service.looker;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.domain.looker.ExploreRef;
import main.java.com.mckesson.app.repository.looker.ExploreRepository;

@Service("exploreService")
public class ExploreServiceImpl implements ExploreService {

    private final ExploreRepository repo;

    @Autowired
    public ExploreServiceImpl(ExploreRepository repo) {
        this.repo = repo;
    }

    public ExploreRef findById(Long id) {
        Optional<ExploreRef> optional = repo.findById(id);
        return optional.orElse(null);
    }

    @Override
    public Optional<ExploreRef> findByName(String name) {
        return repo.findDistinctByName(name);
    }

    @Override
    public ExploreRef insert(String name) {
        ExploreRef exploreRef = new ExploreRef();
        exploreRef.setName(name);
        return repo.save(exploreRef);
    }

    @Override
    public ExploreRef save(ExploreRef ref) {
        return repo.save(ref);
    }

    @Override
    public List<ExploreRef> saveAll(Collection<ExploreRef> refs) {
        return repo.saveAll(refs);
    }

}
