package com.mckesson.app.auth.user;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.mckesson.lib.model.customer.AccountId;
import com.mckesson.lib.model.platform.PlatformId;

import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.domain.admin.Module;
import main.java.com.mckesson.app.domain.customer.Account;
import main.java.com.mckesson.app.domain.customer.UserMapping;
import main.java.com.mckesson.app.domain.user.UserProfile;
import main.java.com.mckesson.app.util.StringUtils;

/**
 * Non-mutable class which represents a users access within the system.  All 'mutation' methods will return a new copy of this object
 */
public class UserAccessModel implements Serializable {

    private static final long serialVersionUID = 146622430139780914L;
    private Set<AccountId> accountIds = Sets.newHashSet(); //system defined set of accounts for the user
    private List<UserMapping> UserMappings = Lists.newArrayList(); //customers the user has access to
    private UserProfile userProfile;

    private UserMapping activeUser;         //active CustomerMapping

    public UserAccessModel() {
    }

    public UserAccessModel(Set<AccountId> accountIds, List<UserMapping> UserMappings, UserProfile userProfile) {
        this.accountIds.addAll(accountIds);
        this.UserMappings.addAll(UserMappings);
        this.userProfile = userProfile;
        if (this.UserMappings.size() > 0)
            this.activeUser = this.UserMappings.get(0);
    }

    public UserAccessModel copy(UserAccessModel other) {
        UserAccessModel result = new UserAccessModel();
        result.accountIds = Sets.newHashSet(other.accountIds);
        result.activeUser = other.activeUser;
        result.UserMappings = other.UserMappings;
        result.userProfile = other.userProfile;

        return result;
    }

    /**
     * returns a copy of this model filtered to the selected platform
     *
     * @param p
     * @return
     */
    public UserAccessModel filter(PlatformId p) {
        UserAccessModel result = new UserAccessModel();
        for (AccountId aid : this.accountIds) {
            if (aid.getPlatformId() == p) {
                result.accountIds.add(aid);
            }
        }

        result.activeUser = this.activeUser;
        result.UserMappings = this.UserMappings;
        result.userProfile = this.userProfile;

        return result;
    }

    /**
     * returns a copy of this object, with the new account added to full access.  Any shipto assignments will be removed for the passed account as well.
     *
     * @param aid
     * @return
     */
    public UserAccessModel addFull(AccountId aid) {
        UserAccessModel result = copy(this);
        result.accountIds.add(aid);
        return result;
    }

    public Set<AccountId> getAllAccountIds() {
        return Sets.newHashSet(this.accountIds);
    }

    public List<UserMapping> getUserMappings() {
        return UserMappings;
    }

    public UserProfile getUserProfile() {
        return userProfile;
    }

    public UserMapping getActiveUser() {
        return activeUser;
    }

    public Set<UserMapping> getAllUserMappings() {
        return Sets.newHashSet(this.UserMappings);
    }

    public UserMapping getActiveUserMapping() {
        return this.activeUser;
    }

    // returns true if successful
    public boolean setActiveUserMapping(String userName) {
        for (UserMapping userMapping : this.UserMappings) {
            if (userName.equals(userMapping.getUsername())) {
                this.activeUser = userMapping;
                return true;
            }
        }
        return false;
    }

    //Note: If we need to validate with UserName or Email id then need to get from UserProfile
    public boolean hasCustomerAccess(String userName) {
        for (UserMapping mapping : this.UserMappings) {
            if (userName.equals(mapping.getUsername())) {
                return true;
            }
        }
        return false;
    }


    public boolean isFullAccess(AccountId aid) {
        return this.accountIds.contains(aid);
    }

    public boolean isAnyAccess(AccountId aid) {
        return this.accountIds.contains(aid);
    }

    public Collection<PlatformId> getAccessiblePlatforms() {
        return Sets.newHashSet(PlatformId.SAP);    //TODO update when new Platforms are implemented
    }

    public boolean isFullAccessByAccount(Account account) {
        return this.accountIds.contains(account.getId());
    }

    public boolean isValid() {
        return !this.accountIds.isEmpty();
    }

    public String getDisplayString() {
        Set<AccountId> accounts = Sets.newTreeSet();
        for (AccountId aid : this.getAllAccountIds()) {
            accounts.add(aid);
        }
        String result = "";
        if (accounts.size() > 0) {
            result = "Pharma " + StringUtils.join(Lists.newArrayList(Iterables.limit(accounts, 5)), ", ");
        }
        return result;
    }

    @Override
    public String toString() {
        return this.getDisplayString();
    }

    // It can further extends if we need below methods
    public Collection<CollaborationTeam> getActiveTeams() {
        if (this.activeUser != null) {
            return null;
        }
        return Lists.newArrayList();
    }

    public Collection<Module> getModules() {
        if (this.activeUser != null)
            return this.activeUser.getModule();
        else
            return Lists.newArrayList();
    }

    public boolean canAccessModule(Module module) {
        if (this.activeUser != null)
            return this.activeUser.getModule().contains(module);
        else
            return false;
    }
}

