package com.mckesson.app.service;

import static org.apache.poi.ss.usermodel.CellType.BLANK;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.EntityManager;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import javafx.scene.control.Cell;
import main.java.com.mckesson.app.domain.FileUpload;
import main.java.com.mckesson.app.domain.customer.Customer;
import main.java.com.mckesson.app.misc.ErrorMessagesEnum;
import main.java.com.mckesson.app.repository.FileUploadRepository;
import main.java.com.mckesson.app.repository.customer.CustomerRepository;
import main.java.com.mckesson.app.service.admin.BlobStorageService;

@Service
@Transactional
public class FileUploadService {

    private static final Logger logger = LoggerFactory.getLogger(FileUploadService.class);

    private final FileUploadRepository fileUploadRepository;
    private final CustomerRepository customerRepository;
    private final BlobStorageService blobStorageService;
    private final EntityManager entityManager;


    @Autowired
    public FileUploadService(FileUploadRepository fileUploadRepository, CustomerRepository customerRepository, BlobStorageService blobStorageService, EntityManager entityManager) {
        this.fileUploadRepository = fileUploadRepository;
        this.customerRepository = customerRepository;
        this.blobStorageService = blobStorageService;
        this.entityManager = entityManager;
    }

    public List<ArrayList<String>> uploadFile(MultipartFile multipartFile, String UserId, String customerName,String uploadType) throws Exception {

        List<ArrayList<String>> uploadStatus = new ArrayList<>();
        List<Customer> customer = customerRepository.getCustomerByName(customerName);

        if(checkEmptyFile(multipartFile)){
            ArrayList<String> temp=new ArrayList<>();
            temp.add("ERROR");
            temp.add(ErrorMessagesEnum.valueOf("FILE_UPLOAD_NO_COLUMNS").getErrorMsg());
            uploadStatus.add(temp);
            return uploadStatus;
        } else {

            FileUpload fileUpload = new FileUpload();
            fileUpload.setUploadStatus("PENDING");
            fileUpload.setCreatedDy(UserId);
            fileUpload.setFileName(multipartFile.getOriginalFilename());
            fileUpload.setCreatedDateTime(new Date());
            fileUpload.setCustomerId(customer.get(0).getCustomerId());
            fileUpload.setUploadType(uploadType);

            insertORUpdateFileEntryCommit(fileUpload);
            Long loadFileId = fileUploadRepository.getLoadFileId(fileUpload.getFileName(), fileUpload.getCreatedDy(), fileUpload.getCustomerId());
            try {
                if (uploadType.equals("ACCOUNT_SEGMENTATION"))
                    uploadStatus = processAccountSegmentationFile(multipartFile, loadFileId, customer.get(0).getAmdmEraOwnrPartyId(), UserId, uploadType);
                else
                    uploadStatus = processNonMckessonPurchasesFile(multipartFile, loadFileId, customer.get(0).getCustomerId(), UserId, uploadType);
            } catch (Exception e) {
                fileUpload.setLoadFileId(loadFileId);
                fileUpload.setUploadStatus("Error");
                fileUpload.setUploadedDateTime(new Date());

                insertORUpdateFileEntry(fileUpload);

                logger.error("Unknown error occurred while uploading the data " + e);
                throw new Exception("Unknown error occurred while uploading the data" + loadFileId);
            }
            logger.info("Upload status in file upload service" + uploadStatus.get(0).get(0));
            if (uploadStatus.get(0).get(0).equals("SUCCESS")) {

                fileUpload.setLoadFileId(loadFileId);
                fileUpload.setUploadStatus("Uploaded");
                fileUpload.setUploadedDateTime(new Date());

                insertORUpdateFileEntry(fileUpload);
            } else {
                fileUpload.setLoadFileId(loadFileId);
                fileUpload.setUploadStatus("Error");
                fileUpload.setUploadedDateTime(new Date());

                insertORUpdateFileEntry(fileUpload);
            }
            return uploadStatus;
        }
    }

    private boolean checkEmptyFile(MultipartFile multipartFile) throws IOException {
        XSSFWorkbook workbook = new XSSFWorkbook(multipartFile.getInputStream());
        XSSFSheet spreadsheet = workbook.getSheetAt(0);
        int emptyRows=0,nonEmptyRows=0;
        for (Row row : spreadsheet) {
            if (isRowEmpty(row)) {
                emptyRows++;
            } else{
                nonEmptyRows++;
            }
        }
        return nonEmptyRows == 1 && emptyRows == 0;

    }

    private boolean checkAnyMandatoryEmpty(MultipartFile multipartFile, String uploadType) throws IOException {
        int mandatoryColumnsSize = 0,count=0;
        if (uploadType.equals("NON_MCKESSON_PURCHASES"))
            mandatoryColumnsSize=fileUploadRepository.getMandatoryColumns().size();

        int isRowContainsNullManValues;
        XSSFWorkbook workbook = new XSSFWorkbook(multipartFile.getInputStream());
        XSSFSheet spreadsheet = workbook.getSheetAt(0);
        for (Row row : spreadsheet) {
            isRowContainsNullManValues = row.getPhysicalNumberOfCells();
            if (mandatoryColumnsSize<=isRowContainsNullManValues)
                count=0;
            else
                count++;
        }
        return count == 0;

    }

    private static boolean isRowEmpty(Row row) {
        boolean isEmpty = true;
        DataFormatter dataFormatter = new DataFormatter();
        if (row != null) {
            for (Cell cell : row) {
                isEmpty = dataFormatter.formatCellValue(cell).trim().length() <= 0;
            }
        }
        return isEmpty;
    }

    private void insertORUpdateFileEntry(FileUpload fileUpload) {
        try {
            fileUploadRepository.saveAndFlush(fileUpload);
        } catch (Exception e) {
            logger.error("Unknown error occurred while updating the data " +" ---->"+ e);
        }
    }

    private void insertORUpdateFileEntryCommit(FileUpload fileUpload) {

        entityManager.createNativeQuery("INSERT INTO reporting_analytics.file_upload (upload_status, created_by, file_name, created_date_time, customer_id, upload_type) " +
                        " VALUES ( :1, :2, :3, :4, :5, :6)")
            .setParameter("1", fileUpload.getUploadStatus())
            .setParameter("2", fileUpload.getCreatedDy())
            .setParameter("3", fileUpload.getFileName())
            .setParameter("4", fileUpload.getCreatedDateTime())
            .setParameter("5", fileUpload.getCustomerId())
            .setParameter("6", fileUpload.getUploadType()).executeUpdate();
        try {
            entityManager.getTransaction().commit();
        } catch (Exception ignored) { }
    }

    private List<ArrayList<String>> processAccountSegmentationFile(MultipartFile multipartFile, Long loadFileId, String amdmEraOwnrPartyId, String userId, String uploadType) throws Exception {
        List<ArrayList<String>> errorMsgs = new ArrayList<>();
        ArrayList<String> columns = new ArrayList<>();
        columns.add("FACILITY");
        columns.add("ACCOUNT NUMBER");
        columns.add("ACCOUNT TYPE");
        columns.add("ACCOUNT FACILITY");
        columns.add("ACCOUNT ACCOUNT NUMBER");
        columns.add("ACCOUNT ACCOUNT TYPE");
        HashMap<String, Integer> columnsNums = new HashMap<>();

        XSSFWorkbook workbook = new XSSFWorkbook(multipartFile.getInputStream());
        XSSFSheet spreadsheet = workbook.getSheetAt(0);

        Row row1 = spreadsheet.getRow(0);
        Iterator<Cell> cellIterator = row1.cellIterator();
        while (cellIterator.hasNext()) {
            Cell cell = cellIterator.next();
            for (String column : columns) {
                if (column.equals(cell.getStringCellValue().toUpperCase().trim())) {
                    columnsNums.put(column, cell.getColumnIndex());
                }
            }
        }

        String result = checkHeaderValidation(columnsNums);
        logger.info(" Load starting for..... "+loadFileId);
        if (result.length() == 0) {
            HashMap<String, String> dataMap = new HashMap<>();
            List<String> dataList = new ArrayList<>();

            Row row2;
            for (int i = 1; i <= spreadsheet.getLastRowNum(); i++) {
                DataFormatter fmt = new DataFormatter();
                row2 = spreadsheet.getRow(i);
                if (!isRowEmpty(row2)) {
                    String accountFacility = columnsNums.containsKey("ACCOUNT FACILITY") ? row2.getCell(columnsNums.get("ACCOUNT FACILITY")).toString() : row2.getCell(columnsNums.get("FACILITY")).toString();
                    String accountType = columnsNums.containsKey("ACCOUNT ACCOUNT TYPE") ? row2.getCell(columnsNums.get("ACCOUNT ACCOUNT TYPE")).toString() : row2.getCell(columnsNums.get("ACCOUNT TYPE")).toString();
                    String accountNumber = columnsNums.containsKey("ACCOUNT ACCOUNT NUMBER") ? fmt.formatCellValue(row2.getCell(columnsNums.get("ACCOUNT ACCOUNT NUMBER"))) : fmt.formatCellValue(row2.getCell(columnsNums.get("ACCOUNT NUMBER")));
                    dataMap.put("account_id", String.format("%06.0f", Double.parseDouble(accountNumber)));
                    dataMap.put("account_type", accountType);
                    dataMap.put("facility", accountFacility);
                    dataMap.put("load_file_id", loadFileId.toString());
                    dataMap.put("uploaded_by", userId);
                    dataMap.put("uploaded_datetime", String.valueOf(new Date()));

                    // Validate that account number belongs to customer
                    if (customerRepository.checkAccountExists(amdmEraOwnrPartyId, accountNumber) == 1) {
                        ObjectMapper om = new ObjectMapper();
                        om.configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true);
                        String alphabetized = om.writeValueAsString(dataMap);
                        dataList.add(alphabetized);
                    } else {
                        ArrayList<String> tempErrors = new ArrayList<>();
                        String columnName = columnsNums.containsKey("ACCOUNT ACCOUNT NUMBER") ? "ACCOUNT ACCOUNT NUMBER" : "ACCOUNT NUMBER";
                        int col = columnsNums.get(columnName);
                        tempErrors.add(columnName);
                        tempErrors.add(accountNumber);
                        tempErrors.add("Customer does not have access to this ACCOUNT NUMBER");
                        tempErrors.add(String.valueOf(i + 1));
                        tempErrors.add(String.valueOf(col + 1));
                        errorMsgs.add(tempErrors);
                    }
                }
            }

            if(errorMsgs.size()>0) {
                return errorMsgs;
            }

            // Prettify JSON string
            Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
            JsonElement je = JsonParser.parseString(dataList.toString());
            String jsonString = gson.toJson(je);
            blobStorageService.putBlob(jsonString, uploadType);

            ArrayList<String> temp=new ArrayList<>();
            temp.add("SUCCESS");
            errorMsgs.add(temp);
            return errorMsgs;
        } else {
            ArrayList<String> temp=new ArrayList<>();
            temp.add(result);
            errorMsgs.add(temp);
            return errorMsgs;
        }
    }

    @Modifying
    private List<ArrayList<String>> processNonMckessonPurchasesFile(MultipartFile multipartFile, Long loadFileId, long customerId, String UserId, String uploadType) throws IOException {
        List<Object[]> xlColumns=getUploadFileTemplate();
        ArrayList<Object> manColumns = fileUploadRepository.getMandatoryColumns();
        ArrayList<Integer> columnsNums = new ArrayList<>();
        ArrayList<String> mandatoryColumns = new ArrayList<>();
        StringBuilder InvalidColumns = new StringBuilder();
        List<ArrayList<String>> errorMsgs = new ArrayList<>();

        DataFormatter fmt = new DataFormatter();

        XSSFWorkbook workbook = new XSSFWorkbook(multipartFile.getInputStream());
        XSSFSheet spreadsheet = workbook.getSheetAt(0);

        Row row1 = spreadsheet.getRow(0);
        if(row1==null){
            ArrayList<String> errorMsg = new ArrayList<>();
            errorMsg.add("ERROR");
            errorMsg.add(ErrorMessagesEnum.valueOf("FILE_UPLOAD_NO_COLUMNS").getErrorMsg());
            errorMsgs.add(errorMsg);
            return errorMsgs;
        }

        Iterator<Cell> cellIterator = row1.cellIterator();
        while (cellIterator.hasNext()) {
            Cell cell = cellIterator.next();
            if (cell != null) {
                if (cell.getCellType() == BLANK) {
                } else {
                    if (fileUploadRepository.checkInvalidColumns(cell.getStringCellValue()) == 0) {  // check how many invalid columns are there in uploaded file
                        InvalidColumns.append(cell.getStringCellValue()).append(",");
                    }
                    for (Object[] ob : xlColumns) {
                        if (ob[0].toString().toUpperCase().equals(cell.getStringCellValue().toUpperCase().trim())) {
                            columnsNums.add(cell.getColumnIndex());
                            if (ob[3].toString().equals("Y")) { // check how many mandatory columns are there in uploaded file
                                mandatoryColumns.add(ob[0].toString().toUpperCase());
                            }
                        }
                    }
                }
            }
        }

        if(!InvalidColumns.toString().equals("")){
            ArrayList<String> errorMsg = new ArrayList<>();
            errorMsg.add("INVALID_ERROR");
            errorMsg.add(ErrorMessagesEnum.valueOf("FILE_UPLOAD_INVALID_COLUMN_MISSING").getErrorMsg());
            errorMsg.add(InvalidColumns.toString());
            errorMsgs.add(errorMsg);
            return errorMsgs;
        }
        if(fileUploadRepository.checkMandatoryColumnsCount()!=mandatoryColumns.size()){
            StringBuilder missingColumns = new StringBuilder();

            HashSet<String> map = new HashSet<>();
            for (Object i : mandatoryColumns)
                map.add(i.toString().toUpperCase());
            for (Object i : manColumns) {
                if (!map.contains(i.toString().toUpperCase())){
                    missingColumns.append(i.toString()).append(",");
                }
            }
            ArrayList<String> errorMsg = new ArrayList<>();
            errorMsg.add("MANDATORY_ERROR");
            errorMsg.add(ErrorMessagesEnum.valueOf("FILE_UPLOAD_MANDATORY_COLUMN_MISSING").getErrorMsg());
            errorMsg.add(missingColumns.toString());
            errorMsgs.add(errorMsg);
            return errorMsgs;
        }

        logger.info(" Load starting for..... "+loadFileId);
        Row row2;
        List<String> itemNumbersInFile=new ArrayList<>();
        List<String> accountNumbersInFile=new ArrayList<>();

        List<String> validItemNumbersInFile;
        List<String> validAccountNumbersInFile;
        List<String> validAccountNumbersForCustomerInFile;

        for (int i = 1; i <= spreadsheet.getLastRowNum(); i++) {
            row2 = spreadsheet.getRow(i);
            if (!isRowEmpty(row2)) {
                for (int j = 0; j < columnsNums.size(); j++) {
                    String tempCellValue;
                    if (row2.getCell(columnsNums.get(j)) == null) {
                        tempCellValue = "";
                    } else {
                        tempCellValue = fmt.formatCellValue(row2.getCell(columnsNums.get(j)));
                    }
                    if(row1.getCell(j).toString().trim().equalsIgnoreCase("ITEM NUMBER")){
                        itemNumbersInFile.add(tempCellValue);
                    }
                    if(row1.getCell(j).toString().trim().equalsIgnoreCase("ACCOUNT NUMBER")){
                        accountNumbersInFile.add(tempCellValue);
                    }
                }
            }
        }
        validItemNumbersInFile=fileUploadRepository.getValidItemNumbers(itemNumbersInFile);
        validAccountNumbersInFile=fileUploadRepository.getValidAccounts(accountNumbersInFile);
        validAccountNumbersForCustomerInFile=fileUploadRepository.getValidAccountsForCustomer(accountNumbersInFile, customerId);


        for (int i = 1; i <= spreadsheet.getLastRowNum(); i++) {
            row2 = spreadsheet.getRow(i);
            if (!isRowEmpty(row2)) {

                boolean ItemNumberFlag=false, VendorItemNumberFlag=false;
                int ItemNumberRow=0, ItemNumberCol=0, VendorItemNumberRow=0, VendorItemNumberCol=0;

                for (int j = 0; j < columnsNums.size(); j++) {
                    String tempCellValue = "";
                    if (row2.getCell(columnsNums.get(j)) == null) {
                        tempCellValue = "";
                    } else {
                        tempCellValue = fmt.formatCellValue(row2.getCell(columnsNums.get(j)));
                    }
                    ArrayList<String> temp = runValidationChecks(validItemNumbersInFile, validAccountNumbersInFile, validAccountNumbersForCustomerInFile, row1.getCell(j).toString().trim().toUpperCase(), tempCellValue, i + 1, j + 1, UserId, customerId, mandatoryColumns);

                    if(row1.getCell(j).toString().trim().equalsIgnoreCase("ITEM NUMBER")){
                        if(tempCellValue==null || tempCellValue.equals("")){
                            ItemNumberFlag = true;
                            ItemNumberRow = i + 1;
                            ItemNumberCol = j + 1;
                        }
                    }

                    if(row1.getCell(j).toString().trim().equalsIgnoreCase("VENDOR ITEM NUMBER")){
                        if(tempCellValue==null || tempCellValue.equals("")){
                            VendorItemNumberFlag=true;
                            VendorItemNumberRow = i + 1;
                            VendorItemNumberCol = j + 1;
                        }
                    }

                    if (temp.size() > 0)
                        errorMsgs.add(temp);

                    if(VendorItemNumberFlag && ItemNumberFlag){
                        ArrayList<String> temp2=new ArrayList<>();
                        ArrayList<String> temp3=new ArrayList<>();
                        temp2.add("ITEM NUMBER");
                        temp2.add(tempCellValue);
                        temp2.add("Item Number and Vendor Item Number should not be blank.");
                        temp2.add(String.valueOf(ItemNumberRow));
                        temp2.add(String.valueOf(ItemNumberCol));
                        errorMsgs.add(temp2);

                        temp3.add("VENDOR ITEM NUMBER");
                        temp3.add(tempCellValue);
                        temp3.add("Vendor Item Number and Item Number should not be blank.");
                        temp3.add(String.valueOf(VendorItemNumberRow));
                        temp3.add(String.valueOf(VendorItemNumberCol));
                        errorMsgs.add(temp3);

                        ItemNumberFlag=false;
                        VendorItemNumberFlag=false;
                    }
                }
            }
        }

        if(errorMsgs.size()>0){
           return errorMsgs;
       } else {
            try {
                ArrayList<HashMap<String, String>> dataMap = new ArrayList<>();
                XSSFRow row0 = spreadsheet.getRow(0);
                for (int i = 1; i <= spreadsheet.getLastRowNum(); i++) {
                    row2 = spreadsheet.getRow(i);
                    HashMap<String, String> data1 = new HashMap<>();

                    if (!isRowEmpty(row2)) {
                        for (int j = 0; j < columnsNums.size(); j++) {
                            data1.put(fmt.formatCellValue(row0.getCell(columnsNums.get(j))), fmt.formatCellValue(row2.getCell(columnsNums.get(j))));
                        }
                        data1.put("load_file_id", loadFileId.toString());
                        data1.put("uploaded_by", UserId);
                        data1.put("uploaded_datetime", String.valueOf(new Date()));
                        data1.put("customer_id", String.valueOf(customerId));
                        dataMap.add(data1);

                    }
                }
                List<JSONObject> jsonObj = new ArrayList<>();

                for (HashMap<String, String> data : dataMap) {
                    JSONObject obj = new JSONObject(data);
                    jsonObj.add(obj);
                }

                JSONArray jsonArray = new JSONArray(jsonObj);
                List<String> dataList = new ArrayList<>();
                List<Object[]> vendorPurchasesMap = fileUploadRepository.getOtherVendorsMappingColumns();

                // Parse each JSONObject and format
                logger.info("Formatting non-McKesson JSON");
                for (Object obj : jsonArray) {
                    ObjectMapper om = new ObjectMapper();
                    Map<String, Object> map = om.readValue(obj.toString(), HashMap.class);

                    // Replace keys with sql names
                    for (Object[] col : vendorPurchasesMap) {
                        if (map.get(col[1]) != null) {
                            map.put((String) col[0], map.remove(col[1]));
                        }
                    }
                    // Alphabetize keys
                    om.configure(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS, true);
                    String alphabetized = om.writeValueAsString(map);
                    dataList.add(alphabetized);
                }
                // Prettify JSON string
                Gson gson = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
                JsonElement je = JsonParser.parseString(dataList.toString());
                String jsonString = gson.toJson(je);

                // Upload to blob storage
                logger.info("Uploading to azure storage");
                blobStorageService.putBlob(jsonString, uploadType);
            } catch (Exception e) {
                logger.error("Unknown error while processing file " + e);
            }

            ArrayList<String> temp=new ArrayList<>();
            temp.add("SUCCESS");
            errorMsgs.add(temp);
            return errorMsgs;
        }
    }

    // Check if individuals methods imporve...?
    private ArrayList<String> runValidationChecks(List<String> validItemNumbersInFile, List<String> validAccountNumbersInFile, List<String> validAccountNumbersForCustomerInFile,String columnName, String columnValue, int row, int col, String userId, long customerId, ArrayList<String> mandatoryColumns) {
        ArrayList<String> errorMsg=new ArrayList<>();
        if(mandatoryColumns.contains(columnName.toUpperCase())){
            if(columnValue==null || columnValue.equals("")) {
                errorMsg.add(columnName);
                errorMsg.add(columnValue);
                errorMsg.add("Required field value is blank");
                errorMsg.add(String.valueOf(row));
                errorMsg.add(String.valueOf(col));
                return errorMsg;
            }
        }

          if(columnValue==null || columnValue.equals(""))
              return errorMsg;
        if(columnName.equalsIgnoreCase("PRICE PER PACKAGE") ||columnName.equalsIgnoreCase("QUANTITY") || columnName.equalsIgnoreCase("RECEIVED QUANTITY") || columnName.equalsIgnoreCase("EXTENDED PRICE")){
            Pattern p = Pattern.compile("[$,.,0-9]+");
            Matcher m = p.matcher(columnValue);
            if (!m.matches()) {  // errorMsg = columnName+": Invalid number format and ColumnValue is "+columnValue;
                errorMsg.add(columnName);
                errorMsg.add(columnValue);
                errorMsg.add("Invalid number format");
                errorMsg.add(String.valueOf(row));
                errorMsg.add(String.valueOf(col));
            }

        } else if (columnName.equalsIgnoreCase("DATE RECEIVED") || columnName.equalsIgnoreCase("PURCHASE DATE")){

            if (!validateDate(columnValue)){
                errorMsg.add(columnName);
                errorMsg.add(columnValue);
                errorMsg.add("Invalid date format");
                errorMsg.add(String.valueOf(row));
                errorMsg.add(String.valueOf(col));
            }
               // errorMsg = columnName+":  Invalid date format and ColumnValue is "+columnValue;
        } else {
            switch (columnName) {
                case "ACCOUNT NUMBER":
                    if (!columnValue.trim().toUpperCase().startsWith("DP")) {
                        // First check if the account exists
                        //Long count=  fileUploadRepository.validateMcKessonAccount(columnValue);
                        boolean count =validAccountNumbersInFile.stream().anyMatch(s -> s.contains(columnValue));
                        if (!count) {
                            errorMsg.add(columnName);
                            errorMsg.add(columnValue);
                            errorMsg.add("ACCOUNT NUMBER not started with DP Or Invalid ACCOUNT NUMBER.");
                            errorMsg.add(String.valueOf(row));
                            errorMsg.add(String.valueOf(col));
                        }
                        else {
                            // Second, check if existing account belongs to customer
                            //Long accountIsValid = fileUploadRepository.validateMcKessonAccountByCustomer(columnValue, customerId);
                            boolean accountIsValid =validAccountNumbersForCustomerInFile.stream().anyMatch(s -> s.contains(columnValue));
                            if (!accountIsValid) {
                                errorMsg.add(columnName);
                                errorMsg.add(columnValue);
                                errorMsg.add("Customer does not have access to this ACCOUNT NUMBER");
                                errorMsg.add(String.valueOf(row));
                                errorMsg.add(String.valueOf(col));
                            }
                        }
                    }
                    break;
                case "NDC":
                    if (columnValue.length() != 11){
                        errorMsg.add(columnName);
                        errorMsg.add(columnValue);
                        errorMsg.add("NDC value is not 11 digits");
                        errorMsg.add(String.valueOf(row));
                        errorMsg.add(String.valueOf(col));
                    }
                       // errorMsg = " NDC value is not 11 digits and ColumnValue is "+columnValue;
                    break;
                case "UPC":
                    if (columnValue.length() > 11){
                        errorMsg.add(columnName);
                        errorMsg.add(columnValue);
                        errorMsg.add("UPC value is max 11 digits");
                        errorMsg.add(String.valueOf(row));
                        errorMsg.add(String.valueOf(col));
                    }
                       // errorMsg = " UPC value is max 11 digits and ColumnValue is "+columnValue;
                    break;
                case "ITEM NUMBER":
                    // validate against McKesson item number
                        boolean count =validItemNumbersInFile.stream().anyMatch(s -> s.contains(columnValue));//fileUploadRepository.validateItemNumber(columnValue);
                        if (!count) {
                            errorMsg.add(columnName);
                            errorMsg.add(columnValue);
                            errorMsg.add("Invalid McKesson item number");
                            errorMsg.add(String.valueOf(row));
                            errorMsg.add(String.valueOf(col));
                        }
                    break;
                case "BRAND/GENERIC/OTC":
                    switch (columnValue) {
                        case "B":
                        case "O":
                        case "G":
                        case "b":
                        case "o":
                        case "g":
                            // validate Product Category
                            break;
                        default:
                            errorMsg.add(columnName);
                            errorMsg.add(columnValue);
                            errorMsg.add("Invalid Product Category (Brand, generic, OTC (B,G, O))");
                            errorMsg.add(String.valueOf(row));
                            errorMsg.add(String.valueOf(col));
                    }
                    /*if (!columnValue.equalsIgnoreCase("B")){
                        errorMsg.add(columnName);
                        errorMsg.add(columnValue);
                        errorMsg.add("Invalid Product Category (Brand, generic, OTC (B,G, O))");
                        errorMsg.add(String.valueOf(row));
                        errorMsg.add(String.valueOf(col));
                    } else if(!columnValue.equalsIgnoreCase("O")){
                        errorMsg.add(columnName);
                        errorMsg.add(columnValue);
                        errorMsg.add("Invalid Product Category (Brand, generic, OTC (B,G, O))");
                        errorMsg.add(String.valueOf(row));
                        errorMsg.add(String.valueOf(col));
                    } else if (!columnValue.equalsIgnoreCase("G")){
                        errorMsg.add(columnName);
                        errorMsg.add(columnValue);
                        errorMsg.add("Invalid Product Category (Brand, generic, OTC (B,G, O))");
                        errorMsg.add(String.valueOf(row));
                        errorMsg.add(String.valueOf(col));
                    }*/
                      //  errorMsg = " Invalid Product Category (Brand, generic, OTC (B,G, O)) and ColumnValue is "+columnValue;
                    break;
                case "LABEL NAME":
                    //get label name from NDC, if doesn’t exist populate
                    break;
            }
        }
        return errorMsg;
    }

    public static boolean validateDate(String strDate) {
        if (strDate.trim().equals("")) {
            return true;
        } else {

            SimpleDateFormat sdfrmt = new SimpleDateFormat("MM/dd/yyyy");
            sdfrmt.setLenient(false);

            try {
                Date javaDate = sdfrmt.parse(strDate);
            } catch (ParseException e) {
                return false;
            }
            return true;
        }
    }

    private String checkHeaderValidation(HashMap<String, Integer> columnsNums) {
        if (columnsNums.size() == 0)
            return ErrorMessagesEnum.valueOf("FILE_UPLOAD_NO_COLUMNS").getErrorMsg();
        else if (columnsNums.size() < 3)
            return ErrorMessagesEnum.valueOf("FILE_UPLOAD_MISSING").getErrorMsg();
        else if (columnsNums.size() > 3)
            return ErrorMessagesEnum.valueOf("FILE_UPLOAD_DUPLICATE").getErrorMsg();
        else
            return "";
    }

    public List<Object[]> getUploadFileTemplate() {
          return fileUploadRepository.getUploadFileTemplate();
    }

    public List<Object[]> getUploadedFilesInfo(String customerName, String userId) {
        return fileUploadRepository.getUploadedFilesInfo(customerName, userId);
    }

    public void deleteFileData(Long loadFileId) {
        FileUpload fileUpload = new FileUpload();

        try {
            fileUploadRepository.deleteFileData(loadFileId);
            fileUploadRepository.deleteFileInfo(loadFileId);
        }catch (Exception e) {
            fileUpload.setLoadFileId(loadFileId);
            fileUpload.setUploadStatus("Delete Error");
            fileUpload.setUploadedDateTime(new Date());
            insertORUpdateFileEntry(fileUpload);
            logger.error("Unknown error occurred while deleting the data loadFileId"+loadFileId +" ---->"+ e);
        }
    }
}




