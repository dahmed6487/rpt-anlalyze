package com.mckesson.app.web.rest.domain;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javafx.scene.control.Cell;
import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.service.FileUploadService;
import main.java.com.mckesson.app.util.UserAuthentication;

@RestController
@RequestMapping("/api/file")
public class FileUploadController {
    private static final Logger logger = LoggerFactory.getLogger(FileUploadService.class);
    private final UserAuthentication userAuthentication;
    private final FileUploadService fileUploadService;

    @Autowired
    public FileUploadController(UserAuthentication userAuthentication, FileUploadService fileUploadService) {
        this.userAuthentication = userAuthentication;
        this.fileUploadService = fileUploadService;
    }
   @PostMapping(value = "/upload",consumes = "multipart/form-data", produces = {"application/json" })
    public List<ArrayList<String>> uploadFile(@RequestParam("file") MultipartFile multipartFile, @RequestParam("customerName") String customerName, @RequestParam("uploadType") String uploadType) throws Exception {
       List<ArrayList<String>> uploadResponse = fileUploadService.uploadFile(multipartFile,userAuthentication.getLoggedInUser().getUsername(),customerName,uploadType);
       logger.info("Response from upload " + uploadResponse.size() + "upload text " + uploadResponse.get(0).get(0));
       return uploadResponse;
    }

    @GetMapping(value = "/download/non-mck-purchases/template")
    public void getUploadFileTemplate(final HttpServletResponse response) throws IOException {
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        List<Object[]> xlColumns=fileUploadService.getUploadFileTemplate();

        response.addHeader("Content-disposition", "attachment; filename=NonMckessonPurchases_Template.xlsx");
        response.setContentType("application/vnd.ms-excel");

        Workbook workbook = new XSSFWorkbook();
        workbook.createSheet("Template");
        workbook.setSheetName(0, "Template");
        Sheet sheet = workbook.getSheetAt(0);

        CellStyle cellStyle = workbook.createCellStyle();
        Font font = sheet.getWorkbook().createFont();
        font.setBold(true);
        font.setColor(Font.COLOR_RED);
        cellStyle.setFont(font);
        int rowIndex = 0;
        int columnIndex = 0;
        sheet.createRow(rowIndex);
        for (Object[] ob : xlColumns){
            Cell cell = sheet.getRow(rowIndex).createCell(columnIndex);
            cell.setCellValue((String)ob[0]);
            if(ob[3].equals('Y'))
            cell.setCellStyle(cellStyle);
            sheet.autoSizeColumn(cell.getColumnIndex());
            columnIndex++;
        }

        workbook.createSheet("Descriptions");
        workbook.setSheetName(1, "Descriptions");
        Sheet descriptionSheet = workbook.getSheetAt(1);
        descriptionSheet.createRow(0);
        descriptionSheet.getRow(0).createCell(0).setCellValue("Field");
        Cell fieldCell = descriptionSheet.getRow(0).createCell(0);
        fieldCell.setCellValue("Field");
        Cell descriptionCell = descriptionSheet.getRow(0).createCell(1);
        descriptionCell.setCellValue("Description");
        CellStyle paragraph = workbook.createCellStyle();
        paragraph.setWrapText(true);
        descriptionSheet.setColumnWidth(1, 70*256);
        rowIndex = 1;
        for (Object[] ob : xlColumns){
            descriptionSheet.createRow(rowIndex);
            Cell excelColumnCell = descriptionSheet.getRow(rowIndex).createCell(0);
            excelColumnCell.setCellValue((String)ob[0]);
            if(ob[3].equals('Y'))
                excelColumnCell.setCellStyle(cellStyle);
            descriptionSheet.autoSizeColumn(excelColumnCell.getColumnIndex());
            Cell description = descriptionSheet.getRow(rowIndex).createCell(1);
            description.setCellValue((String)ob[2]);
            description.setCellStyle(paragraph);
            rowIndex++;
        }

        workbook.write(response.getOutputStream());
        response.flushBuffer();
    }

    @GetMapping(value = "get/uploaded-files-info/{customerName}")
    public List<Object[]>  getUploadedFilesInfo(@PathVariable String customerName) {
        return fileUploadService.getUploadedFilesInfo(customerName, userAuthentication.getLoggedInUser().getUsername());
    }

    @DeleteMapping(value = "delete/file/{loadFileId}")
    public ResponseEntity deleteFileData(@PathVariable Long loadFileId) {
        fileUploadService.deleteFileData(loadFileId);
        return new ResponseEntity(HttpStatus.OK);
    }
}

