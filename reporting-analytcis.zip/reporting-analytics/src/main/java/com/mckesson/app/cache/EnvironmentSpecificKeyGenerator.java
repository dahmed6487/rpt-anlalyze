package com.mckesson.app.cache;

import java.lang.reflect.Method;
import java.util.Arrays;

import javax.annotation.Nonnull;
import javax.crypto.KeyGenerator;
import javax.inject.Inject;

import org.omg.CORBA.Environment;
import org.springframework.stereotype.Component;

import main.java.com.mckesson.app.util.StringUtils;

/**
 * A {@link org.springframework.cache.annotation.Cacheable} {@link KeyGenerator} that takes the Spring environment into account
 * when creating the keys, to support multiple environments being able to utilize the same backing store for cache.
 */
@Component("EnvironmentSpecificKeyGenerator")
public class EnvironmentSpecificKeyGenerator implements KeyGenerator {
    public static final String NAME = "EnvironmentSpecificKeyGenerator";

    private final Environment environment;

    @Inject
    public EnvironmentSpecificKeyGenerator(Environment environment) {
        this.environment = environment;
    }

    /**
     * Generates an environment-specific key for a cache.
     */
    @Override
    @Nonnull
    public Object generate(Object target, Method method, @Nonnull Object... params) {
        return target.getClass().getSimpleName()
                + "_" + method.getName() + "_" + Arrays.toString(environment.getActiveProfiles())
                + "_" + StringUtils.arrayToDelimitedString(params, "_");
    }
}
