package com.mckesson.app.domain.customer;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Where;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "security_group")
@Where(clause = "deleted_date is null")
public class SecurityGroup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "native")
    @Column(name = "security_group_id")
    private Long securityGroupId;
    @Column(name = "platform")
    private String platformId;
    private String name;
    @Column(name = "description")
    private String description;
    @Column(name = "customer_id")
    private Long customerId;
    @Column(name = "external_id")
    private Long externalId;
    @Column(name = "created_by")
    private String createdBy;
    @Column(name = "created_date")
    private Date createdDate;
    @Column(name = "updated_by")
    private String updatedBy;
    @Column(name = "updated_date")
    private Date updatedDate;
    @Column(name = "deleted_by")
    private String deletedBy;
    @Column(name = "deleted_date")
    private Date deletedDate;

    public SecurityGroup() {
    }

    @ManyToMany(mappedBy = "securityGroup")
    @JsonIgnore
    private Collection<UserMapping> userMappingSecurityGroup;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", insertable = false, updatable = false)
    private Customer customerSecurityGroup;

    @OneToMany(mappedBy = "securityGroup")
    @JsonIgnore
    private Collection<SecurityGroupAccounts> securityGroupAccounts;

    public Customer getCustomerSecurityGroup() {
        return customerSecurityGroup;
    }

    public void setCustomerSecurityGroup(Customer customerSecurityGroup) {
        this.customerSecurityGroup = customerSecurityGroup;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getSecurityGroupId() {
        return securityGroupId;
    }

    public void setSecurityGroupId(Long securityGroupId) {
        this.securityGroupId = securityGroupId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Collection<UserMapping> getUserMappingSecurityGroup() {
        return userMappingSecurityGroup;
    }

    public void setUserMappingSecurityGroup(Collection<UserMapping> userMappingSecurityGroup) {
        this.userMappingSecurityGroup = userMappingSecurityGroup;
    }

    public Collection<SecurityGroupAccounts> getSecurityGroupAccounts() {
        return securityGroupAccounts;
    }

    public void setSecurityGroupAccounts(Collection<SecurityGroupAccounts> securityGroupAccounts) {
        this.securityGroupAccounts = securityGroupAccounts;
    }

    public String getPlatformId() {
        return platformId;
    }

    public void setPlatformId(String platformId) {
        this.platformId = platformId;
    }

    public Long getExternalId() {
        return externalId;
    }

    public void setExternalId(Long externalId) {
        this.externalId = externalId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getDeletedBy() {
        return deletedBy;
    }

    public void setDeletedBy(String deletedBy) {
        this.deletedBy = deletedBy;
    }

    public Date getDeletedDate() {
        return deletedDate;
    }

    public void setDeletedDate(Date deletedDate) {
        this.deletedDate = deletedDate;
    }

}
