package com.mckesson.app.service.looker.config;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "exploreqids")
public class QidConfiguration {
    private Map<String, String> purchases;

    public Map<String, String> getPurchases() {
        return purchases;
    }

    public void setPurchases(Map<String, String> purchases) {
        this.purchases = purchases;
    }
}
