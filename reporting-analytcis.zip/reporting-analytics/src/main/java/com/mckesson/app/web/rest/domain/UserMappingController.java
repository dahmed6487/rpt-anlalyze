package com.mckesson.app.web.rest.domain;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import main.java.com.mckesson.app.domain.customer.UserMapping;
import main.java.com.mckesson.app.service.customer.UserMappingService;

/**
 * Class used to drive UserMapping operations for data display on Admin/Domain screen
 */
@RestController
@RequestMapping("/api/user-mapping")
public class UserMappingController {

    private final UserMappingService userMappingService;

    @Autowired
    public UserMappingController(UserMappingService userMappingService) {
        this.userMappingService = userMappingService;
    }

    /**
     * @return
     */
    @GetMapping("/get")
    public List<UserMapping> getUserMapping() {
        return userMappingService.getUserMapping();
    }

    @GetMapping("/principal")
    public Object getPrincipal() {
        return SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    }

    /**
     * This Method updates UserMapping and
     *
     * @param List of userMapping
     * @return List of userMapping
     */
    @PostMapping(value = "/update")
    public List<UserMapping> updateUserMapping(@RequestBody List<UserMapping> userMapping) {
        return userMappingService.updateUserMapping(userMapping);
    }

    /**
     * Delete from user_map_collab_team_relation
     * Delete from user_map_module_relation
     * Delete from user_map_security_group_relation
     * and Update the Delete date in user_mapping
     *
     * @param userMapping
     * @return ResponseEntity
     */
    @PostMapping("/delete")
    public ResponseEntity<String> deleteUserMapping(@RequestBody List<UserMapping> userMapping) {
        return userMappingService.deleteUserMapping(userMapping);
    }

    /**
     * Insert mapping into UserMap Teams & Module
     * Input should contain mappingType(Team or Module) and UserMapping and collaborationTeamId or moduleId
     *
     * @param map
     * @return
     */
    @PostMapping("/insert/relation")
    public ResponseEntity<String> insertOrUpdateRelation(@RequestBody Map<String, String> map) {
        return userMappingService.insertOrUpdateRelation(map);
    }

    @PutMapping("/soft-delete/team")
    public ResponseEntity<String> softDeleteUserFromTeam(@RequestParam String userId, @RequestParam String teamId) {
        boolean softDeleted = userMappingService.softDeleteUserFromTeam(userId, teamId);
        if (softDeleted) {
            return new ResponseEntity<>(HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    /**
     * Delete mapping UserMap Module
     *
     * @param list
     * @return
     */
    @PostMapping("/delete/module/relation")
    public ResponseEntity<String> deleteRelationModuleById(@RequestBody List<Integer> list) {
        return userMappingService.deleteModuleRelationById(list);
    }

    /**
     * Delete mapping UserMap SecurityGroup
     *
     * @param list
     * @return
     */
    @PostMapping("/delete/security/relation")
    public ResponseEntity<String> deleteSecurityGroupRelationById(@RequestBody List<Integer> list) {
        return userMappingService.deleteSecurityGroupRelationById(list);
    }
/*
*
   7.Update Teams Mapping into Customer
   8.Update Groups mapping
   9.Update Module mapping
* */


}
