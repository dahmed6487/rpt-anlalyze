package com.mckesson.app.repository.admin;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import main.java.com.mckesson.app.domain.admin.Module;

public interface ModuleRepository extends JpaRepository<Module, Long>, JpaSpecificationExecutor<Module> {

    @Query(value = "select * from (select distinct t1.* from module t1 LEFT OUTER JOIN module t2" +
            " on t2.parent_id=t1.module_id and t2.module_type=t1.module_type ) t where t.module_type='folder'  and parent_id=?1", nativeQuery = true)
    List<Module> getModuleForIds(Long moduleId);

    @Transactional
    @Modifying
    @Query(value = "delete t from collab_team_module_relation t where t.module_id in ?1 ", nativeQuery = true)
    void deleteRelation(List<Long> list);

    @Transactional
    @Modifying
    @Query("update #{#entityName} t set t.deletedDate= ?1 where t.moduleId in ?2 ")
    void inActive(Date deletedDate, List<Long> list);

    @Transactional
    @Modifying
    @Query(value = "update module t set  deleted_date=null where t.module_id in ?1 ", nativeQuery = true)
    void active(List<Long> list);

    @Query(value = "select module_id from customer_module_relation where customer_id=?1", nativeQuery = true)
    List<BigInteger> findByCustomerId(long customerId);

    @Query(value = "select m.* from solutions s, module m where s.module_id=m.module_id and m.module_id=?1", nativeQuery = true)
    Optional<Module> findByModuleId(long moduleId);

    Optional<Module> findByTitleIgnoreCase(String title);

    @Query(value = "select m.* from module m,solutions s where m.module_id=s.module_id and m.module_type=?1 " +
            "union select * from module where  module_type!='canned report' and module_type=?1",nativeQuery = true)
    List<Module> findByModuleType(String moduleType);

    @Query(value = "SELECT COUNT(*) FROM customer_module_relation WHERE customer_id = ?1 AND module_id = ?2", nativeQuery = true)
    int countRecordsCustomerModuleRelationByCustomerIdAndModuleId(long customerId, long moduleId);

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM customer_module_relation WHERE customer_id = ?1 AND module_id = ?2", nativeQuery = true)
    int removeCustomerModuleRelation(long customerId, long moduleId);

    @Query(value = "SELECT COUNT(*) FROM collab_team_module_relation WHERE collaboration_team_id = ?1 AND module_id = ?2", nativeQuery = true)
    int countRecordsTeamModuleRelationByTeamIdAndModuleId(long teamId, long moduleId);

    @Transactional
    @Modifying
    @Query(value = "INSERT INTO collab_team_module_relation (collaboration_team_id, module_id) VALUES (?1, ?2)", nativeQuery = true)
    int saveTeamModuleRelation(long teamId, long moduleId);

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM collab_team_module_relation WHERE collaboration_team_id = ?1 AND module_id = ?2", nativeQuery = true)
    int removeTeamModuleRelation(long teamId, long moduleId);

    @Query(value = "select * from module where external_id=?1", nativeQuery = true)
    Optional<Module> findByFolderId(String folderId);

    @Query(value = "select distinct m.title from customer_module_relation cmr,customer cs,module m where cs.customer_id=cmr.customer_id and m.module_id=cmr.module_id and amdm_era_ownr_party_id=?1 ", nativeQuery = true)
    ArrayList<String> getModulesForCustomer(String commonEntityId);

    @Query(value = "select distinct m.title from collab_team_module_relation ctr,module m where m.module_id=ctr.module_id and collaboration_team_id=?1", nativeQuery = true)
    ArrayList<String> getModulesForTeam(Long teamId);

    @Query(value = "select distinct title from  module where  module_type='canned report' and external_id is not null and platform='looker'", nativeQuery = true)
    ArrayList<String> getModules();

    @Query(value = "select * from  module m, customer_module_relation cmr where  module_type='canned report' and external_id is not null and platform='looker'\n" +
            " and m.module_id=cmr.module_id and cmr.customer_id in (select customer_id from customer where common_entity_name=?1)", nativeQuery = true)
    List<Module> getCustomerModule(String customerName);

    @Query(value = "select * from  module m, customer_module_relation cmr where  module_type='canned report' and external_id is not null and platform='looker'\n" +
            " and m.module_id=cmr.module_id and cmr.customer_id=?1", nativeQuery = true)
    List<Module> getCustomerModulesById(String customerId);

    @Query(value = "select distinct m.title from customer_module_relation cmr,customer cs,module m ,solutions s where m.module_id=s.module_id and cs.customer_id=cmr.customer_id and m.module_id=cmr.module_id and amdm_era_ownr_party_id=?1 and m.module_type=?2", nativeQuery = true)
    ArrayList<String> getModulesForCustomer(String commonEntityId, String moduleType);

    @Query(value = "select distinct title from module where module_type='explore' and platform='ERA'", nativeQuery = true)
    ArrayList<String> getExplores();

    @Query(value = "select m.* from  module m, customer_module_relation cmr where  module_type='explore' and platform='ERA'\n" +
            " and m.module_id=cmr.module_id and cmr.customer_id in (select customer_id from customer where common_entity_name=?1)", nativeQuery = true)
    List<Module> getExploresByCustomer(String customerName);

}
