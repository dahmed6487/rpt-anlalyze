package com.mckesson.app.util;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import main.java.com.mckesson.app.auth.user.ReportUser;

@Component
public class UserAuthentication {
    public ReportUser getLoggedInUser() {
        if (SecurityContextHolder.getContext().getAuthentication().isAuthenticated()) {
            boolean hasUserRole = SecurityContextHolder.getContext().getAuthentication().getAuthorities().stream()
                    .anyMatch(r -> r.getAuthority().equals(ReportUser.USER));
            if (hasUserRole) {
                return (ReportUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            } else {
                return null;
            }
        } else {
            return null;
        }
    }
}