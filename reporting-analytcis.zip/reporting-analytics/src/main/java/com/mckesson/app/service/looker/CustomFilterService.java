package com.mckesson.app.service.looker;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;

import main.java.com.mckesson.app.domain.looker.CustomFilter;
import main.java.com.mckesson.app.domain.looker.FilterCriteria;
import main.java.com.mckesson.app.repository.looker.CustomFilterProjection;
import main.java.com.mckesson.app.vo.CustomFilterCriteriaSummary;
import main.java.com.mckesson.app.vo.CustomFilterGroupSummary;
import main.java.com.mckesson.app.vo.CustomFilterSummary;

/**
 * Responsible for management of 'custom groups' which support the ability to apply 'custom dimensions'
 * for explores. Lookers provides the ability to 'explore' data based on a model/view, and the ability to
 * configure custom dimensions within the native interface, however the process of managing these is
 * somewhat 'low level', so therefore we provide the ability to define custom groupings on a user, an team
 * basis, as well as the ability to share them across multiple explores. Management of the custom groupings
 * is performed via this component.
 */
public interface CustomFilterService {

    String SINGLE_DELIM = "SINGLE_DELIM";
    String TRIPLE_DELIM = "TRIPLE_DELIM";

    CustomFilter createCustomFilter(CustomFilter customFilter, String userId);

    List<CustomFilterSummary> listCustomFilters(int start, int size);

    Page<CustomFilter> searchCustomFilters(int page, String userId, String search);

    Collection<CustomFilter> getAll();

    Optional<CustomFilter> getCustomFilter(Long id);

    CustomFilterGroupSummary getCustomFilterGroupForFilter(Long filterId);

    Collection<CustomFilterCriteriaSummary> getCustomFilterCriteriaForGroup(Long groupId);

    CustomFilter updateCriteriaGroup(CustomFilter customFilter);

    FilterCriteria createFilterCriteria(FilterCriteria filterCriteria, Long groupId);

    FilterCriteria updateFilterCriteria(FilterCriteria filterCriteria, Long criteriaId);

    FilterCriteria getFilterCriteria(Long id);

    boolean deleteFilterCriteria(Long criteriaId);

    void delete(Long id);

    CustomFilter update(CustomFilter customFilter, String userId);

    CustomFilter share(Long id, String[] teams, String userId);

    List<CustomFilterProjection> getCustomListForUserAndExplore(Long exploreId);

    CustomFilter findById(Long id);

    String formatCustomGroupToDynamicFilterSyntax(CustomFilter customGroup);

    Collection<CustomFilter> getByExploreType(String exploreName, String userId);
}
