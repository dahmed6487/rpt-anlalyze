package com.mckesson.app.auth.user;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.mckesson.lib.model.customer.AccountId;
import com.mckesson.lib.model.platform.PlatformId;

@Entity
@Table(name = "user_authorization")
public class UserAuthorizationRule implements Serializable, Comparable<UserAuthorizationRule> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "native")
    @Column(name = "usa_id")
    private long id;

    @Column(name = "user_id")
    private String userId;

    @Column(name = "default_assignment")
    private boolean defaultAssignment;

    @Column(name = "account_id")
    private String accountId;

    @Enumerated(EnumType.STRING)
    @Column(name = "platform")
    private PlatformId platformId;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "create_date")
    private Date createDate;

    public UserAuthorizationRule() {
    }

    public UserAuthorizationRule(String userId, AccountId accountId) {
        this.userId = userId;
        this.accountId = accountId.getAccountId();
        this.platformId = accountId.getPlatformId();
        this.defaultAssignment = false;
        this.createDate = new Date();
    }


    public AccountId toAccountId() {
        return new AccountId(this.platformId, this.accountId);
    }

    public boolean isDefaultAssignment() {
        return defaultAssignment;
    }

    public void setDefaultAssignment(boolean defaultAssignment) {
        this.defaultAssignment = defaultAssignment;
    }

    public PlatformId getPlatformId() {
        return this.platformId;
    }

    public long getId() {
        return id;
    }

    public String getUserId() {
        return userId;
    }

    public String getAccountId() {
        return accountId;
    }

    public String toString() {
        return "UserAuthorizationRule[id=" + this.id + ",user=" + this.userId + ",plat=" + this.getPlatformId() + ",acct=" + this.accountId + ",default=" + this.defaultAssignment + "]";
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public void setCreatedDate(Date createdOn) {
        this.createDate = createdOn;
    }

    @Override
    public int compareTo(UserAuthorizationRule rule) {
        if (this.accountId.equals(rule.getAccountId()) && this.userId.equals(rule.getUserId()) && this.platformId.equals(rule.getPlatformId()))
            return 1;
        return 0;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }

        if (!(o instanceof UserAuthorizationRule)) {
            return false;
        }

        UserAuthorizationRule rule = (UserAuthorizationRule) o;
        return this.compareTo(rule) == 1;
    }
}
