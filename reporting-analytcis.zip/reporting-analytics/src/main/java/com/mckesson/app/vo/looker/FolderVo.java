package com.mckesson.app.vo.looker;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FolderVo {

    @JsonProperty("id")
    private String id;
    @JsonProperty("name")
    private String name;
    @JsonProperty("created_at")
    private String createdAt;
    @JsonProperty("parent_id")
    private String parentId;
    @JsonProperty("looks")
    private List<LookVo> looks;
    @JsonProperty("dashboards")
    private List<DashboardVo> dashboards;
    @JsonProperty("type")
    private String type;
    @JsonProperty("is_personal")
    private boolean personal;
    @JsonProperty("is_personal_descendant")
    private boolean personalDescendant;
    @JsonProperty("child_count")
    int childCount;
    @JsonProperty("favorite_count")
    int favoriteCount;
    @JsonProperty("view_count")
    private int viewCount;
    @JsonProperty("content_metadata_id")
    private String contentMetadataId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public List<LookVo> getLooks() {
        return looks;
    }

    public void setLooks(List<LookVo> looks) {
        this.looks = looks;
    }

    public List<DashboardVo> getDashboards() {
        return dashboards;
    }

    public void setDashboards(List<DashboardVo> dashboards) {
        this.dashboards = dashboards;
    }

    public String toString() {
        return "id=>" + this.id + ", name=>" + this.name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isPersonal() {
        return personal;
    }

    public void setPersonal(boolean personal) {
        this.personal = personal;
    }

    public boolean isPersonalDescendant() {
        return personalDescendant;
    }

    public void setPersonalDescendant(boolean personalDescendant) {
        this.personalDescendant = personalDescendant;
    }

    public int getChildCount() {
        return childCount;
    }

    public void setChildCount(int childCount) {
        this.childCount = childCount;
    }

    public int getFavoriteCount() {
        return favoriteCount;
    }

    public void setFavoriteCount(int favoriteCount) {
        this.favoriteCount = favoriteCount;
    }

    public int getViewCount() {
        return viewCount;
    }

    public void setViewCount(int viewCount) {
        this.viewCount = viewCount;
    }

    public String getContentMetadataId() {
        return contentMetadataId;
    }

    public void setContentMetadataId(String contentMetadataId) {
        this.contentMetadataId = contentMetadataId;
    }
}
