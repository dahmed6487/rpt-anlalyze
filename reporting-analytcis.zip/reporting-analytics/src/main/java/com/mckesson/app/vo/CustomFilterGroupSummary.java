package com.mckesson.app.vo;

public interface CustomFilterGroupSummary {
    Long getId();

    String getName();
}
