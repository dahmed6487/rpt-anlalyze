package com.mckesson.app.config;

import java.util.Map;
import java.util.logging.Logger;

import org.omg.CORBA.Environment;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;

import main.java.com.mckesson.app.auth.permission.UserRole;
import main.java.com.mckesson.app.auth.permission.UserType;
import main.java.com.mckesson.app.auth.user.ConnectUser;
import main.java.com.mckesson.app.auth.user.UserAccessModel;
import main.java.com.mckesson.app.domain.user.UserProfile;
import main.java.com.mckesson.app.service.user.UserProfileService;
import main.java.com.mckesson.app.util.StringUtils;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    private static final Logger LOG = LoggerFactory.getLogger(WebSecurityConfig.class);

    private final Environment env;
    private final UserProfileService userProfileService;

    @Autowired
    public WebSecurityConfig(Environment env, UserProfileService userProfileService) {
        this.env = env;
        this.userProfileService = userProfileService;
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/static/**");
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.cors().and().csrf().csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
                .and().logout()
                .deleteCookies().invalidateHttpSession(true).logoutSuccessUrl(env.getProperty("spring.security.oauth2.client.provider.okta.signout-uri")).permitAll();
        http.authorizeRequests()
                .antMatchers("/api/okta", "/api/user/authenticated", "/", "/initiate-state", "/favicon.ico", "/manifest.json", "/index.html", "/state").permitAll()
                .anyRequest().authenticated()
                .and().oauth2Login().loginPage("/")
                .userInfoEndpoint()
                .userService(this.oauth2UserService());
//              .oidcUserService(this.oidcUserService())
//              .customUserType(ConnectUser.class, env.getProperty("spring.security.oauth2.client.registration.okta.client-id"));

        http.headers()
                .httpStrictTransportSecurity()
                .and().xssProtection();
    }

    private OAuth2UserService<OAuth2UserRequest, OAuth2User> oauth2UserService() {
        final OAuth2UserService delegate = new DefaultOAuth2UserService();

        return (userRequest) -> {
            // Delegate to the default implementation for loading a user
            OAuth2User oAuth2User = delegate.loadUser(userRequest);
            String username = StringUtils.stringOrBlank(oAuth2User.getAttribute("preferred_username"));
            UserType userType = null;
            UserAccessModel uam = new UserAccessModel();
            //          userAuthorizationService.updateRules(username, connectUserAccountService.getAllAccountsforUser(username));

            Map<String, Object> map = null;
            try {
                UserProfile userProfile = userProfileService.checkUserAccess(oAuth2User);
                // map = userAuthorizationService.findDomainMappings(username);
                //List<UserMapping> domainMappings = (List<UserMapping>) map.get("userMapping");
                uam = null;// new UserAccessModel(Sets.newHashSet(), domainMappings,userProfile);
                userType = UserType.lookup(userProfile.getUserRole());
                if (Boolean.parseBoolean(env.getProperty("appconfig.updateLastLogin")))
                    userProfileService.updateLastLoginDate(userProfile.getUsername());

                return new ConnectUser(oAuth2User, new UserRole(userType), uam, userProfile.getIsSudoEnabled(), userProfile.getMarketPartition(), userProfile.getBlaEligible());
            } catch (UsernameNotFoundException e) {
                LOG.error("User details not found for username " + username + " email " + StringUtils.stringOrBlank(oAuth2User.getAttribute("email") + " StackTrace " + e.getStackTrace()));
                return new ConnectUser(oAuth2User, new UserRole(UserType.Guest), uam, "false", "false", "false");
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error(" Error occurred while retrieving domain info " + e.getMessage() + "  StackTrace " + e.getStackTrace());
                return null;
            }
        };
    }

    /* NO LONGER USER
    private OAuth2UserService<OidcUserRequest, OidcUser> oidcUserService() {
        final OidcUserService delegate = new OidcUserService();

        return (userRequest) -> {
            // Delegate to the default implementation for loading a user
            OidcUser oidcUser = delegate.loadUser(userRequest);
            String username = StringUtils.stringOrBlank(oidcUser.getClaims().get("preferred_username"));
            UserType userType = null;
            UserAccessModel uam = new UserAccessModel();
            //          userAuthorizationService.updateRules(username, connectUserAccountService.getAllAccountsforUser(username));

            Map<String, Object> map = null;
            try {
                UserProfile userProfile = userProfileService.checkUserAccess(oidcUser.getUserInfo());
                // map = userAuthorizationService.findDomainMappings(username);
                //List<UserMapping> domainMappings = (List<UserMapping>) map.get("userMapping");
                uam = null;// new UserAccessModel(Sets.newHashSet(), domainMappings,userProfile);
                userType = UserType.lookup(userProfile.getUserRole());
                if (Boolean.parseBoolean(env.getProperty("appconfig.updateLastLogin")))
                    userProfileService.updateLastLoginDate(userProfile.getUsername());

                return new ConnectUser(oidcUser, new UserRole(userType), uam, userProfile.getIsSudoEnabled(), userProfile.getMarketPartition(), userProfile.getBlaEligible());
            } catch (UsernameNotFoundException e) {
                LOG.error("User details not found for username " + username + " email " + StringUtils.stringOrBlank(oidcUser.getClaims().get("email") + " StackTrace " + e.getStackTrace()));
                return new ConnectUser(oidcUser, new UserRole(UserType.Guest), uam, "false", "false", "false");
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error(" Error occurred while retrieving domain info " + e.getMessage() + "  StackTrace " + e.getStackTrace());
                return null;
            }
        };
    }
    */
}