package com.mckesson.app.web.rest.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import main.java.com.mckesson.app.domain.customer.SecurityGroupAccounts;
import main.java.com.mckesson.app.service.customer.SecurityGroupAccountsService;

/**
 * Class used to drive SecurityGroupAccount operations for data display on Admin/Domain screen
 */
@RestController
@RequestMapping("/api/security-group-account")
public class SecurityGroupAccountsController {

    private final SecurityGroupAccountsService securityGroupAccountsService;

    @Autowired
    public SecurityGroupAccountsController(SecurityGroupAccountsService securityGroupAccountsService) {
        this.securityGroupAccountsService = securityGroupAccountsService;
    }

    /**
     * @return
     */
    @GetMapping("/get")
    public List<SecurityGroupAccounts> getAll() {
        return securityGroupAccountsService.getAll();
    }

    /**
     * @param securityGroupAccounts
     * @return
     */
    @PostMapping("/update")
    public ResponseEntity updateAll(@RequestBody List<SecurityGroupAccounts> securityGroupAccounts) {
        securityGroupAccountsService.updateAll(securityGroupAccounts);
        return new ResponseEntity(securityGroupAccounts, HttpStatus.OK);
    }

    /**
     * @param securityGroupAccounts
     * @return
     */
    @PostMapping("/delete")
    public ResponseEntity<String> deleteAll(@RequestBody List<SecurityGroupAccounts> securityGroupAccounts) {
        return securityGroupAccountsService.deleteAll(securityGroupAccounts);
    }
}
