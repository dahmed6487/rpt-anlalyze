package com.mckesson.app.service.looker;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.service.looker.api.ContentApi;
import main.java.com.mckesson.app.service.looker.api.DashboardApi;
import main.java.com.mckesson.app.service.looker.api.FolderApi;
import main.java.com.mckesson.app.service.looker.api.GroupApi;
import main.java.com.mckesson.app.service.looker.api.LookApi;
import main.java.com.mckesson.app.service.looker.api.QueryApi;
import main.java.com.mckesson.app.service.looker.api.SpaceApi;
import main.java.com.mckesson.app.service.looker.api.UserApi;
import main.java.com.mckesson.app.vo.looker.ContentVo;
import main.java.com.mckesson.app.vo.looker.FolderVo;

@Service
public class CollaborationTeamServiceLooker extends BaseSpaceManagementService {

    @Autowired
    public CollaborationTeamServiceLooker(SpaceApi spaceApi, UserApi userApi, DashboardApi dashboardApi, LookApi lookApi, FolderApi folderApi, ContentApi contentApi, QueryApi queryApi, GroupApi groupApi) {
        super(spaceApi, userApi, dashboardApi, lookApi, folderApi, contentApi, queryApi, groupApi);
    }

    public String getAllFolders(String userID) {
        String authToken = getAuthToken();
        return folderApi.getAllFolders(authToken);
    }

    public FolderVo getFolder(String folderId) {
        String authToken = getAuthToken();
        return folderApi.getFolder(authToken, folderId);
    }

    public String getLooks(String userID, String folderId) {
        String authToken = getAuthToken();
        return folderApi.getlooks(authToken, folderId);
    }

    public List<FolderVo> getFolderChildren(String userID, String folderId) throws Exception {
        String authToken = getAuthToken();
        return folderApi.getFolderChildren(folderId, authToken);
    }

    public FolderVo createFolder(String parentId, String folderName, String authToken) throws Exception {
        FolderVo folderVo;
         folderVo = folderApi.createFolder(parentId, folderName, authToken);
         if(folderVo.getId() == null || folderVo.getName() == null) {
             List<FolderVo> folders = folderApi.searchSharedFoldersByNameInParent(folderName, authToken,parentId);
             if (folders.isEmpty()) {
                 folderVo = null;
             } else {
                 folderVo = folders.get(0);
             }
         }
         return folderVo;
    }

    public FolderVo createFolder(String parentId, String folderName) throws Exception {
        String authToken = getAuthToken();
        FolderVo folderVo;
        folderVo = folderApi.createFolder(parentId, folderName, authToken);
        if(folderVo.getId() == null || folderVo.getName() == null) {
            List<FolderVo> folders = folderApi.searchSharedFoldersByNameInParent(folderName, authToken,parentId);
            if (folders.isEmpty()) {
                folderVo = null;
            } else {
                folderVo = folders.get(0);
            }
        }
        return folderVo;
    }

    public List<FolderVo> searchSharedFoldersByNameInParent(String parentId, String folderName) throws Exception {
        String authToken = getAuthToken();
        return folderApi.searchSharedFoldersByNameInParent(folderName, authToken,parentId);
    }

    public FolderVo getFolderByName(String name) throws Exception {
        String authToken = getAuthToken();
        FolderVo folderVo = new FolderVo();

        if (name != null) {
            List<FolderVo> folders = folderApi.searchSharedFoldersByName(name, authToken);
            if (folders.isEmpty()) {
                folderVo = null;
            } else {
                folderVo = folders.get(0);
            }
        }
        return folderVo;
    }

    public FolderVo searchFoldersByName(String name) throws Exception {
        String authToken = getAuthToken();
        FolderVo folderVo = new FolderVo();

        if (name != null) {
            List<FolderVo> folders = folderApi.searchFoldersByName(name, authToken);
            if (folders.isEmpty()) {
                folderVo = null;
            } else {
                folderVo = folders.get(0);
            }
        }
        return folderVo;
    }

    public boolean updateFolder(String parentId, String folderId) {
        String authToken = getAuthToken();
        return folderApi.updateFolder(parentId, folderId, authToken);
    }

    public void giveGroupAccessParent(String groupId) throws Exception {
        String authToken = getAuthToken();
        contentApi.giveGroupAccessParent(authToken, groupId, "view");
    }

    public void deleteTeams(Long externalId) {
        if(externalId!=null) {
            String authToken = getAuthToken();
            spaceApi.deleteFolder(externalId.toString(), authToken);
        }
    }

    public void deleteGroup(Long externalId) {
        if(externalId!=null) {
            String authToken = getAuthToken();
            groupApi.deleteGroup(externalId, authToken);
        }
    }

    public ContentVo getContentAccess(ContentVo contentVo) throws Exception {
        String authToken = getAuthToken();
        return contentApi.getContentAccess(contentVo, authToken);
    }

    public void updateContentAccess(ContentVo contentVo) throws Exception {
        String authToken = getAuthToken();
        contentApi.updateContentAccess(contentVo, authToken);
    }

    public void deleteContentAccess(ContentVo contentVo) throws Exception {
        String authToken = getAuthToken();
        contentApi.deleteContentAccess(contentVo, authToken);
    }

    public void giveGroupAccess(ContentVo contentVo) {
        String authToken = getAuthToken();
        contentApi.giveGroupAccess(authToken, contentVo);
    }

    public void removeGroup(String name) {
        String authToken = getAuthToken();
        GroupVo groupVo=groupApi.getGroupByName(name,authToken);
        if(groupVo!=null)
        groupApi.deleteGroup(groupVo.getId(), authToken);
    }

    public List<ContentVo> allContentAccess(ContentVo teamContent) throws Exception {
        String authToken = getAuthToken();
        return  contentApi.allContentAccess(teamContent, authToken);
    }

    public void removeContentAccess(ContentVo contentVo) {
        String authToken = getAuthToken();
        contentApi.removeContentAccess(contentVo, authToken);
    }

    public List<FolderVo> listChildrenForFolder(String parentFolderId) {
        String userAuthToken = getAuthToken();
        String[] fields = {"id", "name", "parent_id", "created_at", "space_id"};
        return folderApi.listChildrenForFolder(parentFolderId, fields, userAuthToken);
    }
    
    public FolderVo renameFolderName(Long externalId, String customerName) {
        String authToken = getAuthToken();
      return folderApi.renameFolderName(externalId.toString(), customerName, authToken );
    }

    public boolean searchContentInFolder(String folderId) throws Exception {
        String authToken = getAuthToken();
        List<FolderVo> dashBoards= folderApi.searchDashboardContent(folderId, authToken );
        List<FolderVo> looks= folderApi.searchReportContent(folderId, authToken );
        return !dashBoards.isEmpty() || !looks.isEmpty();
    }
}
