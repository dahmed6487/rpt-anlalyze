package com.mckesson.app.service.looker;

import java.util.Collection;

import main.java.com.mckesson.app.domain.looker.FilterCriteria;
import main.java.com.mckesson.app.vo.looker.DimensionVo;

/**
 * Service responsible for generating embed URLs used to produce 'explore' mode views on Iframe content. Embed URL generation is for the most part
 * performed in the same manner for Dashboard, Look, and Embed type views into Looker managed content. However, explore type views support the ability to
 * associate the content with a particular 'query' (represented by a qid, or unique identifier for a query), this is in addition to the model and view attributes
 * that are used to embed an explore. In contrast, embed urls for dashboards and looks accept just a unique identifier for the content to be displayed.
 * Note: This interface exposes a 'short term' method for generating embed URLS for a given explore/user/reference. See getEmbedUrlWithCustomFiltersShortTerm(...)
 * for details.
 */
public interface LookerExploreService {

    /**
     * 10/11/2019 Temporary call method that needs to be used for ALL REQUESTS for explore content.
     * <p>
     * We are currently supporting two use cases. The first is where we are essentially hard coding qid's used in the embed url generation based on a selected model & user account. This is
     * for the purposes of support the ability to demo explores for specific customers. The second use case performs qid assignment based on the current user/selected model and saved
     * custom dimensions/custom groups. The idea is to support both modes in parallel as a short term effort until 'custom grouping' management is fully available and we can abandon the
     * initial approach.
     * <p>
     * TO SUPPORT BOTH USES CASES, THIS METHOD SHOULD BE CALLED.
     */
    String getEmbedUrlWithCustomGroupsShortTerm(String model, String exploreRef) throws Exception;

    /**
     * For a given model, explore, and custom group definition this method will determine whether or not the custom
     * group should be shown on the explore.
     *
     * @param model       the name of the LookML Model
     * @param exploreName the name of the Looker Explore
     * @param criteria    the grouping criteria definitions for a given group
     * @return {@code true} or {@code false} depending on whether or not the components of the custom group exist and
     * are visible in the given model + explore
     */
    Boolean showCustomGroupOnExplore(String model, String exploreName, Collection<FilterCriteria> criteria);

    /**
     * For a given <em>explore</em> and <em>model</em>, returns a collection of all visible dimensions from the Looker API.
     *
     * @param userId the requesting user's user id, used to maintain a user specific cache of dimensions and to auth as
     *               the specified user for Looker requests
     * @return a {@link Collection} of {@link DimensionVo}s which contain the visible dimensions in all models and explores
     */
    Collection<DimensionVo> getAllVisibleDimensions(String userId);

    Collection<DimensionVo> getVisibleDimensionsByExplore(String userId, String explore);

    /**
     * Given a reference to a model, generate an URL that is intended to be used to display the explore in an Iframe. A reference to the view/model is initially provided ('what'
     * we are exploring). In addition to simply generating the link representing the explore in it's default state, additional logic is applied which will identify saved/configured
     * custom groupings, and ensure they are presented in the resulting Iframe.
     *
     * Default behavior for viewing explore content is to display an initial interface, where the user may add 'custom groupings/dimensions' to refine how data is presented. A common
     * use case is for viewers to use the same set of 'custom grouping/dimension' type filters, so custom functionality has been added to save configured dimensions, and automatically
     * apply them. This is not support by default within the Looker product, so custom functionality has been implemented to store saved groupings.
     *
     *  This method is a 'top level' call intended to service an API request for explore content. The caller is abstracted from all details regarding which custom groups/dimensions are
     *  applicable for the request, these details are handled by the calling method. User credentials are provided via the Spring security context, and not passed as a parameter. Logic
     *  regarding which filters are applicable for request, permission checks, etc. are encapsulated by this method.
     *
     *
     * Note: Reference to exploreId is legacy and will most likely change in the near future.
     *
     * @param model
     * @param exploreId
     * @return
     * @throws Exception
     */
    //public String getEmbedUrlWithCustomFilters(String model, Long exploreId)throws Exception;

    String getUpdatedQidForDashboardExplore(String userId,String model, String exploreRef, String qid) throws Exception;

}
