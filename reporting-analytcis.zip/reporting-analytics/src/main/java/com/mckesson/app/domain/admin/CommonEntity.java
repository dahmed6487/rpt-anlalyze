package com.mckesson.app.domain.admin;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "common_entity")
public class CommonEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "native")
    @Column(name = "common_entity_id")
    private String id;

    @Column(name = "common_group")
    private String commonGroup;

    @Column(name = "common_group_desc")
    private String commonGroupDescription;

    @Column(name = "common_entity")
    private String commonEntity;

    @Column(name = "common_entity_desc")
    private String commonEntityDescription;

    @Column(name = "gpo")
    private String gpo;

    @Column(name = "gpo_desc")
    private String gpoDescription;

    @Column(name = "account")
    private String account;

    @Column(name = "gpo_Account")
    private String gpoAccount;

    @Column(name = "platform")
    private String platform;

    @Column(name = "created_date")
    private Date createDate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCommonGroup() {
        return commonGroup;
    }

    public void setCommonGroup(String commonGroup) {
        this.commonGroup = commonGroup;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public String getCommonGroupDescription() {
        return commonGroupDescription;
    }

    public void setCommonGroupDescription(String commonGroupDescription) {
        this.commonGroupDescription = commonGroupDescription;
    }

    public String getCommonEntity() {
        return commonEntity;
    }

    public void setCommonEntity(String commonEntity) {
        this.commonEntity = commonEntity;
    }

    public String getCommonEntityDescription() {
        return commonEntityDescription;
    }

    public void setCommonEntityDescription(String commonEntityDescription) {
        this.commonEntityDescription = commonEntityDescription;
    }

    public String getGPO() {
        return gpo;
    }

    public void setGPO(String gpo) {
        this.gpo = gpo;
    }

    public String getGPODescription() {
        return gpoDescription;
    }

    public void setGPODescription(String gpoDescription) {
        this.gpoDescription = gpoDescription;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getGPOAccount() {
        return gpoAccount;
    }

    public void setGPOAccount(String gpoAccount) {
        this.gpoAccount = gpoAccount;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

}

