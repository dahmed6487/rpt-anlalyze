package com.mckesson.app.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "application_usage_log")
public class ApplicationUsageLog {

    @Id
    @Column(name = "usage_log_id")
    private long usageLogId;

    private String source;

    @Column(name = "event_data")
    private String eventData;

    @Column(name = "event_type")
    private String eventType;

    @Column(name = "user_id")
    private String userId;

    @Column(name = "common_entity")
    private String commonEntity;

    @Column(name = "common_group")
    private String commonGroup;

    @Column(name = "security_group")
    private String securityGroup;

    public long getUsageLogId() {
        return usageLogId;
    }

    public void setUsageLogId(long usageLogId) {
        this.usageLogId = usageLogId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getEventData() {
        return eventData;
    }

    public void setEventData(String eventData) {
        this.eventData = eventData;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCommonEntity() {
        return commonEntity;
    }

    public void setCommonEntity(String commonEntity) {
        this.commonEntity = commonEntity;
    }

    public String getCommonGroup() {
        return commonGroup;
    }

    public void setCommonGroup(String commonGroup) {
        this.commonGroup = commonGroup;
    }

    public String getSecurityGroup() {
        return securityGroup;
    }

    public void setSecurityGroup(String securityGroup) {
        this.securityGroup = securityGroup;
    }
}
