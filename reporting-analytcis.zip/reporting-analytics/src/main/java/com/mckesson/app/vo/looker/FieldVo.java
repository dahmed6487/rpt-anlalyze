package com.mckesson.app.vo.looker;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * A VO mapping the dimensions returned for a <em>Fields</em> JSON array from the Looker API.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FieldVo {

    @JsonProperty("dimensions")
    public List<DimensionVo> dimensions;

    public List<DimensionVo> getDimensions() {
        return dimensions;
    }

    public void setDimensions(List<DimensionVo> dimensions) {
        this.dimensions = dimensions;
    }
}
