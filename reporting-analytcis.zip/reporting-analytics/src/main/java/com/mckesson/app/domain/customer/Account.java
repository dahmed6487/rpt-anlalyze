package com.mckesson.app.domain.customer;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.mckesson.lib.model.customer.AccountId;
import com.mckesson.lib.model.platform.PlatformId;

@Entity
@Table(name = "accounts")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "native")
    @Column(name = "act_id")
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "platform")
    private PlatformId platformId;

    @Column(name = "account_id")
    private String accountId;

    @Column(name = "name")
    private String name;

    private AccountId aid;

    public AccountId getId() {
        if (this.aid == null) {
            return new AccountId(this.platformId, this.accountId);
        }

        return aid;
    }

    public void setId(AccountId id) {
        this.aid = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public PlatformId getPlatformId() {
        return this.aid.getPlatformId();
    }

}
