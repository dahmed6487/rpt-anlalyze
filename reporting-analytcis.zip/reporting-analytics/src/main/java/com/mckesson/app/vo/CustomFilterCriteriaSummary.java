package com.mckesson.app.vo;

import main.java.com.mckesson.app.domain.looker.FilterCriteriaGroup;

public interface CustomFilterCriteriaSummary {
    Long getId();

    String getName();

    FilterCriteriaGroup getGroup();

    String getDimension();

    String getAssociatedDimension();

    String getRelationalOperator();

    String getValue();

    Boolean getDefaultGrouping();
}
