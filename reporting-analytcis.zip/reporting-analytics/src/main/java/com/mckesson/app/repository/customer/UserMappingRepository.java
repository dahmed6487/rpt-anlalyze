package com.mckesson.app.repository.customer;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import main.java.com.mckesson.app.domain.customer.UserMapping;

public interface UserMappingRepository extends JpaRepository<UserMapping, String>, JpaSpecificationExecutor<UserMapping> {
    @Transactional
    List<UserMapping> findByusername(String username);

    @Query(value = "from #{#entityName} t where t.username = ?1")
    List<UserMapping> getUserMapping(String username);

    @Query(value = "from #{#entityName} t where t.username = ?1 and t.customerId = ?2")
    UserMapping getUserMappingByCustomerId(String username, Long customerId);

    @Query(value = "from #{#entityName} t where t.deletedDate is null")
    List<UserMapping> getActiveUserMapping();

    @Transactional
    @Modifying
    @Query(value = "update user_mapping t set  deleted_date=null where t.user_mapping_id in ?1 ", nativeQuery = true)
    void active(List<Long> list);

    @Transactional
    @Modifying
    @Query(value = "delete t from user_map_collab_team_relation t where t.user_mapping_id in ?1 ", nativeQuery = true)
    void deleteUserMapCollabTeamRelation(List<Long> list);

    @Transactional
    @Modifying
    @Query(value = "update user_map_collab_team_relation t set deleted_date=?1 , is_updated='Y' where t.user_mapping_id in ?2 and t.collaboration_team_id=?3 ", nativeQuery = true)
    int softDeleteUserFromTeam(Date deletedDate, List<String> userMappingIds, String teamId);

    @Transactional
    @Modifying
    @Query(value = "delete t from user_map_module_relation t where t.user_mapping_id in ?1 ", nativeQuery = true)
    void deleteUserMapCollabModuleRelation(List<Long> list);

    @Transactional
    @Modifying
    @Query(value = "delete t from user_map_security_group_relation t where t.user_mapping_id in ?1 ", nativeQuery = true)
    void deleteUserMapSecurityGroupRelation(List<Long> list);

    @Transactional
    @Modifying
    @Query("update #{#entityName} t set t.deletedDate= ?1 where t.userMappingId in ?2 ")
    void inActive(Date deletedDate, List<Long> list);

    @Transactional
    @Modifying
    @Query(value = "insert into user_map_security_group_relation values(?1,?2) ", nativeQuery = true)
    void insertOrUpdateTeamsRelation(String collaborationTeamId, String userMappingId);

    @Transactional
    @Modifying
    @Query(value = "insert into user_map_security_group_relation values(?1,?2) ", nativeQuery = true)
    void insertOrUpdateSecurityGroupRelation(String securityGroupId, String userMappingId);

    @Transactional
    @Modifying
    @Query(value = "delete t from user_map_security_group_relation t where t.relation_id in ?1 ", nativeQuery = true)
    void deleteTeamsRelationById(List<Integer> list);

    @Transactional
    @Modifying
    @Query(value = "insert into user_map_module_relation values(?1,?2) ", nativeQuery = true)
    void insertOrUpdateModuleRelation(String collaborationTeamId, String userMappingId);

    @Transactional
    @Modifying
    @Query(value = "delete t from user_map_module_relation t where t.relation_id in ?1 ", nativeQuery = true)
    void deleteModuleRelationById(List<Integer> list);


    @Transactional
    @Modifying
    @Query(value = "delete t from user_map_security_group_relation t where t.relation_id in ?1 ", nativeQuery = true)
    void deleteSecurityGroupRelationById(List<Integer> list);

    @Query(value = " select distinct up.user_id user_id,cs.customer_id customer_id ,1 user_mapping_id, 'p' platform, 'p' user_type, 'p' created_by, current_timestamp created_date, 'p' updated_by, current_timestamp updated_date, 'p' deleted_by, current_timestamp deleted_date from user_profile up,customer cs,era_user_permissions eup where up.user_id=eup.user_id and cs.common_entity_id=eup.customer_id and eup.user_id is not null and eup.customer_id is not null and eup.customer_id in ('200005','073108') and eup.user_id='pingcust'", nativeQuery = true)
    List<UserMapping> getAvailableMapping();

    @Query(value = "select t.*  from user_mapping t where t.user_id=?1 and t.customer_id=?2", nativeQuery = true)
    List<UserMapping> getCustUserMapping(String username, Long customerId);

    @Transactional
    @Modifying
    @Query(value = " INSERT IGNORE INTO user_mapping (platform, customer_id, user_id, created_by, created_date)" +
            " select distinct 'P',cs.customer_id customer_id,up.user_id user_id,'SYSTEM',?1 from user_profile up,customer cs,era_user_permissions eup , customer_whitelist cw" +
            " where up.user_id=eup.user_id and cs.customer_id=eup.customer_id" +
            "  and eup.user_id is not null and eup.customer_id is not null and cw.amdm_era_ownr_party_id=cs.amdm_era_ownr_party_id", nativeQuery = true)
    void insertUserMappings(Date date);

    @Modifying
    @Query(value = "delete from user_mapping where created_by='SYSTEM' and customer_id=?1 ", nativeQuery = true)
    void deleteUserMapping(long customerId);

    @Transactional
    @Modifying
    @Query(value = " INSERT IGNORE INTO user_mapping (platform, customer_id, user_id, created_by, created_date)" +
            " select distinct 'P',cs.customer_id customer_id,up.user_id user_id,'SYSTEM',?1 from user_profile up,customer cs,era_user_permissions eup " +
            " where up.user_id=eup.user_id and cs.customer_id=eup.customer_id and up.user_role='ISA'" +
            "  and eup.user_id is not null and eup.customer_id is not null ", nativeQuery = true)
    void insertSalesUserMappings(Date date);
}
