package com.mckesson.app.web.rest.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import main.java.com.mckesson.app.domain.admin.Module;
import main.java.com.mckesson.app.service.admin.ModuleService;

/**
 * Class used to drive Module operations for data display on Admin/Domain screen
 */
@RestController
@RequestMapping("/api/module")
public class ModuleController {

    private final ModuleService moduleService;

    @Autowired
    public ModuleController(ModuleService moduleService) {
        this.moduleService = moduleService;
    }

    /**
     * Method used to fetch Module data to display on Domain screen's
     *
     * @return
     */
    @GetMapping("/get")
    public List<Module> getModule(@RequestParam String moduleType) {
        return moduleService.getModule(moduleType);
    }

    @GetMapping("/get/customer")
    public List<Module> getCustomerModule(@RequestParam String customerName) {
        return moduleService.getCustomerModule(customerName);
    }

    @GetMapping("/get/customer/{customerId}")
    public List<Module> getCustomerModulesById(@PathVariable String customerId) {
        return moduleService.getCustomerModulesById(customerId);
    }

    @GetMapping("/get/{moduleId}")
    private ResponseEntity getModuleForIds(@PathVariable Long moduleId) {
        return new ResponseEntity(moduleService.getModuleForIds(moduleId), HttpStatus.ACCEPTED);
    }

    /**
     * Method used to Update Module data based on Module
     *
     * @param module
     * @return
     */
    @PostMapping("/update")
    public List<Module> updateModule(@RequestBody List<Module> module) {
        return moduleService.updateModule(module);
    }

    /**
     * Delete from collab_team_module_relation
     * and Update the Delete date in Module
     *
     * @param module
     * @return
     */
    @PostMapping("/delete")
    public ResponseEntity<String> deleteModule(@RequestBody List<Module> module) {
        moduleService.deleteModule(module);
        return new ResponseEntity<String>("Your request has been completed successfully", HttpStatus.ACCEPTED);
    }
}