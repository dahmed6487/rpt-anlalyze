package com.mckesson.app.service.customer;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.domain.customer.SecurityGroupAccounts;
import main.java.com.mckesson.app.repository.customer.SecurityGroupAccountsRepository;

@Service
public class SecurityGroupAccountsService {

    private final SecurityGroupAccountsRepository securityGroupAccountsRepository;

    @Autowired
    public SecurityGroupAccountsService(SecurityGroupAccountsRepository securityGroupAccountsRepository) {
        this.securityGroupAccountsRepository = securityGroupAccountsRepository;
    }

    public List<SecurityGroupAccounts> getAll() {
        return securityGroupAccountsRepository.findAll();
    }

    public List<SecurityGroupAccounts> updateAll(List<SecurityGroupAccounts> securityGroupAccounts) {
        List<Long> list = new ArrayList();
        securityGroupAccounts.stream().forEach(c -> list.add(c.getSecurityGroupAccountId()));
        securityGroupAccountsRepository.active(list);
        return securityGroupAccounts;
    }

    public ResponseEntity<String> deleteAll(List<SecurityGroupAccounts> securityGroupAccounts) {
        List<Long> list = new ArrayList();
        Date deletedDate = new Date();
        securityGroupAccounts.stream().forEach(c -> list.add(c.getSecurityGroupAccountId()));
        securityGroupAccountsRepository.inActive(deletedDate, list);
        return new ResponseEntity<String>("Your request has been completed successfully", HttpStatus.OK);
    }
}
