package com.mckesson.app.domain.looker;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "looker_dyn_field_shared")
public class SharedCustomFilter {

    @Id
    @GeneratedValue
    @Column(name = "LDF_ID")
    private Long id;

    @Column(name = "GRP_ID")
    private Long groupId;

    @OneToOne
    private CustomFilter customFilter;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public CustomFilter getCustomFilter() {
        return customFilter;
    }

    public void setCustomFilter(CustomFilter customFilter) {
        this.customFilter = customFilter;
    }

}
