package com.mckesson.app.service.looker;

import main.java.com.mckesson.app.vo.looker.DashboardFilterConfigResponseVo;

public interface DashboardService {

    String QUALIFIER_TYPE_IS_EQUAL_TO = "IS_EQUAL_TO";
    String QUALIFIER_TYPE_CONTAINS = "CONTAINS";
    String QUALIFIER_TYPE_STARTS_WITH = "STARTS_WITH";
    String QUALIFIER_TYPE_ENDS_WITH = "ENDS_WITH";
    String QUALIFIER_TYPE_IS_BLANK = "IS_BLANK";
    String QUALIFIER_TYPE_IS_NULL = "IS_NULL";
    String QUALIFIER_TYPE_IS_NOT_EQUAL_TO = "IS_NOT_EQUAL_TO";
    String QUALIFIER_TYPE_DOESNT_CONTAIN = "DOESNT_CONTAIN";
    String QUALIFIER_TYPE_DOESNT_START_WITH = "DOESNT_START_WITH";
    String QUALIFIER_TYPE_DOESNT_END_WITH = "DOESNT_END_WITH";
    String QUALIFIER_TYPE_IS_NOT_BLANK = "DOESNT_END_WITH";
    String QUALIFIER_TYPE_IS_NOT_NULL = "IS_NOT_NULL";

    /**
     * Retrieve saved filters for current user and selected dashboard.
     *
     * @param dashboardId
     * @return
     */
    //public List<DashboardFilter> getFiltersForDashboard(String dashboardId);

    /**
     * Persist changes for available filters for selected dashboard.
     *
     * @param filters
     * @return
     */
    //public List<DashboardFilter>updateFilters(List<DashboardFilter>filters);
    void deleteFilter(String filterId);

    DashboardFilterVo createFilter(String userId, DashboardFilterVo filterVo);

    DashboardFilterVo updateFilter(DashboardFilterVo filterVo);

    /**
     * Retrieve dashboard and filter related information for a given user and selected dashboard.
     *
     * @param dashboardId
     * @return
     */
    DashboardFilterConfigResponseVo loadDashboardFilterConfig(String userId, String dashboardId);

    void updateSharedGroups(String filterId, String[] sharedTeams);
}
