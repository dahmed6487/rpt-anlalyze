package com.mckesson.app.service;

import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.transaction.Transactional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

import main.java.com.mckesson.app.domain.ApplicationLog;
import main.java.com.mckesson.app.repository.ApplicationLogRepository;
import main.java.com.mckesson.app.util.UserAuthentication;

@Service
public class ApplicationLogService {
    private static final Logger log = LoggerFactory.getLogger(ApplicationLogService.class);

    private final UserAuthentication userAuthentication;
    private final ApplicationLogRepository applicationLogRepository;

    @Autowired
    public ApplicationLogService(UserAuthentication userAuthentication, ApplicationLogRepository applicationLogRepository) {
        this.userAuthentication = userAuthentication;
        this.applicationLogRepository = applicationLogRepository;
    }

    @Transactional
    public void insertApplicationLog(List<Object> object, String eventType) {
        try {
            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            ApplicationLog applicationLog = new ApplicationLog();
            applicationLog.setEventType(eventType);
            applicationLog.setEventData(ow.writeValueAsString(object));
            applicationLog.setUserId(userAuthentication.getLoggedInUser().getUsername());
            log.info("Inserting Audit info :: eventType: " + applicationLog.getEventType() + " : UserId: " + userAuthentication.getLoggedInUser().getUsername());
            applicationLogRepository.saveAndFlush(applicationLog);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            log.error("Error occurred while inserting the Audit info " + e.getMessage());
        }


    }

    @Transactional
    public void insertOrUpdateRecentSearchLog(String searchCriteria, String userId, long criteriaId) {
          applicationLogRepository.insertOrUpdateRecentSearchLog(searchCriteria, criteriaId, userId, new Date());
    }
}
