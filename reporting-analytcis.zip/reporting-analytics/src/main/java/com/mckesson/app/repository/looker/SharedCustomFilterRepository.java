package com.mckesson.app.repository.looker;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import main.java.com.mckesson.app.domain.looker.LookerEvent;
import main.java.com.mckesson.app.domain.looker.SharedCustomFilter;

public interface SharedCustomFilterRepository extends JpaRepository<SharedCustomFilter, Long>, JpaSpecificationExecutor<LookerEvent> {

}
