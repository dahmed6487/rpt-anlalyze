package com.mckesson.app.vo.looker;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ContentVo {
    @JsonProperty("id")
    public String id;

    @JsonProperty("content_metadata_id")
    public String contentMetadataId;

    @JsonProperty("permission_type")
    private String permissionType;

    @JsonProperty("group_id")
    private String groupId;

    @JsonProperty("inherits")
    private Boolean inherits;

    @JsonProperty("user_id")
    private String userId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContentMetadataId() {
        return contentMetadataId;
    }

    public void setContentMetadataId(String contentMetadataId) {
        this.contentMetadataId = contentMetadataId;
    }

    public String getPermissionType() {
        return permissionType;
    }

    public void setPermissionType(String permissionType) {
        this.permissionType = permissionType;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public Boolean getInherits() {
        return inherits;
    }

    public void setInherits(Boolean inherits) {
        this.inherits = inherits;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}

