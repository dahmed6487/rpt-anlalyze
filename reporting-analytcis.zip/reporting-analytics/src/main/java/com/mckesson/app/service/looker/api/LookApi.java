package com.mckesson.app.service.looker.api;

import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.util.MappingUtils;
import main.java.com.mckesson.app.util.RestClient;
import main.java.com.mckesson.app.vo.looker.LookVo;

@Component
public class LookApi extends ApiBase {
    private static final Logger LOG = LoggerFactory.getLogger(LookApi.class);

    public LookVo getLook(String lookId, String[] fields, String authToken) {
        try {
            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/looks/" + lookId;
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, params);
            LookVo look = new LookVo();
            MappingUtils.populateFromJson(jsonResponse, look);
            return look;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public Long searchLook(LookVo look, String spaceId, String authToken) {

        try {

            String[] fields = {"id", "title"};

            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/looks/search?title=" + java.net.URLEncoder.encode(look.getTitle(), "UTF-8") + "&space_id=" + spaceId + "&fields=title%2Cid";
            String jsonResponse = RestClient.performGETOperation(authToken, requestUrl, params);
            List<LookVo> responseLook = MappingUtils.getCollectionFromJson(jsonResponse, LookVo.class);
            LOG.info("################## jsonResponse " + jsonResponse + " ############### " + responseLook.get(0).getTitle());
            return responseLook.get(0).getId();
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public void deleteLook(String lookId, String authToken) {
        try {
            String requestUrl = this.lookerApiHost + "/looks/" + lookId;
            RestClient.performDELETEOperation(authToken, requestUrl);
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public LookVo updateLook(LookVo look, String[] fields, String authToken) {
        try {

            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/looks/" + look.getId();
            //String jsonBody = MappingUtils.serializeToJson(look);

            String jsonBody = "{ \"title\":\"" + look.getTitle() + "\",\"description\":\"" + look.getDescription() + "\" }";

            String jsonResponse = RestClient.performPATCHOperation(authToken, requestUrl, jsonBody, null);
            MappingUtils.populateFromJson(jsonResponse, look);
            return look;

        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }


    /**
     * based on look id get the lookinfo with looks
     * copy to a space id or folder id destination
     *
     * @param look
     * @param fields
     * @param authToken
     * @return
     */
    public LookVo shareReport(String externalId, LookVo look, String[] fields, String authToken) {
        try {

            HashMap<String, String> params = getFieldCriteria(fields, new HashMap());
            String requestUrl = this.lookerApiHost + "/looks";
            look.setFolderId(externalId);
            //String jsonBody = "{ \"folder_id\":\""+ externalId +"\",\"title\":\""+ look.getTitle() +"\",\"description\":\""+ look.getDescription() +"\",\"query_id\":\""+look.getQueryId()+"\" }";
            String jsonBody = MappingUtils.serializeToJson(look);

            String jsonResponse = RestClient.performPOSTOperation(authToken, requestUrl, jsonBody, params);
            System.out.println("jsonResponse--------------------->" + jsonResponse);
            LookVo returnLook = new LookVo();
            MappingUtils.populateFromJson(jsonResponse, returnLook);
            return returnLook;
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

}
