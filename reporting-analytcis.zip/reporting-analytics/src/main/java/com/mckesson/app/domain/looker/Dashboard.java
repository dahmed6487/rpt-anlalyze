package com.mckesson.app.domain.looker;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "solutions")
public class Dashboard {
    @Id
    @Column(name = "id")
    private Integer id;

    private String name;
    private String description;

    @Column(name = "module_id")
    private Integer moduleId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer newId) {
        id = newId;
    }

    public String getName() {
        return name;
    }

    public void setName(String newName) {
        name = newName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String newDescription) {
        description = newDescription;
    }

    public Integer getModuleId() {
        return moduleId;
    }

    public void setModuleId(Integer newModuleId) {
        moduleId = newModuleId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Dashboard dashboard = (Dashboard) o;
        return Objects.equals(id, dashboard.id) && Objects.equals(name, dashboard.name) && Objects.equals(description, dashboard.description) && Objects.equals(moduleId, dashboard.moduleId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, description, moduleId);
    }

    @Override
    public String toString() {
        return "Dashboard{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", moduleId=" + moduleId +
                '}';
    }
}
