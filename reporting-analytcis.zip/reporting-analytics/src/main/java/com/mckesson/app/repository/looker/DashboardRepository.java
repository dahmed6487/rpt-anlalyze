package com.mckesson.app.repository.looker;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import main.java.com.mckesson.app.domain.looker.Dashboard;

@Repository
public interface DashboardRepository extends JpaRepository<Dashboard, Integer> {

     @Query(value ="select distinct s.* from customer_module_relation cmr,customer cs,module m ,solutions s  where s.module_id=m.module_id and cs.customer_id=cmr.customer_id and m.module_id=cmr.module_id and common_entity_name=?1 and m.category!='NOT_EXTERNAL'" ,nativeQuery = true)
    List<Dashboard> getSolutionForCustomer(String customerName);

    @Query(value ="\n" +
            "select distinct s.* from collab_team_module_relation ctr,module m, solutions s where m.module_id=ctr.module_id and s.module_id=m.module_id and m.category!='NOT_EXTERNAL' and collaboration_team_id in (\n" +
            "            select distinct ct.collaboration_team_id from user_mapping um,collaboration_team ct, user_map_collab_team_relation r\n" +
            "            where r.collaboration_team_id=ct.collaboration_team_id and um.user_mapping_id=r.user_mapping_id\n" +
            "              and um.customer_id=ct.customer_id and user_id=?1 and um.customer_id in (select customer_id from customer where common_entity_name=?2))" ,nativeQuery = true)
    List<Dashboard>  getSolutionsForUser(String username,String customerName);

    @Query(value ="select distinct s.* from customer_module_relation cmr,customer cs,module m ,solutions s,user_mapping um\n" +
            "where s.module_id=m.module_id and cs.customer_id=cmr.customer_id and um.customer_id=cs.customer_id\n" +
            "  and m.module_id=cmr.module_id and common_entity_name=?1 and um.user_id=?2" ,nativeQuery = true)
    List<Dashboard> getSolutionsForCustomerBasedOnUser(String customerName, String username);

    @Query(value ="select distinct external_id from module where platform='looker' and module_type='canned report' and deleted_date is null" ,nativeQuery = true)
    ArrayList<Integer> getAllActiveCannedFolders();

    @Query(value ="select distinct module_id from module where platform='looker' and module_type='canned report' and deleted_date is null" ,nativeQuery = true)
    ArrayList<BigInteger> getAllActiveCannedFoldersId();

    @Query(value = "select module_id from customer_module_relation where customer_id in (select customer_id from customer where amdm_era_ownr_party_id=?1) and module_id =?2",nativeQuery = true)
    ArrayList<Integer> isModuleRelationExists(String commonEntityId, BigInteger moduleId);

    @Modifying
    @Query(value = "insert into customer_module_relation (customer_id, module_id) values ((select customer_id from customer where amdm_era_ownr_party_id=?1),?2)",nativeQuery = true)
    void insertCustomerRelation(String commonEntityId, BigInteger moduleId);

    @Query(value = "select distinct s.* from module m ,solutions s  where s.module_id=m.module_id and m.category!='N' and m.category!='NOT_EXTERNAL'", nativeQuery = true)
    List<Dashboard> getSolutionsForCustomerUser();

    @Query(value = "    select distinct s.* from customer_module_relation cmr,customer cs,module m ,solutions s  where s.module_id=m.module_id and cs.customer_id=cmr.customer_id and m.module_id=cmr.module_id and m.category!='N' and m.category!='NOT_EXTERNAL' and common_entity_name=?1", nativeQuery = true)
    List<Dashboard> getSolutionForCustomerUser(String customerName);

    @Query(value ="select distinct s.* from collab_team_module_relation ctr,module m, solutions s where m.module_id=ctr.module_id and s.module_id=m.module_id  and m.category!='N' and m.category!='NOT_EXTERNAL' and collaboration_team_id in (\n" +
            "                       select distinct ct.collaboration_team_id from user_mapping um,collaboration_team ct, user_map_collab_team_relation r\n" +
            "                        where r.collaboration_team_id=ct.collaboration_team_id and um.user_mapping_id=r.user_mapping_id\n" +
            "                          and um.customer_id=ct.customer_id and user_id=?1 and um.customer_id in (select customer_id from customer where common_entity_name=?2))" ,nativeQuery = true)
    List<Dashboard> getSolutionsForCustomerUserTeam(String username, String customerName);

    @Query(value = "select distinct s.* from module m ,solutions s  where s.module_id=m.module_id and m.category!='NOT_EXTERNAL'", nativeQuery = true)
    List<Dashboard> getSolutionsForExternalUser();

    @Query(value = "select distinct s.* from module m ,solutions s  where s.module_id=m.module_id", nativeQuery = true)
    List<Dashboard> getSolutions();
}
