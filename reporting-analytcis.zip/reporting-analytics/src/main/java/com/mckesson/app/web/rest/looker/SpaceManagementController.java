package com.mckesson.app.web.rest.looker;

import java.awt.PageAttributes.MediaType;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.service.looker.SpaceManagementService;
import main.java.com.mckesson.app.util.UserAuthentication;
import main.java.com.mckesson.app.vo.ReportItemVo;
import main.java.com.mckesson.app.vo.looker.DashboardVo;
import main.java.com.mckesson.app.vo.looker.FolderVo;
import main.java.com.mckesson.app.vo.looker.LookVo;

/**
 * API endpoint which provides functionality for managing report related content
 * such as folders, reports, and dashboards for a given user.
 */
@RestController
@RequestMapping("/report-management/user")
public class SpaceManagementController {

    Logger logger = LoggerFactory.getLogger(SpaceManagementController.class);

    private final UserAuthentication userAuthentication;
    private final SpaceManagementService spaceManagementService;

    @Autowired
    public SpaceManagementController(UserAuthentication userAuthentication, SpaceManagementService spaceManagementService) {
        this.userAuthentication = userAuthentication;
        this.spaceManagementService = spaceManagementService;
    }

    /**
     * Retrieve collection of manageable 'objects' for current user. This will reflect the entire contents of the current user's
     * folder, including recursively their contents as well. Top level structure returned will be a referene to the user's root
     * space.
     *
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, path = "/objects")
    public ResponseEntity getManageableItems() {
        long startTime = System.currentTimeMillis();
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        ReportItemVo results = spaceManagementService.getFolderStructureForCurrentUser(reportUser);
        logger.debug("Total execution time for operation to retrieve manageable objects is " + (System.currentTimeMillis() - startTime));
        return new ResponseEntity(results, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.DELETE, path = "/folder/{folderId}")
    public ResponseEntity deleteSelectedFolders(@PathVariable(name = "folderId") String folderId) {
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        spaceManagementService.deleteFolder(reportUser, folderId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.DELETE, path = "/report/{reportId}")
    public ResponseEntity deleteSelectedReports(@PathVariable(name = "reportId") String reportId) {
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        spaceManagementService.deleteReport(reportUser, reportId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.DELETE, path = "/dashboard/{dashboardId}")
    public ResponseEntity deleteSelectedDashboards(@PathVariable(name = "dashboardId") String dashboardId) {
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        spaceManagementService.deleteDashboard(reportUser, dashboardId);
        return new ResponseEntity(HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.POST, path = "/folders/children")
    public ResponseEntity createFolder(@RequestBody ReportItemVo folder) {
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        spaceManagementService.createFolder(reportUser, folder.getName(), null);
        logger.debug("Successfully created folder '" + folder.getName() + "'");
        return new ResponseEntity(HttpStatus.CREATED);
    }

    @RequestMapping(method = RequestMethod.POST, path = "/folders/{parentFolderId}/children")
    public ResponseEntity createFolder(@RequestBody ReportItemVo folder, @PathVariable String parentFolderId) {
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        ReportItemVo report = spaceManagementService.createFolder(reportUser, folder.getName(), parentFolderId);
        logger.debug("Successfully created folder '" + folder.getName() + "'");
        return new ResponseEntity(report, HttpStatus.CREATED);
    }

    @RequestMapping(method = RequestMethod.PUT, path = "/folders/{folderId}")
    public ResponseEntity updateFolder(@RequestBody ReportItemVo reportItem, @PathVariable String folderId) {
        logger.debug("Updating existing folder id=>'" + folderId + "'");

        FolderVo folder = new FolderVo();
        folder.setId(reportItem.getId());
        folder.setName(reportItem.getName());
        folder.setParentId(reportItem.getParentId());

        spaceManagementService.updateSpace(folder);

        return new ResponseEntity(folder, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.PUT, path = "/dashboards/{dashboardId}")
    public ResponseEntity updateDashboard(@RequestBody ReportItemVo reportItem, @PathVariable String dashboardId) {
        logger.debug("Updating existing dashboard id=>'" + dashboardId + "'");

        if (dashboardId.equalsIgnoreCase("undefined")) {
            return new ResponseEntity("Valid value for parameter 'folderId' must be passed, where a value of 'undefined' was supplied.", HttpStatus.BAD_REQUEST);
        }

        DashboardVo dashboard = new DashboardVo();
        dashboard.setId(dashboardId);
        dashboard.setTitle(reportItem.getName());
        dashboard.setDescription(reportItem.getDescription());

        spaceManagementService.updateDashboard(dashboard);

        return new ResponseEntity(dashboard, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.PUT, path = "/reports/{lookId}")
    public ResponseEntity updateLook(@RequestBody ReportItemVo reportItem, @PathVariable Long lookId) {
        logger.debug("Updating existing look id=>'" + lookId + "'");

        LookVo look = new LookVo();
        look.setId(lookId);
        look.setTitle(reportItem.getName());
        look.setDescription(reportItem.getDescription());

        spaceManagementService.updateLook(look);

        return new ResponseEntity(look, HttpStatus.OK);
    }

    /**
     * copy look from myreports to teamsreports
     *
     * @param data   {id:id,name: name, description: description,teams2:teams}
     * @param lookId
     * @return
     */
    @RequestMapping(method = RequestMethod.POST, path = "/report/share/{lookId}")
    public Map<String, List<List<String>>> shareReport(@RequestBody Map<String, Object> data, @PathVariable long lookId) {
        logger.debug("Updating existing look id=>'" + lookId + "'");
        ReportUser reportUser = userAuthentication.getLoggedInUser();
        LookVo look = new LookVo();
        look.setId(lookId);
        look.setTitle((String) data.get("title"));
        look.setDescription((String) data.get("description"));
        List<List<String>> teams = (List<List<String>>) data.get("teams");
        List<List<Integer>> teamIds = (List<List<Integer>>) data.get("teamIds");
        Boolean overWriteFlag = (Boolean) data.get("overWriteFlag");
        return spaceManagementService.shareReport(reportUser, look, teams,teamIds, overWriteFlag);
    }


    @RequestMapping(method = RequestMethod.GET, path = "/folder/{parentFolderId}/dashboards", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity listDashboardsForFolder(@PathVariable("parentFolderId") String parentFolderId) {
        logger.debug("Retrieving dashboards for selected folder " + parentFolderId);
        ReportUser reportUser = userAuthentication.getLoggedInUser();

        if (parentFolderId.equalsIgnoreCase("undefined")) {
            return new ResponseEntity("Valid value for parameter 'parent folder id' must be passed, where a value of 'undefined' was supplied.", HttpStatus.BAD_REQUEST);
        }

        List<ReportItemVo> reportItems = spaceManagementService.listDashboardsForFolder(reportUser, parentFolderId);
        return new ResponseEntity(reportItems, HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET, path = "/folder/{parentFolderId}/children", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity listChildrenForFolder(@PathVariable("parentFolderId") String parentFolderId) {
        logger.debug("Retrieving dashboards for selected folder " + parentFolderId);
        ReportUser reportUser = userAuthentication.getLoggedInUser();

        if (parentFolderId.equalsIgnoreCase("undefined")) {
            return new ResponseEntity("Valid value for parameter 'parent folder id' must be passed, where a value of 'undefined' was supplied.", HttpStatus.BAD_REQUEST);
        }

        List<FolderVo> list = spaceManagementService.listChildrenForFolder(reportUser, parentFolderId);
        return new ResponseEntity(list, HttpStatus.OK);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity handlePermissionViolation() {
        return new ResponseEntity(HttpStatus.UNAUTHORIZED);
    }

}
