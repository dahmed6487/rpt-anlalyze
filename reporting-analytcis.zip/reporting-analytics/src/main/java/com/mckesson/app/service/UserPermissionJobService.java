package com.mckesson.app.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import javax.persistence.EntityManager;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import main.java.com.mckesson.app.domain.FileUpload;
import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.domain.customer.Customer;
import main.java.com.mckesson.app.domain.customer.SecurityGroup;
import main.java.com.mckesson.app.repository.FileUploadRepository;
import main.java.com.mckesson.app.repository.admin.CollaborationTeamRepository;
import main.java.com.mckesson.app.repository.customer.CustomerRepository;
import main.java.com.mckesson.app.repository.customer.SecurityGroupRepository;
import main.java.com.mckesson.app.repository.customer.UserMappingRepository;
import main.java.com.mckesson.app.service.looker.CollaborationTeamServiceLooker;
import main.java.com.mckesson.app.service.looker.LookerAdminService;
import main.java.com.mckesson.app.service.looker.SpaceManagementService;
import main.java.com.mckesson.app.util.StringUtils;
import main.java.com.mckesson.app.vo.looker.ContentVo;
import main.java.com.mckesson.app.vo.looker.FolderVo;

@Service
@Transactional
public class UserPermissionJobService {

    private static final Logger LOG = LoggerFactory.getLogger(UserPermissionJobService.class);

    private final CustomerRepository customerRepo;
    private final CollaborationTeamRepository collaborationTeamRepository;
    private final CollaborationTeamServiceLooker collaborationTeamServiceLooker;
    private final LookerAdminService lookerAdminService;
    private final SecurityGroupRepository securityGroupRepository;
    private final UserMappingRepository userMappingRepository;
    private final SpaceManagementService spaceManagementService;
    private final FileUploadRepository fileUploadRepository;
    private final EntityManager entityManager;

    @Value("${appconfig.teamsCleanMode}")
    boolean teamsCleanMode;

    @Value("${looker.sharedFolderId}")
    String sharedFolderId;

    @Autowired
    public UserPermissionJobService(CustomerRepository customerRepo, CollaborationTeamRepository collaborationTeamRepository, CollaborationTeamServiceLooker collaborationTeamServiceLooker, LookerAdminService lookerAdminService, SecurityGroupRepository securityGroupRepository, UserMappingRepository userMappingRepository, SpaceManagementService spaceManagementService, FileUploadRepository fileUploadRepository, EntityManager entityManager) {
        this.customerRepo = customerRepo;
        this.collaborationTeamRepository = collaborationTeamRepository;
        this.collaborationTeamServiceLooker = collaborationTeamServiceLooker;
        this.lookerAdminService = lookerAdminService;
        this.securityGroupRepository = securityGroupRepository;
        this.userMappingRepository = userMappingRepository;
        this.spaceManagementService = spaceManagementService;
        this.fileUploadRepository = fileUploadRepository;
        this.entityManager = entityManager;
    }

    public int usersToCreateCount() {
        return customerRepo.usersToCreateCount();
    }

    public void insertUserProfiles() {
        customerRepo.insertUserProfiles(new Date());
    }


    public void updateUserFunctions() {
        customerRepo.updateUserFunctions();
        customerRepo.updateUserMarketPartition();
        //customerRepo.updateUserBlaEligible();
        customerRepo.updateAccountsCount();
    }


    public int customersToCreateCount() {
        return customerRepo.customersToCreateCount();
    }


    public void insertCustomers() {
        customerRepo.insertCustomers(new Date());
    }

    @Transactional
    public void updateGroupInfo() {
        customerRepo.updateGroupInfo();
    }

    /**
     * bulk insert user mapping which are not exist in user mapping table based customer id and user id
     */
    public void insertUserMappings() {
        userMappingRepository.insertUserMappings(new Date());
    }

    /**
     * To create InternalUsers and BetaUsers groups if not exists
     *
     * TODO Enhancement:  assign this group only to Beta groups
     */
    @Transactional
    public void createInternalUserSecurityGroups() {
        // InternalUsers will have access to all accounts
        GroupVo betaGroupVo = new GroupVo();
        betaGroupVo.setName("BetaUsers");

        try {
            List<Customer> internalUserCustomer = customerRepo.getCustomerByName("BetaUsers");
            if(internalUserCustomer.size() == 0) {
                Customer betaUsers = new Customer();
                betaUsers.setPlatformId("P");
                betaUsers.setCommonEntityName("BetaUsers");
                betaUsers.setCommonEntityId("0");
                betaUsers.setCommonGroupId("0");
                betaUsers.setCommonGroupName("BetaUsers");
                betaUsers.setCreatedBy("System");
                betaUsers.setTotalAccounts("0");
                betaUsers.setCreatedDate(new Date());

                customerRepo.save(betaUsers);

                betaGroupVo = lookerAdminService.createGroup(betaGroupVo);

                SecurityGroup betaGroup = new SecurityGroup();
                betaGroup.setPlatformId("P");
                betaGroup.setCustomerId(betaUsers.getCustomerId());
                betaGroup.setName(betaGroupVo.getName());
                betaGroup.setExternalId(betaGroupVo.getId());
                betaGroup.setCreatedBy("SYSTEM");
                betaGroup.setCreatedDate(new Date());

                securityGroupRepository.save(betaGroup);

                collaborationTeamServiceLooker.giveGroupAccessParent(betaGroupVo.getId().toString());
            }
        } catch (Exception e) {
            LOG.error("Error occurred while insert BetaUsers SecurityGroup or creating BetaUsers SecurityGroup in looker  Group-->"+ betaGroupVo.getId()+"  GroupName-->"+ betaGroupVo.getName()+" getMessage--> "+e.getMessage());
            insertErrorMsg("Error occurred while insert BetaUsers SecurityGroup or creating BetaUsers SecurityGroup in looker  Group-->"+ betaGroupVo.getId()+"  GroupName-->"+ betaGroupVo.getName()+" getMessage--> "+e.getMessage(),"CreateInternalUsers");
        }

        // BetaUsers will have access to only the beta Customers
        GroupVo groupVo = new GroupVo();
        groupVo.setName("InternalUsers");

        try {
            List<Customer> internalUserCustomer = customerRepo.getCustomerByName("InternalUsers");
            if (internalUserCustomer.size() == 0) {
                Customer internalUsers = new Customer();
                internalUsers.setPlatformId("P");
                internalUsers.setCommonEntityName("InternalUsers");
                internalUsers.setCommonEntityId("0");
                internalUsers.setCommonGroupId("0");
                internalUsers.setCommonGroupName("InternalUsers");
                internalUsers.setCreatedBy("System");
                internalUsers.setTotalAccounts("0");
                internalUsers.setCreatedDate(new Date());
                internalUsers.setDeletedDate(new Date());

                customerRepo.save(internalUsers);

                groupVo = lookerAdminService.createGroup(groupVo);

                SecurityGroup internalGroup = new SecurityGroup();
                internalGroup.setPlatformId("P");
                internalGroup.setCustomerId(internalUsers.getCustomerId());
                internalGroup.setName(groupVo.getName());
                internalGroup.setExternalId(groupVo.getId());
                internalGroup.setCreatedBy("SYSTEM");
                internalGroup.setCreatedDate(new Date());
                internalGroup.setDeletedDate(new Date());

                securityGroupRepository.save(internalGroup);
                collaborationTeamServiceLooker.giveGroupAccessParent(groupVo.getId().toString());
            }
        } catch (Exception e) {
            LOG.error("Error occurred while insert InternalUsers SecurityGroup or creating InternalUsers SecurityGroup in looker Group-->" + groupVo.getId() + " GroupName-->" + groupVo.getName() + " getMessage--> " + e.getMessage());
            insertErrorMsg("Error occurred while insert InternalUsers SecurityGroup or creating InternalUsers SecurityGroup in looker Group-->" + groupVo.getId() + " GroupName-->" + groupVo.getName() + " getMessage--> " + e.getMessage(), "CreateInternalUsers");
        }
    }

    /**
     * First it will loop all the customer which are not created in looker and following steps executed for each team or customer
     * 1.Create new group
     */

    //ToDO add: check external id is null then create group and update group table
    @Transactional
    public void insertSecurityGroups() {
        List<Customer> customers = customerRepo.getCustomerSecurityGroupsToCreate();
        customers.forEach(customer -> {
            GroupVo groupVo = new GroupVo();
            try {
                LOG.info("Creating SecurityGroup for customer id " + customer.getAmdmEraOwnrName());
                groupVo.setName(customer.getAmdmEraOwnrName());
                groupVo = lookerAdminService.createGroup(groupVo);

                entityManager.createNativeQuery("insert into security_group(platform, customer_id, name, external_id, created_by, created_date) " +
                        " VALUES ( :1, :2, :3, :4, :5,:6)")
                        .setParameter("1", "P")
                        .setParameter("2", customer.getCustomerId())
                        .setParameter("3", groupVo.getName())
                        .setParameter("4", groupVo.getId())
                        .setParameter("5", "SYSTEM")
                        .setParameter("6", new Date()).executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error("Error occurred while insert SecurityGroup or creating SecurityGroup in looker  Group-->"+groupVo.getId()+"  GroupName-->"+groupVo.getName()+" getMessage--> "+e.getMessage());
                insertErrorMsg("Error occurred while insert SecurityGroup or creating SecurityGroup in looker  Group-->"+groupVo.getId()+"  GroupName-->"+groupVo.getName()+" getMessage--> "+e.getMessage(),"lookerAdminService.createGroup");
            }
        });

        List<SecurityGroup> missingGroupIds = securityGroupRepository.getMissingGroupIdGroups();
        missingGroupIds.forEach(securityGroup -> {
            GroupVo groupVo = new GroupVo();
            try {
                groupVo.setName(securityGroup.getName());
                groupVo = lookerAdminService.createGroup(groupVo);
                securityGroup.setExternalId(groupVo.getId());
                securityGroup.setCreatedBy("SYSTEM");
                securityGroup.setCreatedDate(new Date());
                securityGroup.setUpdatedBy("SYSTEM");
                securityGroup.setUpdatedDate(new Date());
                securityGroupRepository.saveAndFlush(securityGroup);
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error("Error occurred while updating SecurityGroup  Group-->"+groupVo.getId()+"  GroupName-->"+groupVo.getName()+" getMessage--> "+e.getMessage());
                insertErrorMsg("Error occurred while updating SecurityGroup  Group -->"+groupVo.getId()+"  GroupName-->"+groupVo.getName()+" getMessage--> "+e.getMessage(),"lookerAdminService.createGroup");
            }
        });

    }

    @Transactional
    public void insertCollaborationTeam() {
        String teamsFolderId=createAndCleanTeamFolder();
        List<Customer> customers = customerRepo.getCustomersToCreate();
        customers.forEach(customer -> {
            FolderVo folderVo = new FolderVo();
            ContentVo content = new ContentVo();
            try {
                LOG.info("Creating CollaborationTeam for customer id " + customer.getAmdmEraOwnrName());
                List<FolderVo> folderVos=collaborationTeamServiceLooker.searchSharedFoldersByNameInParent("1",customer.getAmdmEraOwnrName());
                if(folderVos.isEmpty()) {
                    folderVo = collaborationTeamServiceLooker.createFolder(teamsFolderId, customer.getAmdmEraOwnrName());
                    content.setContentMetadataId(folderVo.getContentMetadataId());
                    content.setInherits(false);
                    collaborationTeamServiceLooker.updateContentAccess(content);
                    collaborationTeamServiceLooker.updateFolder("1", folderVo.getId()); //move folder back to parent
                    entityManager.createNativeQuery("insert into collaboration_team(platform, customer_id, name, external_id, created_by, created_date) " +
                                    " VALUES ( :1, :2, :3, :4, :5,:6)")
                            .setParameter("1", "P")
                            .setParameter("2", customer.getCustomerId())
                            .setParameter("3", customer.getAmdmEraOwnrName())
                            .setParameter("4", folderVo.getId())
                            .setParameter("5", "SYSTEM")
                            .setParameter("6", new Date()).executeUpdate();
                } else {
                    collaborationTeamServiceLooker.updateFolder(teamsFolderId, folderVo.getId()); //move folder Teams folder
                    content.setContentMetadataId(folderVo.getContentMetadataId());
                    content.setInherits(false);
                    collaborationTeamServiceLooker.updateContentAccess(content);
                    collaborationTeamServiceLooker.updateFolder("1", folderVo.getId()); //move folder back to parent
                    entityManager.createNativeQuery("insert into collaboration_team(platform, customer_id, name, external_id, created_by, created_date) " +
                                    " VALUES ( :1, :2, :3, :4, :5,:6)")
                            .setParameter("1", "P")
                            .setParameter("2", customer.getCustomerId())
                            .setParameter("3", customer.getAmdmEraOwnrName())
                            .setParameter("4", folderVos.get(0).getId())
                            .setParameter("5", "SYSTEM")
                            .setParameter("6", new Date()).executeUpdate();
                }
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error("Error occurred while insertUserMappingCollaborationTeam or creating folder in looker  folderId-->" + folderVo.getId() + "  CommonEntityName-->" + customer.getCommonEntityName() + " getMessage--> " + e.getMessage());
                insertErrorMsg("Error occurred while insertUserMappingCollaborationTeam or creating folder in looker  folderId-->" + folderVo.getId() + "  CommonEntityName-->" + customer.getCommonEntityName() + " getMessage--> " + e.getMessage(), "collaborationTeamServiceLooker.createFolder");
            }
        });

        List<CollaborationTeam> missingTeamIds = collaborationTeamRepository.getMissingCollaborationTeam();
        missingTeamIds.forEach(collaborationTeam -> {
            FolderVo folderVo = new FolderVo();
            ContentVo content = new ContentVo();
            try {
                folderVo = collaborationTeamServiceLooker.createFolder(teamsFolderId, collaborationTeam.getName());
                content.setContentMetadataId(folderVo.getContentMetadataId());
                content.setInherits(false);
                collaborationTeamServiceLooker.updateContentAccess(content);
                collaborationTeamServiceLooker.updateFolder("1",folderVo.getId()); //move folder back to parent
                collaborationTeam.setExternalId(Long.valueOf(folderVo.getId()));
                collaborationTeam.setCreatedDate(new Date());
                collaborationTeam.setUpdatedBy("SYSTEM");
                collaborationTeam.setUpdatedDate(new Date());
                collaborationTeamRepository.saveAndFlush(collaborationTeam);
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error("Error occurred while insertUserMappingCollaborationTeam or updating folder in looker  folderId-->" + folderVo.getId() + "  Team Name-->" + collaborationTeam.getName() + " getMessage--> " + e.getMessage());
                insertErrorMsg("Error occurred while insertUserMappingCollaborationTeam or updating folder in looker  folderId-->" + folderVo.getId() + "  Team Name-->" + collaborationTeam.getName() + " getMessage--> " + e.getMessage(), "collaborationTeamServiceLooker.createFolder");
            }
        });
    }


    /**
     * 1. Fetch Folder for Customer
     * 2. Change Content Access on Folder to Custom list of users with "inherits": false
     * 3. Remove content access to Folder for Groups (A newly created Folder automatically inherits the content access settings of the parent folder)
     * 4. Grant Groups view access to folder
     * ~~~~~~~~~~~ new changes~~~~~~~~
     * for new teams:
     *        1. Created folder under teams not under parent
     *        2. set inherits to false and Assign appropriate group
     *        3. move folder under parent
     * For existing folders
     *        1.if yes--> pick the team and move to Teams folder
     *        2. Assign appropriate group and move back to parent

     */
    @Transactional
    public void collaborationTeamToGroupRelation() {
        Long internalUsersGroupId = securityGroupRepository.getSecurityGroupByName("InternalUsers").get(0).getExternalId();
        Long betaUsersGroupId = securityGroupRepository.getSecurityGroupByName("BetaUsers").get(0).getExternalId();
        List<CollaborationTeam> teams;
        String teamsFolderId=createAndCleanTeamFolder();
        if(teamsCleanMode){
            teams=collaborationTeamRepository.getAllCollabTeams();
        } else{
             teams = collaborationTeamRepository.getNewCollabTeams();
        }

        LOG.info("Found " + teams.size() + " Teams to permission in Looker");
        teams.forEach(team -> {
            FolderVo folderVo = new FolderVo();
            GroupVo groupVo;
            LOG.info("Adding Team Folder permissions for Customer " + team.getCustomerId() + " + external_id [" + team.getExternalId() + "]");
            try {
                folderVo = collaborationTeamServiceLooker.getFolder(StringUtils.stringOrNull(team.getExternalId()));
                ContentVo content = new ContentVo();
                content.setInherits(false);
                if (folderVo == null) {
                    folderVo = collaborationTeamServiceLooker.createFolder(teamsFolderId, team.getName()); /// created under new teams folder
                    content.setContentMetadataId(folderVo.getContentMetadataId());
                    content.setInherits(false);
                    collaborationTeamServiceLooker.updateContentAccess(content);
                } else {
                    content.setContentMetadataId(folderVo.getContentMetadataId());

                        ContentVo currentAccess = collaborationTeamServiceLooker.getContentAccess(content);
                        // check if folder is still set to inherits = true
                        if (currentAccess.getInherits()) {
                            // move under teams
                            collaborationTeamServiceLooker.updateFolder(teamsFolderId, folderVo.getId());
                            content.setInherits(false);
                            collaborationTeamServiceLooker.updateContentAccess(content);

                        } else {
                            // check how many contents if more than 5 --> clean
                            if (collaborationTeamServiceLooker.allContentAccess(content).size() > 5) {
                                collaborationTeamServiceLooker.updateFolder(teamsFolderId, folderVo.getId());
                                content.setInherits(false);
                                collaborationTeamServiceLooker.updateContentAccess(content);
                            }
                        }
                }
                    //move folder back to parent
                collaborationTeamServiceLooker.updateFolder("1",folderVo.getId());
                    // re-add permissions
                    groupVo = lookerAdminService.getGroupByName(team.getName());
                    if (groupVo != null) {
                        collaborationTeamServiceLooker.giveGroupAccessParent(groupVo.getId().toString());
                        ContentVo teamContent = new ContentVo();
                        teamContent.setContentMetadataId(folderVo.getContentMetadataId());
                        teamContent.setPermissionType("edit");
                        teamContent.setGroupId(groupVo.getId().toString());
                        collaborationTeamServiceLooker.giveGroupAccess(teamContent);

                        teamContent.setGroupId(internalUsersGroupId.toString());
                        collaborationTeamServiceLooker.giveGroupAccess(teamContent);
                        if(customerRepo.getCustomerIdByCustomerNameForBeta(team.getName())!=null){
                            teamContent.setGroupId(betaUsersGroupId.toString());
                            collaborationTeamServiceLooker.giveGroupAccess(teamContent);
                        }
                    }
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error("Error occurred while collaborationTeamToGroupRelation or creating folder in looker  folderId-->"+folderVo.getId()+"  team -->"+team.getName()+" getMessage--> "+e.getMessage());
                insertErrorMsg("Error occurred while collaborationTeamToGroupRelation or creating folder in looker  folderId-->"+folderVo.getId()+"  team -->"+team.getName()+" getMessage--> "+e.getMessage(),"changeContentAccess");
            }
        });
    }

    @Transactional
    public void insertUserMapCollabTeamRelation() {
       try {
           entityManager.createNativeQuery("insert into user_map_collab_team_relation (collaboration_team_id,user_mapping_id,created_by, created_date)\n" +
                   "select distinct ct.collaboration_team_id, um.user_mapping_id,'SYSTEM',:1 from user_mapping um,collaboration_team ct where um.customer_id=ct.customer_id and ct.external_id is not null and ct.deleted_date is null\n" +
                   " and ct.created_by=um.created_by and ct.created_by='SYSTEM' and not exists(select 1 from user_map_collab_team_relation r where r.user_mapping_id=um.user_mapping_id and r.collaboration_team_id=ct.collaboration_team_id)")
                   .setParameter("1", new Date()).executeUpdate();
       } catch (Exception e) {
           LOG.error(e.getMessage(), e);
       }
    }

    @Transactional
    public void insertUserMapSecurityGroupRelation() {
        entityManager.createNativeQuery("insert into user_map_security_group_relation (security_group_id, user_mapping_id, created_by, created_date)\n" +
                "select ct.security_group_id, um.user_mapping_id, 'SYSTEM', :1 from user_mapping um,security_group ct where um.customer_id=ct.customer_id and ct.external_id is not null and ct.deleted_date is null\n" +
                " and ct.created_by=um.created_by and ct.created_by='SYSTEM'\n" +
                "and not exists(select 1 from user_map_security_group_relation r where r.user_mapping_id=um.user_mapping_id and r.security_group_id=ct.security_group_id) ")
                .setParameter("1", new Date()).executeUpdate();
    }

    public void updateAccessCannedReports() {
        List<FolderVo> folderVo = null;
        List<SecurityGroup> securityGroupList = securityGroupRepository.getNewSecurityGroups();
        if(securityGroupList.size() > 0) {
            try {
                folderVo = collaborationTeamServiceLooker.getFolderChildren("1", sharedFolderId);
            } catch (Exception e) {
                e.printStackTrace();
            }

            ContentVo sharedContentVo = new ContentVo();
            sharedContentVo.setContentMetadataId("1");
            sharedContentVo.setPermissionType("view");

            List<FolderVo> finalList = folderVo;
            securityGroupList.forEach(group -> {
                LOG.info("Adding content for group " + group.getExternalId());
                try {
                    sharedContentVo.setGroupId(group.getExternalId().toString());
                    collaborationTeamServiceLooker.giveGroupAccess(sharedContentVo);
                } catch (Exception e) {
                    e.printStackTrace();
                    LOG.error("Error occurred while Canned Reports folderId-->1 groupName " + group.getName() + "getMessage--> " + e.getMessage());
                    insertErrorMsg("Error occurred while Canned Reports folderId-->1 groupName " + group.getName() + "getMessage--> " + e.getMessage(), "collaborationTeamServiceLooker.CannedReportsGroupAccess");
                }

                assert finalList != null;
                for (FolderVo child : finalList) {
                    ContentVo contentVo = new ContentVo();
                    contentVo.setContentMetadataId(child.getContentMetadataId());
                    contentVo.setGroupId(group.getExternalId().toString());
                    contentVo.setPermissionType("view");
                    try {
                        collaborationTeamServiceLooker.giveGroupAccess(contentVo);
                    } catch (Exception e) {
                        e.printStackTrace();
                        LOG.error("Error occurred while Canned Reports  folderId-->" + child.getId() + "  folderName -->" + child.getName() + "  groupName " + group.getName() + "getMessage--> " + e.getMessage());
                        insertErrorMsg("Error occurred while Canned Reports  folderId-->" + child.getId() + "  folderName -->" + child.getName() + "  groupName " + group.getName() + "getMessage--> " + e.getMessage(), "collaborationTeamServiceLooker.CannedReportsGroupAccess");
                    }
                }
            });
        }
    }

    public void insertErrorMsg(String errorMsg, String errorType) {
        entityManager.createNativeQuery("INSERT INTO reporting_analytics.application_log (event_data, user_id, event_type) " +
                " VALUES ( :1, :2, :3)")
                .setParameter("1", errorMsg)
                .setParameter("2", "JOB")
                .setParameter("3", errorType).executeUpdate();
        try {
            entityManager.getTransaction().commit();
        } catch (Exception ignored) { }
    }

    public String createAndCleanTeamFolder() {
            FolderVo folderVo = new FolderVo();
            try {
                    folderVo = collaborationTeamServiceLooker.createFolder("1", "Teams");
                    ContentVo content = new ContentVo();
                    content.setInherits(false);
                    content.setContentMetadataId(folderVo.getContentMetadataId());
                    collaborationTeamServiceLooker.updateContentAccess(content);
                    collaborationTeamServiceLooker.deleteContentAccess(content);
                    if(collaborationTeamServiceLooker.allContentAccess(content).size()>0){
                        collaborationTeamServiceLooker.deleteContentAccess(content);
                    }
           return folderVo.getId();
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error("Error occurred while cleanTeamsFolder or creating folder in looker  folderId-->"+folderVo.getId()+" getMessage--> "+e.getMessage());
            }
        return null;
    }
    /**
     * Get all invalid customers
     *     based on the customer ID get user mapping id
     *            based on user mapping id clean colab teams and security groups mappings and module relation id
     * delete security group and colab team based on the customer id
     * delete customer
     */
    @Transactional
    public void cleanInvalidCustomers() {
        if (customerRepo.getTotalCountOfDimCustAcctCurr() > 1000) // Run cleanup only if v_if_ra_dim_cust_acct_curr count is greater than 1000
        {
            List<Customer> invalidCustomers = customerRepo.getInvalidCustomers();
        invalidCustomers.forEach(customer -> {
            try {
                collaborationTeamRepository.deleteColabTeamMapping(customer.getCustomerId());
                securityGroupRepository.deleteSecurityTeamMapping(customer.getCustomerId());
                securityGroupRepository.deleteModuleMapping(customer.getCustomerId());
                userMappingRepository.deleteUserMapping(customer.getCustomerId());
                Optional<List<CollaborationTeam>> collaborationTeam = collaborationTeamRepository.findByCustomerId(customer.getCustomerId());
                if (collaborationTeam.isPresent()) {
                    try {
                        if (!collaborationTeamServiceLooker.searchContentInFolder(collaborationTeam.get().get(0).getExternalId().toString())) { // delete Looker folder only if it empty
                            collaborationTeamServiceLooker.deleteTeams(collaborationTeam.get().get(0).getExternalId());
                        }
                    } catch (Exception ignored) {
                    }
                }
                collaborationTeamRepository.deleteColabTeam(customer.getCustomerId());
                List<SecurityGroup> securityGroup = securityGroupRepository.getSecurityGroupByCustomerId(customer.getAmdmEraOwnrPartyId());
                if (securityGroup.size() > 0) {
                    try {
                        collaborationTeamServiceLooker.deleteGroup(securityGroup.get(0).getExternalId());
                    } catch (Exception ignored) {
                    }
                }
                securityGroupRepository.deleteSecurity(customer.getCustomerId());
                List<FileUpload> fileUpload = fileUploadRepository.getLoadFileIdsByCustomer(customer.getCustomerId());
                for (FileUpload upload : fileUpload) {
                    fileUploadRepository.deleteFileDataAccount(upload.getLoadFileId());
                    fileUploadRepository.deleteFileData(upload.getLoadFileId());
                }
                fileUploadRepository.deleteFileByCustomer(customer.getCustomerId());
                customerRepo.deleteCustomerById(customer.getCustomerId());
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error("Error occurred while cleanInvalidCustomers    getMessage--> " + e.getMessage());
            }
        });
    }
    }

    /**
     * $$$$$$ Deleting only Mapping $$$$$$     *
     * delete from user mapping where common entity id not in customer_whitelist for a user
     * Get all invalid user mapping
     *            based on user mapping id clean colab teams and security groups mappings and module relation id
     */

    public void cleanInvalidUserMapping() {
        List<Customer> invalidUserMapping = customerRepo.getInvalidUserMapping();
        invalidUserMapping.forEach(customer -> {
            try {
            collaborationTeamRepository.deleteColabTeamMapping(customer.getCustomerId());
            securityGroupRepository.deleteSecurityTeamMapping(customer.getCustomerId());
            securityGroupRepository.deleteModuleMapping(customer.getCustomerId());
            userMappingRepository.deleteUserMapping(customer.getCustomerId());
            } catch (Exception ignored) { }
        });
    }

    public void updateCustomerInfo() {

        entityManager.createNativeQuery(" UPDATE customer up join (SELECT amdm_era_ownr_party_id, amdm_era_ownr_name FROM  v_if_ra_dim_cust_acct_curr\n" +
                        " where amdm_era_ownr_party_id is not null GROUP BY amdm_era_ownr_party_id) spf on up.amdm_era_ownr_party_id=spf.amdm_era_ownr_party_id set up.amdm_era_ownr_name=spf.amdm_era_ownr_name, up.updated_date=:1, up.updated_by='SYSTEM'\n" +
                        " where up.amdm_era_ownr_name!=spf.amdm_era_ownr_name").setParameter("1", new Date()).executeUpdate();
        try {
            entityManager.getTransaction().commit();
        } catch (Exception ignored) { }

        List<Customer> getUpdateCustomerInfo = customerRepo.getNameChangedCustomerList();


        getUpdateCustomerInfo.forEach(customer -> {
            GroupVo groupVo;
            FolderVo folderVo;
            CollaborationTeam collaborationTeam;
            SecurityGroup securityGroup;

            collaborationTeam = collaborationTeamRepository.getTeamByCustomerId(customer.getCustomerId());
            folderVo=collaborationTeamServiceLooker.renameFolderName(collaborationTeam.getExternalId(), customer.getCommonEntityName());
            if(folderVo!=null) {
                collaborationTeam.setUpdatedBy("SYSTEM");
                collaborationTeam.setUpdatedDate(new Date());
                collaborationTeam.setName(customer.getCommonEntityName());
                collaborationTeamRepository.saveAndFlush(collaborationTeam);
            }
            securityGroup = securityGroupRepository.getSecurityGroupByNameByCustomerId(customer.getCustomerId());
            groupVo=lookerAdminService.renameGroupName(securityGroup.getExternalId(), customer.getCommonEntityName());
            if(groupVo!=null) {
                securityGroup.setUpdatedBy("SYSTEM");
                securityGroup.setUpdatedDate(new Date());
                securityGroup.setName(customer.getCommonEntityName());
                securityGroupRepository.saveAndFlush(securityGroup);
            }
        });
    }

    public void insertSalesUserProfiles() {
        customerRepo.insertSalesUserProfiles(new Date());
        customerRepo.updateUserProfilesRoleToSalesUser(new Date());
    }

    public void insertSalesUserMappings() {
        userMappingRepository.insertSalesUserMappings(new Date());
    }

    /**
     * Get amdm customer list
     * Find common entity count for AMDM
     *    If one to one updated the AMDM info
     *    if one to many insert as new customer
     */
    public void switchToAMDMOwnerId() {
        List<String> getAMDMCustomersList=  customerRepo.getAMDMCustomersList();
        getAMDMCustomersList.forEach(updatedCustomer -> {
            List<String> getCommonEntityCount=  customerRepo.getCommonEntityCount(updatedCustomer);
            if(getCommonEntityCount.size()==1){
                customerRepo.updateAMDMCustomer(updatedCustomer);
            } else {
                customerRepo.insertAMDMCustomers(new Date(),updatedCustomer);
            }
        });
    }

    /**
     * Rename the looker Folders & Group based on AMDM name for only one to one
     *  one to many it will be inserted as part daily job     *
     */
    public void updateLookerFolderGroupNames() {
        List<Customer> getAMDMCustomersListForTeams = customerRepo.getTeamsForRename();
        getAMDMCustomersListForTeams.forEach(updatedCustomer -> {
            try {
                List<Customer> getCommonEntityList = customerRepo.getCommonEntityList(updatedCustomer.getAmdmEraOwnrName());
                   if(getCommonEntityList.size()==1){
                           try {
                                   FolderVo folderVo;
                                   CollaborationTeam collaborationTeam;
                                   collaborationTeam = collaborationTeamRepository.getTeamByCustomerId(getCommonEntityList.get(0).getCustomerId());
                                   folderVo=collaborationTeamServiceLooker.renameFolderName(collaborationTeam.getExternalId(), updatedCustomer.getAmdmEraOwnrName());
                                   if(folderVo!=null) {
                                       collaborationTeam.setUpdatedBy("AMDM_SYSTEM");
                                       collaborationTeam.setUpdatedDate(new Date());
                                       collaborationTeam.setName(updatedCustomer.getAmdmEraOwnrName());
                                       collaborationTeamRepository.saveAndFlush(collaborationTeam);
                                   } else{
                                       insertErrorMsg("Error occurred while updating FolderName in updateLookerFolderGroupNames  folderId-->" + collaborationTeam.getExternalId() + "  folderName -->" +updatedCustomer.getAmdmEraOwnrName(), "renameFolder");
                                   }
                           } catch (Exception e) {
                               e.printStackTrace();
                               LOG.error("Error occurred while renaming    getMessage--> " + e.getMessage() +" getCustomerId "+getCommonEntityList.get(0).getCustomerId());
                           }
                       try {
                       GroupVo groupVo;
                       SecurityGroup securityGroup;

                       securityGroup = securityGroupRepository.getSecurityGroupByNameByCustomerId(getCommonEntityList.get(0).getCustomerId());
                       groupVo=lookerAdminService.renameGroupName(securityGroup.getExternalId(), updatedCustomer.getAmdmEraOwnrName());
                       if(groupVo!=null) {
                           securityGroup.setUpdatedBy("AMDM_SYSTEM");
                           securityGroup.setUpdatedDate(new Date());
                           securityGroup.setName(updatedCustomer.getAmdmEraOwnrName());
                           securityGroupRepository.saveAndFlush(securityGroup);
                       } else{
                           assert groupVo != null;
                           insertErrorMsg("Error occurred while renaming groupId-->" + groupVo.getId() + "  folderName -->" +updatedCustomer.getAmdmEraOwnrName(), "renameGroup");
                       }
                   } catch (Exception e) {
                    e.printStackTrace();
                    LOG.error("Error occurred while renaming    getMessage--> " + e.getMessage() +" getCustomerId "+getCommonEntityList.get(0).getCustomerId());
                }
             }
            } catch (Exception e) {
                e.printStackTrace();
                LOG.error("Error occurred while getAMDMCustomersListForTeams    getMessage--> " + e.getMessage());
            }
        });
        }

    /**
     * move folders if contains looks and dashboard
     *   mark with updated_by="move"
     *    Note: do not delete these folders from looker as part of clean up process
     */
    public void moveContentFromMultipleFolders() {
        List<Customer> list = customerRepo.getMultipleList();
        list.forEach(customer -> {
            List<String> getCommonEntityList = customerRepo.getMultipleCommonEntityList(customer.getAmdmEraOwnrPartyId());
            getCommonEntityList.forEach(commonEntity -> {
                try {
                    List<FolderVo> folderVos=collaborationTeamServiceLooker.searchSharedFoldersByNameInParent("1",commonEntity);
                    folderVos.forEach(folderVo -> {
                        try {
                            if(collaborationTeamServiceLooker.searchContentInFolder(folderVo.getId())){
                                List<FolderVo> amdmFolderDetails=collaborationTeamServiceLooker.searchSharedFoldersByNameInParent("1",customer.getAmdmEraOwnrName());
                                ContentVo content = new ContentVo();
                                content.setContentMetadataId(folderVo.getContentMetadataId());
                                content.setInherits(true);
                                collaborationTeamServiceLooker.updateContentAccess(content);
                                collaborationTeamServiceLooker.updateFolder(amdmFolderDetails.get(0).getId(), folderVo.getId());
                                collaborationTeamRepository.updateMovedFolder("MOVED",folderVo.getId());
                                customerRepo.updateMovedCustomer(folderVo.getId());
                            } else {
                                collaborationTeamServiceLooker.deleteTeams(Long.valueOf(folderVo.getId()));
                                collaborationTeamServiceLooker.removeGroup(commonEntity);
                                collaborationTeamRepository.updateMovedFolder("DELETED",folderVo.getId());
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }

            });
        });


    }

    public void updateModuleRelation() {
        List<String> customerIds = customerRepo.getModuleRelationCustomerIds();
        customerIds.forEach(customerId -> {
             Customer amdmCustomerId=customerRepo.getAMDMCustomersForModuleRelation(customerId);
             if(amdmCustomerId!=null)
             customerRepo.updateModuleRelationCustomerId(customerId,amdmCustomerId.getCustomerId());
        });
    }

    public void fileUploadCustomerIds() {
        List<String> customerIds = customerRepo.getfileUploadCustomerIds();
        customerIds.forEach(customerId -> {
            Customer amdmCustomerId=customerRepo.getAMDMCustomersForModuleRelation(customerId);
            if(amdmCustomerId!=null)
            customerRepo.updatefileUploadCustomerId(customerId,amdmCustomerId.getCustomerId());
        });
    }

    public void removeUnknowns() {
        List<CollaborationTeam> getTeamNames = collaborationTeamRepository.getUnknownsTeams();
        getTeamNames.forEach(team -> {
            try {
                List<FolderVo> folderName=collaborationTeamServiceLooker.searchSharedFoldersByNameInParent("1",team.getName());
                if(!folderName.isEmpty()) {
                    if (!collaborationTeamServiceLooker.searchContentInFolder(folderName.get(0).getId())) {
                        collaborationTeamServiceLooker.deleteTeams(Long.valueOf(folderName.get(0).getId()));
                        collaborationTeamServiceLooker.removeGroup(team.getName());
                        collaborationTeamRepository.updateMovedFolder("DELETED", folderName.get(0).getId());
                    }
                } else
                    collaborationTeamRepository.updateMovedFolderWithName("DELETED",team.getName());
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

