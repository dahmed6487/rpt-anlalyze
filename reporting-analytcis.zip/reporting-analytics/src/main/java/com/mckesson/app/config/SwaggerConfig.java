package com.mckesson.app.config;

import org.omg.CORBA.Environment;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Configuration to build swagger documentation for all the rest end-points
 * defined under the package "com.mckesson.app.web.rest". Sample URL to access
 * documentation would be "http://localhost:8080/swagger-ui.html"
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {

    private final Environment env;

    public SwaggerConfig(Environment env) {
        this.env = env;
    }

    @Bean
    public Docket api() {

        ApiInfoBuilder apiInfoBuilder = new ApiInfoBuilder();
        apiInfoBuilder
                .contact(new Contact(env.getProperty("mckesson.swagger.contact.name"), "",
                        env.getProperty("mckesson.swagger.contact.email")))
                .description(env.getProperty("mckesson.swagger.description"));

        return new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfoBuilder.build()).select()
                .apis(RequestHandlerSelectors.basePackage("com.mckesson.app.web.rest")).paths(PathSelectors.any())
                .build();
    }
}