package com.mckesson.app.service.looker;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import javax.transaction.Transactional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.domain.admin.Module;
import main.java.com.mckesson.app.domain.looker.Dashboard;
import main.java.com.mckesson.app.repository.looker.DashboardRepository;
import main.java.com.mckesson.app.service.admin.ModuleService;
import main.java.com.mckesson.app.service.customer.CustomerService;
import main.java.com.mckesson.app.vo.ReportItemVo;
import main.java.com.mckesson.app.vo.looker.DashboardVo;

@Service
@Transactional
public class DashboardJobService {

    private final Logger logger = LoggerFactory.getLogger(DashboardJobService.class);

    private final SpaceManagementService spaceManagementService;
    private final LookerService lookerService;
    private final ModuleService moduleService;
    private final DashboardRepository dashboardRepository;

    @Autowired
    public DashboardJobService(SpaceManagementService spaceManagementService, LookerService lookerService, ModuleService moduleService, DashboardRepository dashboardRepository, CustomerService customerService) {
        this.spaceManagementService = spaceManagementService;
        this.lookerService = lookerService;
        this.moduleService = moduleService;
        this.dashboardRepository = dashboardRepository;
    }

    /**
     * "0 0 4 * * *"  // midnight everyday
     */
    @Scheduled(cron = "${appconfig.dashboardJobCron}")
    public void updateSolutionsTable() {
        logger.debug("Starting updateSolutionsTable job");

        ArrayList<Integer> folderIds = dashboardRepository.getAllActiveCannedFolders();

        logger.debug("Processing folders");

        for (Integer folderId : folderIds) {
            logger.debug("Processing folder ID: {}", folderId);
            logger.debug("Getting dashboard descriptions for each dashboard in folder: {}", folderId);
            Optional<List<DashboardVo>> optionalDashboardDescriptionsForFolder = lookerService.getDashboardDescriptions(folderId.toString());
            List<ReportItemVo> reportItems = spaceManagementService.listDashboardsForFolderDashboardJobService(folderId.toString());

            if (optionalDashboardDescriptionsForFolder.isPresent()) {
                List<DashboardVo> dashboardDescriptions = optionalDashboardDescriptionsForFolder.get();
                logger.debug("Dashboard descriptions were found: {}", dashboardDescriptions.toString());
                logger.debug("Getting dashboards for folder: {}", folderId);
                logger.debug("Dashboards were found: {}", reportItems.toString());
                for (ReportItemVo report : reportItems) {
                    String description = getDashboardDescriptionById(dashboardDescriptions, report.getId());
                    logger.debug("Getting module object for folder: {}", folderId);
                    Optional<Module> optionalModule = moduleService.getModuleByFolderId(folderId.toString());

                    if (optionalModule.isPresent()) {
                        if(description!=null) {
                            Module module = optionalModule.get();
                            logger.debug("Module was found: {}", module);
                            Dashboard dashboard = new Dashboard();
                            dashboard.setId(Integer.parseInt(report.getId()));
                            dashboard.setName(report.getName());
                            dashboard.setDescription(description);
                            dashboard.setModuleId(Integer.parseInt(String.valueOf(module.getModuleId())));
                            logger.debug("Saving dashboard {}", dashboard.toString());
                            dashboardRepository.save(dashboard);
                            logger.debug("Saved!");
                        }
                    } else {
                        logger.warn("Module objects were not found for {}", folderId);
                    }
                }
            } else {
                logger.warn("Dashboard descriptions were not found for {}", folderId);
            }
        }
        logger.debug("Done!");
    }

    private String getDashboardDescriptionById(List<DashboardVo> dashboards, String id) {
        for (DashboardVo dashboard : dashboards) {
            if (id.equals(dashboard.getId())) {
                return dashboard.getDescription();
            }
        }
        return "";
    }
}
