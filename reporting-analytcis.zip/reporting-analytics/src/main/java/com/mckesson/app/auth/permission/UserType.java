package com.mckesson.app.auth.permission;

public enum UserType {
    SuperAdmin("SA", "Super Admin"),
    CustomerAdmin("CA", "Customer Admin"),
    CustomerUser("CU", "Customer User"),
    InternalAdmin("IA", "Internal Admin"),
    InternalUser("IU", "Internal User"),
    InternalSales("ISA", "Internal Sales"),
    InternalSupport("ISU", "Internal Support"),
    Guest("G", "Guest");


    private final String code;
    private final String description;

    UserType(String code, String desc) {
        this.code = code;
        this.description = desc;
    }

    public static UserType lookup(String code) {
        switch (code) {
            case "SA":
                return SuperAdmin;
            case "CA":
                return CustomerAdmin;
            case "IA":
                return InternalAdmin;
            case "IU":
                return InternalUser;
            case "ISA":
                return InternalSales;
            case "ISU":
                return  InternalSupport;
            case "G":
                return  Guest;
            case "CU":
            default:
                return CustomerUser;
        }
    }

    public boolean isAdmin() {
        return this.equals(CustomerAdmin) || this.equals(InternalAdmin) || this.equals(SuperAdmin) || this.equals(InternalSales) ||
                this.equals(InternalSupport);
    }

    public boolean isInternal() {
        return UserType.InternalAdmin.equals(this) || UserType.InternalUser.equals(this) || UserType.SuperAdmin.equals(this) ||
                UserType.InternalSales.equals(this) || UserType.InternalSupport.equals(this);
    }

    public boolean isCustomer() {
        return UserType.CustomerAdmin.equals(this) || UserType.CustomerUser.equals(this);
    }

    public boolean isCustomerUser() {
        return UserType.CustomerUser.equals(this);
    }

    public boolean hasUserManagementAccess() {
        return this.equals(InternalSales) || this.equals(InternalSupport) || this.equals(InternalAdmin) || this.equals(CustomerAdmin) ||
                this.equals(SuperAdmin);
    }

    public boolean hasTeamManagementAccess() {
        return this.equals(InternalSales) || this.equals(InternalSupport) || this.equals(InternalAdmin) || this.equals(CustomerAdmin) ||
                this.equals(SuperAdmin);
    }

    public boolean hasCustomerManagementAccess() {
        return this.equals(SuperAdmin);
    }

    public boolean hasAccountSegmentationAccess() {
        return this.equals(InternalSales) || this.equals(InternalSupport) || this.equals(InternalAdmin) || this.equals(CustomerAdmin) ||
                this.equals(SuperAdmin);
    }

    public boolean hasVendorPurchasesAccess() {
        return this.equals(InternalSales) || this.equals(InternalSupport) || this.equals(InternalAdmin) || this.equals(CustomerAdmin) ||
                this.equals(SuperAdmin);
    }

    public boolean canSudo() {
        return this.equals(InternalSales) || this.equals(InternalSupport) || this.equals(InternalAdmin) || this.equals(CustomerAdmin) ||
                this.equals(SuperAdmin);
    }

    public boolean canAccessAllAccounts() {
        return this.equals(SuperAdmin);
    }

    public boolean hasHealthSystem123Access() {
        return this.equals(InternalSales) || this.equals(InternalSupport) || this.equals(InternalAdmin) || this.equals(SuperAdmin);
    }

    public boolean canCreateCustomGroups() {
        return this.equals(InternalSales) || this.equals(InternalSupport) || this.equals(InternalAdmin) || this.equals(CustomerUser) ||
                this.equals(CustomerAdmin) || this.equals(SuperAdmin);
    }

    public boolean canShareToTeams() {
        return this.equals(InternalUser) || this.equals(InternalSales) || this.equals(InternalSupport) || this.equals(InternalAdmin) ||
                this.equals(CustomerUser) || this.equals(CustomerAdmin) || this.equals(SuperAdmin);
    }

    public boolean canManageRoles() {
        return this.equals(SuperAdmin);
    }

    public String getDescription() {
        return description;
    }

    public String getCode() {
        return code;
    }
}
