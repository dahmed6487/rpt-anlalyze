package com.mckesson.app.service.admin;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.domain.admin.Module;
import main.java.com.mckesson.app.domain.customer.Customer;
import main.java.com.mckesson.app.repository.admin.ModuleRepository;
import main.java.com.mckesson.app.service.customer.CustomerService;
import main.java.com.mckesson.app.service.customer.UserMappingService;
import main.java.com.mckesson.app.util.UserAuthentication;

@Service
public class ModuleService {

    private final ModuleRepository moduleRepository;
    private final UserAuthentication userAuthentication;
    private final UserMappingService userMappingService;
    private final CustomerService customerService;
    private final CollaborationTeamService collaborationTeamService;

    @Autowired
    public ModuleService(ModuleRepository moduleRepository, UserAuthentication userAuthentication, UserMappingService userMappingService, CustomerService customerService, @Lazy CollaborationTeamService collaborationTeamService) {
        this.moduleRepository = moduleRepository;
        this.userAuthentication = userAuthentication;
        this.userMappingService = userMappingService;
        this.customerService = customerService;
        this.collaborationTeamService = collaborationTeamService;
    }

    public List<Module> getModule(String moduleType) {
        return moduleRepository.findByModuleType(moduleType);
    }

    public List<Module> updateModule(List<Module> module) {
        List<Long> list = new ArrayList();
        module.stream().forEach(c -> list.add(c.getModuleId()));
        moduleRepository.active(list);
        return module;
    }

    public void deleteModule(List<Module> module) {
        List<Long> list = new ArrayList();
        Date deletedDate = new Date();
        module.stream().forEach(c -> list.add(c.getModuleId()));
        moduleRepository.deleteRelation(list);
        moduleRepository.inActive(deletedDate, list);

    }

    public List<Module> getModuleForIds(Long moduleId) {
        return moduleRepository.getModuleForIds(moduleId);
    }

    public Optional<Module> getModuleByFolderId(String folderId) {
        return moduleRepository.findByFolderId(folderId);
    }

    // TODO we need to optimize this since this is slow
    public Set<Module> getModulesByUserAccess(String customerName) {
        ReportUser reportUser = userAuthentication.getLoggedInUser();

        Optional<Customer> optionalCustomer = customerService.findCustomerByCustomerName(customerName);

        if (optionalCustomer.isPresent()) {
            Customer selectedCustomer = optionalCustomer.get();
            List<Module> modulesFromCustomers = getModulesFromCustomers(Collections.singletonList(selectedCustomer));

            List<CollaborationTeam> teamsByUserAndSelectedCustomer = userMappingService.getTeamsByUserAndCustomer(reportUser.getUsername(), customerName);
            List<Module> modulesFromTeams = getModulesFromTeams(teamsByUserAndSelectedCustomer);

            return Stream.of(modulesFromTeams, modulesFromCustomers).flatMap(Collection::stream)
                    .collect(Collectors.toSet());
        } else {
            return Collections.emptySet();
        }
    }

    private List<Module> getModulesFromTeams(List<CollaborationTeam> teamsForUser) {
        List<Module> moduleResults = new ArrayList<>();

        for (CollaborationTeam team : teamsForUser) {
            Optional<List<String>> optionalContentAccessesFromTeam = collaborationTeamService.findContentAccessesByTeamId(team.getCollaborationTeamId());

            if (optionalContentAccessesFromTeam.isPresent()) {
                List<String> moduleTitlesFromTeam = optionalContentAccessesFromTeam.get();

                for (String moduleTitle : moduleTitlesFromTeam) {
                    Optional<Module> foundModule = moduleRepository.findByTitleIgnoreCase(moduleTitle);

                    if (foundModule.isPresent()) {
                        moduleResults.add(foundModule.get());
                    }
                }
            }
        }

        return moduleResults;
    }

    private List<Module> getModulesFromCustomers(List<Customer> customersForUser) {
        List<Module> moduleResults = new ArrayList<>();

        for (Customer customer : customersForUser) {
            List<BigInteger> moduleIdsFromCustomer = moduleRepository.findByCustomerId(customer.getCustomerId());

            for (BigInteger moduleId : moduleIdsFromCustomer) {
                Optional<Module> foundModule = moduleRepository.findById(moduleId.longValue());

                if (foundModule.isPresent()) {
                    moduleResults.add(foundModule.get());
                }
            }
        }

        return moduleResults;
    }

    public List<Module> getCustomerModule(String customerName) {
      return  moduleRepository.getCustomerModule(customerName);
    }

    public List<Module> getCustomerModulesById(String customerId) {
        return  moduleRepository.getCustomerModulesById(customerId);
    }
}
