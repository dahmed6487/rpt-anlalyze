package com.mckesson.app.repository.customer;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import main.java.com.mckesson.app.domain.FileUpload;
import main.java.com.mckesson.app.domain.customer.CustomAccountFields;


public interface CustomAccountFieldsRepository extends JpaRepository<CustomAccountFields, Long>, JpaSpecificationExecutor<FileUpload> {

    @Transactional
    @Modifying
    @Query(value = "insert into custom_account_fields (account_id, facility, account_type, load_file_id) VALUES (?1,?2,?3,?4)",nativeQuery = true)
    void insertData(String accountId, String facility, String accountType, long loadFileId);

    @Query(value = "select exists (select * from custom_account_fields where account_id=?1)",nativeQuery = true)
    int checkAccountExists(String accountId);

    @Transactional
    @Modifying
    @Query(value = "update custom_account_fields set account_type=?1,facility=?2 where account_id=?3",nativeQuery = true)
    void updateDate(String accountType, String facility, String accountId);
}