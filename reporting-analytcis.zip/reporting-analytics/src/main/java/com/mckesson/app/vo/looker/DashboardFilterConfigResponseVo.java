package com.mckesson.app.vo.looker;

import java.util.List;

public class DashboardFilterConfigResponseVo {

    private List<DashboardFilterVo> savedFilters;
    private List<DashboardFilterVo> dashboardFilters;
    private String lookerHost;

    public DashboardFilterConfigResponseVo(List<DashboardFilterVo> savedFilters, List<DashboardFilterVo> dashboardFilters) {
        this.savedFilters = savedFilters;
        this.dashboardFilters = dashboardFilters;
    }

    public List<DashboardFilterVo> getSavedFilters() {
        return savedFilters;
    }

    public void setSavedFilters(List<DashboardFilterVo> savedFilters) {
        this.savedFilters = savedFilters;
    }

    public List<DashboardFilterVo> getDashboardFilters() {
        return dashboardFilters;
    }

    public void setDashboardFilters(List<DashboardFilterVo> dashboardFilters) {
        this.dashboardFilters = dashboardFilters;
    }

    public String getLookerHost() {
        return lookerHost;
    }

    public void setLookerHost(String lookerHost) {
        this.lookerHost = lookerHost;
    }

}
