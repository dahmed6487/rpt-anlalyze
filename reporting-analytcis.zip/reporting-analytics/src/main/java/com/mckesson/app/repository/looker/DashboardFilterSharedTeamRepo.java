package com.mckesson.app.repository.looker;

import org.springframework.data.jpa.repository.JpaRepository;

import main.java.com.mckesson.app.domain.looker.DashboardFilterSharedTeam;

public interface DashboardFilterSharedTeamRepo extends JpaRepository<DashboardFilterSharedTeam, Integer> {

}
