package com.mckesson.app.misc;

import java.sql.SQLException;
import java.util.logging.Logger;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Class to handle exceptions
 * when exception occurred each api/server call respond with errorDesc and errorId and which needs to decode and show in UI
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class CustomException extends ResponseEntityExceptionHandler {
    private static final Logger LOG = LoggerFactory.getLogger(CustomException.class);

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorDetails> exception(Exception exception) {
        LOG.error("Error occurred - Message: " + exception.getMessage() + ". Cause: " + exception.getCause() + ". exception: " + exception);
        LOG.error(ToStringBuilder.reflectionToString(exception));

        if (exception instanceof UsernameNotFoundException) {
            ErrorDetails errorDetails = new ErrorDetails("401", exception.getMessage());
            return new ResponseEntity<>(errorDetails, HttpStatus.UNAUTHORIZED);
        }

        if (exception instanceof SQLException) {
            ErrorDetails errorDetails = new ErrorDetails(exception.getMessage(), ((SQLException) exception).getSQLState());
            return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        if (exception instanceof Exception) {
            ErrorDetails errorDetails = new ErrorDetails("500", exception.getMessage());
            ResponseEntity responseEntity = new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
            return responseEntity;
        }

        ErrorDetails errorDetails = new ErrorDetails("500", exception.getMessage());
        ResponseEntity responseEntity = new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
        return responseEntity;

    }
}
