package com.mckesson.app.util;

/**
 * <p/>
 * (c) 2005 Copyright - McKesson Medical-Surgical Minnesota Supply Inc. All
 * Rights Reserved
 *
 * @author <a href="mailto:Sean.Kleinjung@redline.mckhboc.com">Sean
 * Kleinjung</a>
 * @version $Id: StringUniquenessVerifier.java,v 1.1 2009/06/18 19:09:04 dbod
 * Exp $
 */
public interface StringUniquenessVerifier {
    boolean isUnique(String s);
}