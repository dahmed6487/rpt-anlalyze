package com.mckesson.app.repository.looker;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import main.java.com.mckesson.app.domain.looker.FilterCriteria;
import main.java.com.mckesson.app.vo.CustomFilterCriteriaSummary;

public interface CustomFilterGroupCriteriaRepository extends JpaRepository<FilterCriteria, Long> {
    @Query("select c.id as id, c.name as name, c.dimension as dimension, c.relationalOperator as relationalOperator, c.value as value, c.defaultGrouping as defaultGrouping, c.associatedDimension as associatedDimension FROM FilterCriteria c where c.group.id = :groupId")
    List<CustomFilterCriteriaSummary> getByGroupId(Long groupId);
}
