package com.mckesson.app;

import main.java.com.mckesson.app.service.looker.LookerEmbedUrlGenerator;

public class EmbedTest {

    public static void main(String[] args) {

        LookerEmbedUrlGenerator generator = new LookerEmbedUrlGenerator();
        generator.initialize("dev.looker.intelligence.mckesson.com", "Sales_dev, r_a_connect", "1a8f60c630bffd8f57f6aae361c37385751bbda7cd577b6bc0ce41650fbd9546", "3,7,9,8,16,17,19", null);

        try {
            System.out.println("Start");

            //'page:properties:changed' event triggered
            //dashboard.url attribute
            String url = "/embed/dashboards/MWQzcgVFVFHQmlZRSoVanq?embed_domain=http:%2F%2Flocalhost:8080&theme=gray&Current%20Period=last%20month%20for%201%20month&Previous%20Period=2%20months%20ago%20for%201%20month&Account%20Number=100000&Account%20Name=&filter_config=%7B%22Current%20Period%22:%5B%7B%22type%22:%22advanced%22,%22values%22:%5B%7B%22constant%22:%22last%20month%20for%201%20month%22%7D,%7B%7D%5D,%22id%22:8%7D%5D,%22Previous%20Period%22:%5B%7B%22type%22:%22advanced%22,%22values%22:%5B%7B%22constant%22:%222%20months%20ago%20for%201%20month%22%7D,%7B%7D%5D,%22id%22:9%7D%5D,%22Account%20Number%22:%5B%7B%22type%22:%22%3D%22,%22values%22:%5B%7B%22constant%22:%22100000%22%7D,%7B%7D%5D,%22id%22:10%7D%5D,%22Account%20Name%22:%5B%7B%22type%22:%22%3D%22,%22values%22:%5B%7B%22constant%22:%22%22%7D,%7B%7D%5D,%22id%22:11%7D%5D%7D";


            String externalUserId = "Looker-Dev-U1";
            String firstName = "Looker-Dev-U1";
            String lastName = "demo";
            //public String getEmbedUrl (String externalUserId, String embedUrl, String firstName, String lastName)throws Exception {

            String embedUrl = generator.getEmbedUrl(externalUserId, url, firstName, lastName, null, null);

            System.out.println("Embed URL: " + embedUrl);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
