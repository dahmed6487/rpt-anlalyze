package com.mckesson.app.service.looker;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;

import main.java.com.mckesson.app.service.looker.config.QidConfiguration;
import main.java.com.mckesson.app.util.StringUtils;

/**
 * Singleton Utility class responsible for preparing looker Embed URL
 * with user and other supplied parameters.
 */
@Component
public class LookerEmbedUrlGenerator {

    private static final Logger log = LoggerFactory.getLogger(LookerEmbedUrlGenerator.class);

    private static final Joiner COMMA_JOINER = Joiner.on(",");

    private static final LookerEmbedUrlGenerator instance = new LookerEmbedUrlGenerator();
    public static final String STRING_FORMAT = "UTF-8";

    private String lookerHost;
    private String lookerModels;
    private String lookerEmbedKey;
    private String groupIds;
    private QidConfiguration qidConfiguration;

    String sessionLength = "43200"; // Connect portal times out after 4 hours. Set Looker to timeout after 12

    public static LookerEmbedUrlGenerator getInstance() {
        return instance;
    }

    /**
     * this should be called during application startup
     *
     * @param lookerHost
     * @param lookerModels
     * @param lookerEmbedKey
     * @param groupIds
     * @param qidConfiguration
     */
    public void initialize(String lookerHost, String lookerModels, String lookerEmbedKey,
                           String groupIds, QidConfiguration qidConfiguration) {
        this.lookerHost = lookerHost;
        this.lookerModels = lookerModels;
        this.lookerEmbedKey = lookerEmbedKey;
        this.groupIds = groupIds;
        this.qidConfiguration = qidConfiguration;
    }

    public String getDashboardEmbedUrl(String firstName, String lastName, String userID, String dashboardId,
                                       String filters, String embedDomain, String userAttributes, String groupIdList)
            throws Exception {
        return getEmbedUrl(firstName, lastName, userID, "/embed/dashboards-next/" + dashboardId, false, null, null, filters, embedDomain, userAttributes, groupIdList);
    }

    public String getExploreEmbedUrl(String firstName, String lastName, String userID, String modelName,
                                     String explore, String qid, String exploreType, String embedDomain, String userAttributes, String groupIdList) throws Exception {
        return getEmbedUrl(firstName, lastName, userID, "/embed/explore/" + modelName + "/" + explore, true, qid, exploreType, null, embedDomain, userAttributes, groupIdList);
    }

    public String getLookEmbedUrl(String firstName, String lastName, String userID,
                                  String lookId, String embedDomain, String userAttributes, String groupIdList) throws Exception {
        return getEmbedUrl(firstName, lastName, userID, "/embed/looks/" + lookId, false, null, null, null, embedDomain, userAttributes, groupIdList);
    }

    private String jsonFormat(String val) {
        return "\"" + val + "\"";
    }

    private String getUserAttributes(String accountId, Integer dataHistoryMonths, String marketPartition, String blaEligible) {

        StringBuilder userAttributesSb = new StringBuilder("{");
        List<String> userAttributeParts = Lists.newArrayList();
        if (accountId != null) {
            userAttributeParts.add("\"external_user_id\":\"" + accountId + "\",\"demo\":\"" + accountId + "\"");
        }
        if (dataHistoryMonths != null) {
            userAttributeParts.add("\"data_history_months\":\"" + dataHistoryMonths + "\"");
        }
        if (StringUtils.isNotBlank(marketPartition)) {
            userAttributeParts.add("\"market_segment\":\"" + marketPartition + "\"");
        }
        if (StringUtils.isNotBlank(blaEligible)) {
            userAttributeParts.add("\"bla_eligible\":\"" + blaEligible + "\"");
        }
        return userAttributesSb.append(COMMA_JOINER.join(userAttributeParts)).append("}").toString();
    }

    private String encodeString(String stringToEncode, String secret) throws Exception {

        byte[] keyBytes = secret.getBytes();
        SecretKeySpec signingKey = new SecretKeySpec(keyBytes, "HmacSHA1");
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(signingKey);
        byte[] rawHmac = Base64.getEncoder().encode(mac.doFinal(stringToEncode.getBytes(StandardCharsets.UTF_8)));
        return new String(rawHmac, StandardCharsets.UTF_8);
    }

    private String jsonFormatArray(String val) {
        StringBuilder sb = new StringBuilder();
        String[] splitValues = val.split(",");
        for (int x = 0; x < splitValues.length; x++) {
            if (x != 0) {
                sb.append(",");
            }
            sb.append("\"" + val + "\"");
        }
        return "[" + sb.toString() + "]";
    }

    private String getEmbedUrl(String firstName, String lastName, String userID, String embedURL, Boolean explore, String qid, String exploreType, String filters, String embedDomain, String userAttributes, String groupIdList)
            throws Exception {

        //String permissions = "[\"see_user_dashboards\",\"access_data\",\"see_looks\",\"see_drill_overlay\",\"download_without_limit\",\"save_content\",\"explore\",\"embed_browse_spaces\"]";
        String permissions = "[\"see_user_dashboards\",\"access_data\",\"see_looks\",\"see_drill_overlay\",\"download_without_limit\",\"save_content\",\"explore\",\"embed_browse_spaces\",\"schedule_look_emails\",\"schedule_external_look_emails\",\"send_outgoing_webhook\",\"send_to_sftp\",\"create_table_calculations\"]";

        // hours. 4.5*60*60=16,200
//		String sessionLength = "3600"; //RADI-1608: set to 1 hour for testing
        String accessFilters = "{}"; // converted to JSON Object of Objects
        String groupIDs = "[" + groupIdList + "]"; // converted to JSON array, can be set to null (value, not JSON) for no groups
        String externalGroupID = "\"\""; // converted to JSON string
        String forceLoginLogout = "true"; // converted to JSON boolean
        //String userAttributes = getUserAttributes(externalUserID, dataHistoryMonths);

        Calendar cal = Calendar.getInstance();
        SecureRandom random = new SecureRandom();
        String nonce = "\"" + (new BigInteger(130, random).toString(32)) + "\"";
        String time = Long.toString(cal.getTimeInMillis() / 1000L);

        if (embedDomain.startsWith("localhost")) {
            embedDomain = "http://" + embedDomain;
        } else {
            embedDomain = "https://" + embedDomain;
        }

        if (embedDomain.endsWith("/")) {
            embedDomain = embedDomain.substring(0, embedDomain.length() - 1);
        }

        //String strEmbedUrl = embedURL + "?embed_domain=" + lookerEmbedDomain + "&Account Number=000007,000084";
        if (embedDomain.endsWith("/")) {
            embedDomain = embedDomain.substring(0, embedDomain.length() - 1);
        }


        String strEmbedUrl;
		if(qid!=null){
			if(explore)
				strEmbedUrl = embedURL + "?embed_domain=" + embedDomain +"&qid="+ qid +"&toggle=vis&theme=gray";
			else
				strEmbedUrl = embedURL + "?embed_domain=" + embedDomain +"&qid="+ qid +"&theme=gray";
		}
		else{
			if(explore)
				strEmbedUrl = embedURL +"?embed_domain=" + embedDomain +"&toggle=vis&theme=gray";
			else
				strEmbedUrl = embedURL +"?embed_domain=" + embedDomain +"&theme=gray";
		}

        if (filters != null) {
            strEmbedUrl += "&" + filters;
        }


        // If no qid was passed in check to see if this embed should have one pulled in from the configuration
		/*
		if (qid == null) {
			Optional<String> potentialQid = getQidForUserAndExplore(externalUserID, explore, exploreType);
			if (potentialQid.isPresent()) {
				qid = potentialQid.get();
			}
		}*/

        // If we have a qid (from configuration or provided to embed call) add it to the embed URL
		/*if (qid != null) {
			strEmbedUrl += "&qid=" + qid;
		}*/

        System.out.println(strEmbedUrl);

        String fullEmbedPath = "/login/embed/" + java.net.URLEncoder.encode(strEmbedUrl + "", STRING_FORMAT);
        String userIDFormatted = "\"" + userID + "\""; // converted to JSON string

        String formattedModels = jsonFormatArray(lookerModels);

        String urlToSign = "";
        urlToSign += lookerHost + "\n";
        urlToSign += fullEmbedPath + "\n";
        urlToSign += nonce + "\n";
        urlToSign += time + "\n";
        urlToSign += sessionLength + "\n";
        urlToSign += userIDFormatted + "\n";
        urlToSign += permissions + "\n";
        urlToSign += formattedModels + "\n";
        urlToSign += groupIDs + "\n";
        urlToSign += externalGroupID + "\n";
        urlToSign += userAttributes + "\n";
        urlToSign += accessFilters;

        String signature = encodeString(urlToSign, lookerEmbedKey);

        String signedURL = "nonce=" + java.net.URLEncoder.encode(nonce, "UTF-8") + "&time="
                + java.net.URLEncoder.encode(time, "UTF-8") + "&session_length="
                + java.net.URLEncoder.encode(sessionLength, "UTF-8") + "&external_user_id="
                + java.net.URLEncoder.encode(userIDFormatted, "UTF-8") + "&permissions="
                + java.net.URLEncoder.encode(permissions, "UTF-8") + "&models="
                + java.net.URLEncoder.encode(formattedModels, "UTF-8") + "&group_ids="
                + java.net.URLEncoder.encode(groupIDs, "UTF-8") + "&external_group_id="
                + java.net.URLEncoder.encode(externalGroupID, "UTF-8") + "&user_attributes="
                + java.net.URLEncoder.encode(userAttributes, "UTF-8") + "&access_filters="
                + java.net.URLEncoder.encode(accessFilters, "UTF-8") + "&first_name="
                + java.net.URLEncoder.encode(jsonFormat(firstName), "UTF-8") + "&last_name="
                + java.net.URLEncoder.encode(jsonFormat(lastName), "UTF-8") + "&force_logout_login="
                + java.net.URLEncoder.encode(forceLoginLogout, "UTF-8") + "&signature="
                + java.net.URLEncoder.encode(signature, "UTF-8");

        return "https://" + lookerHost + fullEmbedPath + '?' + signedURL;
    }

    private Optional<String> getQidForUserAndExplore(String externalUserId, boolean isExplore, String exploreType) {
        if (isExplore) {
            switch (exploreType) {
                case "purchases":
                    return Optional.ofNullable(qidConfiguration.getPurchases().get(externalUserId));
                default:
                    return Optional.empty();
            }
        } else {
            return Optional.empty();
        }
    }

    public String getEmbedUrl(String externalUserId, String embedUrl, String firstName, String lastName, String marketPartition, String blaEligible) throws Exception {

        Integer dataHistoryMonths = null;

        String permissions = "[\"see_user_dashboards\",\"access_data\",\"see_looks\",\"see_drill_overlay\",\"download_without_limit\",\"save_content\",\"explore\",\"embed_browse_spaces\",\"schedule_look_emails\",\"schedule_external_look_emails\",\"send_outgoing_webhook\",\"send_to_sftp\"]";

        String fullEmbedPath = "/login/embed/" + java.net.URLEncoder.encode(embedUrl + "", STRING_FORMAT);
        String userIDFormatted = "\"" + externalUserId + "\""; // converted to JSON string

        // hours. 4.5*60*60=16,200
        // String sessionLength = "3600"; //RADI-1608: set to 1 hour for testing
        String accessFilters = "{}"; // converted to JSON Object of Objects
        String groupIDs = "[" + groupIds + "]"; // converted to JSON array, can be set to null (value, not JSON) for no groups
        String externalGroupID = "\"\""; // converted to JSON string
        String forceLoginLogout = "true"; // converted to JSON boolean
        String userAttributes = getUserAttributes(externalUserId, dataHistoryMonths, marketPartition, blaEligible);

        Calendar cal = Calendar.getInstance();
        SecureRandom random = new SecureRandom();
        String nonce = "\"" + (new BigInteger(130, random).toString(32)) + "\"";
        String time = Long.toString(cal.getTimeInMillis() / 1000L);

        String formattedModels = jsonFormatArray(lookerModels);

        String urlToSign = "";
        urlToSign += lookerHost + "\n";
        urlToSign += fullEmbedPath + "\n";
        urlToSign += nonce + "\n";
        urlToSign += time + "\n";
        urlToSign += sessionLength + "\n";
        urlToSign += userIDFormatted + "\n";
        urlToSign += permissions + "\n";
        urlToSign += formattedModels + "\n";
        urlToSign += groupIDs + "\n";
        urlToSign += externalGroupID + "\n";
        urlToSign += userAttributes + "\n";
        urlToSign += accessFilters;

        String signature = encodeString(urlToSign, lookerEmbedKey);

        String signedURL = "nonce=" + java.net.URLEncoder.encode(nonce, "UTF-8") + "&time="
                + java.net.URLEncoder.encode(time, "UTF-8") + "&session_length="
                + java.net.URLEncoder.encode(sessionLength, "UTF-8") + "&external_user_id="
                + java.net.URLEncoder.encode(userIDFormatted, "UTF-8") + "&permissions="
                + java.net.URLEncoder.encode(permissions, "UTF-8") + "&models="
                + java.net.URLEncoder.encode(formattedModels, "UTF-8") + "&group_ids="
                + java.net.URLEncoder.encode(groupIDs, "UTF-8") + "&external_group_id="
                + java.net.URLEncoder.encode(externalGroupID, "UTF-8") + "&user_attributes="
                + java.net.URLEncoder.encode(userAttributes, "UTF-8") + "&access_filters="
                + java.net.URLEncoder.encode(accessFilters, "UTF-8") + "&first_name="
                + java.net.URLEncoder.encode(jsonFormat(firstName), "UTF-8") + "&last_name="
                + java.net.URLEncoder.encode(jsonFormat(lastName), "UTF-8") + "&force_logout_login="
                + java.net.URLEncoder.encode(forceLoginLogout, "UTF-8") + "&signature="
                + java.net.URLEncoder.encode(signature, "UTF-8");

        return "https://" + lookerHost + fullEmbedPath + '?' + signedURL;
    }

}