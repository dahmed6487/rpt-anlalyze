package com.mckesson.app.service.looker.api;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mckesson.lib.rest.RestFactory;
import com.mckesson.lib.rest.client.*;
import com.mckesson.lib.rest.engine.jaxrs.JAXRSRestFactory;

import main.java.com.mckesson.app.misc.ApiException;
import main.java.com.mckesson.app.util.RestClient;

@Component("QueryApi")
public class QueryApi extends ApiBase {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static final String ENTITY_REF = "/queries";

    private final RestFactory restFactory;

    public QueryApi() {
        this.restFactory = new JAXRSRestFactory();
    }

    public Query createQuery(String queryJson, String[] fields) throws ApiException {
        try {
            RestClient restClient = restFactory.getRestClient(lookerApiHost);
            RestLocation restLocation = RestLocation.root()
                    .path(ENTITY_REF)
                    .queryParam("fields", String.join(",", fields));
            String auth = getAuthToken();
            RestHeaders headers = RestHeaders.withHeader("Authorization", "token " + auth);
            RestEntity<String> restEntity = RestEntity.json(queryJson);
            RestResponse<String> response = restClient.post(restLocation, headers, restEntity, String.class);
            return OBJECT_MAPPER.readValue(response.getEntity(), new TypeReference<Query>() {
            });
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public String runInlineQuery(String queryJson, String resultFormat, String auth) throws ApiException {
        try {
            RestClient restClient = restFactory.getRestClient(lookerApiHost);
            RestLocation restLocation = RestLocation.root()
                    .path(ENTITY_REF)
                    .path("run")
                    .path(resultFormat);

            RestHeaders headers = RestHeaders.withHeader("Authorization", "token " + auth);
            RestEntity<String> restEntity = RestEntity.json(queryJson);
            RestResponse<String> response = restClient.post(restLocation, headers, restEntity, String.class);
            return response.getEntity();
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

    public String getQuery(String qid) throws ApiException {
        try {
            RestClient restClient = restFactory.getRestClient(lookerApiHost);
            RestLocation restLocation = RestLocation.root()
                    .path("/queries/slug/" + qid);
            String auth = getAuthToken();
            RestHeaders headers = RestHeaders.withHeader("Authorization", "token " + auth);
            RestResponse<String> response = restClient.get(restLocation, headers, String.class);
            return response.getEntity();
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }


    public RestResponse<String> getResultFormatQueryId(String qid, String resultFormat) throws ApiException {
        try {
            RestClient restClient = restFactory.getRestClient(lookerApiHost);
            RestLocation restLocation = RestLocation.root()
                    .path("/queries/" + qid).path("/run/"+resultFormat);
            String auth = getAuthToken();
            RestHeaders headers = RestHeaders.withHeader("Authorization", "token " + auth);
            return restClient.get(restLocation, headers, String.class);
        } catch (Exception e) {
            throw new ApiException(e.getMessage());
        }
    }

}
