package com.mckesson.app.domain.customer;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class CustomersDto {
    @SerializedName("customers")
    private List<Customer> customers;
    @SerializedName("totalPages")
    private int totalPages;

    public List<Customer> getCustomers() {
        return customers;
    }

    public void setCustomers(List<Customer> newCustomers) {
        customers = newCustomers;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int newTotalPages) {
        totalPages = newTotalPages;
    }
}
