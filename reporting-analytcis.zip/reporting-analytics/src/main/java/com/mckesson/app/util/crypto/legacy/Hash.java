package com.mckesson.app.util.crypto.legacy;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.MessageDigest;

public class Hash {

    /**
     * Uses SHA-1 hash. this method should only be used for finger printing files
     * and not for hashing sensitive information like passwords.
     */
    public static String hash(InputStream in, String alg) {
        StringBuffer hash = new StringBuffer(64);
        try {
            MessageDigest md = MessageDigest.getInstance(alg);
            byte[] bytes = new byte[512];
            long size = 0;
            int read = 0;
            while ((read = in.read(bytes)) != -1) {
                md.update(bytes, 0, read);
                size += read;
            }
            byte[] bhash = md.digest();

            for (byte b : bhash) {
                hash.append(Integer.toHexString(0xFF & b));
            }
            return hash.toString();

        } catch (Exception e) {
            return null;
        }
    }

    public static String md5(byte[] bytes) {
        return hash(new ByteArrayInputStream(bytes), "MD5");
    }

    public static String md5(String s) {
        return md5(s.getBytes());
    }

    public static String sha1(byte[] bytes) {
        return hash(new ByteArrayInputStream(bytes), "SHA-1");
    }

    public static String sha1(String s) {
        return md5(s.getBytes());
    }
}