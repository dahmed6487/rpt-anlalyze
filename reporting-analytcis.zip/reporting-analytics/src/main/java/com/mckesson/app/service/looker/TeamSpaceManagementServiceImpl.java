package com.mckesson.app.service.looker;

import java.util.List;
import java.util.logging.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import main.java.com.mckesson.app.auth.user.ConnectUser;
import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.service.admin.CollaborationTeamService;
import main.java.com.mckesson.app.service.customer.CustomerService;
import main.java.com.mckesson.app.service.looker.api.ContentApi;
import main.java.com.mckesson.app.service.looker.api.DashboardApi;
import main.java.com.mckesson.app.service.looker.api.FolderApi;
import main.java.com.mckesson.app.service.looker.api.GroupApi;
import main.java.com.mckesson.app.service.looker.api.LookApi;
import main.java.com.mckesson.app.service.looker.api.QueryApi;
import main.java.com.mckesson.app.service.looker.api.SpaceApi;
import main.java.com.mckesson.app.service.looker.api.UserApi;
import main.java.com.mckesson.app.service.user.UserProfileService;
import main.java.com.mckesson.app.vo.ReportItemVo;
import main.java.com.mckesson.app.vo.looker.DashboardVo;
import main.java.com.mckesson.app.vo.looker.FolderVo;
import main.java.com.mckesson.app.vo.looker.LookVo;
import main.java.com.mckesson.app.vo.looker.UserVo;

@Service("TeamSpaceManagementService")
public class TeamSpaceManagementServiceImpl extends BaseSpaceManagementService implements TeamSpaceManagementService {

    Logger logger = LoggerFactory.getLogger(TeamSpaceManagementServiceImpl.class);

    private final CollaborationTeamService collaborationTeamService;

    @Autowired
    public TeamSpaceManagementServiceImpl(
            SpaceApi spaceApi,
            UserApi userApi,
            DashboardApi dashboardApi,
            LookApi lookApi,
            FolderApi folderApi,
            ContentApi contentApi,
            QueryApi queryApi, UserProfileService userProfileService, CollaborationTeamService collaborationTeamService, CustomerService customerService, GroupApi groupApi) {

        super(spaceApi, userApi, dashboardApi, lookApi, folderApi, contentApi, queryApi, groupApi);
        this.collaborationTeamService = collaborationTeamService;
    }

    @Value("mockTeamSpaceRootDirId")
    private String mockTeamSpaceRootDirId;

    /**
     * Given the current user's id, obtain a reference to their team space.
     *
     * @param user
     * @return
     */
    private String getTeamBaseFolderReference(ReportUser user, String customerName) {
        List<CollaborationTeam> list = collaborationTeamService.getTeamIdForCustomer(user, customerName);
        return list.get(0).getExternalId().toString();
    }

    @Override
    public ReportItemVo getTeamFolderStructure(ReportUser reportUser, String customerName) {

        String authToken = getAuthToken();

        //Establish refernce to current user
        //String userID= getLoggedInUser().getUsername();
        UserVo user = userApi.getUserByEmbed(reportUser.getUsername(), authToken);

        //Locate default team space which sets scope of where to retrieve objects from
        String teamSpace = getTeamBaseFolderReference(reportUser, customerName);

        //
        String[] folderFields = {"id", "name", "created_at","parent_id"};
        FolderVo userFolder = spaceApi.getFolder(teamSpace, folderFields, authToken);

        ReportItemVo rootItem = convertFolderToVo(userFolder);

        String[] fields = {"id", "title", "name", "description", "favorite_count", "created_at", "last_viewed_at", "deleted","user_id","query","parent_id"};
        String[] dbFields = {"id", "title", "name", "description", "favorite_count", "created_at", "last_viewed_at", "deleted", "user_id", "dashboard_elements","parent_id"};

        List<LookVo> looks = spaceApi.getLooksForFolder(teamSpace, fields, authToken);
        rootItem.getChildren().addAll(convertLooksToVos(looks,false,user.getId()));

        List<DashboardVo> dashboards = spaceApi.getDashboardsForFolder(teamSpace, dbFields, authToken);
        rootItem.getChildren().addAll(convertDashboardsToVos(dashboards,false,user.getId()));

        List<FolderVo> childFolders = spaceApi.getChildFolders(teamSpace, authToken);
        for (FolderVo child : childFolders) {
            rootItem.getChildren().add(getFolderStructure(child.getId(), authToken,user.getId()));
        }

        //setAuthPerms(rootItem, user);
        //formatTimestamps(rootItem);

        return rootItem;
    }

    @Override
    public List<ReportItemVo> getFolderStructure(String scope) {

        //Establish reference to current user
        //String userID=getLoggedInUser().getUsername();


        return null;
    }

    @Override
    public ReportItemVo createFolder(ReportUser reportUser, String name, String parentId, String customerName) {

        String authToken = spaceApi.getAuthToken();

        if (reportUser.getUsername() == null) {
            logger.warn("Cannot identitify connect user");
            throw new AccessDeniedException("Cannot identify connect user!");
        }

        //String[] userFields = {"id","first_name","last_name","display_name","personal_space_id"};
        UserVo user = userApi.getUserByEmbed(reportUser.getUsername(), authToken);

        //If no parent folder is referenced, then we are adding the new folder to the user's root folder.
        if (parentId == null) {
            //Note: data type mismatch between folder id (string) and reference on user object (string).
            parentId = Long.toString(user.getPersonalSpaceId());
            parentId = getTeamBaseFolderReference(reportUser, customerName);
        }

        FolderVo folder = new FolderVo();
        folder.setParentId(parentId);
        folder.setName(name);

        folder = spaceApi.createFolder(folder, authToken);

        ReportItemVo item = new ReportItemVo();
        item.setId(System.currentTimeMillis() + "");
        item.setName(name);
        item.setType(ReportItemVo.ITEM_TYPE_FOLDER);
        setDate(item);
        item.setLastActionType("Created");
        item.setLastActionAuthor(getCurrentUserNameFormatted(reportUser));

        return item;

    }

    @Override
    public void deleteFolder(String userID, String folderId) {

        String authToken = spaceApi.getAuthToken();
        if (userID == null) {
            logger.warn("Cannot identitify connect user");
            throw new AccessDeniedException("Cannot identify connect user!");
        }

        spaceApi.deleteFolder(folderId, authToken);
    }

    @Override
    public void deleteReport(String userID, String lookId) {
        String authToken = spaceApi.getAuthToken();
        if (userID == null) {
            logger.warn("Cannot identitify connect user");
            throw new AccessDeniedException("Cannot identify connect user!");
        }
        lookApi.deleteLook(lookId, authToken);
    }

    @Override
    public void deleteDashboard(String userID, String dashboardId) {
        String authToken = spaceApi.getAuthToken();
        if (userID == null) {
            logger.warn("Cannot identitify connect user");
            throw new AccessDeniedException("Cannot identify connect user!");
        }
        dashboardApi.deleteDashboard(dashboardId, authToken);
    }

    @Override
    public void updateSpace(FolderVo folder) {
            String authToken = spaceApi.getAuthToken();
            this.spaceApi.updateSpace(folder, authToken);
    }

    void assertRightsForTeamFolder() {

    }

    void assertRightsForTeamDashboard() {

    }

    void assertRightsForTeamReport() {

    }


    void setAuthPerms(ReportItemVo parent, ConnectUser currentUser) {
        if (currentUser.getUsername().contains("A1") || currentUser.getUsername().contains("A2")) {

            parent.setCurrentUserMayEdit(true);
            if (parent.getChildren() != null) {
                for (ReportItemVo item : parent.getChildren()) {
                    setAuthPerms(item, currentUser);
                }
            }
        }

    }

    void setAuthPerms(List<ReportItemVo> items, ConnectUser currentUser) {

        if (currentUser.getUsername().contains("A1") || currentUser.getUsername().contains("A2")) {
            for (ReportItemVo item : items) {
                item.setCurrentUserMayEdit(true);
            }
        }

        //for(ReportItemVo item:items) {
        //	item.setCurrentUserMayEdit(true);
        //}
    }
}
