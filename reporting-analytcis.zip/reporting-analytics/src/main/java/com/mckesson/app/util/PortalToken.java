package com.mckesson.app.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.ISODateTimeFormat;

public class PortalToken {

    private final static String ENCODING = "UTF-8";
    private final static DateTimeZone TIME_ZONE = DateTimeZone.forID("GMT");
    private final static DateTimeFormatter FORMAT = ISODateTimeFormat.basicOrdinalDateTime().withZone(TIME_ZONE);

    private Map<String, String> parameters;

    private final String user;
    private final DateTime created;

    public static PortalToken parse(String input) throws PortalTokenException {
        if (input == null || "".equals(input.trim()))
            throw new PortalTokenException("Input is Blank");
        String[] rows = input.split("\n");
        if (rows.length >= 2) {
            try {
                DateTime created = FORMAT.parseDateTime(rows[0]);
                String user = rows[1].trim();
                PortalToken token = new PortalToken(user, created);
                for (int i = 2; i < rows.length; i++) {
                    int split = rows[i].indexOf('=');
                    if (split > 0) {
                        token.set(URLDecoder.decode(rows[i].substring(0, split), ENCODING),
                                URLDecoder.decode(rows[i].substring(split + 1), ENCODING));
                    }
                }
                return token;
            } catch (Exception e) {
                throw new PortalTokenException("Invalid Token Format", e);
            }
        }
        throw new PortalTokenException("Invalid Token Length");
    }

    public PortalToken(String user) {
        this.user = user;
        this.created = new DateTime(TIME_ZONE);
    }

    protected PortalToken(String user, DateTime dateTime) {
        this.user = user;
        this.created = dateTime;
    }

    public PortalToken set(String key, String value) {
        if (key != null && value != null) {
            if (this.parameters == null)
                this.parameters = new HashMap<String, String>();
            this.parameters.put(key, value);
        }
        return this;
    }

    public PortalToken set(String key, boolean value) {
        return this.set(key, Boolean.toString(value));
    }

    public PortalToken set(String key, long value) {
        return this.set(key, Long.toString(value));
    }

    public String get(String key) {
        return (key != null && this.parameters != null) ? this.parameters.get(key) : null;
    }

    public boolean is(String key) {
        return Boolean.parseBoolean(this.get(key));
    }

    public DateTime getCreated() {
        return this.created;
    }

    public String getUser() {
        return this.user;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer(128);
        FORMAT.printTo(sb, this.created);
        sb.append('\n').append(this.user).append('\n');
        if (this.parameters != null) {
            try {
                for (Map.Entry<String, String> e : this.parameters.entrySet()) {
                    sb.append(URLEncoder.encode(e.getKey(), ENCODING)).append('=');
                    sb.append(URLEncoder.encode(e.getValue(), ENCODING)).append('\n');
                }
            } catch (UnsupportedEncodingException e) {
                // nothing
            }
        }
        return sb.toString();
    }

    public boolean isValidFor(long time, TimeUnit unit) {
        return this.created.plusMillis((int) TimeUnit.MILLISECONDS.convert(time, unit)).isAfterNow();
    }

}