package com.mckesson.app.service.user;

import java.awt.print.Pageable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

import javax.persistence.EntityManager;

import org.omg.CORBA.Environment;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import main.java.com.mckesson.app.auth.permission.UserType;
import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.domain.customer.Customer;
import main.java.com.mckesson.app.domain.looker.WhiteList;
import main.java.com.mckesson.app.domain.user.UserProfile;
import main.java.com.mckesson.app.misc.EntityNotFoundException;
import main.java.com.mckesson.app.repository.customer.CustomerRepository;
import main.java.com.mckesson.app.repository.user.UserProfileRepository;
import main.java.com.mckesson.app.util.MappingUtils;
import main.java.com.mckesson.app.util.RestClient;
import main.java.com.mckesson.app.util.StringUtils;
import main.java.com.mckesson.app.util.UserAuthentication;

@Service
@Transactional
public class UserProfileService {

    private static final Logger LOG = LoggerFactory.getLogger(UserProfileService.class);

    private final UserAuthentication userAuthentication;
    private final UserProfileRepository userProfileRepository;
    private final Environment environment;
    private final CustomerRepository customerRepository;
    private final EntityManager entityManager;


    @Autowired
    public UserProfileService(UserAuthentication userAuthentication, UserProfileRepository userProfileRepository, Environment environment, CustomerRepository customerRepository, EntityManager entityManager) {
        this.userAuthentication = userAuthentication;
        this.userProfileRepository = userProfileRepository;
        this.environment = environment;
        this.customerRepository = customerRepository;
        this.entityManager = entityManager;
    }

    public UserProfile createUserProfile(UserProfile userProfile) {
        return userProfileRepository.save(userProfile);
    }

    public Page<UserProfile> getUsers(String page, Long customerId, String fieldToSortBy, String direction) {
        if (customerId == null) {
            Pageable pageable = createPageableWithFieldToSortBy(page, fieldToSortBy, true, direction);
            return userProfileRepository.findAll(pageable);
        } else {
            Pageable pageable = createPageableWithFieldToSortBy(page, fieldToSortBy, false, direction);
            return userProfileRepository.getCustomerUsers(customerId, pageable);
        }
    }

    public Page<UserProfile> getActiveUsers(ReportUser user, String page, Long customerId, String fieldToSortBy, String direction) {
        Pageable pageable = createPageableWithFieldToSortBy(page, fieldToSortBy, false, direction);
        if (customerId == null) {
                return userProfileRepository.getAllActiveUsers(pageable);
        } else {
            // Customer Admin see only external users
            return user.getRole().getType().equals(UserType.CustomerAdmin) ? userProfileRepository.getActiveExternalUsers(customerId, pageable)
                    : userProfileRepository.getActiveUsers(customerId, pageable);
        }
    }


    public Page<UserProfile> searchUsers(ReportUser user, String page, String searchString, String customerName, String fieldToSortBy, String direction) {
        Pageable pageable = createPageableWithFieldToSortBy(page, fieldToSortBy, false, direction);

        if (customerName == null) {
            return user.getRole().getType().equals(UserType.SuperAdmin) ? userProfileRepository.searchAllUsersByUsernameOrFirstNameOrLastNameOrEmailForAS(searchString, pageable)
                    : userProfileRepository.searchAllUsersByUsernameOrFirstNameOrLastNameOrEmail(searchString, pageable, user.getUsername());
        } else {
            return userProfileRepository.searchCustomerUsersByUsernameOrFirstNameOrLastNameOrEmail(customerRepository.getCustomerIdForCustomerName(customerName), searchString, pageable);
        }
    }

    public Page<UserProfile> searchActiveUsers(ReportUser user, String page, String searchString, String customerName, String fieldToSortBy, String direction) {
        Pageable pageable = createPageableWithFieldToSortBy(page, fieldToSortBy, false, direction);
        if (customerName == null) {
            return user.getRole().getType().equals(UserType.SuperAdmin) ? userProfileRepository.searchAllActiveUsersByUsernameOrFirstNameOrLastNameOrEmailForAS(searchString, pageable)
                    : userProfileRepository.searchActiveUsersByUsernameOrFirstNameOrLastNameOrEmailForIA(searchString, pageable);
        } else {
            // Customer Admin will see only external users
            return (user.getRole().getType().equals(UserType.CustomerAdmin)) ?  userProfileRepository.searchActiveExternalCustomerUsersByUsernameOrFirstNameOrLastNameOrEmail(customerRepository.getCustomerIdForCustomerName(customerName), searchString, pageable)
            : userProfileRepository.searchActiveCustomerUsersByUsernameOrFirstNameOrLastNameOrEmail(customerRepository.getCustomerIdForCustomerName(customerName), searchString, pageable);
        }
    }


    private Pageable createPageableWithFieldToSortBy(String page, String fieldToSortBy, boolean needEntityProperty, String direction) {
        Pageable pageable;
        if (needEntityProperty) {
            fieldToSortBy = convertFieldToEntityProperty(fieldToSortBy);
        } else {
            fieldToSortBy = convertFieldToColumnName(fieldToSortBy);
        }

        Sort.Direction sortDirection = Sort.Direction.ASC;
        if (direction != null) {
            if (direction.equalsIgnoreCase("descending")) {
                sortDirection = Sort.Direction.DESC;
            }
        }

        if (page.equals("All")) {
            pageable = PageRequest.of(0, Integer.MAX_VALUE, Sort.by(sortDirection, fieldToSortBy));
        } else {
            pageable = PageRequest.of(Integer.parseInt(page), 20, Sort.by(sortDirection, fieldToSortBy));
        }

        return pageable;
    }

    private String convertFieldToEntityProperty(String fieldToSortBy) {

        if (fieldToSortBy == null) {
            fieldToSortBy = "username";
        } else {
            fieldToSortBy = fieldToSortBy.toLowerCase();

            switch (fieldToSortBy) {
                case "id":
                    fieldToSortBy = "username";
                    break;
                case "first name":
                    fieldToSortBy = "firstName";
                    break;
                case "last name":
                    fieldToSortBy = "lastName";
                    break;
                case "role":
                    fieldToSortBy = "userRole";
                    break;
                case "status":
                    fieldToSortBy = "active";
                    break;
            }
        }
        return fieldToSortBy;
    }

    private String convertFieldToColumnName(String fieldToSortBy) {

        if (fieldToSortBy == null) {
            fieldToSortBy = "user_id";
        } else {
            fieldToSortBy = fieldToSortBy.toLowerCase();

            switch (fieldToSortBy) {
                case "id":
                    fieldToSortBy = "user_id";
                    break;
                case "first name":
                    fieldToSortBy = "firstname";
                    break;
                case "last name":
                    fieldToSortBy = "lastname";
                    break;
                case "role":
                    fieldToSortBy = "user_role";
                    break;
                case "status":
                    fieldToSortBy = "active";
                    break;
            }
        }
        return fieldToSortBy;
    }

    public boolean updateUserProfile(UserProfile userProfile) {
        Optional<UserProfile> userProfileResult = userProfileRepository.findById(userProfile.getUsername());

        if (userProfileResult.isPresent()) {
            UserProfile newUserProfile = userProfileResult.get();
            newUserProfile.setUserRole(userProfile.getUserRole());
            newUserProfile.setFirstName(userProfile.getFirstName());
            newUserProfile.setLastName(userProfile.getLastName());
            newUserProfile.setEmail(userProfile.getEmail());
            newUserProfile.setFunctionCode(userProfile.getFunctionCode());
            newUserProfile.setActive(userProfile.getActive());
            newUserProfile.setIsSudoEnabled(userProfile.getIsSudoEnabled());
            newUserProfile.setDataHistoryMonths(userProfile.getDataHistoryMonths());
            newUserProfile.setUpdatedBy(userAuthentication.getLoggedInUser().getUsername());
            newUserProfile.setUpdatedDate(new Date(System.currentTimeMillis()));
            userProfileRepository.save(newUserProfile);
            return true;
        } else {
            return false;
        }
    }

    public ResponseEntity<String> deleteUserProfile(String username) throws EntityNotFoundException {
        userProfileRepository.deleteById(username);
        return new ResponseEntity<String>("UserProfile is deleted successfully", HttpStatus.ACCEPTED);
    }

    public ResponseEntity<String> deleteAllUsers(List<UserProfile> userProfile) {
        userProfileRepository.deleteAll(userProfile);
        return new ResponseEntity<String>("UserProfiles are deleted successfully", HttpStatus.ACCEPTED);
    }

    public UserProfile getUserDetailsByEmail(String email) {
        return userProfileRepository.getUserDetailsByEmail(email);
    }

    public Optional<UserProfile> findByUserName(String username) {
        return userProfileRepository.findById(username);
    }

    public UserProfile getUserDetails(String userID) {
        return userProfileRepository.getUserDetailsByUsername(userID);
    }

    /** NO LONGER USED
     * a method to insert or update userprofile details for internal or external users
     * 1.CheckUser type based on emaildomain
     * 2.If external and user doesnt exists then throw error message
     * 3.if external user not have first name and last time then insert when login
     *
     * @param userInfo
     * @return

    public UserProfile checkUserAccess(OidcUserInfo userInfo) {
        String email = StringUtils.stringOrBlank(userInfo.getClaims().get("email"));
        String userID = StringUtils.stringOrBlank(userInfo.getClaims().get("preferred_username"));
        String firstName = StringUtils.stringOrBlank(userInfo.getClaims().get("given_name"));
        String lastName = StringUtils.stringOrBlank(userInfo.getClaims().get("family_name"));
        String userRole = "IU";
        String active = "Y";
        String Internal = "true";

        checkERAAccess(userID, email); // method to check the ERA access with API

        UserProfile userProfile = userProfileRepository.getUserDetailsByUsername(userID);
        if (email.endsWith("@mckesson.com") || email.contains("@mckesson.com")) {
            if (userProfile == null) {
                userProfile = new UserProfile();
                userProfile.setUsername(userID);
                userProfile.setFirstName(firstName);
                userProfile.setLastName(lastName);
                userProfile.setEmail(email);
                userProfile.setUserRole(StringUtils.stringOrBlank(userRole));
                userProfile.setActive(StringUtils.stringOrBlank(active));
                userProfile.setInternal(StringUtils.stringOrBlank(Internal));
                userProfile.setCreatedBy("SYSTEM");
                userProfile.setIsSudoEnabled("false");
                userProfile.setCreatedDate(new Date());
                userProfile = userProfileRepository.save(userProfile);
            } else if (!StringUtils.equals(userProfile.getFirstName(), firstName)
                    || !StringUtils.equals(userProfile.getLastName(), lastName)) {
                userProfile.setUpdatedDate(new Date());
                userProfile.setFirstName(firstName);
                userProfile.setLastName(lastName);
                userProfile = userProfileRepository.save(userProfile);
            }
        } else {
            if (userProfile == null) {
                throw new UsernameNotFoundException("You do not have access to Mckesson ERA. Please contact the McKesson ERA Support Line at 800-829-3444, between 8am-5pm M-F(CST).");
            } else {
                if (StringUtils.isBlank(userProfile.getEmail())) {
                    userProfile.setEmail(email);
                    userProfile.setIsSudoEnabled("false");
                    userProfile = userProfileRepository.save(userProfile);
                } else if (!StringUtils.equals(userProfile.getFirstName(), firstName)
                        || !StringUtils.equals(userProfile.getLastName(), lastName)) {
                    userProfile.setFirstName(firstName);
                    userProfile.setLastName(lastName);
                    userProfile.setUpdatedDate(new Date());
                    userProfile = userProfileRepository.save(userProfile);
                }
            }
        }
        return userProfile;
    }
     */

    /**
     * a method to insert or update userprofile details for internal or external users
     * 1.CheckUser type based on emaildomain
     * 2.If external and user doesnt exists then throw error message
     * 3.if external user not have first name and last time then insert when login
     *
     * @param userInfo
     * @return
     */
    public UserProfile checkUserAccess(OAuth2User userInfo) {
        String email = StringUtils.stringOrBlank(userInfo.getAttribute("email")).toLowerCase();
        String userID = StringUtils.stringOrBlank(userInfo.getAttribute("preferred_username")).toLowerCase();
        String firstName = StringUtils.stringOrBlank(userInfo.getAttribute("given_name"));
        String lastName = StringUtils.stringOrBlank(userInfo.getAttribute("family_name"));
        String userRole = "IU";
        String active = "Y";
        String Internal = "true";

        checkERAAccess(userID, email); // method to check the ERA access with API

        UserProfile userProfile = userProfileRepository.getUserDetailsByUsername(userID);
        if (email.endsWith("@mckesson.com") || email.contains("@mckesson.com")) {
            if (userProfile == null) {
                userProfile = new UserProfile();
                userProfile.setUsername(userID);
                userProfile.setFirstName(firstName);
                userProfile.setLastName(lastName);
                userProfile.setEmail(email);
                userProfile.setUserRole(StringUtils.stringOrBlank(userRole));
                userProfile.setActive(StringUtils.stringOrBlank(active));
                userProfile.setInternal(StringUtils.stringOrBlank(Internal));
                userProfile.setCreatedBy("SYSTEM");
                userProfile.setIsSudoEnabled("false");
                userProfile.setCreatedDate(new Date());
                userProfile = userProfileRepository.save(userProfile);
            } else if (!StringUtils.equals(userProfile.getFirstName(), firstName)
                    || !StringUtils.equals(userProfile.getLastName(), lastName)) {
                userProfile.setUpdatedDate(new Date());
                userProfile.setFirstName(firstName);
                userProfile.setLastName(lastName);
                userProfile = userProfileRepository.save(userProfile);
            }
        } else {
            if (userProfile == null) {
                throw new UsernameNotFoundException("You do not have access to Mckesson ERA. Please contact the McKesson ERA Support Line at 800-829-3444, between 8am-5pm M-F(CST). Error code:0004");
            } else {
                if (StringUtils.isBlank(userProfile.getEmail())) {
                    userProfile.setEmail(email);
                    userProfile.setIsSudoEnabled("false");
                    userProfile = userProfileRepository.save(userProfile);
                } else if (!StringUtils.equals(userProfile.getFirstName(), firstName)
                        || !StringUtils.equals(userProfile.getLastName(), lastName)) {
                    userProfile.setFirstName(firstName);
                    userProfile.setLastName(lastName);
                    userProfile.setUpdatedDate(new Date());
                    userProfile = userProfileRepository.save(userProfile);
                }
            }
        }
        return userProfile;
    }

    public void updateLastLoginDate(String userId) {
        userProfileRepository.updateLastLoginDate(userId, new Date());
    }

    public List<Customer> getCustomers(String userId) {
        UserProfile userProfile = userProfileRepository.getUserDetailsByUsername(userId);
        return userProfile.getInternal().equalsIgnoreCase("true") ? userProfile.getUserRole().equals("ISA") ? customerRepository.getCustomerByIdForAdminTool(userId) : userProfile.getUserRole().equals("IU") ? customerRepository.getBetaCustomers() : customerRepository.getCustomerForAdminTool()
                : customerRepository.getCustomerByIdForAdminTool(userId);
    }

    public void checkERAAccess(String userId, String email) {
        if (StringUtils.equals(this.environment.getProperty("whitelist.enabled"), "true")) {
            String requestUrl = this.environment.getProperty("whitelist.url")+userId.toLowerCase()+"/groups";
            String authToken = this.environment.getProperty("whitelist.authToken");
            WhiteList whiteList =null;

            LOG.info(" WhiteListUrl @@@@@@@ "+requestUrl);
            try {
                String myResponse = RestClient.performGETOperation(authToken, requestUrl, new HashMap(), "ApiKey ");
                whiteList = new WhiteList();
                MappingUtils.populateFromJson(myResponse, whiteList);
            } catch (Exception exception) {
                LOG.error("Error occurred while getting details with Whitelisting API for the User "+userId+" Exception "+exception.getMessage());
            }
            if (whiteList == null || whiteList.getData()==null || (!whiteList.getData().contains("Reports And Analysis 2.0"))) {
                throw new UsernameNotFoundException("You do not have access to Mckesson ERA. Please contact the McKesson ERA Support Line at 800-829-3444, between 8am-5pm M-F(CST). Error code:0005");
            }
        }
        if (!email.endsWith("@mckesson.com") || !email.contains("@mckesson.com")) {
            UserProfile userProfile = userProfileRepository.getUserDetailsByUsername(userId);
            if (userProfile == null) {
                throw new UsernameNotFoundException("You do not have access to Mckesson ERA. Please contact the McKesson ERA Support Line at 800-829-3444, between 8am-5pm M-F(CST). Error code:0006");
            }
        }

    }
}