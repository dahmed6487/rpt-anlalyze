package com.mckesson.app.repository.customer;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import main.java.com.mckesson.app.domain.admin.CommonEntity;

public interface CommonEntityRepository extends JpaRepository<CommonEntity, Long> {
    @Query("select c.commonGroup as commonGroup, c.commonGroupDescription as commonGroupDescription, c.commonEntity as commonEntity, c.commonEntityDescription as commonEntityDescription, c.gpo as gpo, c.gpoDescription as gpoDescription, c.account as account, c.gpoAccount as gpoAccount FROM CommonEntity c where c.id = :commonEntityId")
    List<CommonEntity> getCommonEntityById(String commonEntityId);

    @Query("select c.commonGroup as commonGroup, c.commonGroupDescription as commonGroupDescription, c.commonEntity as commonEntity, c.commonEntityDescription as commonEntityDescription, c.gpo as gpo, c.gpoDescription as gpoDescription, c.account as account, c.gpoAccount as gpoAccount FROM CommonEntity c")
    List<CommonEntity> getAll();

}
