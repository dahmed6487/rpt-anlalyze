package com.mckesson.app.repository.user;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import main.java.com.mckesson.app.domain.user.Whitelist;

public interface WhitelistRepository extends JpaRepository<Whitelist, String>, JpaSpecificationExecutor<Whitelist> {

    Whitelist findByUserIdIgnoreCase(String userId);

}
