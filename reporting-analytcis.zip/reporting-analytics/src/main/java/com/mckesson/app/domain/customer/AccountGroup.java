package com.mckesson.app.domain.customer;

public class AccountGroup {
}
