package com.mckesson;

import java.util.List;

import main.java.com.mckesson.app.service.looker.api.DashboardApi;
import main.java.com.mckesson.app.service.looker.api.SpaceApi;
import main.java.com.mckesson.app.vo.looker.DashboardVo;

public class StageDataOperations {

    public static void main(String[] args) {
        try {

            System.out.println("Start");

            String lookerHost = "https://dev.looker.intelligence.mckesson.com:19999/api/3.1";
            String userId = "CZkdhMy7jVFtdWhvwHmc";
            String token = "Q85cpdSBgZ5pHv5wrBd9kqRh";

            String baseSpaceLocation = "81";

            SpaceApi spaceApi = new SpaceApi();
            DashboardApi dashboardApi = new DashboardApi();

            spaceApi.setConfig(userId, token, lookerHost);
            dashboardApi.setConfig(userId, token, lookerHost);

            String authToken = dashboardApi.getAuthToken();

            //authToken = "cgtDMKtb2vQRddkwRHsHjtGWKqKswFmbhJj28cM4";
            //authToken = "cgtDMKtb2vQRddkwRHsHjtGWKqKswFmbhJj28cM4";

            String[] fields = {"id", "name", "dashboard_filters"};
            DashboardVo dashboard;
            dashboard = dashboardApi.getDashboard("17", fields, authToken);

            String[] dbFields = {"id", "title", "name", "description", "favorite_count", "created_at", "last_viewed_at", "deleted", "parent_id", "dashboard_elements"};
            List<DashboardVo> dashboards = spaceApi.getDashboardsForFolder("114", dbFields, authToken);


            System.out.println("Fin.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
