package com.mckesson.app.service.customer;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import main.java.com.mckesson.app.domain.customer.SecurityGroupAccounts;
import main.java.com.mckesson.app.repository.customer.SecurityGroupAccountsRepository;
import main.java.com.mckesson.app.service.customer.SecurityGroupAccountsService;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SecurityGroupAccountsServiceTest {
    private MockMvc mockMvc;

    @Mock
    SecurityGroupAccountsRepository securityGroupAccountsRepository;

    @InjectMocks
    SecurityGroupAccountsService securityGroupAccountsService;

    String userName="Test User";
    SecurityGroupAccounts securityGroupAccounts=new SecurityGroupAccounts();
    SecurityGroupAccounts securityGroupAccounts2=new SecurityGroupAccounts();

    @Before
    public void setUp() throws Exception {
        mockMvc= MockMvcBuilders.standaloneSetup(securityGroupAccountsService).build();

        securityGroupAccounts.setSecurityGroupAccountId((long) 1);
        securityGroupAccounts.setType("TestType");
        securityGroupAccounts.setId1((long) 1);
        securityGroupAccounts.setId2((long) 2);
        securityGroupAccounts.setId3((long) 3);
        securityGroupAccounts.setId4((long) 4);

    }

    @Test
    public void getAll() {
        when(securityGroupAccountsRepository.findAll()).thenReturn(Arrays.asList(securityGroupAccounts));
        assertEquals(Arrays.asList(securityGroupAccounts),securityGroupAccountsService.getAll());
        verify(securityGroupAccountsRepository).findAll();
    }

    @Test
    public void updateAll() {
        securityGroupAccountsService.updateAll(Arrays.asList(securityGroupAccounts));
        assertEquals(Arrays.asList(securityGroupAccounts),securityGroupAccountsService.updateAll(Arrays.asList(securityGroupAccounts)));
        //verify(securityGroupAccountsRepository).saveAll(Arrays.asList(securityGroupAccounts));
    }

    @Test
    public void deleteAll() {
        ResponseEntity response = new  ResponseEntity<String> ("Your request has been completed successfully", HttpStatus.OK);
        securityGroupAccountsService.deleteAll(Arrays.asList(securityGroupAccounts));
        doNothing().when(securityGroupAccountsRepository).inActive(new Date(), Arrays.asList(1L));
        assertEquals(response,securityGroupAccountsService.deleteAll(Arrays.asList(securityGroupAccounts)));
//        verify(securityGroupAccountsRepository).delete(securityGroupAccounts);
    }
}
