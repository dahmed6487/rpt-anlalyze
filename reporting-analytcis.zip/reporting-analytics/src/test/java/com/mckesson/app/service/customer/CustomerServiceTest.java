package com.mckesson.app.service.customer;


import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.awt.print.Pageable;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.domain.admin.Module;
import main.java.com.mckesson.app.domain.customer.ContentAccessDto;
import main.java.com.mckesson.app.domain.customer.Customer;
import main.java.com.mckesson.app.domain.customer.CustomerAccount;
import main.java.com.mckesson.app.repository.admin.CollaborationTeamRepository;
import main.java.com.mckesson.app.repository.admin.ModuleRepository;
import main.java.com.mckesson.app.repository.customer.CustomerRepository;
import main.java.com.mckesson.app.repository.customer.SecurityGroupRepository;
import main.java.com.mckesson.app.service.customer.CustomerService;
import main.java.com.mckesson.app.service.looker.CollaborationTeamServiceLooker;
import main.java.com.mckesson.app.service.looker.LookerAdminService;
import main.java.com.mckesson.app.util.UserAuthentication;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CustomerServiceTest {

    private MockMvc mockMvc;

    @Mock
    CustomerRepository customerRepository;

    @Mock
    ModuleRepository moduleRepository;

    @Mock
    LookerAdminService lookerAdminService;

    @Mock
    UserAuthentication userAuthentication;

    @Mock
    CollaborationTeamRepository collaborationTeamRepository;

    @Mock
    CollaborationTeamServiceLooker collaborationTeamServiceLooker;

    @Mock
    SecurityGroupRepository securityGroupRepository;

    @InjectMocks
    CustomerService customerService;

    String userName = "Test User";
    Customer customer = new Customer();
    Customer customer2 = new Customer();
    CustomerAccount customerAccount;
    ReportUser reportUser;
    Module module = new Module();

    @Before
    public void setUp() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(customerService).build();
        customerService = new CustomerService(customerRepository, lookerAdminService, moduleRepository, userAuthentication, collaborationTeamRepository, collaborationTeamServiceLooker, securityGroupRepository);
        customer.setCustomerId((long) 1);
        customer.setPlatformId(null);
        customer.setCommonGroupId("Test CommonGroup");
        customer.setCommonGroupName("Test CommonGroupDesc");
        customer.setCommonEntityId("Test CommonEntity");
        customer.setCommonEntityName("Test CommonEntityDesc");
        customer.setCustomerName("Test Name");
        customer.setSettings("Test Settings");

        customer2.setCustomerId(2L);
        customer2.setPlatformId(null);
        customer2.setCommonGroupId("Test CommonGroup2");
        customer2.setCommonGroupName("Test CommonGroupDesc2");
        customer2.setCommonEntityId("Test CommonEntity2");
        customer2.setCommonEntityName("Test CommonEntityDesc2");
        //customer2.setName("TestName2");
        customer2.setSettings("Test Settings2");

        module.setUpdatedDate(new Date());
        module.setTitle("test1");
        module.setPlatformId("1");
        module.setModuleType("module");
        module.setModuleId(1L);


        reportUser = mock(ReportUser.class);
    }

    @Test
    public void getAll() {
        when(customerRepository.findAll()).thenReturn(Arrays.asList(customer));
        customerRepository.findAll();
        assertEquals(null, customerService.getAllCustomers());
    }

    @Test
    public void updateAll() {
        when(customerRepository.saveAll(Arrays.asList(customer))).thenReturn(Arrays.asList(customer));
        assertEquals(false, customerService.updateCustomer(customer));
        when(customerRepository.saveAll(Arrays.asList(customer))).thenReturn(Arrays.asList(customer));
//        verify(customerRepository, atLeastOnce()).findByCommonEntityId("anyString");
        when(customerRepository.findByCommonEntityId("Test CommonEntity2")).thenReturn(Optional.ofNullable(customer));
        Optional<Customer> customerOptional = customerRepository.findByCommonEntityId("Test CommonEntity2");
        assertTrue(customerOptional.isPresent());
        assertNotNull(customerOptional.get());
        Customer customer = customerOptional.get();
        customerRepository.save(customer);
        verify(customerRepository, atLeastOnce()).save(customer);
    }

    @Test
    public void deleteAll() {

        ResponseEntity response = new ResponseEntity<String>("Your request has been completed successfully", HttpStatus.ACCEPTED);
        assertEquals(response, customerService.deleteAll(Arrays.asList(customer)));
//        verify(customerRepository).deleteCustomer(new Date(), Arrays.asList(1L));

    }

    @Test
    public void getCustomer() {
        when(customerService.getCustomer()).thenReturn(Arrays.asList(customer));
        customerService.getCustomer();
        verify(customerRepository).getCustomer();
    }

    @Test
    public void getCustomerIdByCustomerName() {
        when(customerService.getCustomerIdByCustomerName(customer.getCustomerName())).thenReturn(String.valueOf(customer.getCustomerId()));
        assertEquals(String.valueOf(customer.getCustomerId()), customerService.getCustomerIdByCustomerName("Test Name"));
        verify(customerRepository).getCustomerIdByCustomerName(customer.getCustomerName());
    }


    @Test
    public void getAllCustomers() {
        customerService = mock(CustomerService.class);
        //doThrow(new EntityNotFoundException("You do not have access to any Accounts/Customers. Please contact your administrator.")).when(customerService.getCustomersForUser(reportUser));
        //assertEquals(new EntityNotFoundException("You do not have access to any Accounts/Customers. Please contact your administrator."), customerService.getCustomersForUser(reportUser));
        // when(customerService.findAccountsByCommonEntityId("1")).thenReturn(Optional.ofNullable(Arrays.asList(customerAccount)));
//        doNothing().when(customerService).insertUserProfiles();
        doNothing().when(customerService).updateUserFunctions();
        doNothing().when(customerService).insertCustomers();
        doNothing().when(customerService).insertUserMappings();
        when(customerService.mappingsCount()).thenReturn(5);
        customerService.updateUserFunctions();
        customerService.insertCustomers();
        customerService.insertUserMappings();
        assertEquals(5, customerService.mappingsCount());
        customerService.insertUserProfiles();
        customerService.getCustomer();
        when(customerService.getCustomer()).thenReturn(Arrays.asList(customer));
        assertEquals(Arrays.asList(customer), customerService.getCustomer());
        customerService.getCustomerPage(1);
        when(customerService.findAccountsByCommonEntityId("Test CommonEntity")).thenReturn(Optional.ofNullable(Arrays.asList(customerAccount)));
    }

    @Test
    public void getCustomerPage() {

        Pageable twentyElementsPage = PageRequest.of(1, 20);
        Page<Customer> page = customerRepository.findByCommonEntityNameContainingIgnoreCasePageZero(twentyElementsPage);
        Mockito.when(customerService.getCustomerPage(1)).thenReturn(page);
        verify(customerRepository).findByCommonEntityNameContainingIgnoreCasePageZero(twentyElementsPage);

    }

    @Test
    public void searchCustomerPage() {
        Pageable twentyElementsPage = PageRequest.of(1, 20);
        //verify(customerRepository).findByCommonEntityNameContainingIgnoreCasePageZero(twentyElementsPage);
        assertEquals(customerRepository.findByCommonEntityNameContainingIgnoreCasePageZero(twentyElementsPage), customerService.searchCustomerPage(1, "test"));
        verify(customerRepository).findByCommonEntityNameContainingIgnoreCase("test", twentyElementsPage);

    }

    @Test
    public void findCustomerByCommonEntityId() {
        when(customerService.findCustomerByCommonEntityId(String.valueOf(1L))).thenReturn(Optional.ofNullable(customer));
        //assertEquals(Optional.ofNullable(customer), customerService.findCustomerByCommonEntityId(String.valueOf(1L)));
//        verify(customerRepository).findByCommonEntityId(String.valueOf(1L));
    }

    @Test
    public void updateCustomer() {
        assertEquals(false, customerService.updateCustomer(customer));
       // verify(customerRepository).findByCommonEntityId(customer.getCommonEntityId());
        //assertEquals(customer.);
    }

//    @Test
//    public void getCustomersForUser() {
//        when(customerService.getCustomersForUser(reportUser)).thenThrow(new EntityNotFoundException("You do not have access to any Accounts/Customers. Please contact your administrator."));
//    }

    @Test
    public void insertUserProfiles() {
        doNothing().when(customerRepository).insertUserProfiles(new Date());
        customerService.insertUserProfiles();
//        verify(customerRepository).insertUserProfiles(new Date());
    }

    @Test
    public void updateUserFunctions() {

        doNothing().when(customerRepository).updateUserFunctions();
        customerService.updateUserFunctions();
        verify(customerRepository).updateUserFunctions();
    }

//    @Test
//    public void insertCustomers() {
//        doNothing().when(customerRepository).insertCustomers(new Date());
//        customerService.insertCustomers();
//        verify(customerRepository).insertCustomers(new Date());
//    }

    @Test
    public void mappingsCount() {
        when(customerService.mappingsCount()).thenReturn(1);
        assertEquals(1, customerService.mappingsCount());
        verify(customerRepository).mappingsCount();
    }

    @Test
    public void insertUserMappings() {
        //   doNothing().when(customerRepository).insertUserMappings(new Date());
        customerService.insertUserMappings();
//        verify(customerRepository).insertUserMappings(new Date());
    }

    @Test
    public void findContentAccessesByCommonEntityId() {
        assertEquals(Optional.ofNullable(Arrays.asList()), customerService.findContentAccessesByCommonEntityId(customer.getCommonEntityId(), "canned report"));
        verify(moduleRepository).getModulesForCustomer(customer.getCommonEntityId(), "canned report");
        // verify(moduleRepository).getModules();
    }

    @Test
    public void findContentAccessesByCommonEntityId_modyleTypeExplore() {
        assertEquals(Optional.ofNullable(Arrays.asList()), customerService.findContentAccessesByCommonEntityId(customer.getCommonEntityId(), "explore"));
        //verify(moduleRepository).getExplores();
    }

    @Test
    public void getContentAccessByCustomer() {
        when(customerService.getContentAccessByCustomer(customer.getCustomerName())).thenReturn(Arrays.asList(module));
        verify(moduleRepository).getExploresByCustomer(customer.getCustomerName());
        when(moduleRepository.getExploresByCustomer(customer.getCustomerName())).thenReturn(Arrays.asList());
        List<Module> foundModule = (moduleRepository.getExploresByCustomer(customer.getCustomerName()));
        assertEquals(0, foundModule.size());
//        verify(moduleRepository).findByModuleType("explore");
    }

    @Test
    public void findAccountsByCommonEntityId() {
        assertEquals(Optional.ofNullable(Arrays.asList()), customerService.findAccountsByCommonEntityId(customer.getCommonEntityId()));
        verify(customerRepository).findAccountsByCommonEntityId(customer.getCommonEntityId());
    }

    @Test
    public void updateCustomerContentAccesses() throws Exception {
        assertEquals(false, customerService.updateCustomerContentAccesses(customer.getCommonEntityId(), module.getModuleType(), Arrays.asList(new ContentAccessDto())));
//        verify(customerRepository).checkExistingAccess(customer.getCommonEntityId(), "testModule", module.getModuleType());
//        verify(customerRepository).updateAccess(customer.getCommonEntityId(), "testModule", module.getModuleType());
    }

    @Test
    public void updateExploreContentAccesses() throws Exception {
        ContentAccessDto contentAccessDto = new ContentAccessDto();
        contentAccessDto.setAccessible(true);
        contentAccessDto.setModule("testModule");
        assertEquals(true, customerService.updateExploreContentAccesses(customer.getCommonEntityId(), module.getModuleType(), Arrays.asList(contentAccessDto)));

    }

    @Test
    public void getGroupAccessOfLookerFolder() {
        assertEquals(false, customerService.getGroupAccessOfLookerFolder(1L, module.getModuleId()));

    }

    @Test
    public void modifyAccessSoGroupHasAccessToLookerFolder() {
        assertEquals(false, customerService.modifyAccessSoGroupHasAccessToLookerFolder(1L, module.getModuleId()));
    }

}
