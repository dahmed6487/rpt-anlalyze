package com.mckesson.app.service.admin;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;

import main.java.com.mckesson.app.auth.user.ReportUser;
import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.domain.admin.Module;
import main.java.com.mckesson.app.domain.customer.UserMapping;
import main.java.com.mckesson.app.domain.user.UserProfile;
import main.java.com.mckesson.app.misc.EntityNotFoundException;
import main.java.com.mckesson.app.misc.ErrorMessagesEnum;
import main.java.com.mckesson.app.repository.admin.CollaborationTeamRepository;
import main.java.com.mckesson.app.repository.admin.ModuleRepository;
import main.java.com.mckesson.app.repository.customer.CustomerRepository;
import main.java.com.mckesson.app.repository.customer.UserMappingRepository;
import main.java.com.mckesson.app.repository.user.UserProfileRepository;
import main.java.com.mckesson.app.service.admin.CollaborationTeamService;
import main.java.com.mckesson.app.service.customer.CustomerService;
import main.java.com.mckesson.app.service.customer.UserMappingService;
import main.java.com.mckesson.app.service.looker.CollaborationTeamServiceLooker;
import main.java.com.mckesson.app.service.looker.SpaceManagementService;
import main.java.com.mckesson.app.service.looker.api.ContentApi;
import main.java.com.mckesson.app.service.looker.api.FolderApi;
import main.java.com.mckesson.app.service.looker.api.GroupApi;
import main.java.com.mckesson.app.service.user.UserProfileService;
import main.java.com.mckesson.app.util.UserAuthentication;

@RunWith(MockitoJUnitRunner.class)
public class CollaborationTeamServiceTest {
    private MockMvc mockMvc;

    @Mock
    CollaborationTeamRepository collaborationTeamRepository;

    @Mock
    UserProfileRepository userProfileRepo;

    @Mock
    UserMappingRepository userMappingRepository;



    @Mock
    CollaborationTeamServiceLooker collaborationTeamServiceLooker;

    @Mock
    ModuleRepository moduleRepository;

    @Mock
    UserProfileService userProfileService;

    @Mock
    CustomerService customerService;

    @Mock
    SpaceManagementService spaceManagementService;

    @Mock
    CustomerRepository customerRepository;

    @Mock
    FolderApi folderApi;

    @Mock
    GroupApi groupApi;

    @Mock
    ReportUser reportUser;

    @Mock
    SecurityContextHolder securityContextHolder;

    @Mock
    UserAuthentication userAuthentication;

    ObjectMapper objectMapper = new ObjectMapper();

    @InjectMocks
    UserMappingService userMappingService = mock(UserMappingService.class);

    @InjectMocks
    CollaborationTeamService collaborationTeamService;

    String userName = "Test User";
    CollaborationTeam collaborationTeam = new CollaborationTeam();
    static List<UserProfile> users = new ArrayList<>();
    List<CollaborationTeam> collaborationTeamArrayList = new ArrayList<>();
    static UserMapping userMapping;

    static UserProfile user;
    Module module = new Module();

    @Before
    public  void dataLoad() {
        user = new UserProfile();
        user.setUserRole("EMPLOYEE");
        user.setActive("ACTIVE");
        user.setCreatedBy("");
        user.setCreatedDate(new Timestamp(System.currentTimeMillis()));
        user.setExternalId(1L);
        user.setBlaEligible("true");
        user.setFirstName("Mr. X");
        users.add(user);

        userMapping = new UserMapping();
        userAuthentication = new UserAuthentication();
        reportUser.setUsername("Test User");



    }

    @Before
    public void setUp() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(collaborationTeamService).build();
        collaborationTeamService = new CollaborationTeamService(collaborationTeamRepository, collaborationTeamServiceLooker, userProfileService, userProfileRepo, userAuthentication, userMappingService, moduleRepository, customerService, customerRepository, folderApi, groupApi, new ContentApi(), spaceManagementService, moduleRepository, objectMapper);
        collaborationTeam.setCollaborationTeamId((1L));
        collaborationTeam.setPlatformId(null);
        collaborationTeam.setCustomerId(1L);
        collaborationTeam.setName("TestCollabTeamName");
        collaborationTeamArrayList.add(collaborationTeam);


        module.setModuleId(1L);
        module.setModuleType("test type");
        module.setTitle("Title test");
        module.setUrl("https://url.com");
        module.setColor("test color");

    }

    @Test
    public void getAllTeams() {
        when(collaborationTeamService.getAllTeams()).thenReturn(Arrays.asList(collaborationTeam));
        assertEquals(Arrays.asList(collaborationTeam), collaborationTeamService.getAllTeams());
        verify(collaborationTeamRepository).findAll();
    }

//    @Test
//    public void createTeam() {
//        when(collaborationTeamService.createTeam(collaborationTeam)).thenReturn(collaborationTeam);
//        verify(collaborationTeamRepository).save(collaborationTeam);
//        verify(moduleRepository).findByCustomerId(collaborationTeam.getCustomerId());
//    }

    @Test
    public void updateTeam() {
        //when(collaborationTeamService.updateTeam(collaborationTeam)).thenReturn(true);
        Boolean actual = collaborationTeamService.updateTeam(collaborationTeam);
        assertFalse(actual);

//        assertEquals(anyBoolean(), collaborationTeamService.updateTeam(collaborationTeam));
//        verify(collaborationTeamRepository).findById(collaborationTeam.getCollaborationTeamId());
//        //when(collaborationTeamRepository.findById(collaborationTeam.getCollaborationTeamId())).thenReturn(Optional.ofNullable(collaborationTeam));
//        assertTrue(Optional.ofNullable(collaborationTeam).isPresent());
////        when(collaborationTeam.isPresent()).thenReturn(true);
////        verify(collaborationTeamRepository).save(Optional.ofNullable(collaborationTeam).get());
//
//        assertEquals(null, collaborationTeamRepository.save(collaborationTeam));
    }

    @Test
    public void deleteTeams() {
        collaborationTeamService.deleteTeams(Arrays.asList(collaborationTeam));
        verify(collaborationTeamRepository, atLeastOnce()).deleteRelation(anyList());
        verify(collaborationTeamRepository, atLeastOnce()).inActive(any(), anyList());
    }

    @Test
    public void getTeamsForIds() {
        List<Long> listOfIds = new ArrayList<>();
        listOfIds.add(2L);
        listOfIds.add(5L);
        when(collaborationTeamService.getTeamsForIds(listOfIds)).thenReturn(Arrays.asList(collaborationTeam));
        assertEquals(Arrays.asList(collaborationTeam), collaborationTeamService.getTeamsForIds(listOfIds));
        verify(collaborationTeamRepository).findAllById(listOfIds);
    }

    @Test
    public void insertOrUpdateRelation() {
        ResponseEntity response = new ResponseEntity<>("Your request has been completed successfully", HttpStatus.ACCEPTED);
        assertEquals(response,collaborationTeamService.insertOrUpdateRelation(collaborationTeam.getCollaborationTeamId(), collaborationTeam.getCollaborationTeamId(), Arrays.asList(user)));
        assertEquals(null,userMappingService.findCustomerMapping(users.get(0).getUsername(), 1L));
        assertNotNull(userMapping);
        //verify(collaborationTeamRepository).insertOrUpdateRelation(collaborationTeam.getCollaborationTeamId(), userMapping.getUserMappingId());
    }

    @Test
    public void getTeamIdsForCurrentUser() {
        HashSet<String> set = new HashSet<>();
        assertEquals(set, collaborationTeamService.getTeamIdsForCurrentUser(userMapping.getUsername()));
        verify(collaborationTeamRepository).getTeamIdsForCurrentUser(userMapping.getUsername());

    }

    @Test
    public void removeTeamFromUserTest() {

        assertEquals(false, collaborationTeamService.removeTeamFromUser(collaborationTeam.getCollaborationTeamId(), userMapping.getCustomerId(), userMapping.getUsername()));
//        when(userMappingService.findCustomerMapping(userMapping.getUsername(), userMapping.getCustomerId())).thenReturn(userMapping);
        assertNotNull(userMapping);
//        verify(collaborationTeamRepository).deleteRelationByTeamAndUser(collaborationTeam.getCollaborationTeamId(), userMapping.getCustomerId());
    }

    @Test
    public void deleteRelationById() {
        ResponseEntity response = new ResponseEntity<>("Your request has been completed successfully", HttpStatus.ACCEPTED);
        assertEquals(response, collaborationTeamService.deleteRelationById(Arrays.asList(collaborationTeam.getCollaborationTeamId().intValue())));
        verify(collaborationTeamRepository).deleteRelationById(Arrays.asList(collaborationTeam.getCollaborationTeamId().intValue()));
    }

    @Test

    public void getTeams() {
        when(collaborationTeamService.getTeams(Long.toString(collaborationTeam.getCollaborationTeamId()))).thenReturn(Optional.ofNullable(collaborationTeam));
        assertEquals(Optional.ofNullable(collaborationTeam), collaborationTeamService.getTeams(Long.toString(collaborationTeam.getCollaborationTeamId())));
        verify(collaborationTeamRepository).findById(collaborationTeam.getCollaborationTeamId());
        //when(collaborationTeamService.getTeamIdForCustomer)
    }

    @Test
    public void getTeamByCustomerId() {
        when(collaborationTeamService.getTeamsByCustomerId(collaborationTeam.getCustomerId())).thenReturn(Optional.ofNullable(Arrays.asList(collaborationTeam)));
        assertEquals(Optional.ofNullable(Arrays.asList(collaborationTeam)), collaborationTeamService.getTeamsByCustomerId(collaborationTeam.getCustomerId()));
        verify(collaborationTeamRepository).findByCustomerId(collaborationTeam.getCustomerId());
    }

    @Test
    public void getMembersByCollabTeamId() {
        when(collaborationTeamService.getMembersByCollabTeamId(collaborationTeam.getCollaborationTeamId().toString())).thenReturn(Optional.ofNullable(Arrays.asList(user)));
        assertEquals(Optional.ofNullable(Arrays.asList(user)), collaborationTeamService.getMembersByCollabTeamId(collaborationTeam.getCollaborationTeamId().toString()));
        verify(userProfileRepo).getMembersByCollabTeamId(collaborationTeam.getCollaborationTeamId().toString());

//        verify(userProfileRepo, atLeastOnce()).getMembersByCollabTeamId();
    }

    //@Test
    public void deleteTeam_false() {
        when(collaborationTeamService.deleteTeam(collaborationTeam.getCollaborationTeamId())).thenReturn(false);
        assertEquals(false, collaborationTeamService.deleteTeam(collaborationTeam.getCollaborationTeamId()));
        verify(collaborationTeamRepository).findById(collaborationTeam.getCollaborationTeamId());
        assertEquals(collaborationTeam, collaborationTeamRepository.getTopLevelCustomerTeam(collaborationTeam.getCustomerId()));
        verify(collaborationTeamRepository).getTopLevelCustomerTeam(collaborationTeam.getCustomerId());

    }


    //@Test
    public void deleteTeam_true() {
//        when(collaborationTeamService.deleteTeam(collaborationTeam.getCollaborationTeamId())).thenThrow(new EntityNotFoundException("You are not assigned to any Teams"));
        //when(collaborationTeamService.deleteTeam(collaborationTeam.getCollaborationTeamId())).thenReturn(true);
        when(collaborationTeamService.deleteTeam(collaborationTeam.getCollaborationTeamId())).thenThrow(new EntityNotFoundException(ErrorMessagesEnum.valueOf("TEAMS_NOT_FOUND").getErrorMsg()));
        assertEquals(true, collaborationTeamService.deleteTeam(collaborationTeam.getCollaborationTeamId()));
        verify(collaborationTeamRepository).findById(collaborationTeam.getCollaborationTeamId());
        verify(collaborationTeamRepository).getTopLevelCustomerTeam(collaborationTeam.getCustomerId());
        assertNotEquals(collaborationTeam, collaborationTeamRepository.getTopLevelCustomerTeam(collaborationTeam.getCustomerId()));
        assertNotNull(collaborationTeam.getExternalId());
        verify(collaborationTeamServiceLooker).deleteTeams(collaborationTeam.getExternalId());
        verify(collaborationTeamRepository).deleteUserMapTeamRelation(collaborationTeam.getCollaborationTeamId());
        verify(collaborationTeamRepository).deleteModuleTeamRelation(collaborationTeam.getCollaborationTeamId());
        verify(collaborationTeamRepository).delete(collaborationTeam);
    }


    @Test
    public void findContentAccessesByTeamId() {
        assertEquals(Optional.empty(), collaborationTeamService.findContentAccessesByTeamId(module.getModuleId()));
        ArrayList<String> list = new ArrayList<>();
        list.add("test");
//        when(moduleRepository.getModulesForTeam(collaborationTeam.getCollaborationTeamId())).thenReturn(list);
        verify(moduleRepository).getModulesForTeam(collaborationTeam.getCollaborationTeamId());
    }


}