package com.mckesson.app.service.looker;

//
//import com.mckesson.app.domain.looker.CustomFilter;
//import com.mckesson.app.domain.looker.FilterCriteria;
//import com.mckesson.app.domain.looker.FilterCriteriaGroup;
//import com.mckesson.app.misc.ApiException;
//import com.mckesson.app.repository.looker.CustomFilterGroupCriteriaRepository;
//import com.mckesson.app.repository.looker.CustomFilterGroupRepository;
//import com.mckesson.app.repository.looker.CustomFilterRepository;
//import com.mckesson.app.service.looker.CustomFilterService;
//import com.mckesson.app.service.looker.CustomFilterServiceImpl;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.junit.MockitoJUnitRunner;
//import org.springframework.data.domain.Page;
//import org.springframework.data.domain.PageRequest;
//import org.springframework.data.domain.Pageable;
//
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//import java.util.Arrays;
//import java.util.LinkedList;
//import java.util.List;
//import java.util.Optional;
//
//import static com.mckesson.app.service.looker.CustomFilterService.SINGLE_DELIM;
//import static com.mckesson.app.service.looker.CustomFilterService.TRIPLE_DELIM;
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertTrue;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//@RunWith(MockitoJUnitRunner.Silent.class)
//public class CustomFilterServiceImplTest {
//
//    @Mock
//    MockUtils mockUtils;
//
//    @InjectMocks
//    private CustomFilterServiceImpl customFilterService;
//
//    @InjectMocks
//    CustomFilterRepository customFilterRepo;
//
//    @Mock
//    CustomFilterGroupRepository customFilterGroupRepo;
//
//    @Mock
//    CustomFilterGroupCriteriaRepository customFilterCriteriaRepo;
//
//    /**
//     * Given a user defined name for a custom dimension, confirm that we can generate a properly formatted
//     * reference for it.
//     */
//
//    @Test
//    public void searchCustomFilters(){
//
//        Pageable twentyElementsPage = PageRequest.of(page, 20);
//        Mockito.when(customFilterService.searchCustomFilters(1,"",""))
//                .thenReturn(customFilterRepo.findByUserIdAndNameContainingIgnoreCase("","",page));
//        assertEquals(Arrays.asList(customFilterRepo), customFilterService.searchCustomFilters(1,"",""));
//        verify(customFilterRepo).findByUserIdAndNameContainingIgnoreCase("","",page);
//    }
//
//    @Test
//    public void listCustomFilters(){
//        Mockito.when(customFilterService.listCustomFilters(1,1)).thenReturn(customFilterRepo.list());
//        assertEquals(Arrays.asList(customFilterRepo), customFilterService.listCustomFilters(1,1));
//        verify(customFilterRepo).list();
//    }
//
//    @Test
//    public void getAll(){
//        Mockito.when(customFilterService.getAll()).thenReturn(customFilterRepo.findAll());
//        assertEquals(Arrays.asList(customFilterRepo),customFilterService.getAll());
//        verify(customFilterRepo).findAll();
//    }
//    @Test
//    public void getByExploreType(){
//        Mockito.when(customFilterService.getByExploreType("",""))
//                .thenReturn(customFilterRepo.getByExploreType("",""));
//        assertEquals(Arrays.asList(customFilterRepo),customFilterService.getByExploreType("",""));
//        verify(customFilterRepo).getByExploreType("","");
//    }
//
//    @Test
//    public void findById(){
//
//        Mockito.when(customFilterService.findById()).thenReturn(customFilterRepo.findById());
//       assertEquals(null, customFilterService.findById());
//       verify(customFilterRepo).findById();
//    }
//    @Test
//    public void getCustomFilter(){
//        Mockito.when(customFilterService.getCustomFilter()).thenReturn(Arrays.asList(customFilterRepo.findById()));
//        assertEquals(Arrays.asList(customFilterRepo.findById()), customFilterService.getCustomFilter());
//        verify(customFilterRepo).findById();
//    }
//
//    @Test
//    public void getCustomFilterGroupForFilter(){
//
//        Mockito.when(customFilterGroupRepo.getByFilterId()).thenReturn(customFilterGroupRepo.getByFilterId());
//        assertEquals(customFilterRepo,customFilterGroupRepo.getByFilterId());
//        verify(customFilterGroupRepo).getByFilterId();
//    }
//
//    @Test
//    public void delete(){
//        Mockito.when(customFilterService.getCustomFilter()).thenReturn(customFilterRepo.delete());
//        assertEquals(customFilterService, customFilterRepo.delete());
//        verify(customFilterRepo).delete();
//    }
//
//    @Test
//    public void getCustomFilterCriteriaForGroup(){
//
//        Mockito.when(customFilterCriteriaRepo.getByGroupId()).thenReturn(customFilterCriteriaRepo.getByGroupId(groupId));
//        assertEquals(customFilterCriteriaRepo.getByGroupId());
//        verify(customFilterCriteriaRepo).getByGroupId();
//    }
//    @Test
//    public void testFormatDimensionLabel() {
//        String result = customFilterService.formatDimensionName("My Explore Ref");
//        assertTrue(result.contentEquals("my_explore_ref"));
//    }
//    @Test
//            public void getFilterCriteria(){
//        FilterCriteria existing = customFilterCriteriaRepo.findById("").orElseThrow(() -> new ApiException(String.format("No filter criteria with id=%s found!", "")));
//        Mockito.when(customFilterCriteriaRepo.findById()).thenReturn(Optional.ofNullable(existing));
//        assertEquals(customFilterCriteriaRepo, customFilterCriteriaRepo.findById());
//        verify(customFilterCriteriaRepo).findById();
//
//    }
//    @Test
//            public void getCustomListForUserAndExplore(){
//        when(customFilterRepo.listForExplore()).thenReturn(customFilterRepo.listForExplore(exploreId));
//        assertEquals(customFilterRepo, customFilterRepo.listForExplore());
//        verify(customFilterRepo).listForExplore();
//    }
//
//    @Test
//            public void delimitJson(){
//        String source = null;
//        source = source.replace(SINGLE_DELIM, "\\\"");
//        source = source.replace(TRIPLE_DELIM, "\\\\\\\"");
//        assertEquals(null, source);
//    }
//
//    @Test
//            public void
//
//
//    /**
//     * Utility method for loading text file from classpath. As a general strategy, expected LookML content is defined in text files.
//     *
//     * @param fileName
//     * @return
//     * @throws Exception
//     */
//    String getJsonSource(String fileName) throws Exception{
//        Class clazz = CustomFilterServiceImplTest.class;
//        InputStream inputStream = clazz.getResourceAsStream("/"+ fileName);
//        return readFromInputStream(inputStream);
//    }
//
//    String readFromInputStream(InputStream inputStream)
//            throws IOException {
//        StringBuilder resultStringBuilder = new StringBuilder();
//        try (BufferedReader br
//                     = new BufferedReader(new InputStreamReader(inputStream))) {
//            String line;
//            while ((line = br.readLine()) != null) {
//                resultStringBuilder.append(line).append("\n");
//            }
//        }
//        return resultStringBuilder.toString();
//    }
//
//
//    @Test
//    public void testFormatCriteria() {
//
//        String[] criteria = {"Facility A", "Facility B", "Facility C"};
//
//        String result = customFilterService.formatCriteria(criteria);
//
//        String expResult = "`"+ TRIPLE_DELIM +"Facility A"+ TRIPLE_DELIM +","+ TRIPLE_DELIM +"Facility B"+ TRIPLE_DELIM +","+ TRIPLE_DELIM + "Facility C"+ TRIPLE_DELIM +"`";
//
//        assertEquals(null, result, expResult);
//    }
//
//    @Test
//    public void testDelimitJson() {
//        String expResult = "\\\"a sample string\\\", [\\\\\\\" another sample string \\\\\\\"]";
//        String input = SINGLE_DELIM +"a sample string"+ SINGLE_DELIM +", ["+ TRIPLE_DELIM +" another sample string "+ TRIPLE_DELIM +"]";
//        String result = customFilterService.delimitJson(input);
//        assertTrue(result, expResult.equals(result));
//    }
//
//    /**
//     * When multiple groups are present in a filter definition, we need to create a parent-child relation as a precursor to creating nested
//     * LookML statements.
//     */
////	@Test
////	public void testTranslateElementsToHierarchy() {
////		List<FilterCriteriaGroup> groups = new ArrayList();
////		FilterCriteriaGroup group;
////		groups.add(new FilterCriteriaGroup("Group1"));
////		groups.add(new FilterCriteriaGroup("Group2"));
////		groups.add(new FilterCriteriaGroup("Group3"));
////
////		FilterCriteriaGroup result = customFilterService.createNestedReferences(groups);
////
////		assertTrue(result.getChild()!=null);
////		assertTrue(result.getChild().getChild()!=null);
////		assertTrue(result.getName().equals("Group1"));
////		assertTrue(result.getChild().getName().equals("Group2"));
////		assertTrue(result.getChild().getChild().getName().equals("Group3"));
////
////	}
//
//    /**
//     * Validate ability to format filter groups into the LookML equivelant.
//     */
//    @Test
//    public void testFormatFilterGroup() throws Exception{
//        String expResult;
//        FilterCriteriaGroup group;
//        List<FilterCriteriaGroup>groups;
//        String result = null;
//
//        //Confirm that the correct LookML fragment is generated when only a single group is present.
//        expResult = formatForComparison(getJsonSource("lookml/single-filter-group.txt"));
//        group = mockUtils.getMockFilterGroup();
//        result = formatForComparison(customFilterService.formatCustomGroup(new LinkedList<>(group.getFilterCriteria()), null));
//        assertTrue(result.equalsIgnoreCase(expResult));
//    }
//
//    /**
//     * Given a collection or filters in parent-child format, ensure that the correct LookML token is generated.
//     */
//    @Test
//    public void testFormatFilterGroups() throws Exception{
//        String expResult = formatForComparison(getJsonSource("lookml/three-filter-group.txt"));
//        FilterCriteriaGroup group = MockUtils.getMockFilterGroups();
//        String result = formatForComparison(customFilterService.formatCustomGroup(new LinkedList<>(group.getFilterCriteria()),  null));
//        assertTrue(result.equalsIgnoreCase(expResult));
//
//        expResult = formatForComparison(getJsonSource("lookml/three-filter-group-other.txt"));
//        result = formatForComparison(customFilterService.formatCustomGroup(new LinkedList<>(group.getFilterCriteria()), "other"));
//        assertTrue(result.equalsIgnoreCase(expResult));
//    }
//
//    /**
//     * Validate ability to format the top level custom filter object into the LookML equivalent.
//     */
//    @Test
//    public void testFormatCustomFilterToDynamicFieldSyntaxInternal() throws Exception{
//        String expResult;
//        FilterCriteriaGroup group;
//        String result = null;
//
//        //Confirm the basic attributes are formatted correctly which no groups are defined.
//        expResult = formatForComparison(getJsonSource("lookml/custom-filter-no-groups-.txt"));
//        CustomFilter filter  = MockUtils.getMockCustomFilterWithNoGroupDefinitions();
//        //result = formatForComparison(customFilterService.formatCustomFilterToDynamicFieldSyntaxInternal(filter.getCriteriaGroup()));
//        assertTrue(result.equalsIgnoreCase(expResult));
//
////		//Confirm the correct LookML is present which a custom query is defined.
////			expResult = formatForComparison(getJsonSource("lookml/custom-group-custom-query.txt"));
////			group = MockUtils.getMockCustomFilterWithCustomQuery();
////			result = formatForComparison(customFilterService.formatCustomFilterToDynamicFieldSyntaxInternal(group));
////			assertTrue(result.equalsIgnoreCase(expResult));
//
//        //Confirm that the correct LookML if defined when a single group is defined.
//        expResult =  formatForComparison(getJsonSource("lookml/custom-group-single-group.txt"));
//        group = MockUtils.getMockFilterGroup();
//        //result = formatForComparison(customFilterService.formatCustomFilterToDynamicFieldSyntaxInternal(group));
//        assertTrue(result.equalsIgnoreCase(expResult));
//
//        //Confirm LookML syntax is generated when multiple group groups are defined.
//        expResult =  formatForComparison(getJsonSource("lookml/custom-group-multiple-groups.txt"));
//        group = MockUtils.getMockFilterGroups();
//        //result = formatForComparison(customFilterService.formatCustomFilterToDynamicFieldSyntaxInternal(group));
//        assertTrue(result.equalsIgnoreCase(expResult));
//
//
//    }
//
//    /**
//     * For the purposes of comparison, we don't care about line breaks and whitespace characters, so we provide a method
//     * of stripping these characters out for testing purposes.
//     *
//     * @return
//     */
//    String formatForComparison(String input) {
//        return input.replaceAll(" ", "").replaceAll("\n", "").replaceAll("\t", "");
//    }
//}
