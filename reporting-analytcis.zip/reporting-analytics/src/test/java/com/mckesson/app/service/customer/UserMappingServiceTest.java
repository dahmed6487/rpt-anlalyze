package com.mckesson.app.service.customer;


import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.domain.customer.UserMapping;
import main.java.com.mckesson.app.repository.admin.CollaborationTeamRepository;
import main.java.com.mckesson.app.repository.customer.UserMappingRepository;
import main.java.com.mckesson.app.service.customer.UserMappingService;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserMappingServiceTest {

    private MockMvc mockMvc;

    @Mock
    UserMappingRepository userMappingRepository;

    @Mock
    CollaborationTeamRepository collaborationTeamRepository;

    @InjectMocks
    UserMappingService userMappingService;

    UserMapping userMapping=new UserMapping();

    String userName="Test User";

    CollaborationTeam collaborationTeam = new CollaborationTeam();
    Map<String, String> userMap = new HashMap<>();

    @Before
    public void setUp() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(userMappingService).build();
        userMapping.setUserMappingId((long) 1);
        userMapping.setCustomerId((long) 1);
        userMapping.setPlatformId(null);
        userMapping.setUsername("Test User");
        userMapping.setUserType("Internal");

        userMap.put("mappingType", "team");

        collaborationTeam.setCollaborationTeamId((1L));
        collaborationTeam.setPlatformId(null);
        collaborationTeam.setCustomerId(1L);
        collaborationTeam.setName("Collaboration name");
        collaborationTeam.setCreatedBy("Test");
    }

    @Test
    public void getUserMapping() {
        Mockito.when(userMappingService.getUserMapping()).thenReturn(Arrays.asList(userMapping));//Method mocking with when, thenreturn
        assertEquals(Arrays.asList(userMapping), userMappingService.getUserMapping());// assert (check) method mocking is returning the same
        verify(userMappingRepository).findAll();// verify the executed methods in the mocked method



        //Mockito.when(userMappingRepository.getUserMapping(userMapping.getUsername())).thenReturn(Arrays.asList(userMapping));
        //verify(userMappingRepository).getUserMapping(String.valueOf(userMapping));
    }

    @Test
    public void updateUserMapping() {
        //userMappingService.updateUserMapping(Arrays.asList(userMapping));
        assertEquals(Arrays.asList(userMapping),userMappingService.updateUserMapping(Arrays.asList(userMapping)));
        //doNothing().when(userMappingRepository).active(Arrays.asList(1L, 2L));
//        verify(userMappingRepository).saveAll(Arrays.asList(userMapping));
    }

    @Test
    public void deleteUserMapping() {
        ResponseEntity<String> responseEntity=new ResponseEntity<String>("Your request has been completed successfully", HttpStatus.ACCEPTED);
        //Mockito.when(userMappingRepository.deleteAll(Arrays.asList(userMapping))).thenReturn(responseEntity);
        userMappingService.deleteUserMapping(Arrays.asList(userMapping));
        assertEquals(responseEntity,userMappingService.deleteUserMapping(Arrays.asList(userMapping)));
        //verify(userMappingRepository).delete(userMapping);
    }

    @Test
    public void getTeamsForUser(){
        Mockito.when(userMappingService.getTeamsForUser(userMapping.getUsername())).thenReturn(Arrays.asList(collaborationTeam));
        assertEquals(Arrays.asList(collaborationTeam), userMappingService.getTeamsForUser(userMapping.getUsername()));
        verify(collaborationTeamRepository).getCollaborationTeams(userMapping.getUsername());
    }

    @Test
    public void getTeamsByUserAndCustomer() {
        Mockito.when(userMappingService.getTeamsByUserAndCustomer(userMapping.getUsername(), userMapping.getUsername())).thenReturn(Arrays.asList(collaborationTeam));
        assertEquals(Arrays.asList(collaborationTeam), userMappingService.getTeamsByUserAndCustomer(userMapping.getUsername(), userMapping.getUsername()));
        verify(collaborationTeamRepository).getTeamsByUserAndSelectedCustomer(userMapping.getUsername(), userMapping.getUsername());
    }

    @Test
    public void findCustomerMappings(){
        Mockito.when(userMappingService.findCustomerMappings(userMapping.getUsername())).thenReturn(Arrays.asList(userMapping));
        assertEquals(Arrays.asList(userMapping), userMappingService.findCustomerMappings(userMapping.getUsername()));
        verify(userMappingRepository).findByusername(userMapping.getUsername());
    }

    @Test
    public void insertOrUpdateRelation(){
        ResponseEntity response = new ResponseEntity<>("Your request has been completed successfully", HttpStatus.ACCEPTED);
        userMap.put("collaborationTeamId", "test1");
        userMap.put("userMappingId", "test2");
        userMap.put("mappingType", "team");
        userMappingService.insertOrUpdateRelation(userMap);
        doNothing().when(userMappingRepository).insertOrUpdateTeamsRelation(userMap.get("collaborationTeamId"), userMap.get("userMappingId"));
        verify(userMappingRepository).insertOrUpdateTeamsRelation(userMap.get("collaborationTeamId"), userMap.get("userMappingId"));

//        userMap.put("mappingType", "module");
//        Mockito.when(userMappingService.insertOrUpdateRelation(userMap)).thenReturn(response);
//        userMap.put("moduleId", "test2");
        //verify(userMappingRepository).insertOrUpdateModuleRelation(userMap.get("moduleId"), userMap.get("userMappingId"));

//        userMap.put("mappingType", "securityGroup");
//        Mockito.when(userMappingService.insertOrUpdateRelation(userMap)).thenReturn(response);
//        userMap.put("securityGroupId", "test4");
        //verify(userMappingRepository).insertOrUpdateTeamsRelation(userMap.get("securityGroupId"), userMap.get("userMappingId"));

        // Mockito.when(userMappingService.insertOrUpdateRelation(userMap)).thenReturn(response);
    }


    @Test
    public void insertOrUpdateRelation_case3(){
        ResponseEntity response = new ResponseEntity<>("Your request has been completed successfully", HttpStatus.ACCEPTED);
        userMap.put("userMappingId", "test2");
        userMap.put("securityGroupId", "test4");
        userMap.put("mappingType", "securityGroup");
        userMappingService.insertOrUpdateRelation(userMap);
        doNothing().when(userMappingRepository).insertOrUpdateSecurityGroupRelation(userMap.get("securityGroupId"), userMap.get("userMappingId"));
        verify(userMappingRepository).insertOrUpdateSecurityGroupRelation(userMap.get("securityGroupId"), userMap.get("userMappingId"));

    }



    @Test
    public void insertOrUpdateRelation_case2(){
        ResponseEntity response = new ResponseEntity<>("Your request has been completed successfully", HttpStatus.ACCEPTED);
        userMap.put("userMappingId", "test2");
        userMap.put("moduleId", "test2");
        userMap.put("mappingType", "module");
        userMappingService.insertOrUpdateRelation(userMap);
        doNothing().when(userMappingRepository).insertOrUpdateModuleRelation(userMap.get("moduleId"), userMap.get("userMappingId"));
        verify(userMappingRepository).insertOrUpdateModuleRelation(userMap.get("moduleId"), userMap.get("userMappingId"));
    }


    @Test
    public void deleteModuleRelationById(){

        ResponseEntity response = new ResponseEntity<>("Your request has been completed successfully", HttpStatus.ACCEPTED);
        userMappingService.deleteModuleRelationById(Arrays.asList(1, 2, 3));
        verify(userMappingRepository).deleteModuleRelationById(Arrays.asList(1, 2, 3));
    }

    @Test
    public void deleteSecurityGroupRelationById() {
        ResponseEntity response = new ResponseEntity<>("Your request has been completed successfully", HttpStatus.ACCEPTED);
        userMappingService.deleteSecurityGroupRelationById(Arrays.asList(1, 2, 3));
        verify(userMappingRepository).deleteSecurityGroupRelationById(Arrays.asList(1, 2, 3));
    }

    @Test
    public void softDeleteUserFromTeam(){
        assertEquals(false, userMappingService.softDeleteUserFromTeam(userMapping.getUsername(), userMapping.getUsername()));
        verify(userMappingRepository).findByusername(userMapping.getUsername());
        //verify(userMappingRepository).softDeleteUserFromTeam(new Date(), Arrays.asList("test1", "`test2`"), userMapping.getUsername());
    }

}
