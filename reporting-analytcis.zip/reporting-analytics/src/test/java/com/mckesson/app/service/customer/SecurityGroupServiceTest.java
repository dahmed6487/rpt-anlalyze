package com.mckesson.app.service.customer;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import main.java.com.mckesson.app.domain.customer.SecurityGroup;
import main.java.com.mckesson.app.repository.customer.SecurityGroupRepository;
import main.java.com.mckesson.app.service.customer.SecurityGroupService;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SecurityGroupServiceTest {
    private MockMvc mockMvc;

    @Mock
    SecurityGroupRepository securityGroupRepository;

    @InjectMocks
    SecurityGroupService securityGroupService;

    String userName="Test User";
    SecurityGroup securityGroup=new SecurityGroup();
    SecurityGroup securityGroup2=new SecurityGroup();

    @Before
    public void setUp() throws Exception {
        mockMvc= MockMvcBuilders.standaloneSetup(securityGroupService).build();
        securityGroup.setSecurityGroupId((long) 1);
        securityGroup.setPlatformId(null);
        securityGroup.setName("TestCollabTeamName");
    }

    @Test
    public void getAll() {
        when(securityGroupRepository.findAll()).thenReturn(Arrays.asList(securityGroup));
        assertEquals(Arrays.asList(securityGroup),securityGroupService.getAll());
        verify(securityGroupRepository).findAll();
    }

    @Test
    public void updateAll() {

        when(securityGroupRepository.saveAll(Arrays.asList(securityGroup))).thenReturn(Arrays.asList(securityGroup));
        assertEquals(Arrays.asList(securityGroup),securityGroupService.updateAll(Arrays.asList(securityGroup)));

    }

//    @Test
//    public void deleteAll() {
//
//        ResponseEntity responseEntity = new ResponseEntity<String>("Your request has been completed successfully", HttpStatus.ACCEPTED);
//        when(securityGroupRepository.deleteAll(Arrays.asList(securityGroup)).thenReturn(responseEntity));
//        assertEquals(null ,securityGroupService.deleteAll(Arrays.asList(securityGroup)));
//        verify(securityGroupRepository).delete();
//    }
}
