package com.mckesson.app.service.admin;

import static org.mockito.Mockito.mock;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import main.java.com.mckesson.app.repository.FileUploadRepository;
import main.java.com.mckesson.app.service.admin.BlobStorageService;

@RunWith(MockitoJUnitRunner.Silent.class)
public class BlobStorageServiceTest {

    @Mock
    FileUploadRepository fileUploadRepository;

    @InjectMocks
    BlobStorageService blobStorageService;

    @Before
    public void setUp(){
       // blobStorageService = new BlobStorageService(fileUploadRepository, null);
    }

    @Test
    public void putBlob() throws IOException {
        blobStorageService = mock(BlobStorageService.class);
        blobStorageService.putBlob("{}", "ACCOUNT_SEGMENTATION");
    }


}