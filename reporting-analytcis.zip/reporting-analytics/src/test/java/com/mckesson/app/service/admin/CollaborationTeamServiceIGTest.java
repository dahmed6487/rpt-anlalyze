package com.mckesson.app.service.admin;

import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.repository.admin.CollaborationTeamRepository;
import main.java.com.mckesson.app.service.admin.CollaborationTeamService;
import main.java.com.mckesson.app.service.looker.CollaborationTeamServiceLooker;
import main.java.com.mckesson.app.service.looker.api.FolderApi;
import main.java.com.mckesson.app.vo.looker.FolderVo;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CollaborationTeamServiceIGTest {

    @Mock
    CollaborationTeamRepository repository;

    @Mock
    FolderApi folderApi;

    @Mock
    CollaborationTeamServiceLooker collaborationTeamServiceLooker;

    @InjectMocks
    CollaborationTeamService collaborationTeamService;

    String username = "shiva.elakapally@mckesson.com";
    String parentId = "237";

    CollaborationTeam col = new CollaborationTeam();
    List<CollaborationTeam> collaborationTeams = new ArrayList<>();

    @Before
    public void initiatingValues() {


        col.setCollaborationTeamId(1L);
        col.setPlatformId("SAP");
        col.setCustomerId((long) 22);
        col.setName("vanderbilt Team3");
        col.setCreatedBy(username);
        col.setCreatedDate(new Date());
        collaborationTeams.add(col);
    }

    @Test
    public void createTeams() throws Exception {
        FolderVo folderId = new FolderVo();
        folderId.setId("1");
        when(collaborationTeamServiceLooker.createFolder(parentId, col.getName(), "ext")).thenReturn(folderId);
        //collaborationTeamService.createTeams(Arrays.asList(col), parentId);
//        verify(repository).save(col);
        //       Assert.assertEquals(Arrays.asList(col), repository.save(col));
    }
/*

    @Test
    public void updateTeam() {
        CollaborationTeam col = new CollaborationTeam();
        col.setCollaborationTeamId(12L);
        col.setPlatformId("SAP");
        col.setCustomerId((long) 1);
        col.setName("updateTeams vanderbilt Team2");
        col.setExternalId(249L);
        col.setUpdatedBy(username);
        col.setUpdatedDate(new Date());
        when(collaborationTeamService.updateTeam(col)).thenReturn(true);
        collaborationTeamService = mock(CollaborationTeamService.class);
        when(repository.findById(col.getCollaborationTeamId())).thenReturn(Optional.ofNullable(col));

        Assert.assertEquals(true, collaborationTeamService.updateTeam(col));
    }
 */

}