package com.mckesson.app.repository.admin;

import org.junit.Test;

public class ModuleRepositoryTest {

    @Test
    public void save() {
    }
}