package com.mckesson.app.service.looker;




import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import main.java.com.mckesson.app.repository.looker.ExploreRepository;
import main.java.com.mckesson.app.service.looker.ExploreService;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ExploreServiceImplTest {

    @Mock
    ExploreRepository exploreRepository;

    @Mock
    ExploreService exploreService;

    private MockMvc mockMvc;

    @Before
    public void setUp() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(exploreService).build();

    }
    @Test
    public void findById(){
//        when(exploreService.findById()).thenReturn()
    }

    @Test
    public void findByName(){

    }

    @Test
    public void insert(){

    }

    @Test
    public void save(){

    }

    @Test
    public void saveAll(){

    }


}
