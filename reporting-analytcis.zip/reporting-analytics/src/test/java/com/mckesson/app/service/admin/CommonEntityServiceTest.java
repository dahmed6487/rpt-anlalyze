package com.mckesson.app.service.admin;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import main.java.com.mckesson.app.domain.admin.CommonEntity;
import main.java.com.mckesson.app.repository.customer.CommonEntityRepository;
import main.java.com.mckesson.app.service.admin.CommonEntityService;


@RunWith(MockitoJUnitRunner.Silent.class)
public class CommonEntityServiceTest {
    private MockMvc mockMvc;

    CommonEntity commonEntity;

    @Mock
    CommonEntityRepository commonEntityRepo;

    @InjectMocks
    CommonEntityService commonEntityService;




    @Before
    public void setUp() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(commonEntityService).build();
        //commonEntityRepo.getCommonEntityById("1");
        //commonEntityRepo.getAll();

        commonEntity = new CommonEntity();
        commonEntity.setCommonEntity("test common entity");
        commonEntity.setCommonEntityDescription("description");
        commonEntity.setCommonGroup("common entity test group");
        commonEntity.setCommonGroupDescription("group description");
        commonEntity.setId("1");
        commonEntity.setAccount("account");
        commonEntity.setGPO("GPO");


    }

    @Test
    public void CommonEntityService(){
        assertNotNull(commonEntityRepo);
    }

    @Test
    public void getById(){
        when(commonEntityService.getById(commonEntity.getId())).thenReturn(Arrays.asList(commonEntity));
        assertEquals(Arrays.asList(commonEntity), commonEntityService.getById(commonEntity.getId()));
        verify(commonEntityRepo).getCommonEntityById(commonEntity.getId());
    }


    @Test
    public void getAllCommonEntities(){
        when(commonEntityService.getAllCommonEntities()).thenReturn(Arrays.asList(commonEntity));
        assertEquals(Arrays.asList(commonEntity), commonEntityService.getAllCommonEntities());
        verify(commonEntityRepo).getAll();
    }

}