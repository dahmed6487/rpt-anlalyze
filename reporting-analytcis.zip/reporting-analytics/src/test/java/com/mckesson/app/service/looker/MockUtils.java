package com.mckesson.app.service.looker;


import org.assertj.core.util.Lists;

import main.java.com.mckesson.app.domain.looker.CustomFilter;
import main.java.com.mckesson.app.domain.looker.FilterCriteria;
import main.java.com.mckesson.app.domain.looker.FilterCriteriaGroup;

public class MockUtils {

    public static FilterCriteriaGroup getMockFilterGroup() {
        FilterCriteriaGroup group = new FilterCriteriaGroup();
        group.setName("Custom Group 1");
        FilterCriteria criteria = new FilterCriteria();
        criteria.setName("Sample group 1");
        criteria.setValue("Facility 1,Facility 2,Facility 3");
        criteria.setDimension("some_explore.building");
        group.getFilterCriteria().add(criteria);
        return group;
    }

    public static FilterCriteriaGroup getMockFilterGroups(){
        FilterCriteriaGroup group = getMockFilterGroup();
        group.setName("Custom Group 2");
        FilterCriteria first = new FilterCriteria();
        FilterCriteria second = new FilterCriteria();
        FilterCriteria third = new FilterCriteria();

        first.setName("Sample group 1");
        first.setDimension("some_explore.building");
        first.setValue("Facility 1,Facility 2,Facility 3");

        second.setName("Sample group 2");
        second.setDimension("some_explore.building");
        second.setValue("Facility 4,Facility 5,Facility 6");

        third.setName("Sample group 3");
        third.setDimension("some_explore.building");
        third.setValue("Facility 7,Facility 8,Facility 9");

        group.getFilterCriteria().addAll(Lists.newArrayList(first, second, third));

        return group;
    }

    public static CustomFilter getMockCustomFilterWithNoGroupDefinitions(){
        CustomFilter filter = new CustomFilter();

        filter.setName("Sample Custom Filter");
        filter.setUseOtherAsDefaultGroup(true);

        return filter;
    }

    public static CustomFilter getMockCustomFilterWithCustomQuery(){
        CustomFilter filter = new CustomFilter();

        filter.setName("Sample Custom Filter");
        filter.setUseOtherAsDefaultGroup(true);
        FilterCriteriaGroup group = getMockFilterGroup();
        group.setCustomFormula("SELECT * FROM....");
        filter.setCriteriaGroup(group);

        return filter;
    }

    public static CustomFilter getMockCustomFilterWithSingleGroup(){
        CustomFilter filter = MockUtils.getMockCustomFilterWithNoGroupDefinitions();
        filter.setCriteriaGroup(getMockFilterGroup());
        return filter;
    }

    public static CustomFilter getMockCustomFilterWithMultpleGroups(){
        CustomFilter filter = MockUtils.getMockCustomFilterWithNoGroupDefinitions();
        filter.setCriteriaGroup(getMockFilterGroups());
        return filter;
    }
}
