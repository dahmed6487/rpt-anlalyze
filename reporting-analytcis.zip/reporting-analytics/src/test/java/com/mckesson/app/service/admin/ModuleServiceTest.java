package com.mckesson.app.service.admin;


import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import main.java.com.mckesson.app.domain.admin.CollaborationTeam;
import main.java.com.mckesson.app.domain.admin.Module;
import main.java.com.mckesson.app.domain.customer.Customer;
import main.java.com.mckesson.app.repository.admin.ModuleRepository;
import main.java.com.mckesson.app.service.admin.ModuleService;
import main.java.com.mckesson.app.service.customer.CustomerService;
import main.java.com.mckesson.app.service.customer.UserMappingService;
import main.java.com.mckesson.app.util.UserAuthentication;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ModuleServiceTest {
    private MockMvc mockMvc;

    @Mock
    ModuleRepository moduleRepository;

    @Mock
    UserAuthentication userAuthentication;

    @Mock
    CustomerService customerService;

    @Mock
    UserMappingService userMappingService;


    @InjectMocks
    ModuleService moduleService;

    String userName="Test User";
    Module module=new Module();
    Module module2=new Module();

    Customer customer = new Customer();
    CollaborationTeam collaborationTeam = new CollaborationTeam();

    @Before
    public void setUp() throws Exception {
        mockMvc= MockMvcBuilders.standaloneSetup(moduleService).build();
        module.setModuleId(1L);
        module.setPlatformId(null);
        module.setTitle("Test Title");
        module.setHost("Test host");
        module.setUrl("Test URL");
        module.setExternalId((long) 1);
        module.setCategory("Test Category");
        module.setDescription("Description");
        module.setColor("Red");
        module.setCreatedBy("Jon Doe");
        module.setCreatedDate(new Date(System.currentTimeMillis()));
        module.setDeletedBy("Jon Doe");
        module.setDeletedDate(new Date(System.currentTimeMillis()));
        module.setPlatformId("2");
        module.setUrl("http://dummy.com");
        module.setUpdatedBy("Jon Doe");
        module.setUpdatedDate(new Date(System.currentTimeMillis()));

        customer.setCustomerId(1L);
        customer.setCustomerName("Jon Doe");
        customer.setOwnerName("sr. Jon Doe");
        customer.setCommonEntityId("2");
        customer.setCommonGroupId("3");
        customer.setCommonGroupName("Joe");
        customer.setbFlag("b");
        customer.setBuyingGroupId("1");
        customer.setCreatedBy("user");
        customer.setCreatedDate(new Date(System.currentTimeMillis()));

    }

    @Test
    public void testGetModule() {
        assertEquals(new ArrayList(),moduleService.getModule(""));
        when(moduleRepository.findAll()).thenReturn(Arrays.asList(module));
        assertEquals(Arrays.asList(module), moduleRepository.findAll());
    }

    @Test
    public void testUpdateModule() {
        assertEquals(Arrays.asList(module),moduleService.updateModule(Arrays.asList(module)));
        //verify(moduleRepository, atLeastOnce()).saveAll(Arrays.asList(module));
        // verify(moduleRepository, atLeastOnce()).active(Arrays.asList(1L));
        doNothing().when(moduleRepository).active(Arrays.asList(1L));
    }

    @Test
    public void testGetModuleForIds() {
        when(moduleRepository.getModuleForIds(1L)).thenReturn(Arrays.asList(module));
        assertEquals(Arrays.asList(module), moduleService.getModuleForIds(1L));

    }


    @Test
    public void testGetModulesByUserAccess() {
        //verify(customerService, atLeastOnce()).findCustomerByCustomerName(anyString());
        when(customerService.findCustomerByCustomerName("Jon Doe")).thenReturn(Optional.ofNullable(customer));
        assertNotNull(customer);
        assertEquals(Optional.ofNullable(customer),customerService.findCustomerByCustomerName("Jon Doe"));
        when(userMappingService.getTeamsByUserAndCustomer("Hello ", "World")).thenReturn(Arrays.asList(collaborationTeam));
        //assertEquals(Arrays.asList(collaborationTeam), userMappingService.getTeamsByUserAndCustomer("Hello","Jon Doe"));
    }

    @Test
    public void testGetCustomerModule() {

        when(moduleRepository.getCustomerModule("Jon Doe")).thenReturn(Arrays.asList(module));
        assertEquals(Arrays.asList(module), moduleRepository.getCustomerModule("Jon Doe"));
    }

    @Test
    public void testGetCustomerModulesById() {
        when(moduleRepository.getCustomerModulesById("1")).thenReturn(Arrays.asList(module));
        assertEquals(Arrays.asList(module), moduleService.getCustomerModulesById("1"));
    }

    @Test
    public void testgetCustomerModule(){
        when(moduleRepository.getCustomerModule("test")).thenReturn(Arrays.asList(module));
        assertEquals(Arrays.asList(module), moduleService.getCustomerModule("test"));
    }



    @Test
    public void testGetModuleByFolderId() {
        when(moduleRepository.findByFolderId("1")).thenReturn(Optional.ofNullable(module));
        assertEquals(Optional.ofNullable(module), moduleService.getModuleByFolderId("1"));

    }



    @Test
    public void deleteModule(){
        // when(moduleService.deleteModule()).thenReturn(moduleRepository.deleteRelation());
        //assertEquals();
    }

}
