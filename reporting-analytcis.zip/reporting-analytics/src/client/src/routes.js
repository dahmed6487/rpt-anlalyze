import React from 'react';
// Pages
import LookerEmbedFrame from './components/embed/looker-embed-frame';
import WordpressEmbedFrame from './components/embed/wordpress-embed-frame';
import ReportManagementContainer from './containers/report-mgmnt-container';
import CustomGroupPanel from './containers/custom-group-panel';
import AdminPages from './pages/administrator/admin';
import SolutionEmbedFrame from "./components/solutions/solutionEmbedFrame";
import ScheduledReports from './containers/scheduled-reports';

import { AccountSegmentationIcon, SubmitIdeasIcon, HelpIcon, AdminstrationIcon, AtAGlance, SolutionsIcon, ExploreIcon, CustomGroupsIcon, MyReportsIcon, TeamReportsIcon, ScheduledReportsIcon, UserManagementIcon, TeamManagementIcon, CustomerManagementIcon, OtherVendorPurchasesIcon } from "./components/icons/svg";

const routes = [
  //direct menu items
  {
    path: '/',
    exact: true,
    header: 'At a Glance',
    component: LookerEmbedFrame,
    menuTitle: 'At a Glance',
    icon: <AtAGlance width={24} height={24} />,
    iconClass: "fas fa-glasses",
    menu: 'sidebar',
    defaultExpand: false,
    role:'all'
  },
  {
    path: '/help',
    exact: true,
    header: 'Need Help',
    component: WordpressEmbedFrame,
    menuTitle: 'Need Help',
    iconClass: "far fa-question-circle",
    role:'all'
  },
  {
    path: '/solutions',
    header: 'Solutions',
    icon: <SolutionsIcon width={24} height={24} />,
    menuTitle: 'Solutions (Canned Reports)',
    exact: true,
    menu: 'sidebar',
    showArrow: true,
    role:'all',
    routes: [
      {
        path: '/solutions/',
        menuTitle: 'Solution',
        header: 'Solution',
        component: SolutionEmbedFrame
      },
    ]
  },
  {
    path: '/explore',
    exact: true,
    header: 'Explore',
    component: LookerEmbedFrame,
    icon: <ExploreIcon width={24} height={24} />,
    menuTitle: 'Explore (Custom Reports)',
    menu: 'sidebar',
    iconClass: 'fa fa-sliders-h',
    role:'all',
    routes: [
      {
        path: '/explore/purchases',
        menuTitle: 'Purchase History',
        exact: true,
        header: 'Purchases Explore',
        component: LookerEmbedFrame
      },
      {
        path: '/explore/v_if_ra_dim_cust_acct_item',
        menuTitle: 'Pricing Catalog',
        exact: true,
        header: 'Pricing Catalog',
        component: LookerEmbedFrame
      },
      {
        path: '/explore/idb',
        menuTitle: 'IDB',
        exact: true,
        header: 'IDB Explore',
        component: LookerEmbedFrame
      },
      {
        path: '/explore/cust_acct_current',
        menuTitle: 'Rebates',
        exact: true,
        header: 'Rebates',
        component: LookerEmbedFrame
      },
      {
        path: '/explore/physical-inventory',
        menuTitle: 'Physical Inventory',
        exact: true,
        header: 'Physical Inventory Explore',
        component: LookerEmbedFrame
      }
      /*  , {
          path: '/explore/contracts',
          menuTitle: 'Contracts',
          exact: true,
          header: 'Contracts Explore',
          component: LookerEmbedFrame
       } */
    ]
  },
 /* {
    path: '/recent-activity',
    exact: true,
    header: 'Recent Activity',
    component: LookerEmbedFrame,
    menuTitle: 'Recent Activity',
    iconClass: "fas fa-history",
    menu: 'sidebar',
    defaultExpand: false,
    role:'all'
  }, */

  {
    path: '/custom-groups',
    exact: true,
    menuTitle: 'Custom Groups',
    header: 'Custom Groups',
    component: <CustomGroupPanel />,
    icon: <CustomGroupsIcon width="24px" height="24px" />,
    menu: 'sidebar',
    showArrow: true,
    modal: true,
    iconClass: 'fas fa-layer-group',
    role:'all'
  },
  {
    path: '/my-reports',
    exact: true,
    component: ReportManagementContainer,
    icon: <MyReportsIcon
     width="24px" height="24px" />,
    header: 'My Reports',
    menuTitle: 'My Reports',
    menu: 'sidebar',
    type: 'reports',
    defaultExpand: false,
    iconClass: 'fas fa-heart',
    role:'all'
  },
  {
    path: '/team-reports',
    exact: true,
    header: 'Team Reports',
    component: ReportManagementContainer,
    icon: <TeamReportsIcon
     width="24px" height="24px" />,
    menuTitle: 'Team Reports',
    menu: 'sidebar',
    iconClass: 'fas fa-chart-pie',
    role:'all'
  },
  {
    path: '/scheduled-reports',
    exact: true,
    menuTitle: 'My Scheduled Reports',
    header: 'My Scheduled Reports',
    icon: <ScheduledReportsIcon
     width="24px" height="24px" />,
    component: <ScheduledReports />,
    menu: 'sidebar',
    showArrow: true,
    modal: true,
    iconClass: 'fas fa-clock',
    separator: true,
    role:'all'
  },
  {
    path: '/admin',
    exact: false,
    menuTitle: 'Administration',
    header: 'Administration',
    icon: <AdminstrationIcon width="24px" height="24px" />,
    showArrow: true,
    component: AdminPages,
    menu: 'sidebar',
    iconClass: 'fas fa-cogs',
    role:'Admin',
    routes: [
      {
        path: '/admin/users',
        menuTitle: 'User Management',
        icon: <UserManagementIcon width="24px" height="24px" />,
        exact: true,
        header: 'User Management',
        component: () => null,
      },
      {
        path: '/admin/teams',
        menuTitle: 'Team Management',
        icon: <TeamManagementIcon width="24px" height="24px" />,
        exact: true,
        header: 'Team Management',
        component: () => null,
      },
      {
        path: '/admin/customers',
        menuTitle: 'Customer Management',
        icon: <CustomerManagementIcon width="24px" height="24px" />,
        exact: true,
        header: 'Customer Management',
        component: () => null,
      },
      {
        path: '/admin/accountSegmentation',
        menuTitle: 'Account Segmentation',
        icon: <AccountSegmentationIcon width="24px" height="24px" />,
        exact: true,
        header: 'Account Segmentation',
        component: () => null,
      },
      {
        path: '/admin/otherVendorPurchase',
        menuTitle: 'Other Vendor Purchases',
        icon: <OtherVendorPurchasesIcon width="24px" height="24px" />,
        exact: true,
        header: 'Other Vendor Purchases',
        component: () => null,
      }
      /*  , {
          path: '/explore/contracts',
          menuTitle: 'Contracts',
          exact: true,
          header: 'Contracts Explore',
          component: LookerEmbedFrame
       } */
    ]
  },
  {
    path: 'https://mckessonera.ideas.aha.io/ideas/new',
    exact: true,
    component: () => null,
    header: 'Submit Ideas',
    menuTitle: 'Submit Ideas',
    menu: 'sidebar',
    type: 'reports',
    target: "_blank",
    defaultExpand: false,
    iconClass: 'far fa-lightbulb',
    icon: <SubmitIdeasIcon width="24px" height="24px" />,
    role:'all'
  },
  {
    path: '#/help',
    exact: true,
    component: () => null,
    icon: <HelpIcon width="24px" height="24px" />,
    header: 'Help',
    menuTitle: 'Help',
    target: "_blank",
    menu: 'sidebar',
    type: 'reports',
    defaultExpand: false,
    iconClass: 'far fa-question-circle',
    role:'all'
  },
  {
    path: '/displayDashboard/:id',
    exact: true,
    header: '',
    component: LookerEmbedFrame,
    menuTitle: '',
    iconClass: "fas fa-glasses",
    menu: 'none',
    defaultExpand: false,
    role:'all',
  },
  {
    path: '/dashboard/:id',
    exact: true,
    header: '',
    component: LookerEmbedFrame,
    menuTitle: '',
    iconClass: "fas fa-glasses",
    menu: 'none',
    defaultExpand: false,
    role:'all'
  },
  {
    path: '/displayReport/:id',
    exact: true,
    header: '',
    component: LookerEmbedFrame,
    menuTitle: '',
    iconClass: "fas fa-glasses",
    menu: 'none',
    defaultExpand: false,
    role:'all'
  },
  {
    path: '/my-reports/explore/:exploreType/:qid/',
    exact: true,
    header: '',
    component: LookerEmbedFrame,
    menuTitle: '',
    iconClass: "fas fa-glasses",
    menu: 'none',
    defaultExpand: false,
    role:'all'
  },
  {
    path: '/team-reports/explore/:exploreType/:qid/',
    exact: true,
    header: '',
    component: LookerEmbedFrame,
    menuTitle: '',
    iconClass: "fas fa-glasses",
    menu: 'none',
    defaultExpand: false,
    role:'all'
  }
];

export default routes;
