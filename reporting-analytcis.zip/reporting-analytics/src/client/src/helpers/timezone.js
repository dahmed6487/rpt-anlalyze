import Moment from 'react-moment';
import jstz from "jstz";
import React from 'react';
import 'moment-timezone';

const Timezone = {
    formatDate: function (date, action) {
        if (!sessionStorage.getItem("timeZone")) {
            let timeZone = jstz.determine() || 'UTC';
            sessionStorage.setItem("timeZone", timeZone.name());
        }

        let timeZone = sessionStorage.getItem("timeZone");

        return (
            <div>
                <Moment parse="YYYY-MM-DDTHH:mm:ssZ"
                        format="MM-DD-YYYY  hh:mm:ss a"
                        tz={timeZone}>
                    {date}
                </Moment>
                {action}
            </div>
        )
    },
    formatDateString: function (date, action) {
        if (!sessionStorage.getItem("timeZone")) {
            let timeZone = jstz.determine() || 'UTC';
            sessionStorage.setItem("timeZone", timeZone.name());
        }

        let timeZone = sessionStorage.getItem("timeZone");

        return (
            <React.Fragment>
                <Moment parse="YYYY-MM-DDTHH:mm:ssZ"
                        format="MM-DD-YYYY  hh:mm:ss a"
                        tz={timeZone}>
                    {date}
                </Moment>
                {action}
            </React.Fragment>
        )
    }
};

export default Timezone;