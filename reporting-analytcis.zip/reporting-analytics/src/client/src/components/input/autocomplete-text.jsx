import React, {Component, Fragment} from "react";

import {connect} from "react-redux";
import * as CustomGroupingActions from '../../redux/actions/custom-filters-actions';
import LoadingSpinner from '../custom-filters/edit-view/loadingSpinner';

/**
 * A generic Autocomplete component comprising of a textbox and a list of suggestions.
 *
 * Pass all possible values to the component, and also a function to perform an operation when the chosen value is selected.
 */
class AutocompleteTextBox extends Component {
    static defaultProps = {
        suggestions: [],
        submit: null,
        submitIcon: null
    };

    constructor(props) {
        super(props);

        this.state = {
            // The active selection's index
            activeSuggestion: 0,
            // The suggestions that match the user's input
            filteredSuggestions: [],
            // Whether or not the suggestion list is shown
            showSuggestions: false,
            // What the user has entered
            userInput: ""
        };
    }

    onChange = (event) => {
        this.props.dispatch(CustomGroupingActions.userInput(event.currentTarget.value));
        const { suggestions } = this.props;
        const userInput = event.currentTarget.value;

        // Filter our suggestions that don't contain the user's input
        const filteredSuggestions = suggestions.filter(
            suggestion =>
                suggestion.toLowerCase().indexOf(userInput.toLowerCase()) > -1
        );

        this.setState({
            activeSuggestion: 0,
            filteredSuggestions,
            showSuggestions: true,
            userInput: event.currentTarget.value
        });
    };

    onClick = (event) => {
        this.props.dispatch(CustomGroupingActions.userInput(event.currentTarget.innerText));
        this.setState({
            activeSuggestion: 0,
            filteredSuggestions: [],
            showSuggestions: false,
            userInput: event.currentTarget.innerText
        });
    };

    onKeyDown = (event) => {
        const { activeSuggestion, filteredSuggestions } = this.state;

        if (event.key === "Enter") {
            this.submit();
        } else if (event.key === "ArrowUp") {
            if (activeSuggestion === 0) {
                return;
            }

            this.setState({ activeSuggestion: activeSuggestion - 1 });
        } else if (event.key === "ArrowDown") {
            if (activeSuggestion - 1 === filteredSuggestions.length) {
                return;
            }

            this.setState({ activeSuggestion: activeSuggestion + 1 });
        }
    };

    submit = () => {
        const {activeSuggestion, filteredSuggestions, showSuggestions } = this.state;
        let selected = (showSuggestions && filteredSuggestions.length > 0) ? filteredSuggestions[activeSuggestion] : this.props.userInput;
        if (this.props.submit) {
            this.props.submit(selected);
        }
        this.props.dispatch(CustomGroupingActions.userInput(""));
        this.setState({
            activeSuggestion: 0,
            showSuggestions: false,
            userInput: ""
        });
    };

    getSubmitButton = () => {
        if (this.props.submit && !this.props.isLoading && this.state.userInput) {
            return (<button type="button" id="era-autocomplete-text-add-button" onClick={this.submit} className="btn btn-primary btn-inverted">Add</button>);
        } else {
            return (<button type="button" id="era-autocomplete-text-add-button" onClick={this.submit} className="btn btn-primary btn-inverted" disabled>Add</button>);
        }
    };

    render() {
        const {
            onChange,
            onClick,
            onKeyDown,
            getSubmitButton,
            state: {
                activeSuggestion,
                filteredSuggestions,
                showSuggestions,
            }
        } = this;

        let suggestionsListComponent;

        if (showSuggestions && this.props.userInput) {
            if (filteredSuggestions.length) {
                suggestionsListComponent = (
                    <ul className="suggestions">
                        {filteredSuggestions.map((suggestion, index) => {
                            let className;

                            // Flag the active suggestion with a class
                            if (index === activeSuggestion) {
                                className = 'suggestion-active';
                            }

                            return (
                                <li className={className} key={suggestion} onClick={onClick}>
                                    {suggestion}
                                </li>
                            );
                        })}
                    </ul>
                );
            } else {
                suggestionsListComponent = null;
            }
        }

        return (
            <React.Fragment>
                <div className="autocomplete">
                    <div className="era-autocomplete">
                        <div>
                            <textarea
                                className="form-control"
                                onChange={onChange}
                                onKeyDown={onKeyDown}
                                value={this.props.userInput}
                            />
                            {this.props.isLoading
                            && (
                                <div className="loadingSpinner">
                                    <LoadingSpinner />
                                </div>
                               )}
                        </div>
                        {getSubmitButton()}
                    </div>

                    {suggestionsListComponent}
                </div>
            </React.Fragment>
        );
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        store: state,
        isLoading: state.customFilters.isLoading,
        userInput: state.customFilters.userInput
    };
};


export default connect(mapStateToProps)(AutocompleteTextBox);
