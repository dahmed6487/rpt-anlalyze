import React, {Component} from "react";
import axios from "axios";
import autoBind from "react-autobind";
import {connect} from 'react-redux';

import * as CustomDashboardFilterActions from '../redux/actions/custom-filter-criteria-actions';
import * as SpaceManagementActions from '../redux/actions/space-mgmnt-actions';
import * as CustomDashboardFilterConstants from '../redux/constants/custom-filter-criteria-constants';

const dataLayer = window.dataLayer;

class IFrameEventListener extends Component {

    constructor(props, context) {
        super(props, context);
        autoBind(this);
    }

    componentDidMount() {
      window.addEventListener("message", this.handleIframeMsg);
      window.addEventListener("message", this.handleIframeMsgGTM);
    }

    /**
     * Pushes all iframe event messages to Google Tag Manager.
     */
    handleIframeMsgGTM(event) {
        // Don't spam the console if react devtools is connected
        if (!event.data.source || event.data.source.includes("react-devtools")) {
            return;
        }
        this.props.dispatch(SpaceManagementActions.getDashboardEventData(JSON.parse(event.data)));
        dataLayer.push({
            event: this.props.data.type,
            looker_data: this.props.data
        });
    }

    handleIframeMsg(event) {
        try{
          this.props.dispatch(SpaceManagementActions.getDashboardEventData(JSON.parse(event.data)));
        }
        catch(e){
          return;
        }
        if(this.props.data.type&&this.props.data.type=="page:properties:changed" && this.props.data.height % 1 !== 0){
          this.props.dispatch(SpaceManagementActions.getValuesForDashboard(true));
        }

        if(this.props.data.type&& this.props.data.type=="page:changed"){
          this.props.dispatch(SpaceManagementActions.getValuesForDashboard(false));
        }

        if(this.props.data.type&&this.props.data.type=="dashboard:filters:changed"){
            this.props.dispatch(CustomDashboardFilterActions.triggerDashboardFilterConfigChange(this.props.data.dashboard.dashboard_filters));
        }        

        //When ...
        if(this.props.data.type&&this.props.data.type=="page:changed"){
          this.props.dispatch(SpaceManagementActions.clearSpacesdCache());
        }

        const eventWhitelist = [
            "dashboard:run:start",
            "dashboard:run:complete",
            "dashboard:download",
            "dashboard:tile:download",
            "dashboard:filters:changed",
            "look:run:start",
            "look:run:complete",
            "drillmenu:click",
            "explore:state:changed",
            "explore:run:start",
            "explore:run:complete"
        ];

        if (eventWhitelist.includes(this.props.data.type)) {
          if (this.props.data.dashboard != null) {
            this.props.data.dashboard.url = "";
          } else if (this.props.data.explore != null) {
            this.props.data.explore.url = "";
          } else if (this.props.data.look != null) {
            this.props.data.look.url = "";
          }

          let currentUser = this.props.currentUser;

          //When the dashboard has fully loaded, fire an event so that the application is notified, specifically
          //we are letting the 'my filters' feature know that this has occured so that other operations 
          //such as loading additional dashboard information and saved filters may occur.
          if(this.props.data.type=="dashboard:run:complete"||this.props.data.type=="explore:run:complete"){
            this.props.dispatch({type: CustomDashboardFilterConstants.EVENT_DASHBOARD_LOADED, payload: this.props.data.dashboard.id });
          }

          //This is to update Page title, when clicking inside iframe
          if (this.props.data.type === 'drillmenu:click'){
              document.title = this.props.data.label;
          }

                if(this.props.data.link_type === "dashboard" && this.props.data.type === "drillmenu:click") {
                    const pathname = this.props.history.location.pathname;
                    const getSolutionData = this.findSolutionDataId(this.props.data.label);
                    let getSolutionDataId = "";
                    let deepLevelReportLabel = "";

                    if (getSolutionData) {
                        getSolutionDataId = getSolutionData.id;
                        deepLevelReportLabel = getSolutionData.name;
                    }

                    //localStorage.setItem("deepLevelReport",JSON.stringify({"url": this.props.data.url, "label": this.props.data.label}));
                    window.history.replaceState("", "", `#${pathname}/${getSolutionDataId}-${deepLevelReportLabel}`)
                }

          axios
            .post("/looker/event/save", this.props.data, {
              headers: {"userId": currentUser}
            })
            .then(res => "")
            .catch(err => console.log("LookerEvent Save Failed"));
        }
      }

    render = () => {return null};
}

const mapStateToProps = (state, props) => {
  return{
      store: state,
      currentUser: state.user.currentUser,
      iframeUrl: state.iframe.iframeUrl,
      currentFilterConfig: state.customFilterCriteria.currentFilterConfig,
      path: state.iframe.path,
      filtersUrl: state.iframe.filtersUrl,
      data: state.iframe.data
  }
}

export default connect(mapStateToProps)(IFrameEventListener);