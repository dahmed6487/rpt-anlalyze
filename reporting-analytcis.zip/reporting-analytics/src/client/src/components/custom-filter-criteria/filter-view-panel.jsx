import React, {Component} from "react";
import {connect} from 'react-redux';

import * as CustomFilterCriteriaActions from '../../redux/actions/custom-filter-criteria-actions';

/**
 * FilterViewPanel
 * 
 * Used to represent an existing filter, provides the ability to apply/deselect a filter from a 
 * given dashboard.
 * 
 */
class FilterViewPanel extends Component{

    filterSelected = () =>{
        
        if(this.props.curFilter.applied){
            this.props.dispatch(CustomFilterCriteriaActions.deselectFilter(this.props.curFilter.id));
        }else{
            this.props.dispatch(CustomFilterCriteriaActions.selectFilter(this.props.curFilter.id));
        }
    }

    getActionButtonLabel = () => {
        if(this.props.curFilter.applied==true){
            return "Deselect";
        }
        else{
            return "Select";
        }
    }

    render =() =>{
        return(
            <div className="panel">
                <div className="row">
                    <div className="col-md-3">{this.props.curFilter.dimension}</div>
                    <div className="col-md-3">{this.props.curFilter.criteria[0].qualifier}</div>
                    <div className="col-md-3">{this.props.curFilter.criteria[0].values}</div>
                    <div className="col-md-3">
                        <button type="button" onClick={this.filterSelected}>{this.getActionButtonLabel()}</button>
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state, props) => {
    return {};
}

export default connect(mapStateToProps)(FilterViewPanel)