
import React, {Component} from "react";
import {connect} from 'react-redux';

import * as CustomFilterCriteriaActions from '../../redux/actions/custom-filter-criteria-actions';

import ActionPanel from "../action-panel";


//import * as SharingConstants from '../../constants/sharing-constants'

import * as ShareActions from '../../redux/actions/sharing-actions';

/**
 * FilterViewPanel
 * 
 * Used to represent an existing filter, provides the ability to apply/deselect a filter from a 
 * given dashboard.
 * 
 */
class FilterPanel extends Component{

    filterSelected = () =>{
        if(this.props.curFilter.applied){
            this.props.filterSelectionHandler(this.props.curFilter, false);
        }else{
            this.props.filterSelectionHandler(this.props.curFilter, true);
        }
    }

    saveSharedTeams = (itemId, sharedTeams) => {
        this.props.dispatch(CustomFilterCriteriaActions.saveSharedTeams(itemId, sharedTeams));
    }

    openShareFilterDialog = () => {
        this.props.dispatch(ShareActions.shareElement(this.props.curFilter.id,'Dashboard Filters', this.props.curFilter.name, this.props.curFilter.sharedTeams, this.saveSharedTeams));
    }

    /**
     * Event handler for when a user elects to save changes to a filter. For 'new' unsaved filters, this will persist
     * the state for the filter. For existing filters, this will update the 'name' attribute, along with the updated 
     * criteria. 
     */
    onSaveChanges = () => {
        this.props.saveHandler(this.props.curFilter, this.props.filterIndex);
    }

    onFilterNameChanged = (newVal) =>{
        this.props.onFilterNameChanged(newVal, this.props.filterIndex, this.props.curFilter.title);
    }

    getAppliedClassName = () => {
        if(this.props.curFilter.applied){
            return "glyphicon glyphicon-ok";
        }
        else{
            return "glyphicon glyphicon-remove";
        }
    }

    render =() =>{

        const filterName = this.props.curFilter.name;

        return(
                <div className={'col-md-12 row panelRow filter-row ' + (this.props.curFilter.applied ? 'filter-selected' : '')}>
                   <div className="filter-column">
                    <div className="col-md-5 col-sm-5 panelColumn">
                            <input type="checkbox" className=" col-md-3 panelColumn filter-checkbox" onChange={this.filterSelected} />
                            <span className="check-box-effect" />
                            <div className="col-md-9 panelColumn filter-panel-name">
                                {this.props.curFilter.title}
                            </div>
                        </div>
                        <div className="col-md-3 col-sm-3 criteriaValueLabel panelColumn">
                            {this.props.curFilter.criteriaValue}
                        </div>
                        <div className="col-md-3 col-sm-3 text-left ">
                            <ActionPanel curFilter={this.props.curFilter} deleteFilterHandler={this.props.deleteFilterHandler} />
                        </div>
                   </div>
                </div>
        );
    }
}

const isSharedWithUser = () => {
    return true;
}

const mapStateToProps = (state, props) => {
    return {
        currentUser: state.user.currentUser
    };
}

export default connect(mapStateToProps)(FilterPanel)