import React, {Component} from "react";
import autoBind from "react-autobind";
import {connect} from 'react-redux';
import * as CustomFilterCriteriaActions from '../../redux/actions/custom-filter-criteria-actions';
import * as CustomFilterCriteriaConstants from '../../redux/constants/custom-filter-criteria-constants';
import * as CustomDashboardFilterActions from '../../redux/actions/custom-filter-criteria-actions';
import FilterPanel from './filter-panel';
import CreateNewFilter from './create-new-filter';

class FilterSelection extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);

    this.state = {
      expanded: false
    };
  }

  render() {
    const { expanded } = this.state;
    if(this.props.createFilter) {
      return <CreateNewFilter/>
    }
    return  (
        <li className="nav-filter">
            <a href="#" className="menu-link-sub">
                <span className="link-text" onClick={this.launchFilterSelectionDialog}>My Filters</span>
                <span className="fas fa-angle-down" onClick={this.launchFilterSelectionDialog} />
            </a>
            <div className={'sub-links ' + (expanded ? 'show' : 'hide')}>
                <div className="panel filter-panel">
                    <div className="filter-banner"><span className="filter-banner-text">Select the filters you wish to apply to your reportand click Apply</span></div>
                    <div>
                        <div className="filter-banner"><span className="filter-banner-text">Select the filters you wish to apply to your reportand click Apply</span></div>
                        {/*<div className="filter-search-container-new">
                            <div>
                                <input type="text" className="text-filter" value={this.state.searchString} onChange={this.handleChange}/>
                                <span className="fas fa-search search-filter"></span>
                            </div>
                            <button type="button" className="closeDialogButton create-filter" onClick={this.closeFilterPanel}>CREATE NEW FILTER</button>
                        </div>*/}
                        { this.getFilterSelectionContent() }
                        <div className="filter-footer">
                            <button type="button" className="closeDialogButton filter-apply" onClick={this.onFilterSaved}>Apply</button>
                            <button type="button" className="closeDialogButton filter-cancel" onClick={this.closeFilterPanel}>Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        </li>
    );
  }

  onFilterSaved = (selFilter, index) => {
    this.props.dispatch(CustomFilterCriteriaActions.saveFilter(selFilter, index));
  }

  onFilterSelectionEvent = (filter, selected) =>{
    if(selected){
        this.props.dispatch(CustomFilterCriteriaActions.selectFilter(filter));   
    }
    else{
        this.props.dispatch(CustomFilterCriteriaActions.deselectFilter(filter));
    }
  }

  deleteFilterHandler = (filter) => {
        
    if(filter.id!=null&&filter.id!=""){
        this.props.dispatch(CustomFilterCriteriaActions.deleteSavedFilter(filter));
    }
    else{
        this.props.dispatch(CustomFilterCriteriaActions.deleteFilter(filter));
    }
  }

  getFilterSelectionContent = () => {
    var filterFields = new Array();

    this.getFiltersForDisplay().forEach((filter,index)=>{
        filterFields.push(<div key={index}><FilterPanel key={index} curFilter={filter} 
            onFilterNameChanged={this.onFilterNameChanged} 
            deleteFilterHandler={this.deleteFilterHandler} 
            saveHandler={this.onFilterSaved}
            filterIndex={index}
            filterSelectionHandler={this.onFilterSelectionEvent} 
            shareFilterHandler={this.onShareFilterEvent} 
            ></FilterPanel></div>);
    });

    return(
        <div>
            <div className="container filter-container">
                <div className="search-container">
                    <input className="form-control search-input" type="text" placeholder="Search" aria-label="Search" /*onChange={e => this.handleSearchChange(e.target.value)}*/ />
                </div>
                <div className="row header-row panel-header filter-header">
                    <div className="col-md-4 col-xs-2 filter-name filter-action">Filter Name</div>
                    <div className="col-md-3 col-xs-1 filter-name">Criteria</div>
                </div>
                {filterFields}
            </div>
        </div>
    );
}

getFiltersForDisplay = () => {
    var allFilters = this.props.availableFilterSet;
    var defaultFilters = this.props.defaultFilters;

    var results = [];
    for( var x=0;x<allFilters.length;x++){
        var filter = allFilters[x];
        if(!defaultFilters.includes(filter.title)){
            results.push(filter);
        }
    }
    return results;
}
}

const mapStateToProps = (state, props) => {
  return{
      store: state,
      currentUser: state.user.currentUser,
      availableFiltersLoaded: state.customFilterCriteria.availableFiltersLoaded,
      availableFilterSet: state.customFilterCriteria.availableFilterSet,
      defaultFilters: state.customFilterCriteria.defaultFilters==null ?  []:  state.customFilterCriteria.defaultFilters,
      createFilter: state.customFilterCriteria.createFilter
  }
}

export default connect(mapStateToProps)(FilterSelection);