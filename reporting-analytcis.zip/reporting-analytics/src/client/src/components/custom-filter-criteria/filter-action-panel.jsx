import React, {Component} from "react";
import autoBind from "react-autobind";
import {connect} from 'react-redux';
import * as CustomFilterCriteriaActions from '../../redux/actions/custom-filter-criteria-actions';
import GroupDefinitionView from '../custom-group/group/group-definition-view';
import * as UserUIActions from '../../redux/actions/user-actions';
import * as DeleteDialogActions from '../../redux/actions/delete-dialog-actions';
import LookerService from '../../services/looker-service';
import CustomGroupPanel from '../../containers/custom-group-panel';
import GroupView from '../custom-group/group/group-view';

class FilterActionPanel extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);

    this.state = {

    };
  }

  render() {
    return  (
      <div className="action-panel action-group-panel">
        <span className="action-filters-text" onClick={this.openFilterDialog}>Edit</span>
        <span className="action-filters-text" onClick={this.openFilterDelete}>Delete</span>
      </div>
    );
  }

  saveSharedTeams = (itemId, sharedTeams) => {
    this.props.dispatch(CustomFilterCriteriaActions.saveSharedTeams(itemId, sharedTeams));
  }

  openFilterDialog = (event) => {
      const { curFilter = {}, group = {} } = this.props;
      const title = 'Edit Group Definition';
      const dialogOptions = {
          title: title,
          content: <GroupDefinitionView group={group} title={title} definition={curFilter} />
      };
      this.props.dispatch(UserUIActions.dialogOpen(dialogOptions));
  }

  openFilterDelete = () => {
      const { curFilter = {}, group = {} } = this.props;
      this.props.dispatch(DeleteDialogActions.openDeleteDialog(curFilter.id, "definition", () => this.deleteFilter(curFilter.id, group)));
  }

  deleteFilter(filterId, group){

      LookerService.deleteCriteria(filterId)
          .then(()=>{
              this.props.dispatch(UserUIActions.dialogClose());
              const dialogOptions = {
                  title: 'Edit Custom Group',
                  content: <GroupView group={group} />
              };
              this.props.dispatch(UserUIActions.dialogOpen(dialogOptions));
              // Close the delete dialog
              this.props.dispatch(DeleteDialogActions.closeDeleteDialog());
          });
  }

  /**
    * Retrieve action panel contents:
    *  When a 'new' filter is created through the action of adding/changing criteria in the Looker Iframe, the only available actions 
    * are to 'save/persist' or delete the new filter. The option to save the new filter is only enabled when a value is present for the 
    * 'name' attribute of the filter.
    * 
    *  When a 'saved' filter is presented, the user has the option of editing the name and updating the saved filter, or they may apply the filter.  
    * 
  */

}

const mapStateToProps = (state, props) => {
  return{
      store: state,
      currentUser: state.user.currentUser
  }
}

export default connect(mapStateToProps)(FilterActionPanel);