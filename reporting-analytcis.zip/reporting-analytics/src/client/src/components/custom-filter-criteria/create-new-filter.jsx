import React, {Component} from "react";
import autoBind from "react-autobind";
import {connect} from 'react-redux';
import { Link } from "react-router-dom";
import * as CustomFilterCriteriaActions from '../../redux/actions/custom-filter-criteria-actions';
import * as CustomFilterCriteriaConstants from '../../redux/constants/custom-filter-criteria-constants';
import * as CustomDashboardFilterActions from '../../redux/actions/custom-filter-criteria-actions';
import FilterPanel from './filter-panel';

class CreateNewFilter extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);

    this.state = {
      expanded: false,
      filterAccounts: false
    };
  }

  filterAccounts = () => {
    this.setState ({
      filterAccounts: !this.state.filterAccounts
    });
  }

  render() {
    return  (
        <div className="col-md-9 col-sm-12 col-xs-9 panel panel-default custom-panel create-new-filter">
          <div>
            <div className="create-filter-header col-md-2"> Create Filter</div>
            <input type="text" className="create-filter-text col-md-5 " placeholder="Give a name to your filter" onChange={this.handleChange} />
          </div>
          <div className="col-md-12">
            <div className="col-md-3">
              <ul className="list-filters sub-menu">
                <li onClick={this.filterAccounts} className={this.state.filterAccounts ? 'filter-accounts' : ''}>
                  <span>Acounts</span>
                          {this.state.filterAccounts ? <span className="link-icon fas fa-chevron-right filter-arrow-right" /> : ''}
                </li>
                <li>
                  <span />
                  Markets
                </li>
                <li>
                  <span />
                  Regions
                </li>
                <li>
                  <span />
                  Products
                </li>
                <li>
                  <span />
                  Date Range
                </li>
              </ul>
            </div>
            <div className="col-md-9">
              {this.state.filterAccounts
              && <div>
                  <div className="filter-account-text col-md-12">
                    <div className="edit-account-id col-md-3">Account ID</div>
                    <div className="account-text col-md-3">
                      <input type="text" placeholder="Is Equal To" style={{ height: '35px' }} />
                    </div>
                    <div className="account-text col-md-6">
                      <input
                        type="text"
                        placeholder="Input Text"
                        style={{ width: '523px', height: '35px' }}
                      />
                    </div>
                  </div>
                  <div className="filter-account-text col-md-12">
                    <div className="edit-account-id col-md-3">Name</div>
                    <div className="account-text col-md-3">
                    <input
                      type="text"
                      placeholder="Is Equal To"
                      style={{ height: '35px' }}
                    />
                    </div>
                    <div className="account-text col-md-6">
                    <input
                      type="text"
                      placeholder="Input Text"
                      style={{ width: '523px', height: '35px' }}
                    />
                    </div>
                  </div>
                  <div className="filter-account-text col-md-12">
                    <div className="edit-account-id col-md-3">Facility</div>
                    <div className="account-text col-md-3">
                    <input
                      type="text"
                      placeholder="Is Equal To"
                      style={{ height: '35px' }}
                    />
                    </div>
                    <div className="account-text col-md-6">
                    <input
                      type="text"
                      placeholder="Input Text"
                      style={{ width: '523px', height: '35px' }}
                    />
                    </div>
                  </div>
                  <div className="filter-account-text col-md-12">
                    <div className="edit-account-id col-md-3">Type</div>
                    <div className="account-text col-md-3">
                    <input
                      type="text"
                      placeholder="Is Equal To"
                      style={{ height: '35px' }}
                    />
                    </div>
                    <div className="account-text col-md-6">
                    <input
                      type="text"
                      placeholder="Input Text"
                      style={{ width: '523px', height: '35px' }}
                    />
                    </div>
                  </div>
                </div>
              }
            </div>
          </div>
        </div>
    );
  }
}

const mapStateToProps = (state, props) => {
  return{
      store: state,
      currentUser: state.user.currentUser,
      availableFiltersLoaded: state.customFilterCriteria.availableFiltersLoaded,
      availableFilterSet: state.customFilterCriteria.availableFilterSet,
      defaultFilters: state.customFilterCriteria.defaultFilters==null ?  []:  state.customFilterCriteria.defaultFilters,
      createFilter: state.customFilterCriteria.createFilter
  }
}

export default connect(mapStateToProps)(CreateNewFilter);