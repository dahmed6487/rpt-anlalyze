import React, {Component} from "react";
import autoBind from "react-autobind";
import {connect} from 'react-redux';
import {SET_IFRAME_INDEX, SWITCH_ACCOUNT} from '../../redux/constants/iframe-constants';
import {SET_MOCK_USER,SET_CUSTOMERS_DATA} from '../../redux/constants/user-constants';
import {SWITCH_ACCOUNT_REPORTS, SWITCH_ACCOUNT_USERSPACE} from '../../constants/space-mgmnt-constants';
import * as UserActions from "../../redux/actions/user-actions"
import UserService from "../../redux/services/user-service";
import CustomerService from "../../redux/services/customer-service";
import AsyncSelect from 'react-select/async';
import LookerService from "../../services/looker-service";
import * as AdminActions from "../../redux/actions/account-settings-actions";
import axios from 'axios';
import AccessDeniedError from "./../login/access-denied-error";
import ReactDOM from "react-dom";
import { HashRouter } from "react-router-dom";


class AccountSelection extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);

        this.state = {
            expanded: false,
            searchString: '',
            iframeIndex: 0,
            iframeUrl: "",
            selectedFolder: null,
            userSpace: null,
            allAccounts:[],
            top12Acc:[],
            isDropLoading :true,
        };
    }

    componentDidMount() {
        let allAcc=[],top12Accs=[], allCustomerAccount = [];
        CustomerService.getCustomersForUser()
            .then((response) => {
                response.data.map((item, index) => {
                    if(this.props.userRole !=='SuperAdmin'){
                    if(index<12){
                        top12Accs.push({value: item.totalAccounts, label:  item.amdmEraOwnrName})
                    }}
                    allAcc.push({value: item.totalAccounts, label:  item.amdmEraOwnrName})
                    allCustomerAccount.push(item);
                });
                this.setState({allAccounts:allAcc,isDropLoading:false,top12Acc:top12Accs})
                 this.props.dispatch({type: SET_CUSTOMERS_DATA, payload: allCustomerAccount});

                 // When a user has a single customer, set the userAccount to this customer and dispatch Explore Content Accesses
                 if(this.state.allAccounts.length===1) {
                     localStorage.setItem('userAccount', this.state.allAccounts[0].label);
                     this.getContentAccesses(localStorage.getItem('userAccount'));
                 }
                }
            ).catch((err) => {
            this.setState({allAccounts:allAcc,isDropLoading:false,top12Acc:top12Accs})
        }).finally(() => {
            if (allAcc.length === 1 && allAcc[0].label.toLowerCase() === "all my accounts") {
                ReactDOM.render(<HashRouter><AccessDeniedError supportPhoneNumber={this.props.supportPhoneNumber}/></HashRouter>, document.getElementById('root'));
            }
        });
    }

    render() {
        const { expanded, allAccounts } = this.state;
        const userAccount = localStorage.getItem('userAccount');
        return  (
            <React.Fragment>
                <li className={"account-selector " + (expanded ? "sub-open " : "sub-closed")}>
                    {userAccount ?
                        allAccounts.length > 1 ? <a href="#" onClick={this.openSubMenu} >
                            <span id="eraCurrentCustomer" className="link-text current-user-text">{userAccount}</span>
                            <span className={this.props.isAccDialogClosed ?"fas fa-angle-down" :"fas fa-angle-up"} style={{marginLeft: "0.8rem"}} />
                        </a> : <a href="#"><span id="eraCurrentCustomer" className="link-text current-user-text">{userAccount}</span></a>
                        :
                        <a href="#" >
                            <span id="eraCurrentCustomer" className="link-text current-user-text">Reporting and Analytics</span>
                        </a>
                    }
                </li>
            </React.Fragment>
        );
    }

    closeDialog(event){
        if(event) event.preventDefault();
        this.props.dispatch(UserActions.dialogClose());
    }

    openSubMenu = event => {
        event.preventDefault();
        if(this.state.allAccounts.length===1)
            return;
        const state = this.state;
        const dialog = {
            title: 'Select Customer',
            content: <AccountDialogContent props={state}  event={event} handleUserSelection={this.handleUserSelection} filterAcc={this.filterAcc} noOptionsMessage={this.noOptionsMessage} top12Accs={this.state.top12Acc}/>,
            small: true
        }
        this.props.dispatch(UserActions.dialogOpen(dialog));
        if(this.props.isAccDialogClosed)
            this.closeDialog(event);
    };

    handleChange = e => {
        const state = this.state;
        const dialog = {
            title: 'Select Customer',
            content: <AccountDialogContent props={state} event={e} handleUserSelection={this.handleUserSelection} filterAcc={this.filterAcc} noOptionsMessage={this.noOptionsMessage} top12Accs={this.state.top12Acc}/>,
            small: true
        }
        this.setState({
            searchString: e.target.value
        });
        this.props.dispatch(UserActions.dialogOpen(dialog));

    };

    loadTeamsForUser = (userId) => {
        if (!userId) {
            return;
        }
        UserService.getTeamsForUser(userId)
            .then((teamsResponse) => {
                    this.props.dispatch(UserActions.loadTeamsForUser(teamsResponse.data));
                }
            )
    }

    handleUserSelection = (e,event) => {
        if(e===null)
            return;
        let userId = e.label;
        this.props.dispatch({type: SET_MOCK_USER, payload: userId});
        // reloadIframe is a little bit misleading, if we have an iframe URL set in the store then that variable will determine
        // whether or not the iframe should be manually reloaded (by requesting another url, etc.). In this case there is no
        // iframe url set so we don't need to use that override.
        this.props.dispatch({type: SET_IFRAME_INDEX, payload: {iframeIndex: this.state.iframeIndex, reloadIframe: false}});
        this.props.dispatch({type: SWITCH_ACCOUNT, payload: this.state.iframeUrl});
        this.props.dispatch({type: SWITCH_ACCOUNT_REPORTS, payload: this.state.selectedFolder});
        this.props.dispatch({type: SWITCH_ACCOUNT_USERSPACE, payload: this.state.userSpace});
        localStorage.setItem('userAccount', userId);
        this.getContentAccesses(localStorage.getItem('userAccount'));
        // Load all looker dimensions for all explores for a user whenever the user changes
        this.loadTeamsForUser(userId);
        this.closeDialog(event);

        this.setState({
            expanded: !this.state.expanded,
            searchString: ''
        });
    }

    // Dispatch customer Explore Content Accesses when an account is selected
    getContentAccesses(userAccount){
        axios.get(`/api/customer/get/content-accesses/${userAccount}`)
            .then((response) => {
                this.props.dispatch(UserActions.getExploreContentAccesses(response.data))
            }).catch((error) => {
                this.setState({
                    error: { text: 'There was an error getting this customer\'s content accesses, please try again', type: 'warning' },
                    save: false
                });
            });
    }

    filterAcc = async (inputValue) => {
        if (inputValue.length > 1) {
            if (isNaN(inputValue)) {
                let accounts = this.state.allAccounts;
                accounts = accounts.filter(i =>
                    i.label.toLowerCase().startsWith(inputValue.toLowerCase())
                );
                accounts = accounts.sort(function (a, b) {
                    return b.value - a.value
                });
                return accounts;
            } else {
                const response = await CustomerService.getCustomerByAccount(inputValue);
                const json = await response;
                if (json.data.length === 0) {
                    return null;
                } else {
                    /*  let temp=[];
                      json.data.map((item, index) => {
                          temp.push({value: item.amdmEraOwnrName, label: item.amdmEraOwnrName})
                      });*/
                       let accounts = this.state.allAccounts;
                       accounts = accounts.filter(i =>
                           i.label.toLowerCase().startsWith(json.data[0].amdmEraOwnrName.toLowerCase())
                       );
                       accounts = accounts.sort(function (a, b) {
                           return b.value - a.value
                       });
                    return accounts;

                }
            }

        }
    };

    noOptionsMessage = (inputValue) => {
        if (inputValue["inputValue"].length > 1) {
            let searchStrin = inputValue["inputValue"].toLowerCase();
            searchStrin = this.state.allAccounts.filter(acc => {
                return acc["label"].toLowerCase().indexOf(searchStrin) === 0;
            });
            if (searchStrin.length === 0) {
                return 'No Customers available';
            }
        }
        return null;
    }
}



function AccountDialogContent({props, event, handleUserSelection,filterAcc,noOptionsMessage,top12Accs}){
    return(
        <div className={"account-selection"}>

            <div className={'accounts-available'}>
                <AsyncSelect
                    cacheOptions
                    defaultOptions={top12Accs}
                    placeholder={"Search for a Customer by Name or Six Digit Account Number"}
                    className="select-accounts-dropdown"
                    isSearchable={true}
                    isClearable={true}
                    loadOptions={filterAcc}
                    isLoading={true}
                    noOptionsMessage={noOptionsMessage}
                    onChange={e=> handleUserSelection(e,event)}
                    isLoading={props.isDropLoading}
                    theme={theme => ({
                        ...theme,
                        borderRadius: 0,
                        colors: {
                            ...theme.colors,
                            primary25: '#ddd',
                            primary: '#ddd',
                        },
                    })}
                />
            </div>
        </div>
    );
}



const mapStateToProps = (state, props) => {
    return{
        store: state,
        currentUser: state.user.currentUser,
        isAccDialogClosed:state.user.dialog.isOpen,
        userRole: state.accountSettings.userRole,
        supportPhoneNumber: state.application.supportPhoneNumber
    }
}

export default connect(mapStateToProps)(AccountSelection);