import React, {Component} from "react";
import {connect} from 'react-redux';
import autoBind from "react-autobind";
import {Link, Space} from "@looker/components";
import AsyncSelect from "react-select/async";
import ReactTooltip from "react-tooltip";
import {
    RELOAD_SOLUTION_PANEL,
    SET_IFRAME_INDEX,
    SWITCH_ACCOUNT,
    SWITCH_IFRAME_URL_SOLUTION
} from "../../redux/constants/iframe-constants";
import {SWITCH_ACCOUNT_REPORTS, SWITCH_ACCOUNT_USERSPACE} from "../../constants/space-mgmnt-constants";
import CustomerService from "../../redux/services/customer-service";
import axios from "axios";

class SecondaryAccountSelection extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);

        this.state = {
            secondaryAccountExpanded: false,
            setView: 'Set View',
            setViewList: localStorage.getItem("setViewAppliedDimensions")===null ? [{checkBox: false, dimension: "00", accountValue: ""}] : JSON.parse(localStorage.getItem("setViewAppliedDimensions")),
            setSetViewList: [{checkBox: false, dimension: "00", accountValue: ""}],
            setViewListLength: 0,
            activeRow : 0,
            activeRowValue : "",
            defaultValueOptions: {value: '', label:  ''},
            toolTipText : null,
            toolTipTextFlag :false,
            disabledDropDownDimensions : []
        };
    }

    render() {
        const {secondaryAccountExpanded} = this.state;
        const userAccount = localStorage.getItem('userAccount');
        return (
            <React.Fragment>
                <li  className={"secondary-account-selector " + (secondaryAccountExpanded ? "sub-open " : "sub-closed")}>
                    {userAccount ?
                        <a href="#" data-tip={this.getToolTipText()} className={"secondary-account-set-view-selector"} onClick={this.launchSecondaryAccountDialog}>
                                <span  className={"fas fa-layer-group"}/>&nbsp;&nbsp;
                                <span className="link-text current-user-text">{this.getSetView()}</span>
                                <ReactTooltip multiline={true} place="bottom" type="dark" effect="float" disable={this.state.setViewList.length===0}/>
                        </a>
                        :
                        <a href="#" data-tip={this.getToolTipText()} className={"secondary-account-set-view-selector"}>
                            <span className={"fas fa-layer-group"}/>&nbsp;&nbsp;
                            <span className="link-text current-user-text">{this.state.setView}</span>
                        </a>
                    }
                    {(secondaryAccountExpanded)
                    && (
                        <div className={'dialog dialog-open dialog-small'} style={{top: '70px', left: '397px'}}>
                            <div className="dialog-content">
                                <div className="dialog-header">
                                    <span className="close-btn fas fa-times pull-right"
                                          onClick={this.closeSecondaryAccountPanel}/>
                                    <span className="dialog-title" style={{fontSize: '17px'}}><span className={"fas fa-layer-group"}/>&nbsp;&nbsp;
                                        <span className="link-text current-user-text">Set View</span></span>
                                </div>
                                <div className={"secondary-account-sub-header"}>
                                    <div className={"secondary-account-sub-header-text"}>Here you can choose a set of accounts (by facility, account type and others)
                                        that will filter your results on every report you run in this session. You can change these selections at any time and you can remove your choices by using Clear All.</div>
                                </div>
                                <div className="dialog-body clearfix" style={{height: '100%'}}>
                                    <div>
                                        <div className="row" style={{marginTop: '10px'}}>
                                            <div className="col-sm-5"/>
                                            <div className="col-xs-6 text-right" style={{marginLeft: '13px'}}>
                                                <Link href="Javascript:void(0);" onClick={this.handleClearAll}>
                                                    Clear All
                                                </Link></div>
                                            <div className="col-sm-1"/>
                                        </div>

                                        <div>
                                            <div className="row">
                                                <div className="col-sm-1"/>
                                                <div className="col-sm-4">
                                                    <label htmlFor="userRole">ACCOUNT DIMENSION</label>
                                                </div>
                                                <div className="col-sm-6">
                                                    <label htmlFor="userRole">VALUE</label>
                                                </div>
                                            </div>
                                        </div>
                                        {
                                            this.state.setViewList.map((x, i) => {
                                                const promiseOptions = async (inputValue) => {
                                                    const response = await CustomerService.getAccountDimensions(this.state.activeRowValue, inputValue, localStorage.getItem('userAccount'));
                                                    const json = await response;
                                                    let temp = []
                                                    if (json.data.length === 0) {
                                                        return null;
                                                    } else {
                                                        json.data.map((item, index) => {
                                                            temp.push({
                                                                value: item,
                                                                label: item,
                                                                color: '#FFC400'
                                                            })
                                                        });
                                                    }
                                                    return temp;
                                                }

                                                let noOptionMessage = (inputValue) => {
                                                    return 'Search to add values'
                                                }
                                                return (
                                                    <>
                                                        <div className="row" style={{marginTop: '10px'}}>
                                                            <div className="col-sm-1" style={{marginTop: '15px'}}>
                                                                <input type="checkbox" name="checkBox" style={{transform: 'scale(1.5)',marginLeft: '25px'}}
                                                                               checked={x.checkBox}
                                                                               onChange={e => this.handleSelectChange(e.currentTarget, "checkBox", i)}/>
                                                            </div>

                                                            <div className="col-sm-4">
                                                                <select
                                                                    name="dimension"
                                                                    value={x.dimension}
                                                                    className="form-control"
                                                                    onChange={e => this.handleSelectChange(e, "dimension", i)}
                                                                >
                                                                    {
                                                                        dimensions.map((dimension) => <option
                                                                            value={dimension.key} /*disabled={this.state.disabledDropDownDimensions.find(element => element===dimension.key)}*/ style={{fontSize: '14px'}}>
                                                                            {dimension.name}</option>)
                                                                    }
                                                                </select>
                                                            </div>

                                                            <div className="col-sm-6">
                                                                <AsyncSelect
                                                                    isMulti
                                                                    //cacheOptions
                                                                    defaultOptions={this.state.defaultValueOptions}
                                                                    value={x.accountValue}
                                                                    loadOptions={promiseOptions}
                                                                    placeholder={"Search to add values"}
                                                                    noOptionsMessage={noOptionMessage}
                                                                    className="select-accounts-dropdown"
                                                                    isSearchable={true}
                                                                    isClearable
                                                                    isLoading={false}
                                                                    onChange={e => this.handleSelectChange(e, "accountValue", i)}
                                                                    onInputChange={e =>this.handleAccountInputChange(e, x.dimension, i)}
                                                                    theme={theme => ({
                                                                        ...theme,
                                                                        borderRadius: 0,
                                                                        colors: {
                                                                            ...theme.colors,
                                                                            primary75: '#ddd',
                                                                            primary: '#ddd',
                                                                        },
                                                                    })}
                                                                />
                                                            </div>
                                                            <div className="col-sm-1" style={{marginLeft: '-20px'}}>
                                                                {i > 0 || i === 0 && this.state.setViewListLength > 1 ? (
                                                                    <Space>
                                                                        <Link
                                                                            href="Javascript:void(0);"
                                                                            onClick={() => this.handleRemoveClick(i)}
                                                                            style={{color: "#D9534F"}}
                                                                        >
                                                                            X
                                                                        </Link>
                                                                    </Space>
                                                                ) : (
                                                                    <Space/>
                                                                )}</div>
                                                        </div>
                                                    </>
                                                );
                                            })}
                                        {/*</Grid>*/}
                                        <div className="row" style={{marginTop: '10px'}}>
                                            <div className="col-sm-5"/>
                                            <div className="col-xs-6 text-right" style={{marginLeft: '13px'}}>
                                                <Link href="Javascript:void(0);" onClick={this.handleAddClick}>
                                                    + Add New Account Dimension
                                                </Link></div>
                                            <div className="col-sm-1"/>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <div className="row" style={{marginBottom: '10px'}}>
                                        <div className="col-xs-5">
                                        </div>
                                        <div className="col-xs-6 text-right" style={{marginLeft: '-9px'}}>
                                            <button type="button" className="btn btn-default"
                                                    onClick={this.closeSecondaryAccountPanel}>CANCEL
                                            </button>
                                            &nbsp;&nbsp;&nbsp;&nbsp;
                                            <button type="button" className="btn btn-primary"
                                                    onClick={this.applySecondaryAccountHandler}>SAVE
                                            </button>
                                        </div>
                                        <div className="col-sm-1"/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </li>
            </React.Fragment>

        );
    }
    applySecondaryAccountHandler = () => {
        let list = this.state.setViewList;

        list.forEach(function (value, i, array) {
            if(list[i].dimension==='00')
              list.splice(i, 1);
        });
        if(list.length===0)
            list=[{checkBox: false, dimension: "00", accountValue: ""}];

        localStorage.setItem('setViewAppliedDimensions', JSON.stringify(list))
        let userAttribute = '', finalUserAttribute = '', remainingUserAttributes = '';

        const setViewAppliedDimensions = localStorage.getItem("setViewAppliedDimensions") === null ? [{
            checkBox: false,
            dimension: "cen",
            accountValue: ""
        }] : JSON.parse(localStorage.getItem("setViewAppliedDimensions"));
        setViewAppliedDimensions.map((x, index) => {
            let userAttributeValue = ''
            if (x.checkBox) {
                dimensions.forEach(function (dimension) {
                    if (dimension.key === x.dimension) {
                        userAttribute = '"' + dimension.key + '":';
                    } else {
                        remainingUserAttributes = remainingUserAttributes + '"' + dimension.key + '":"%,NULL",'
                    }
                });
                if (x.accountValue === '' || x.accountValue === null) {
                    userAttribute = userAttribute + '"%,NULL"';
                } else {
                    userAttributeValue = '"';
                    x.accountValue.forEach(function (value) {
                        userAttributeValue = userAttributeValue + "" + value.value + ",";
                    });
                    let lastChar = userAttributeValue.slice(-1);
                    if (lastChar === ',') { // check last character is string
                        userAttributeValue = userAttributeValue.slice(0, -1); // trim last character
                    }
                    userAttribute = userAttribute + userAttributeValue + '"';
                }
                finalUserAttribute = finalUserAttribute + userAttribute + ',';
            }
        });


        let lastChar = remainingUserAttributes.slice(-1);
        if (lastChar === ",") { // check last character is string
            remainingUserAttributes = remainingUserAttributes.slice(0, -1); // trim last character
        }

        if (finalUserAttribute !== '') {
            console.log("finalUserAttribute+remainingUserAttributes +" + finalUserAttribute + remainingUserAttributes)
            localStorage.setItem('finalUserAttribute', encodeURIComponent(finalUserAttribute + remainingUserAttributes))
            if (window.location.href.indexOf("solutions") > -1) {
                let solutionsPanel = document.querySelector('#solutionsPanel');
                if (solutionsPanel === null) {
                    this.props.dispatch({type: RELOAD_SOLUTION_PANEL, payload: {isLoaded: true}});
                    return;
                }
                solutionsPanel.style.display = 'none';
                let urlData = this.getSolutionUrlData();
                let finalUrl = ''
                if (localStorage.getItem("finalUserAttribute") === null)
                    finalUrl = `/looker/dashboard/${urlData.solutionNumber}?customerId=${localStorage.getItem('userAccount')}`;
                else
                    finalUrl = `/looker/dashboard/${urlData.solutionNumber}?customerId=${localStorage.getItem('userAccount')}&finalUserAttribute=${localStorage.getItem("finalUserAttribute")}`;
                axios.get(finalUrl)
                    .then((response) => {
                        this.props.dispatch({type: SWITCH_IFRAME_URL_SOLUTION, payload: response.data});
                        this.props.dispatch({type: RELOAD_SOLUTION_PANEL, payload: {isLoaded: true}});
                    })
            }
            else
            {
                this.props.dispatch({type: SET_IFRAME_INDEX, payload: {iframeIndex: this.state.iframeIndex, reloadIframe: false}});
                this.props.dispatch({type: SWITCH_ACCOUNT, payload: this.state.iframeUrl});
                this.props.dispatch({type: SWITCH_ACCOUNT_REPORTS, payload: this.state.selectedFolder});
                this.props.dispatch({type: SWITCH_ACCOUNT_USERSPACE, payload: this.state.userSpace});
            }

        this.setState({
            secondaryAccountExpanded: false,
        });
    }else {
            this.setState({
                secondaryAccountExpanded: true,
                setViewList  : [{checkBox: false, dimension: "00", accountValue: ""}],
            });
        }
    };

    closeSecondaryAccountPanel = () => {
        this.setState({
            secondaryAccountExpanded: false
        });
    }

    launchSecondaryAccountDialog = (event) => {
        event.preventDefault();
        this.setState({
            secondaryAccountExpanded: !this.state.secondaryAccountExpanded
        });
    }
    handleAddClick = () => {
        let temp = this.state.setViewList;
        let arry=[]
        temp.forEach((value, index) => {
            arry.push(value.dimension);
        })
        temp.push({checkBox: false, dimension: "00", accountValue: ""});
        this.setState({setSetViewList: temp, disabledDropDownDimensions : arry});
    };
    handleSelectChange = (value, name, index) => {
        const list = [...this.state.setViewList];
        list[index][name] = name === 'checkBox' ? value.checked : name === 'dimension' ? value.target.value : value;
        if (name === 'dimension') {
            list[index]["accountValue"]="";
            this.setState({setSetViewList: list, defaultValueOptions: {value: '', label: ''}})
        } else {
         this.setState({setSetViewList: list})
    }
    };

    handleClearAll= () => {
        localStorage.removeItem('finalUserAttribute');
        localStorage.removeItem('setViewAppliedDimensions');
        let list = this.state.setViewList;
        if (list.length === 1) {
            list[0]["accountValue"]="";
            list[0]["dimension"]="00";
            list = [{checkBox: false, dimension: "00", accountValue: ""}];
        } else {
            list.forEach(function (value, i, array) {
                list.splice(i, 1);
            });
            if(list.length>=2){
                list.forEach(function (value, i, array) {
                    list.splice(i, 1);
                });
            }
        }
        this.setState({setSetViewList: list, disabledDropDownDimensions : []})
    }
    handleRemoveClick = (index) => {
        const list = this.state.setViewList;
        list.splice(index, 1);
        let arry=[]
        list.forEach((value, index) => {
            arry.push(value.dimension);
        })
        this.setState({setSetViewList: list, disabledDropDownDimensions : arry})
    };

    handleAccountInputChange =  (value, name, index) => {
        this.setState({activeRowValue: name, activeRow : index})
    };

    toolTipText(setView) {
        this.setState({setView: "name"})
    }

    getToolTipText(toolTipText) {
        if (localStorage.getItem("setViewAppliedDimensions") === null)
            return "Allows you to set parameters that will apply to every report you run in this session";
        else {
            let userAttribute='',finalUserAttribute='';
            const setViewAppliedDimensions = localStorage.getItem("setViewAppliedDimensions")===null ? [{checkBox: false, dimension:"00", accountValue: ""}] : JSON.parse(localStorage.getItem("setViewAppliedDimensions"));
            setViewAppliedDimensions.map((x, index) => {
                let userAttributeValue=''
                if (x.checkBox) {
                    dimensions.forEach(function (dimension) {
                        if (dimension.key === x.dimension) {
                            userAttribute=''+dimension.name+' : ';
                        }
                    });
                    if (x.accountValue === '' || x.accountValue === null) {
                        userAttribute=userAttribute+'';
                    } else {
                         userAttributeValue='';
                        x.accountValue.forEach(function (value) {
                            userAttributeValue=userAttributeValue+""+ value.value + ",";
                        });
                        let lastChar = userAttributeValue.slice(-1);
                        if (lastChar === ',') {
                            userAttributeValue = userAttributeValue.slice(0, -1);
                        }
                        userAttribute=userAttribute+userAttributeValue+'';
                    }
                    finalUserAttribute=finalUserAttribute+userAttribute+'<br />';
                }

            });

            if (finalUserAttribute === '')
                return "Showing:";
            else
                return 'Showing:<br/>' + finalUserAttribute;
    }
    }

    getSetView() {
        if (localStorage.getItem("setViewAppliedDimensions") === null)
            return "Set View";
        else {
            let setViewText = '', text2 = '', text3 = '';

            const setViewAppliedDimensions = localStorage.getItem("setViewAppliedDimensions")===null ? [{checkBox: false, dimension: "00", accountValue: ""}] : JSON.parse(localStorage.getItem("setViewAppliedDimensions"));
            setViewAppliedDimensions.map((x, index) => {
                if (x.checkBox) {
                    dimensions.forEach(function (dimension) {
                        if (dimension.key === x.dimension) {
                            text2 = dimension.name;
                        }
                    });
                    if (x.accountValue === '' || x.accountValue === null) {
                        text3 = ' ';
                    } else {
                        text3 = '';
                        x.accountValue.forEach(function (value) {
                            text3 = text3 + value.value + ',';
                        });
                    }
                    setViewText = setViewText + text2 + ':' + text3;
                }
            });
            let lastChar = setViewText.slice(-1);
            if (lastChar === ',') { // check last character is string
                setViewText = setViewText.slice(0, -1); // trim last character
            }
            if (setViewText === '')
                return "Allows you to set parameters that will apply to every report you run in this session";
            else
                return "Set View :" + setViewText;
        }
    }

    getSolutionUrlData() {
        let urlComponents = window.location.href.split('solutions/')[1].split(/-(.+)/);
        return {
            solutionNumber: urlComponents[0],
            solutionName: urlComponents[1]
        };
    }
}

const dimensions = [
    {key: '00', name: 'Select'},
    {key: 'cen', name: 'Common Entity Name'},
    {key: 'cdn', name: 'District Name'},
    {key: 'crn', name: 'Region Id'},
    {key: 'chi', name: 'Chain Number'},
    {key: 'ngn', name: 'National group Name'},
    {key: 'ngc', name: 'National group Number'},
    {key: 'nsgn', name: 'National Subgroup Name'},
    {key: 'nsgc', name: 'National Subgroup Number'},
    {key: 'acd', name: 'Account Classification'},
    {key: 'cfd', name: 'Facility'},
    {key: 'catd', name: 'Account Type'},
    {key: 'dn', name: 'DEA Number'}
];


const mapStateToProps = (state, props) => {
    return {
        store: state,
        finalUserAttribute: state.user.finalUserAttribute,
        solutionsData: state.user.solutionData,
        currentUser: state.user.currentUser,
        iframeIndex: state.iframe.iframeIndex,
        iframeUrl: state.iframe.iframeUrl,
        reloadIframe: state.iframe.reloadIframe,
        editMode: state.customFilterCriteria.editMode,
        dashboardLoaded: state.customFilterCriteria.dashboardLoaded,
        filterMetaDataStatus: state.customFilterCriteria.filterMetaDataStatus,
        customGroupDialog: state.customFilterCriteria.customGroupDialog,
        data: state.iframe.data,
        path: state.iframe.path,
        filtersUrl: state.iframe.filtersUrl,
        isLoading: state.customFilters.isLoading,
        isLoaded:state.iframe.isLoaded,
        userRole: state.accountSettings.userRole,
        contentAccesses: state.user.exploreContentAccesses,
    };
}
export default connect(mapStateToProps)(SecondaryAccountSelection);