import React, {Component} from "react";
import {connect} from 'react-redux';
import {SET_MOCK_USER} from '../../redux/constants/user-constants';
import UserService from "../../redux/services/user-service";
import {Redirect} from "react-router-dom";
//import * as UserActions from "../redux/actions/user-actions";
import * as UserActions from "../../redux/actions/user-actions"
import CustomerService from "../../redux/services/customer-service.jsx";
import lookerService from "../../services/looker-service";

class AccountSelectionScreen extends Component {

    constructor(props, context) {
        super(props, context);
        autoBind(this);
        this.state = {
            accounts :[]
        };
    }
    componentDidMount() {
        CustomerService.getCustomersForUser()
            .then((response) => {
                    this.setState({accounts: response.data})
                }
            )
    }

    handleUserSelection = (event) => {
        let userId = event.target.value;
        this.props.dispatch({type: SET_MOCK_USER, payload: userId});
        this.loadTeamsForUser(userId);
        lookerService.getSolutionData().then((response) => {
            this.props.dispatch(UserActions.solutionData(response));
        });
    }

    loadTeamsForUser = (userId) => {
        UserService.getTeamsForUser(userId)
            .then((teamsResponse) => {
                    this.props.dispatch(UserActions.loadTeamsForUser(teamsResponse.data));
                }
            ).catch((err) => {
        });
    }

    render(){
        //Redirect user to default report if authenticated.
        if(this.props.currentUser!=null&&this.props.currentUser!=""){
            return(
                <Redirect to={{ pathname: "/", }} />
            );
        }

        return(
            <div className="select-user ">
                <div>
                    <span className="far fa-user-circle user-icon" />
                    <div className="select-user-text ">Select customer</div>
                </div>
                <hr/>
                <div>
                    <div className="select-user-account ">Please Enter a Customer’s Name</div>
                    <div>
                        <select className="select-user-dropdown" onChange={this.handleUserSelection}>
                            {this.state.accounts.map((item, index) => {
                                return <option key={item[1]} value={item[1]}>{item[1]}</option>
                            })}
                        </select>
                    </div>
                </div>
            </div>
        );
    }

}

const mapStateToProps = (state, props) => {
    return {
        currentUser: state.user.currentUser
    };
}

export default connect(mapStateToProps)(AccountSelectionScreen);