import React, { Component } from "react";
import autoBind from "react-autobind";
import OktaSignIn from '@okta/okta-signin-widget';
import axios from "axios";
import DefaultLayout from "../../layout/default/default-layout";
import { connect } from "react-redux";
import ReactDOM from "react-dom";
import { HashRouter } from "react-router-dom";
import mckessonlogoNavbar from '../../../src/img/mckesson-logo-navbar.png';
import UserService from "../../redux/services/user-service";
import * as AdminActions from "../../redux/actions/account-settings-actions";
import AccessDeniedError from "./access-denied-error";

class login extends Component {
    constructor(props) {
        super(props);
        autoBind(this);

        this.state = {
            authenticated: false,
            eraAccess: false,
            errorMsg: null
        };
    }

    async componentDidMount() {
        const resp = await axios.get(`/api/user/authenticated`);
        const content = await resp.data;
        const supportPhoneNumber = this.props.supportPhoneNumber;

        if (content && content !== 'Unauthenticated') {
            UserService.getReportUser()
                .then((response) => {
                        const sudoRole = response.data.sudoRole;
                        const role = response.data.role;
                        this.props.dispatch(AdminActions.userType(response.data.internal));
                    if (response.data.sudoUser) {
                        this.props.dispatch(AdminActions.userName(response.data.sudoFirstName + ' ' + response.data.sudoLastName));
                        this.props.dispatch(AdminActions.userRole(sudoRole.type));
                        this.props.dispatch(AdminActions.loginUserInfo(false, response.data.userDisplayName, response.data.sudoUser));
                        this.props.dispatch(AdminActions.username(response.data.sudoUsername));
                        this.props.dispatch(AdminActions.roleAccessInfo(sudoRole.adminAccess, sudoRole.userManagementAccess, sudoRole.customerManagementAccess, sudoRole.teamManagementAccess, sudoRole.accountSegmentationAccess, sudoRole.vendorPurchasesAccess));
                    } else {
                        this.props.dispatch(AdminActions.userName(response.data.userDisplayName));
                        this.props.dispatch(AdminActions.userRole(role.type));
                        this.props.dispatch(AdminActions.loginUserInfo(true,null, false));
                        this.props.dispatch(AdminActions.username(response.data.username));
                        this.props.dispatch(AdminActions.roleAccessInfo(role.adminAccess, role.userManagementAccess, role.customerManagementAccess, role.teamManagementAccess, role.accountSegmentationAccess, role.vendorPurchasesAccess));
                        this.props.dispatch(AdminActions.canSudo(role.sudoAccess));
                    }
                    if(role.type==='Guest'){
                        UserService.checkERAAccess()
                            .then((response) => {
                                this.setState({ authenticated: true, eraAccess: true, errorMsg: null });
                                }
                            ).catch((err) => {
                            ReactDOM.render(<HashRouter><AccessDeniedError supportPhoneNumber={supportPhoneNumber} errorDesc={err.response.data.error_desc}/></HashRouter>, document.getElementById('root'));
                        });
                    } else{
                        this.setState({ authenticated: true, eraAccess: true, errorMsg: null });
                    }
                })
        } else {
            localStorage.removeItem('userAccount');
            localStorage.removeItem('finalUserAttribute');
            localStorage.removeItem('setViewAppliedDimensions');

            const res = await axios.get(`/initiate-state`);
            const data = await res.data;

            axios.get(`/api/okta`)
                .then(res => {
                    localStorage.setItem('logoutUrl', res.data.LOGOUT_URL);
                    const oktaSignIn = new OktaSignIn({
                        baseUrl: res.data.ISSUER.split('oauth2')[0],
                        clientId: res.data.CLIENT_ID,
                        redirectUri: res.data.REDIRECT_URI,
                        logo: 'https://cdn.mckesson.com/code/ui/1.0.37/img/mck_logo_blue.svg',
                        idpDiscovery: {
                            requestContext: res.data.ISSUER + '/v1/authorize?client_id=' + res.data.CLIENT_ID + '&response_type=code&scope=' + res.data.SCOPES + '&redirect_uri=' + res.data.REDIRECT_URI + '&state=' + encodeURIComponent(data.state)
                        },
                        authParams: {
                            issuer: res.data.ISSUER,
                            responseType: 'code',
                            scopes: ['openid', 'profile', 'email'],
                            state: data.state,
                            display: 'page',
                            pkce: false
                        },
                        tokenManager: {
                            expireEarlySeconds: 120
                        },
                        i18n: {
                            'EN': {
                                'primaryauth.title': 'Log In',
                                'primaryauth.submit': 'Log In',
                                'forgotpassword': 'Forgot your password?',
                                'oform.errorbanner.title': 'Please enter User ID and Password to continue',
                                'help': ' ',
                                'primaryauth.username.placeholder': 'User ID',
                                'primaryauth.username.tooltip': 'User ID',
                                'primaryauth.password.placeholder ': 'Password',
                                'primaryauth.password.tooltip': 'Password',
                                'remember': 'Remember me',
                            }
                        },
                        features: {
                            idpDiscovery: true,
                            rememberMe: false,
                            showPasswordToggleOnSignInPage: true,
                            hideSignOutLinkInMFA: true,
                            registration: true,
                            placeholder: false,
                            required: false
                        },
                        helpLinks: {
                            forgotPassword: res.data.FORGOTPASSWORDLINK,
                        },
                        brandName: 'Spaghetti Inc.',
                    });

                    let currentComponent = this, widgetContainer = document.getElementById("widget-container");

                    ReactDOM.render(headerElement, widgetContainer);
                    widgetContainer.insertAdjacentHTML("afterend", footerElement);

                    oktaSignIn.on('afterRender', function (context) {
                        document.getElementsByClassName('registration-label')[0].innerHTML = "Please call " + supportPhoneNumber + " to speak with a customer support representative who can help with any issues.";
                        document.getElementsByClassName('registration-label')[0].style.color = "#666";
                        document.getElementsByClassName('registration-container')[0].style.padding = "15px";
                        document.getElementsByClassName('registration-link')[0].innerHTML = "";
                    });

                    oktaSignIn.renderEl(
                        { el: '#widget-container' },
                        function success(res) {
                            if (res.status === "IDP_DISCOVERY") {
                                res.idpDiscovery.redirectToIdp();
                            }
                            currentComponent.setState({ authenticated: true });
                        },
                        function error(err) {
                            currentComponent.setState({ authenticated: false });
                        }
                    );
                })
                .catch(function (error) {
                    alert('Error while fetching the Okta details.please reload...')
                });
        }
    }

    render() {
        if (this.state.authenticated) {
            return (
                    <div>
                        <HashRouter>
                            <DefaultLayout authenticated={this.state.authenticated} eraAccess={this.state.eraAccess} errorMsg={this.state.errorMsg} />
                        </HashRouter>
                    </div>
                   );
        } else {
            return (
                <div id="widget-container" />
            );
        }
    }
}

const headerElement = (
<div className="login-form">
    <header className="header">
        <div className="logo">
            <a>
                <img alt="McKesson Connect Logo" src={mckessonlogoNavbar} style={{ padding: '6px 0px 0px 12px' }} />
            </a>
        </div>
    </header>
    <br />
    <div>
        <div className="okta">
            <h1 style={{ width: '347px', height: '66px', margin: ' 0 auto 10px auto' }}>
                Login to Pharmaceutical
                    Solutions & Services
            </h1>
        </div>
    </div>
</div>
);

const footerElement = (
    "<div class=\"footer\">\n" + "<p>To learn more about McKesson, please visit our Corporate website at <a href=\"https://www.mckesson.com\" style=\"\n" +
    "    color: #135a8c;\n" +
    "\">www.mckesson.com</a></p>\n" +
    "    </div>" +
    "<div id=\"wcm-footer\">\n" +
    "        <div class=\"bar\">\n" +
    "            <div class=\"ftr-left\"> \n" +
    "<a style= \"color: #fff;\">Privacy</a>&nbsp;|&nbsp;" +
    "<a href=\"https://testwcm.mckesson.com/portal/site/smo/menuitem.790a2e0edaf35142d42bc2925740d0a0/?vgnextoid=0cf9ffbc64185110VgnVCM1000003344070aRCRD&amp;vgnextfmt=guest\" style= \"color: #fff;\">Online Usage Agreement</a>\t\t\t \n" +
    "            </div>\n" +
    "            <div class=\"ftr-right\"> ©2020 - " + new Date().getFullYear() + " \n" +
    "<a href=\"http://www.mckesson.com\" style= \"color: #fff;\" target=\"_blank\">McKesson Corporation</a>\n" +
    "        </div>\n" +
    "        </div>\n" +
    "\t</div>"
)

const mapStateToProps = (state, ownProps) => {
    return {
        isLoading: state.application.isLoading,
        supportPhoneNumber: state.application.supportPhoneNumber
    }
}

export default connect(mapStateToProps)(login);