import React, { Component } from "react";
import Header from "../header/header";

class BrowserError extends Component {
    render() {
        return (
            <div>
                <nav className="navbar primary-nav navbar-default navbar-fixed-top" style={{ minHeight: '0' }}>
                    <div className="container-fluid">
                        <div className="row display-flex">
                            <Header />
                        </div>
                    </div>
                </nav>
                <div className="error_page-body-content">
                    <h1 style={{ height: '40px' }}> Unsupported Browser </h1>
                    <p> Looks like you are trying to use Internet Explorer. </p>
                    <p> Please visit McKesson ERA using a recent version of Microsoft Edge, Google Chrome, Firefox or Safari. </p>
                </div>
            </div>
        );
    }
}

export default BrowserError;