import React, { Component } from "react";
import Header from "../header/header";
import * as AdminActions from "../../redux/actions/account-settings-actions";
import axios from "axios";

class AccessDeniedError extends Component {
    constructor(props) {
            super(props);
    }

    componentDidMount() {
        localStorage.removeItem('_windowLocation');
        localStorage.removeItem('_session_expired_windowLocation');
        localStorage.removeItem('userAccount');
        localStorage.removeItem('finalUserAttribute');
        localStorage.removeItem('setViewAppliedDimensions');
        localStorage.removeItem('filtersUrl');
        localStorage.removeItem('dashboardNext');
        document.cookie = "pagerefreshedcookie=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";

        axios.get('/api/signout')
            .then(response => {
            })
    }

    render() {
        return (
            <div>
                <nav className="navbar primary-nav navbar-default navbar-fixed-top" style={{ minHeight: '0' }}>
                    <div className="container-fluid">
                        <div className="row display-flex">
                            <Header />
                        </div>
                    </div>
                </nav>
                <div className="error_page-body-content">
                    <span className="nowrap"> {this.props.errorDesc}</span>
                    <p> <sub> Note: Please <a href={"/"}>click here</a>  or refresh the page to go to login page.</sub></p>
                </div>
            </div>
        );
    }
}

export default AccessDeniedError;