import React, { useState } from "react";
import PopoverContent from "./PopoverContent";
import "./Popover.less";

const Popover = ({
  visible,
  onClickOutSide,
  showArrow,
  placement,
  closeOnClick,
  className,
  style,
  children,
  triggerNode,
  trigger,
}) => {
  const [isVisible, SetIsVisible] = useState(visible);

  const onShow = (e) => {
    e.stopPropagation();
    SetIsVisible(true);
  };

  const onClose = () => {
    SetIsVisible(false);
  };

  const onToggle = (e) => {
    e.stopPropagation();
    SetIsVisible((prevVisible) => !prevVisible);
  };

  const onClickOutSideOverlay = () => {
    onClose();
    onClickOutSide && onClickOutSide();
  };

  return (
    <div className="overlay-popover">
      {triggerNode &&
        React.cloneElement(triggerNode, {
          onClick: trigger === "click" || trigger === "hover" ? onToggle : null,
          onMouseOver: trigger === "hover" ? onShow : null,
        })}

      {isVisible && (
        <PopoverContent
          showArrow={showArrow}
          placement={placement}
          closeOnClick={closeOnClick}
          onClickOutSide={onClickOutSideOverlay}
          className={className}
          style={style}
          onClose={onClose}
        >
          {children}
        </PopoverContent>
      )}
    </div>
  );
};

export default Popover;
