import React, { useEffect, useRef } from "react";
import classNames from "classnames";

const PopoverContent = ({
  className,
  placement,
  showArrow,
  style,
  children,
  closeOnClick,
  onClose,
  onClickOutSide,
}) => {
  const node = useRef(null);
  const isInPage = (node) => {
    return node === document.body ? false : document.body.contains(node);
  };
  const handleClickOutSide = (e) => {
    if (node) {
      if (closeOnClick) {
        onClose();
      } else {
        if (isInPage(e.target) && !node.current.contains(e.target)) {
          onClickOutSide();
        }
      }
    }
  };
  const onKeyDown = (e) => {
    if (e.keyCode === 27) {
      e.stopPropagation();
      onClose();
    }
  };

  useEffect(() => {
    node.current.focus();
    window.document.addEventListener("click", handleClickOutSide, false);
    return () => {
      node.current.blur();
      window.document.removeEventListener("click", handleClickOutSide, false);
    };
  }, []);

  return (
    <div
      ref={node}
      tabIndex="-1"
      onKeyDown={onKeyDown}
      className={classNames("overlay-popover-content", className, placement, {
        "-arrow": showArrow,
      })}
      style={style}
    >
      <div className="overlay-popover-inner p-24">{children}</div>
    </div>
  );
};

export default PopoverContent;
