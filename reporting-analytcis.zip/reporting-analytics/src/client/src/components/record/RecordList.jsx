import React, { Component } from 'react';
import RecordRow from './RecordRow';
import RecordMeta from './RecordMeta';
import RecordAction from './RecordAction';
import RecordNumber from './RecordNumber';

export default class RecordList extends Component{
    constructor(props) {
        super(props);
    }

    render() {
        const { rows } = this.props;
        return (
            <React.Fragment>
                {rows.map((row, key) =>
                    <RecordRow key={key}>
                        {row.cols.map((col) => {
                            if(col.type == 'meta') {
                                return (
                                <RecordMeta
                                    label={col.label}
                                    meta={col.meta}
                                    secondary={col.secondary || null}
                                    classes={col.classes}
                                />
                                )
                            }
                            if(col.type == 'action') {
                                return (
                                <RecordAction
                                    label={col.label}
                                    url={col.url}
                                    children={col.children || null}
                                    classes={col.classes}
                                />
                                )
                            }
                            if(col.type == 'number') {
                                return (
                                <RecordNumber
                                    label={col.label}
                                    data={col.data}
                                    secondary={col.secondary || null}
                                    classes={col.classes}
                                />
                                )
                            }
                        })}
                    </RecordRow>
                )}
            </React.Fragment>
        );
    }
}
