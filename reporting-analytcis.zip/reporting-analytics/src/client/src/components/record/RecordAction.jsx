import React from 'react';

function RecordAction(props) {
    return (
        <div className={'record-col record-action ' + (props.classes || '')}>
            <a href={props.url}>{props.label}
                &nbsp;
                <span className="fa fa-angle-right" />
            </a>
            {props.children}
        </div>
    );
}

export default RecordAction;
