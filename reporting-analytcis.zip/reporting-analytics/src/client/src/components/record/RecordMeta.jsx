import React from 'react';

function RecordMeta(props){
    return(
        <div className={'record-col '+(props.classes || '')}>
            <div className="record-label">{props.label}</div>
            <div className="record-meta" title={props.title===undefined || props.title===''?'':props.title}>{props.meta}</div>
            {props.secondary &&
                <div className="secondary-data">{props.secondary}</div>
            }
        </div>
    );
}

export default RecordMeta;