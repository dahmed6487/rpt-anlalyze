import React from 'react';
import Row from './Row';

function RecordRow(props){
    return(
        <div id={props.id} className={'header-record-row ' + props.classes}>
            <Row classes="row header-record">
                {props.children}
            </Row>
        </div>
    );
}

export default RecordRow;
