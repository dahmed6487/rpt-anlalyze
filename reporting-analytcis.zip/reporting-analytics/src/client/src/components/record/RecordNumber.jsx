import React from 'react';

function RecordNumber(props){
    return(
        <div className={'record-col record-number-col ' + (props.classes || '')}>
            <div className="record-label">{props.label}</div>
            <div className="record-number">{props.data}</div>
            {props.secondary
                && <div className="secondary-data">{props.secondary}</div>}
        </div>
    );
}

export default RecordNumber;
