import React, { Component } from "react";
import autoBind from "react-autobind";
import { NavLink } from "react-router-dom";
import { connect } from "react-redux";

class SubMenuChildPurchaseHistory extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);
    this.state = {
      childExpanded: false,
      iframeUrl: ""
    };
  }

  render() {
    const path = this.props.rep.id
    return (
        <NavLink exact className="link-text" to={`/dashboard/${path}`} onClick={this.handleIframe}>
            <div className="menu-link-sub-child newly-purchased-child">
                <span className="link-text">
                    {this.props.rep.name}
                </span>
            </div>
        </NavLink>
    );
  }

  handleIframe = (event) => {
    const SWITCH_ACCOUNT = 'SWITCH_ACCOUNT';
    this.props.dispatch({type: SWITCH_ACCOUNT, payload: this.state.iframeUrl});
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    store: state,
    selectedFolder: state.spaceMgmnt.selectedFolder
  };
}

export default connect(mapStateToProps)(SubMenuChildPurchaseHistory);

