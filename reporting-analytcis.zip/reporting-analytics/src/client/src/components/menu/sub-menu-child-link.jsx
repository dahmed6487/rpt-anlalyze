import React, { Component } from "react";
import autoBind from "react-autobind";
import { NavLink } from "react-router-dom";
import {connect} from 'react-redux';

class SubMenuChildLink extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);
    this.actions = props.actions;
    this.state = {
      iframeUrl: ""
    };
  }

  handleAccount = (event) => {
    const SWITCH_ACCOUNT = 'SWITCH_ACCOUNT';
    this.props.dispatch({type: SWITCH_ACCOUNT, payload: this.state.iframeUrl});
  }

  render() {
    const { route } = this.props;
    return (
      <NavLink exact className="link-text" to={route.path} onClick={this.handleAccount}>
        <div className="menu-link-sub-child">
          <span className="link-text">{route.menuTitle}</span>
        </div>
      </NavLink>
    );
  }
}
const mapStateToProps = (state, props) => {
  return{
      store: state
  }
}
export default connect(mapStateToProps)(SubMenuChildLink);
