import React, { Component } from "react";
import autoBind from "react-autobind";
import { NavLink } from "react-router-dom";
import {connect} from 'react-redux';
import SubMenuChildPurchaseHistory from "./sub-menu-child-purchase-history";

class SubMenuChildLinkFolders extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);
    this.actions = props.actions;
    this.state = {
      iframeUrl: "",
      expanded: false
    };
  }

  handleAccount = (event) => {
    const SWITCH_ACCOUNT = 'SWITCH_ACCOUNT';
    this.props.dispatch({type: SWITCH_ACCOUNT, payload: this.state.iframeUrl});
    this.setState({
      expanded: !this.state.expanded
    })
  }

  purchaseFolder = (event) => {
    event.preventDefault();
    this.setState({
      expanded: !this.state.expanded
    })
  }

  render() {
    const path =  this.props.rep.id
    return (
      <div className={'menu-link-sub  ' + (this.state.expanded ? 'sub-open' : 'sub-closed')}>
        <div className={this.props.rep.name == 'Newly Purchased Items' ? 'fa fa-caret-right newly-purchased-icon' : ' '} onClick={this.purchaseFolder} />
        <div className={this.props.rep.name == 'Newly Purchased Items' ? 'newly-purchased-folder' : ''}>
          <NavLink exact className="link-text" to={ `/dashboard/${path}`} onClick={this.props.rep.name == 'Newly Purchased Items' ? this.purchaseFolder : this.handleAccount}>
            <div className={(this.props.rep.name == 'Newly Purchased Items' ? 'newly-purchased-child' : ' ') + ' menu-link-sub-child '} onClick={this.props.rep.name == 'Newly Purchased Items' && this.purchaseFolder}>
              <span className="link-text">
                  {this.props.rep.name}
              </span>
            </div>
          </NavLink>
          { this.props.rep.name == 'Newly Purchased Items'
            && (
                <div className={'sub-links ' + (this.state.expanded ? 'show' : 'hide')}>
                  {this.props.dashboardNewlyPurchased && this.props.dashboardNewlyPurchased.map((rep, i)=> (
                      <SubMenuChildPurchaseHistory rep={rep} />
                    ))}
                </div>
               )}
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
    return {
      store: state,
      selectedFolder: state.spaceMgmnt.selectedFolder,
      currentUser: state.user.currentUser,
      dashboardNewlyPurchased: state.spaceMgmnt.dashboardNewlyPurchased,
      dashboardValues: state.iframe.dashboardValues
    };
  }
  
export default connect(mapStateToProps)(SubMenuChildLinkFolders);
