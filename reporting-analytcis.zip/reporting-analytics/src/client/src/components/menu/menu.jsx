import React, { Component } from "react";
import autoBind from "react-autobind";
import { NavLink, Link } from "react-router-dom";
import { connect } from "react-redux";
import { withRouter } from 'react-router';
import { SWITCH_ROUTE } from '../../redux/constants/iframe-constants'
// Components
import SubMenuLink from "./sub-menu-link";
import SubMenuLinkReports from "./sub-menu-link-reports";
import { SWITCH_ACCOUNT_REPORTS } from '../../constants/space-mgmnt-constants';
import UserManagementContainer from '../../containers/user-mgmnt-container';
import * as UserMgmntActions from '../../redux/actions/user-mgmnt-actions';
import * as CustomGroupsActions from '../../redux/actions/custom-filters-actions';
import * as UserUIActions from '../../redux/actions/user-actions';
import * as CustomGroupDasboardActions from '../../redux/actions/custom-group-actions';
import { displayDialog } from '../../redux/actions/custom-filters-actions'
import LookerService from "../../services/looker-service";
import TeamService from "../../redux/services/team-service";
import * as UserActions from '../../redux/actions/looker-actions';
import * as CustomDashboardFilterActions from '../../redux/actions/custom-filter-criteria-actions';
import Modal from 'react-modal';
import DefaultPanel from "../../components/default-panel";
import ReactTooltip from "react-tooltip";

import * as Constants from '../../constants/space-mgmnt-constants';
import Dialog from '../modal/Dialog';
import SolutionsPanel from "../solutions/solutionsPanel";
import cn from "classnames";

class Menu extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);

    this.state = {
      expand: this.props.links.defaultExpand,
      selectedFolder: false,
      expanded: false,
      loadSolutionPanel: false
    };
  }

  componentDidMount() {
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
  }

  /**
   * We want to clear out the iFrame URL whenever we switch routes.
   */
  switchRoute = (event, links, id) => {
    if (links.modal) {
      if (event) event.preventDefault();
      this.openDialog(links);
      return;
    }
    let solutionsPanel = document.querySelector("#solutionsPanel");
    if (solutionsPanel) {
      solutionsPanel.style.display = "none";
    }
    this.props.dispatch(UserUIActions.dialogClose());
    if (this.props.links.menuTitle === "My Reports" || this.props.links.menuTitle === "Team Reports") {
      this.props.dispatch({ type: SWITCH_ACCOUNT_REPORTS, payload: this.state.selectedFolder });
    }
    this.props.dispatch({ type: SWITCH_ROUTE, payload: { iframeUrl: "" } });
  }

  isActiveNavLink = (match, location) => {
    if (!match) {
      return false;
    }
  }

  getSubMenuContent = (links) => {
    const userMgntStyles = {
      content: {
        top: '45%',
        left: '53%',
        right: 'auto',
        width: '70%',
        bottom: '-320px',
        background: 'none',
        marginRight: '-50%',
        border: '0',
        overflow: 'auto',
        transform: 'translate(-50%, -50%)'
      },
      overlay: {
        position: "fixed",
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
        width: "100%",
        height: "100%",
        backgroundColor: "rgba(0,0,0,0.1)",
        zIndex: 1050
      }
    };
    if (links.menuTitle) {
      return (
        <div className="menu-link">
          <NavLink exact className="link-text" to={links.path} onClick={this.switchRoute} isActive={this.isActiveNavLink}>
            <div className="parent-link " onClick={this.openMenu(links.menuTitle)}>
              {links.iconClass != null && (
                <i className={links.iconClass} />
              )}
              <span onClick={links.menuTitle === 'Custom Groups' ? this.launchCustomGroupDialog : ''} className="link-text">
                {links.menuTitle === 'Custom Groups'
                  ? (
                    <div>
                      <div className="custom-groups">Custom Groups</div>
                      <span className="link-icon fas fa-chevron-right link-arrow-right" />
                    </div>
                    )
                  : links.menuTitle}
              </span>
            </div>
          </NavLink>
          <Modal
            isOpen={this.props.showUserMgmntModal}
            onRequestClose={this.props.showUserMgmntModal}
            ariaHideApp={false}
            shouldCloseOnOverlayClick={true}
            style={userMgntStyles}
          >
            <UserManagementContainer close={this.closeUserMgmtModal} modalOpen={this.props.showUserMgmntModal} />
          </Modal>
        </div>
      )
    } else {
      return null;
    }
  }

  hasSubMenu() {
    const { location: {pathname} } = this.props;
    if (this.props.links.header === 'Explore' && pathname.indexOf("/explore") !== -1) {
      return true;
    }
    if (this.props.links.header === 'Administration' && pathname.indexOf("/admin") !== -1) {
      return true;
    }
    return false;
  } 

  render() {

    const { links } = this.props;
    const { expand } = this.state;
    const hasSubLinks = links && links.routes && links.routes.length;
    if (this.props.links.header === 'Explore' || this.props.links.header === 'Administration') {
      return links.menu === 'sidebar' ? (
        <div className={'menu-link ' + (expand ? 'sub-open' : 'sub-closed')} data-tip={this.props.isOpen? "" : links.menuTitle}>
          <NavLink
            exact
            to={links.path}
            onClick={hasSubLinks && this.openSubMenu}
            isActive={this.isActiveNavLink}
            className={cn({
              "menu-expand-active": this.hasSubMenu()
            })}
          >
            <div className="parent-link ">
              {links.icon}
              <span className="link-text">
              {' '}
              {links.menuTitle}
              </span>
              <span
                className={
                  hasSubLinks ? 'link-icon fas fa-angle-right show' : ' hide'
                }
                onClick={hasSubLinks && this.openSubMenu}
              />
            </div>
          </NavLink>
          {links.hasOwnProperty('type')
            && (
                <div className={'sub-links tree ' + (expand ? 'show' : 'hide')}>
                  {this.props.selectedFolder && this.props.selectedFolder.children != null && this.props.selectedFolder.children.map((rep, i) => {
                    return <SubMenuLinkReports rep={rep} key={i} />
                  })}
                </div>
                )
          }
          <div className={'sub-links ' + (expand ? 'show' : 'hide')}>
            {hasSubLinks && links.routes.map((link, key) => (
              <SubMenuLink route={link} key={key} />
            ))}
          </div>
          {this.props.links.header === 'Explore'
            && <li role="separator" className="divider" />}
          <ReactTooltip place="right" type="dark" effect="float" disable={this.props.isOpen} />
        </div>
      ) : (
          this.getSubMenuContent(links)
        );

    } else if (this.props.links.header === 'Solutions') {
      return (
        <>
          <li>
            <NavLink to=""
            isActive={() => false}
            className={cn({
              "active": this.state.loadSolutionPanel
            })}
             id="solutionsPanelAnchor" style={{ cursor: 'pointer' }} onClick={(e) => {e.preventDefault();this.openSolutionsPanel();}} data-tip={this.props.isOpen ? "" : "Solutions (Canned Reports)"}>
              {/* <span className="fas fa-lightbulb" style={{ margin: '0 6px' }} /> */}
              {links.icon}
              <span className="link-text">Solutions (Canned Reports)</span>
              <span className="link-icon fas fa-angle-right" />
              <ReactTooltip place="right" type="dark" effect="float" disable={this.props.isOpen} />
            </NavLink>
          </li>
          <SolutionsPanel load={this.state.loadSolutionPanel} />
        </>
      );
    } else {
      const showArrow = links && links.showArrow === true;
      const id = links.menuTitle.replace(' ', '_').toLowerCase();
      const CustomLink = links.target ? ({children, ...props}) => <a target={links.target} {...props}>{children}</a>  : Link;
      return (
        <React.Fragment>
          <li data-tip={this.props.isOpen ? "" : links.menuTitle} >
            <CustomLink
              href={links.path}
              to={{
                pathname: links.path
              }}
              onClick={(event) => this.switchRoute(event, links, id)}
              isActive={() => false}
            className={cn({
              "active": links.modal
            })}
            >
              {links.icon}
              <span className="link-text">
              {' '}
              {links.menuTitle}
              </span>
              <span
                className={
                  showArrow ? 'link-icon fas fa-angle-right' : ' hide'
                }
              />
            </CustomLink>
            <ReactTooltip place="right" type="dark" effect="float" disable={this.props.isOpen} />
          </li>
          {links.separator
            && <li role="separator" className="divider" />}
        </React.Fragment>
      );
    }
  }


  openDialog(link) {
    const dialog = {
      title: link.menuTitle,
      content: link.component
    }
    this.props.dispatch(UserUIActions.dialogOpen(dialog));
  }

  closeDialog(event, link) {
    if (event) event.preventDefault();
    this.props.dispatch(UserUIActions.dialogClose());
  }


  openSubMenu = event => {
    event.preventDefault();

    //Conditionally 'purge' cached 'my reports' content if the user is... selecting the top level link.
    if (this.props.links.menuTitle && this.state.expand) {
      this.props.dispatch({ type: Constants.CLEAR_SPACES_CACHE });
    }

    this.setState({
      expand: !this.state.expand
    });
  };

  launchCustomGroupDialog = () => {
    this.props.dispatch(CustomDashboardFilterActions.customGroupDialog());
    this.props.dispatch(CustomGroupDasboardActions.panelActive());
    this.props.dispatch(CustomDashboardFilterActions.customGroupAction());
    this.setState({
      expanded: !this.state.expanded
    });
  }

  openMenu = (menuTitle) => {
    switch (menuTitle) {
      case "User Management":
        return this.showUserMgmtModal;
      case "Custom Groups":
        return this.showCustomGroupsModal;
      default:
        return "";
    }
  };

  getGroupContent = () => {
    this.props.dispatch(UserActions.listGroups());
  }

  getUserRoleContent = () => {
    this.props.dispatch(UserActions.listRoles());
  }

  getUserContent = () => {
    this.props.dispatch(UserActions.getUsersByGroup(5));
  }

  getUserGroupContent = () => {
    this.props.dispatch(UserActions.getUsers());
  }

  showUserMgmtModal(event) {
    event.preventDefault();
    this.getUserGroupContent();
    this.getUserRoleContent();
    this.getUserContent();
    this.getGroupContent();
    this.setState({ displayMenu: !this.state.displayMenu });
    this.props.dispatch(UserMgmntActions.showModal());
  }

  closeUserMgmtModal(event) {
    event.preventDefault();
    this.props.dispatch(UserMgmntActions.closeModal());
  }

  showCustomGroupsModal(event) {
    LookerService.loadFilters()
      .then((filters) => {
        let groups = filters.data;
        if (groups && groups.length) {
          groups.forEach(group => {
            this.getTeamsFromIds(group);
          });
        }
        this.props.dispatch(CustomGroupsActions.fetchFiltersSuccess(filters.data));
        this.props.dispatch(displayDialog());
      });
    this.getVisibleDimensionOptions();
  }

  getVisibleDimensionOptions = () => {
    LookerService.getVisibleDimensions()
      .then((visibleDimensions) => {
        this.props.dispatch(CustomGroupsActions.setVisibleDimensionOptions(visibleDimensions.data));
      });
  }

  getTeamsFromIds(filter) {
    let sharedTeams = filter.sharedTeams;
    if (!sharedTeams || sharedTeams.length === 0) {
      return;
    }

    TeamService.getTeamsForIds(sharedTeams)
      .then(response => {
        filter.teamNames = response.data.map(team => team.name);
      });
  }

  openSolutionsPanel() {
    let solutionsPanel = document.getElementById("solutionsPanel");

    if (solutionsPanel) {
      if (solutionsPanel.style.display === "grid") {
        this.setState({ loadSolutionPanel: false });
        solutionsPanel.style.display = "none";
      } else {
        this.setState({ loadSolutionPanel: true });
        this.props.dispatch(UserUIActions.dialogClose());
        solutionsPanel.style.display = "grid";
        document.title = "Solutions (Canned Reports)";
      }
    }
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    store: state,
    currentUser: state.user.currentUser,
    userSpace: state.spaceMgmnt.userSpace,
    selectedFolder: state.spaceMgmnt.selectedFolder,
    showUserMgmntModal: state.userMgmnt.showModal,
    showCustomGroupsModal: state.customFilters.customFiltersDisplayDialogModal,
    userResults: state.lookerAdmin.userResults
  };
}

export default connect(mapStateToProps)(withRouter(Menu));
