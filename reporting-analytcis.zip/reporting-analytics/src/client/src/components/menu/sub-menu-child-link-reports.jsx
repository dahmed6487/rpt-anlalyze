import React, { Component } from "react";
import autoBind from "react-autobind";
import { NavLink } from "react-router-dom";
import {connect} from 'react-redux';

class SubMenuChildLinkReports extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);
    this.actions = props.actions;
    this.state = {
      iframeUrl: ""
    };
  }

  handleAccount = (event) => {
    const SWITCH_ACCOUNT = 'SWITCH_ACCOUNT';
    this.props.dispatch({type: SWITCH_ACCOUNT, payload: this.state.iframeUrl});
  }

  render() {
    const path = this.props.repchild.type === 'ITEM_TYPE_REPORT' ? `/displayReport/${this.props.repchild.id}` : `/displayDashboard/${this.props.repchild.id}`;
    return (
      <NavLink exact className="link-text" to={path} onClick={this.handleAccount}>
         <div className="menu-link-sub-child">
            <span className="link-text">{this.props.repchild.name}</span>
        </div>
      </NavLink>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
    return {
      store: state,
      selectedFolder: state.spaceMgmnt.selectedFolder
    };
  }
  
export default connect(mapStateToProps)(SubMenuChildLinkReports);
