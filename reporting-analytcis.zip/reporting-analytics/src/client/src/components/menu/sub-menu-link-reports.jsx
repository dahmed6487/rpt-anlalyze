import React, { Component } from "react";
import autoBind from "react-autobind";
import { NavLink } from "react-router-dom";
import SubMenuChildLink from "./sub-menu-child-link";
import SubMenuChildLinkReports from "./sub-menu-child-link-reports";
import { connect } from "react-redux";

class SubMenuLinkReports extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);
    this.state = {
      childExpanded: false,
      iframeUrl: ""
    };
  }

  render() {
    const { childExpanded } = this.state;
    const path = this.props.rep.type === "ITEM_TYPE_REPORT" ? `/displayReport/${this.props.rep.id}` : `/displayDashboard/${this.props.rep.id}` ;
    return (
      <div onClick={this.handleAccount} className={'menu-link-sub  ' + (childExpanded ? 'sub-open' : 'sub-closed')}>
        <NavLink
          exact
          to={path}
          className="link-text"
          onClick={this.props.rep.type === 'ITEM_TYPE_FOLDER' && this.openSubMenuChild}
        >
          <div onClick={this.props.rep.type === 'ITEM_TYPE_FOLDER' && this.openSubMenuChild} className="parent-link">
            <span className="link-text"> {this.props.rep.name}</span>
            <span
              className={this.props.rep.type === 'ITEM_TYPE_FOLDER' && ('fa fa-caret-right' + " link-icon-child ")}

            />
          </div>
        </NavLink>
        <div className={'sub-links ' + (childExpanded ? 'show' : 'hide')}>
          { this.props.rep.children.length > 0
            && this.props.rep.children.map((repchild, i)=> (
              <SubMenuChildLinkReports repchild={repchild} />
          ))}
        </div>
      </div>
    )
  }

  openSubMenuChild = event => {
    this.props.rep.type === "ITEM_TYPE_FOLDER" && event.preventDefault();
    this.setState({
      childExpanded: !this.state.childExpanded
    });
  };

  handleAccount = (event) => {
    const SWITCH_ACCOUNT = 'SWITCH_ACCOUNT';
    this.props.dispatch({type: SWITCH_ACCOUNT, payload: this.state.iframeUrl});
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    store: state,
    selectedFolder: state.spaceMgmnt.selectedFolder
  };
}

export default connect(mapStateToProps)(SubMenuLinkReports);

