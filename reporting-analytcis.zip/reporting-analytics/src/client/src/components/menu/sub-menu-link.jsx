import React, {Component} from "react";
import autoBind from "react-autobind";
import {NavLink} from "react-router-dom";
import SubMenuChildLink from "./sub-menu-child-link";
import SubMenuChildLinkFolders from "./sub-menu-child-link-folders";
import {connect} from "react-redux";
import * as ReportActions from '../../redux/actions/space-mgmnt-actions';
import * as UserUIActions from '../../redux/actions/user-actions';

class SubMenuLink extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);
    this.state = {
      childExpanded: this.props.route.defaultExpand,
      iframeUrl: ""
    };
  }

  showReport(event) {
     const SWITCH_ACCOUNT = 'SWITCH_ACCOUNT';
     let solutionsPanel = document.querySelector("#solutionsPanel");
     if(solutionsPanel){
         solutionsPanel.style.display = "none";
     }
     this.props.dispatch(UserUIActions.dialogClose());
     this.props.dispatch({type: SWITCH_ACCOUNT, payload: this.state.iframeUrl});
  }

  getPurchaseHistoryContent = () => {
      this.props.dispatch(ReportActions.getDashboardsForFolder( this.props.dashboardValues.purchaseHistory));
  }

  getContractsContent = () => {
      this.props.dispatch(ReportActions.getDashboardsForFolder(this.props.dashboardValues.contracts));
  }

  getControlledSubstancesContent = () => {
    this.props.dispatch(ReportActions.getDashboardsForFolder(this.props.dashboardValues.controlledSubstances));
  }

  getOmitsContent = () => {
    this.props.dispatch(ReportActions.getDashboardsForFolder(this.props.dashboardValues.omits));
  }

  getVaContent = () => {
    this.props.dispatch(ReportActions.getDashboardsForFolder(this.props.dashboardValues.va));
  }

  getReferenceContent = () => {
    this.props.dispatch(ReportActions.getDashboardsForFolder(this.props.dashboardValues.reference));
  }

  getUsageDetailContent = () => {
    this.props.dispatch(ReportActions.getDashboardsForFolder(this.props.dashboardValues.usageDetail));
  }

  getNewlyPurchaseItemstContent = () => {
    this.props.dispatch(ReportActions.getDashboardsForFolder( this.props.dashboardValues.newlyPurchasedItems));
  }

  render() {
    const { route } = this.props;
    const { childExpanded } = this.state;
    const hasSubLinks = route && route.routes && route.routes.length > 0;
    return route.menu === 'sidebar' ? (
      <div
        className={
          'menu-link-sub  ' + (childExpanded ? 'sub-open' : 'sub-closed')
        }
      >
        <NavLink
          exact
          to={route.path}
          className="link-text"
          onClick={this.openSubMenuChild}
        >
          <div className="parent-link">
            {route.icon != null && (
              <img
                src={route.icon}
                alt={route.menuTitle}
                className="link-image"
              />
            )}
            <span
              className={
                (route.iconClass != null ? route.iconClass : ' ')
                + ' link-icon-child '
              }
              onClick={this.openSubMenuChild}
            />
            <span className="link-text">{route.menuTitle}</span>
          </div>
        </NavLink>
        { route.type === 'purchaseHistory'
          && (
              <div className={'sub-links ' + (childExpanded ? 'show' : 'hide')}>
                  { this.props.dashboardPurchaseHistory
                    && this.props.dashboardPurchaseHistory.slice().sort((a, b) => { return a.name > b.name ? 1 : -1 }).map((rep, i)=> (
                    <SubMenuChildLinkFolders rep={rep} />
                  ))}

              </div>
              )
        }
        { route.type === 'contracts'
          && (
              <div className={'sub-links ' + (childExpanded ? 'show' : 'hide')}>
                  { this.props.dashboardContracts
                    && this.props.dashboardContracts.slice().sort((a, b) => { return a.name > b.name ? 1 : -1 }).map((rep, i)=> (
                    <SubMenuChildLinkFolders rep={rep} key={i} />
                  ))}

              </div>
             )}
        { route.type === 'controlledSubstances'
          && (
              <div className={'sub-links ' + (childExpanded ? 'show' : 'hide')}>
                  { this.props.dashboardControlledSubstances
                    && this.props.dashboardControlledSubstances.slice().sort((a, b) => { return a.name > b.name ? 1 : -1 }).map((rep, i)=> (
                    <SubMenuChildLinkFolders rep={rep} key={i} />
                  ))}

              </div>
             )}
        { route.type === 'omits'
          && (
               <div className={'sub-links ' + (childExpanded ? 'show' : 'hide')}>
                  { this.props.dashboardOmits
                    && this.props.dashboardOmits.slice().sort((a, b) => { return a.name > b.name ? 1 : -1 }).map((rep, i)=> (
                      <SubMenuChildLinkFolders rep={rep} />
                  ))}

                </div>
             )
        }
        { route.type === 'va'
          && (
              <div className={'sub-links ' + (childExpanded ? 'show' : 'hide')}>
                  { this.props.dashboardVa
                    && this.props.dashboardVa.slice().sort((a, b) => { return a.name > b.name ? 1 : -1 }).map((rep, i)=> (
                      <SubMenuChildLinkFolders rep={rep} key={i} />
                  ))}

              </div>
             )
        }
        { route.type === 'reference'
          && (
              <div className={'sub-links ' + (childExpanded ? 'show' : 'hide')}>
                  { this.props.dashboardReference
                    && this.props.dashboardReference.slice().sort((a, b) => { return a.name > b.name ? 1 : -1 }).map((rep, i)=> (
                    <SubMenuChildLinkFolders rep={rep} />
                  ))}

              </div>
             )}
         { route.type === 'UsageDetail'
          && (
              <div className={'sub-links ' + (childExpanded ? 'show' : 'hide')}>
                  { this.props.dashboardUsageDetail
                    && this.props.dashboardUsageDetail.slice().sort((a, b) => { return a.name > b.name ? 1 : -1 }).map((rep, i)=> (
                    <SubMenuChildLinkFolders rep={rep} />
                  ))}

              </div>
             )}
        <div className={'sub-links ' + (childExpanded ? 'show' : 'hide')}>
          {hasSubLinks
            && route.routes.map((link, key) => (
              <SubMenuChildLink route={link} key={key} />
            ))}
        </div>
      </div>
    ) : (
      <div className="menu-link-sub ">
        <NavLink exact className="link-text" to={route.path} onClick={this.showReport}>
            {route.icon}
            
            <span className="link-text">{route.menuTitle}</span>
        </NavLink>
      </div>
    );
  }

  openSubMenuChild = (event) => {
    event.preventDefault();
    if(!this.props.dashboardPurchaseHistory && this.props.route.type === 'purchaseHistory') {
      this.getPurchaseHistoryContent();
      this.getNewlyPurchaseItemstContent();
    }else if(!this.props.dashboardContracts && this.props.route.type === 'contracts') {
      this.getContractsContent();
    }else if(!this.props.dashboardControlledSubstances && this.props.route.type === 'controlledSubstances') {
      this.getControlledSubstancesContent();
    }else if(!this.props.dashboardOmits && this.props.route.type === 'omits') {
      this.getOmitsContent();
    }else if(!this.props.dashboardVa && this.props.route.type === 'va') {
      this.getVaContent();
    }else if(!this.props.dashboardReference && this.props.route.type === 'reference') {
      this.getReferenceContent();
    }else if(!this.props.dashboardUsageDetail && this.props.route.type === 'UsageDetail') {
      this.getUsageDetailContent();
    }
    this.setState({
      childExpanded: !this.state.childExpanded
    });
  };
}

const mapStateToProps = (state, ownProps) => {
  return {
    store: state,
    dashboardPurchaseHistory: state.spaceMgmnt.dashboardPurchaseHistory,
    dashboardContracts: state.spaceMgmnt.dashboardContracts,
    dashboardControlledSubstances: state.spaceMgmnt.dashboardControlledSubstances,
    dashboardOmits: state.spaceMgmnt.dashboardOmits,
    dashboardVa: state.spaceMgmnt.dashboardVa,
    dashboardReference: state.spaceMgmnt.dashboardReference,
    dashboardUsageDetail: state.spaceMgmnt.dashboardUsageDetail,
    currentUser: state.user.currentUser,
    dashboardValues: state.iframe.dashboardValues,
    dashboardNewlyPurchased: state.spaceMgmnt.dashboardNewlyPurchased,
    userView: state.lookerAdmin.userView
  };
}

export default connect(mapStateToProps)(SubMenuLink);
