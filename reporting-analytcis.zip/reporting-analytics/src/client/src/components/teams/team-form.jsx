import React, { Component } from 'react';
import autoBind from 'react-autobind';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Alert from '../alert/alert';
import { PauseAndRedirect } from '../user/user-form';

class TeamForm extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);

        this.state = {
            team: {},
            editedName: '',
            error: null,
            save: false
        }
    }

    componentDidMount() {
        this.setState({ team: this.props.team });
    }

    componentDidUpdate(prevProps) {
        if(this.props.team !== prevProps.team) {
            this.setState({ team: this.props.team });
        }
    }

    render() {
        const { team, error, save } = this.state;

        return (
            <div className="user-form">
                {error
                    && (
                    <Alert type={error.type}>
                        {error.text}
                    </Alert>
                    )}
                {save
                    && (
                    <Alert type="success">
                        Team
                        {' '}
                        {this.state.team.name}
                        {' '}
                        has been saved.
                    </Alert>
                    )}
                <div className="row">
                    <div className="col-md-6">
                        <div className="form-group">
                            <label htmlFor="teamName">Name</label>
                            <input
                                className="form-control"
                                type="text"
                                defaultValue={team.name || ''}
                                onChange={(event) => this.handleNameChange(event)}
                            />
                        </div>
                    </div>
                </div>

                <div id="eraSaveTeamModal" className="modal" style={{ height: 'fit-content' }} tabIndex="-1" role="dialog">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header no-icon">
                                <button type="button" onClick={() => this.closeSaveTeamModal()} className="close" data-dismiss="modal" aria-label="Close">
                                    <span className="fa fa-times" />
                                </button>
                                <h4 className="modal-title">Confirm Edit</h4>
                            </div>
                            <div className="modal-body">
                                <p>Are you sure you want to make the following edits?</p>
                                <p>
                                {team.name}
                                {' '}
                                &#8594;
                                {' '}
                                {this.state.editedName}
                                </p>
                            </div>
                            <div className="modal-footer">
                                <button type="button" onClick={() => this.closeSaveTeamModal()} className="btn btn-link btn-sm" data-dismiss="modal">Cancel</button>
                                <button type="button" onClick={() => this.confirmSaveTeam()} className="btn btn-primary btn-sm">Confirm</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="form-footer">
                    <div className="text-right">
                        <Link to="/admin/teams" className="btn btn-link">Cancel</Link>
                        <button onClick={() => this.onSave()} className="btn btn-primary">Save</button>
                    </div>
                </div>

            </div>
        );
    }

    handleNameChange(event) {
        this.setState({ editedName: event.target.value });
    }

    onSave() {
        let modal = document.getElementById('eraSaveTeamModal');
        if (modal) {
            modal.style.display = 'flex';
        }
    }

    saveTeam() {
        let editedTeam = this.state.team;
        editedTeam.name = this.state.editedName;
        axios.put('/api/teams/update', editedTeam)
            .then(() => {
                this.setState({
                    error: null,
                    save: true
                }, () => PauseAndRedirect('#/admin/teams'))
            }).catch((error) => {
            this.setState({
                error: { text: 'There was an error saving this customer, please try again', type: 'warning' },
                save: false
            });
        });
    }

    closeSaveTeamModal() {
        let modal = document.getElementById('eraSaveTeamModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    confirmSaveTeam() {
        this.saveTeam();
        this.closeSaveTeamModal();
    }
}

export default TeamForm;
