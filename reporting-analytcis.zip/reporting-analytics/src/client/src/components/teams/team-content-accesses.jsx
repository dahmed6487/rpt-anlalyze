import React, { Component } from 'react';
import autoBind from 'react-autobind';
import axios from 'axios';
import Alert from '../alert/alert';
import { Link } from 'react-router-dom';
import { connect } from "react-redux";


class TeamContentAccesses extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);

        this.state = {
            team: {},
            modules: [],
            disabledModules: [],
            contentAccesses: [],
            editedContentAccesses: [],
            error: null,
            save: false,
            loading: true,
            saving: false
        }
    }

    componentDidMount() {
        this.setState({
            team: this.props.team
        }, () => this.props.isInternal ? this.getModulesForInternalUser() : this.getModulesForExternalUser());
    }

    componentDidUpdate(prevProps) {
        if(this.props.team !== prevProps.team) {
            this.setState({ team: this.props.team });
        }
    }

    render() {
        const { error, save, loading,saving } = this.state;
        const teamName = this.props.team.name;
        const modules = this.generateModules();
        const contentAccessesDiff = this.generateContentAccessesDiff();

        return (
            <div>
                {error
                && (
                    <Alert type={error.type}>
                        {error.text}
                    </Alert>
                    )}
                {save
                && (
                <Alert type="success">
                    Team
                    {' '}
                    {teamName}
                    {' '}
                    has been saved.
                </Alert>
                    )}
                {saving
                && (
                <Alert type="info">
                    Saving, please wait...
                </Alert>
                    )}

                {loading
                    && <div>Loading...</div>}

                {!loading
                    && (
                    <div>
                        {modules}
                    </div>
                        )}

                <div
                    id="eraSaveTeamContentAccessesModal"
                    className="modal"
                    style={{ height: 'fit-content' }}
                     tabIndex="-1"
                    role="dialog"
                >
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header no-icon">
                                <button
                                        type="button"
                                        onClick={() => this.closeSaveTeamContentAccessesModal()}
                                        className="close"
                                        data-dismiss="modal"
                                        aria-label="Close"
                                >
                                    <span className="fa fa-times" />
                                </button>
                                <h4 className="modal-title">Confirm Edit</h4>
                            </div>
                            <div className="modal-body">
                                <p>Are you sure you want to make the following edits?</p>
                                {contentAccessesDiff}
                            </div>
                            <div className="modal-footer">
                                <button
                                        type="button"
                                        onClick={() => this.closeSaveTeamContentAccessesModal()}
                                        className="btn btn-link btn-sm"
                                        data-dismiss="modal"
                                >
                                Cancel
                                </button>
                                <button
                                        type="button"
                                        onClick={() => this.confirmSaveTeamContentAccesses()}
                                        className="btn btn-primary btn-sm"
                                >
                                Confirm
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="form-footer">
                    <div className="text-right">
                        <Link to="/admin/teams" className="btn btn-link">Cancel</Link>
                        <button type="button" onClick={() => this.onContentAccessesSave()} className="btn btn-primary">Save</button>
                    </div>
                </div>

            </div>
        )
    }

   async getModulesForInternalUser() {
      const moduleType = "canned report";
      const customerId = this.props.team.customerId;
      const[firstResponse, secondResponse] = await Promise.all([
        axios.get(`/api/module/get/customer/${customerId}`),
        axios.get(`/api/module/get?moduleType=${moduleType}`)
      ]);
      let moduleTitles = firstResponse.data.map(module => module.title);
      let disabledModules = (secondResponse.data.filter(x => !moduleTitles.includes(x.title)));
          this.setState({
              modules: secondResponse.data,
              disabledModules: disabledModules
          }, () => this.getContentAccesses());
    }

    getModulesForExternalUser() {
        const customerId = this.props.team.customerId;
        axios.get(`/api/module/get/customer/${customerId}`)
            .then((response) => {
                this.setState({
                    modules: response.data
                }, () => this.getContentAccesses());
            })
            .catch((error) => {
                this.setState({
                    error: { text: 'There was an error getting content accesses, please try again', type: 'warning' },
                    save: false,
                    saving: false
                });
            });
    }

    getContentAccesses() {
        const id = this.props.team.collaborationTeamId;
        axios.get(`/api/teams/get/content-accesses?id=${id}`)
            .then((response) => {
                this.setState({
                    contentAccesses: response.data,
                    loading: false
                }, () => this.validateModulesByContentAccesses());
            })
            .catch((error) => {
                this.setState({
                    error: {
                        text: 'There was an error getting this team\'s content accesses, please try again',
                        type: 'warning'
                    },
                    save: false,
                    loading: false,
                    saving: false
                });
            });
    }

    validateModulesByContentAccesses() {
        for (const contentAccess of this.state.contentAccesses) {
            let module = document.getElementById(`era-${contentAccess}`);
            if (module) {
                module.checked = true;
            }
        }
        for (const disabledModule of this.state.disabledModules) {
            let module = document.getElementById(`era-${disabledModule.title}`);
            if (module) {
                module.disabled = true;
            }
        }
    }

    generateModules() {
        let modules = [];

        for (const module of this.state.modules) {
            modules.push(
                <div className="checkbox">
                    <label>
                        <input id={`era-${module.title}`} type="checkbox" value={module.title} />
                        {module.title}
                    </label>
                </div>
            );
        }

        return modules;
    }

    generateContentAccessesDiff() {
        if(this.state.contentAccesses === '')
            return;
        const { contentAccesses, editedContentAccesses } = this.state;
        const removedContentAccesses = contentAccesses.filter(module => !editedContentAccesses.includes(module));
        const addedContentAccesses = editedContentAccesses.filter(module => !contentAccesses.includes(module));

        const removedContentAccessesString = removedContentAccesses.length === 1 ? removedContentAccesses[0] : [removedContentAccesses.slice(0, removedContentAccesses.length - 1).join(', '), removedContentAccesses[removedContentAccesses.length - 1]].join(', ');
        const addedContentAccessesString = addedContentAccesses && (addedContentAccesses.length === 1 ? addedContentAccesses[0] : [addedContentAccesses.slice(0, addedContentAccesses.length - 1).join(', '), addedContentAccesses[addedContentAccesses.length - 1]].join(', '));

        return (
            <div>
                {removedContentAccesses.length > 0 && (
                    <div>
                        <span style={{ color: 'black' }}>Removed: </span>
                        {removedContentAccessesString}
                    </div>
                )}
                {addedContentAccesses.length > 0 && (
                    <div>
                        <span style={{ color: 'black' }}>Added: </span>
                        {addedContentAccessesString}
                    </div>
                )}
            </div>
        )
    }

    onContentAccessesSave() {
        this.setState({ save: false });
        this.gatherEditedContentAccessesState();
            let modal = document.getElementById('eraSaveTeamContentAccessesModal');
            if (modal) {
                modal.style.display = 'flex';
            }
    }

    gatherEditedContentAccessesState() {
        let editedContentAccesses = [];

        for (const module of this.state.modules) {
            const inputElement = document.getElementById(`era-${module.title}`);
            if (inputElement.checked) {
                editedContentAccesses.push(module.title);
            }
        }

        this.setState({ editedContentAccesses: editedContentAccesses });
    }

    getContentAccessesRequestBody() {
        let requestBody = [];

        for (const module of this.state.modules) {
            requestBody.push({
                module: module.title,
                accessible: this.state.editedContentAccesses.includes(module.title)
            });
        }

        return requestBody;
    }

    closeSaveTeamContentAccessesModal() {
        const modal = document.getElementById('eraSaveTeamContentAccessesModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    confirmSaveTeamContentAccesses() {
        this.saveTeamContentAccesses();
        this.closeSaveTeamContentAccessesModal();
    }

    saveTeamContentAccesses() {
        const id = this.props.team.collaborationTeamId;
        const contentAccessesRequestBody = this.getContentAccessesRequestBody();
            this.setState({
                saving: true,
                save: false,
                error: null
            });
            axios.put(`/api/teams/update/content-accesses?id=${id}`, contentAccessesRequestBody)
                .then((response) => {
                    if (response.status === 206) {
                        this.setState({
                            error: {
                                text: 'Content access updated is incomplete.Please enable Customer level content access for ' + JSON.stringify(response.data) + ' folders.',
                                type: 'warning'
                            },
                            save: false,
                            saving: false
                        }, () => this.props.isInternal ? this.getModulesForInternalUser() :  this.getModulesForExternalUser());
                    } else {
                        this.setState({
                            error: null,
                            save: true,
                            saving: false
                        }, () => this.props.isInternal ? this.getModulesForInternalUser() :  this.getModulesForExternalUser());
                    }
                })
                .catch((error) => {
                    this.setState({
                        error: {
                            text: error.response.data + ', this might be because you are trying to add access that ' +
                                localStorage.getItem('userAccount') + ' does not have access to',
                            type: 'warning'
                        },
                        save: false,
                        saving: false
                    });
                    this.uncheckFailedItems(error.response.data)
                });
    }

    uncheckFailedItems(errorResponse) {
        for (const module of this.state.modules) {
            if (errorResponse.includes(module.title)) {
                document.getElementById('era-' + module.title).checked = false;
            }
        }
    }
}
const mapStateToProps = (state, ownProps) => {
    return {
        isInternal: state.accountSettings.userType
    }
}
export default connect(mapStateToProps)(TeamContentAccesses);
