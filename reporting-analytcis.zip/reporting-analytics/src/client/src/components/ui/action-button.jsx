import React, { Component } from 'react';
import autoBind from 'react-autobind';
import PropTypes from 'prop-types';

export default class ActionButton extends Component{
    constructor (props) {
        super(props);
        autoBind(this);
        this.actions = props.actions;
    }

    static propTypes = {
        actions: PropTypes.array,
        ui: PropTypes.object,
        button: PropTypes.object
    }

    render(){
        const ui = this.props.ui || {};
        const button = this.props.button || {};
        const classes = this.props.button.classes || 'btn btn-action btn-sm';
        return (
          <button type={button.type || 'submit'} className={classes} disabled={button.disabled} onClick={button.handle}>
              {ui.loading && <span className="glyphicon glyphicon-refresh glyphicon-refresh-animate" />}
              {button.icon && <span className={button.icon} />}
              {ui.loading ? ' ' + button.loadingLabel : button.label }
            </button>
        );
    }

}
