import React from 'react';

function Spinner(){
    return (
      <div className="lds-spinner-container">
          <div className="lds-spinner">
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
              <div />
            </div>
        </div>
    );
}

export default Spinner;
