import React, { Component } from 'react';
import autoBind from 'react-autobind';

export default class DefaultPanel extends Component {
  constructor(props, context) {

    super(props, context);
    autoBind(this);

  }

  render() {
    const { panelActive = false, panelTitle = '', children } = this.props;
    return (
      <div>
        <div className={'sub-links ' + (panelActive ? 'show' : 'hide')}>
          <div className="panel panel-default custom-panel modal-panel ">

            <div className="panel-heading"><h4>{panelTitle}</h4></div>

            {children}

          </div>
        </div>
      </div>
    );
  }
}
