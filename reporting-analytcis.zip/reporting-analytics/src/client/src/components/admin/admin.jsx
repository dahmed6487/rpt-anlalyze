import React, { Component } from "react";
import autoBind from "react-autobind";
import { connect } from 'react-redux';
import * as AdminActions from '../../redux/actions/account-settings-actions';
import axios from "axios";

class Admin extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);
    }

    accountSettings = () => {
        this.props.dispatch(AdminActions.editAccount());
        this.props.dispatch(AdminActions.adminHandler());
    };

    logout() {
        this.props.dispatch(AdminActions.adminHandler());
        localStorage.removeItem('_windowLocation');
        localStorage.removeItem('_session_expired_windowLocation');
        localStorage.removeItem('userAccount');
        localStorage.removeItem('finalUserAttribute');
        localStorage.removeItem('setViewAppliedDimensions');
        localStorage.removeItem('filtersUrl');
        localStorage.removeItem('dashboardNext');
        document.cookie = "pagerefreshedcookie=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";

        axios.get('/api/signout')
            .then(response => {
                window.location.href = response.data;
            })
    };

    logoutSudo() {
        this.props.dispatch(AdminActions.adminHandler());
        localStorage.removeItem('_windowLocation');
        localStorage.removeItem('_session_expired_windowLocation');
        localStorage.removeItem('userAccount');
        localStorage.removeItem('finalUserAttribute');
        localStorage.removeItem('setViewAppliedDimensions');
        localStorage.removeItem('filtersUrl');
        document.cookie = "pagerefreshedcookie=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";

        axios.get('/api/sudo/logout')
            .then(response => {
                if(response.data==='success'){
                    localStorage.removeItem('userAccount');
                    localStorage.removeItem('finalUserAttribute');
                    localStorage.removeItem('setViewAppliedDimensions');
                    window.location.reload();
                    window.location = "/"
                }
            })
    };

    render() {
        return (
            <ul className={"era-dropdown-menu"}>
                {this.props.originalUserSudoFlag===true ? <li><a href={'#'} className="admin-user-logout" title={' Log out of ' + this.props.userName} onClick={() => this.logout()}>Log Out</a></li>
                :<li><a href={'#'} title={' Log out of ' + this.props.userName} onClick={() => this.logoutSudo()}>Log Out of {this.props.userName}</a><br/>
                        <a href={'#'} title={' Log out from both ' + this.props.userName+' & '+this.props.fullName} onClick={() => this.logout()}>Log Out</a></li>
                }
            </ul>
        );
    }
}

const mapStateToProps = (state, props) => {
    return {
        store: state,
        currentUserName: state.user.currentUserName,
        editAccount: state.accountSettings.editAccount,
        expanded: state.accountSettings.expanded,
        userName: state.accountSettings.userName,
        originalUserSudoFlag: state.accountSettings.originalUserSudoFlag,
        fullName: state.accountSettings.fullName,
    }
};

export default connect(mapStateToProps)(Admin);
