import React, { Component } from "react";
import { connect } from "react-redux";


class UserProfile extends Component{

    constructor(props) {
        super(props)
        const { dispatch } = props;
        this.actions = props.actions;
    }

    componentDidMount = () => {
    }
   
    render(){
        return (
            <div className="panel user-mgmnt-panel">
                <div>
                    <span className="profile-picture">PROFILE PICTURE</span>
                    <div className="admin-user profile "><span className="admin-user-text">PG</span></div>
                    &nbsp; &nbsp;
                    <div className="upload-profile">
                        <a className="admin-details user-text-id">Upload New Picture</a>
                        &nbsp; &nbsp;
                        <a className="admin-details user-text-id">Remove Picture</a>
                    </div>
                    <div className="topActionItemsElement profile-admin col-lg-1">
                        <button type="button" className="btn btn-default add-button admin-btn">
                            <span className="add-user-text disable-text admin-txt">Admin</span>
                        </button>
                        <button type="button" className="btn btn-default add-button user-btn" >
                            <span className="add-user-text disable-text user-txt">User</span>
                        </button>
                    </div>
                </div>
                <div className="userid-profile">
                    <div className="container reportListSortPanel editUser">
                        <div className="user-id-text dept-txt">
                            <span className="user-text-id">ID/USERNAME</span>
                            <input type="text" className="form-control search-input user-name-search user-edit-search" placeholder="VVandusictson" />
                            &nbsp;&nbsp;
                        </div>
                        <div className="first-last-name">
                            <div className="first-name">
                                <span className="first-name-id user-text-id">FIRST NAME</span>
                                <input type="text" className="form-control search-input first-name-text" placeholder="Valentina" />
                                &nbsp;&nbsp;
                            </div>
                            <div className="last-name">
                                <span className="last-name-id user-text-id">LAST NAME</span>
                                <input type="text" className="form-control search-input lastname-text" placeholder="Van Dusictson" />
                                &nbsp;&nbsp;
                            </div>
                        </div>
                        <div className="user-email-text dept-txt">
                            <span className="email-id user-text-id">DEPARTMENT OR TEAM</span>
                            <input type="text" className="form-control search-input user-name-search user-edit-search" placeholder="Analytics and Reporting" />
                            &nbsp;&nbsp;
                        </div>
                        <div className="first-last-name">
                            <div className="first-name">
                                <span className="first-name-id user-text-id">ORGANIZATION</span>
                                <input type="text" className="form-control search-input first-name-text" placeholder="Valentina" />
                                &nbsp;&nbsp;
                            </div>
                            <div className="last-name">
                                <span className="last-name-id user-text-id">LOCATION</span>
                                <input type="text" className="form-control search-input lastname-text" placeholder="Van Dusictson" />
                                &nbsp;&nbsp;
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
};

const mapStateToProps = (state, ownProps) => {
    return {
        currentUserName: state.user.currentUserName
    };
}

export default connect(mapStateToProps)(UserProfile);