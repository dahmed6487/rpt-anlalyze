import React, { Component } from "react";
import { connect } from "react-redux";
import * as AdminActions from '../../redux/actions/account-settings-actions';
import UserProfile from './user-profile';
import UserAccount from './user-account';

import UserPermissionContainer from '../../containers/user-permsn-container';
import UserRolesContainer from '../../containers/user-roles-container';


class AccountSettings extends Component{

    constructor(props) {
        super(props)
        const { dispatch } = props;
        this.actions = props.actions;
        this.state = {
            userProfile: true
          };
    }

    componentDidMount = () => {
    }

    closeAdminModal = (event) => {
        this.props.dispatch(AdminActions.closeAdminModal());
    }

    userProfile = (event) => {
        event.preventDefault();
        this.setState({
            userProfile: true
        })
    }

    userAccount = (event) => {
        event.preventDefault();
        this.setState({
            userProfile: false
        })
    }  

    render(){
        let user_profile = this.state.userProfile ? "profile-groups" : "";
        let user_account = !this.state.userProfile ? "account-groups" : "accounts";
        let edit_divider = this.state.userProfile ? "user-profile-divider" : "user-account-divider";
        return (
            <React.Fragment>
                <div className="titlePanel container user-mgmnt-title edit-mgmnt-title">
                    <div className="userNameElement col-lg-11 edit-user-header">
                        <div className="edit-user-roles">
                            <span className={user_profile} onClick= {this.userProfile} > Profile</span>
                            {this.state.userProfile ? <hr className="edit-roles-divider profile-divider"></hr> : ""}
                        </div>
                        <div className="edit-user-permissions">
                        <span className={user_account} onClick= {this.userAccount} > Account</span>
                        {!this.state.userProfile ? <hr className="edit-permissions-divider account-divider"></hr> : ""}
                        </div>
                    </div>
                </div>
                <hr className={edit_divider} />
                {this.state.userProfile ?
                <UserProfile/>
                :
                <UserAccount/>
                }
            </React.Fragment>

        );
    }
};

const mapStateToProps = (state, ownProps) => {
    return {
        currentUserName: state.user.currentUserName,
        editAccount: state.accountSettings.editAccount
    };
}

export default connect(mapStateToProps)(AccountSettings);