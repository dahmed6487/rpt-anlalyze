import React, { Component } from "react";
import { connect } from "react-redux";


class UserAccount extends Component{

    constructor(props) {
        super(props)
        const { dispatch } = props;
        this.actions = props.actions;
    }

    componentDidMount = () => {
    }
   
    render(){
        return (
            <div className="panel user-mgmnt-panel">
                <div className="userid-account">
                    <div className="container reportListSortPanel editUser">
                        <div className="user-id-text account-txt">
                            <div>
                                <span className="user-text-id">EMAIL</span>
                                <input type="text" className="form-control search-input user-name-search user-edit-search" placeholder="Penellope.LasVaranosque@companyemailaddress.io" />
                                &nbsp;&nbsp;
                            </div>
                            <a className="admin-details update-email user-text-id">Update Email</a>
                        </div>
                        <div className="pwd-text account-txt">
                            <div>
                                <span className="user-text-id">PASSWORD</span>
                                <input type="text" className="form-control search-input user-name-search user-edit-search" placeholder="********" />
                                &nbsp;&nbsp;
                                <a className="admin-details update-email update-pwd user-text-id">Update Password</a>
                            </div>
                        </div>
                        <div className="pwd-text account-txt">
                            <div className="security">
                                <span className="user-text-id">SECURITY</span>
                            </div>
                            <div className="security security-txt">
                                <span className="user-text-id">Log out of all sessions except the one in your current browser.</span>
                            </div>
                            <a className="admin-details update-email logout user-text-id">Log Out of Other Sessions</a>
                        </div>
                        <div className="pwd-text time-zone-txt">
                            <span className="user-text-id">TIME ZONE</span>
                            <input type="text" className="form-control search-input user-name-search user-edit-search" placeholder="US-Central" />
                            &nbsp;&nbsp;
                        </div>
                    </div>
                </div>
            </div>
        );
    }
};

const mapStateToProps = (state, ownProps) => {
    return {
        currentUserName: state.user.currentUserName
    };
}

export default connect(mapStateToProps)(UserAccount);