import React from 'react';

function Tabs(props){
    const { onClickFn = () => {}, tabs, active = '' } = props;
    return(
        <ul className="nav nav-tabs">
            {tabs.map((tab, key) =>
                <li key={key} role="presentation" className={`${active === tab.id && 'active'}`} title={tab.toolTip}><a href="#" onClick={(event) => onClickFn(event, tab.id)}>{tab.title}</a></li>)}
        </ul>
    )
}

export default Tabs;