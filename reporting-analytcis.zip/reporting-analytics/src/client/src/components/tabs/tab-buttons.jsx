import React from "react";
import classnames from "classnames";
import "./tab-buttons.less";
import Button from "../button";

const TabButtons = (props) => {
  const { onClick = () => {}, tabs = [], activeTab } = props;
  return (
    <nav className="tab-buttons">
      <ul className="tab-nav" role="tablist">
        {tabs.map((tab, key) => (
          <li className="nav-item" key={key} role="presentation">
            <Button
              className={classnames(tab.id === activeTab && "active")}
              style={tab["inlineStyle"]}
              onClick={(event) => {
                onClick?.(event, tab.id);
              }}
            >
              {tab.title}
            </Button>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default TabButtons;
