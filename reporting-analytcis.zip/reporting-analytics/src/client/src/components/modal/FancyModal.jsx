import React, { Component } from 'react';
import autoBind from 'react-autobind';

import ActionButton from '../ui/action-button';

export default class FancyModal extends Component{
    constructor (props) {
        super(props);
        autoBind(this);
    }

    render (){
        const { isOpen, options = {}, buttons = [] } = this.props;
        const { modalTitle, modalHeaderIcon, modalId, modalSize, mode = 'info', form = false } = options;

        return (
            <React.Fragment>
                {isOpen
                    && (
                        <React.Fragment>
                        <div
                            className={'fancy modal show ' + mode} id={modalId}
                             role="dialog"
                             tabIndex="-1"
                             data-dismiss="modal"
                        >
                            <div className={'modal-dialog ' + modalSize} role="document">
                                <div className="modal-content">
                                    <ConditionalWrapper condition={form} wrapper={children => <form>{children}</form>}>
                                        <React.Fragment>
                                            <div className="modal-header">
                                                <h4 className="modal-title">
                                                    {modalHeaderIcon
                                                    && <span className={'modal-icon ' + modalHeaderIcon} />}
                                                    {modalTitle}
                                                </h4>
                                            </div>

                                            {/* Dialog Body */}
                                            {this.props.children
                                            && (
                                            <div className="modal-body">
                                                {this.props.children}
                                            </div>
                                            )}

                                            <div className="modal-footer">
                                                {buttons.map((button, key) => {
                                                    return <ActionButton button={button} key={key} ui={button.ui} />
                                                })}
                                            </div>
                                        </React.Fragment>
                                    </ConditionalWrapper>
                                </div>
                            </div>
                        </div>
                        <div className="modal-backdrop fade in" />
                    </React.Fragment>
)}
            </React.Fragment>
        );
    }
}

const ConditionalWrapper = ({ condition, wrapper, children }) =>
    condition ? wrapper(children) : children;
