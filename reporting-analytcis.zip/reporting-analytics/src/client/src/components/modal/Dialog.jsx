import React, { Component } from "react";
import autoBind from 'react-autobind';
import {connect} from 'react-redux';
import * as UserUIActions from '../../redux/actions/user-actions';

class Dialog extends Component {
    constructor(props){
        super(props);
        autoBind(this);
    }

    render(){
        const { dialog = {}, sidebar = false } = this.props;
        const {
            title,
            isOpen = false,
            showClose = true,
            small = false,
            onClose = this.closeDialog,
            identifier = null,
            content } = dialog;
        return(
            <React.Fragment>
                {(isOpen)
                    && (
                    <div
                        className={'dialog dialog-open ' + (sidebar ? 'sidebar-open' : '') + ' ' + (small ? 'dialog-small' : '')}
                    >
                        <div className="dialog-content">
                            <div className="dialog-header">
                                {showClose
                                && <span className="close-btn fas fa-times pull-right" onClick={(event) => onClose(event, identifier)} />}
                                <div className="dialog-title">
                                    <h4>{title}</h4>
                                </div>
                            </div>
                            <div className="dialog-body clearfix">
                                {content}
                            </div>
                        </div>
                    </div>
                    )}
            </React.Fragment>
        );
    }

    closeDialog(event){
        if(event) event.preventDefault();
        this.props.dispatch(UserUIActions.dialogClose());
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        dialog: state.user.dialog
    }
}

export default connect(mapStateToProps)(Dialog);