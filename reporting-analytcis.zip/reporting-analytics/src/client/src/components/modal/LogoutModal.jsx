import React, {Component} from 'react';
import LogoutNotification from 'react-web-notification/lib/components/Notification';
import Modal from 'react-modal';
import axios from "axios";
class LogoutModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
            minutes: (this.props.seconds/60)-1,
            seconds: this.props.seconds,
            ignore: false,
            title: 'McKesson ERA Logout Warning',
            options: {
                body: `You will be logged out of McKesson ERA Application in ${this.props.seconds/60} minutes. Please go to App to avoid logout.`,
            }
        };
    }

    componentDidMount() {
        this.myInterval = setInterval(() => {
            const { seconds, minutes } = this.state

            if (seconds > 0) {
                this.setState(({ seconds }) => ({
                    seconds: seconds - 1
                }))
            }
            if (seconds === 0) {
                if (minutes === 0) {
                    clearInterval(this.myInterval)

                    axios.get('/api/signout')
                        .then(response => {
                            window.location.href =response.data;
                            localStorage.removeItem('userAccount')
                        })
                        .catch(function (error) {
                        });
                } else {
                    this.setState(({ minutes }) => ({
                        minutes: minutes - 1,
                        seconds: 59
                    }))
                }
            }
        }, 1000)
    }

    componentWillUnmount() {
        clearInterval(this.myInterval)
    }

    handlePermissionGranted(){
        this.setState({
            ignore: false
        });
    }

    handlePermissionDenied(){
        this.setState({
            ignore: true
        });
    }

    handleNotSupported(){
        alert('Web Notification not Supported');
        this.setState({
            ignore: true
        });
    }

    render() {
        const { minutes, seconds } = this.state

        const logoutModalContent = { transform: 'translate(90%, 64%)' };
        return (
            <div>
                {/*<LogoutNotification
                    ignore={this.state.ignore}
                    askAgain={true}
                    notSupported={this.handleNotSupported.bind(this)}
                    onPermissionGranted={this.handlePermissionGranted.bind(this)}
                    onPermissionDenied={this.handlePermissionDenied.bind(this)}
                    timeout={30000}
                    title={this.state.title}
                    options={this.state.options}
                />*/}
                <Modal isOpen={true} className="customLogoutStyles" ariaHideApp={false}>
                    <div role="dialog">
                        <div className="modal-dialog modal-sm">
                            <div className="modal-content" style={logoutModalContent}>
                                <div className="modal-header">
                                    <h4 className="modal-title"><strong>McKesson ERA Logout Warning!</strong></h4>
                                </div>
                                <div className="modal-body">
                                    <p>
                                    You will be logged out in
                                    {' '}
                                    {minutes}
                                    {' '}
                                    minute and
                                    {' '}
                                    {seconds % 60}
                                    {' '}
                                    seconds
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </Modal>
            </div>
        );
    }
}

export default LogoutModal;
