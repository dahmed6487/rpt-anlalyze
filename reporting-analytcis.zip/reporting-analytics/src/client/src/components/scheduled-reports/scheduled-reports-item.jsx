import React, {Component} from 'react';
import autoBind from "react-autobind";
import ActionPanel from '../action-panel';
import {connect} from 'react-redux';
import GroupActionPanel from '../custom-filters/edit-view/group-action-panel';
import * as SpaceManagementActions from '../../redux/actions/space-mgmnt-actions';
import LookerService from '../../services/looker-service';
import * as DeleteDialogActions from "../../redux/actions/delete-dialog-actions"
import * as UserUIActions from '../../redux/actions/user-actions';
import ScheduledReports from '../../containers/scheduled-reports';
import {Link} from "react-router-dom";
import cronstrue from 'cronstrue';
import moment from 'moment-timezone'


class ScheduledReportsItem extends Component{
constructor(props, context){
     super(props, context);
     autoBind(this);

     this.state = {
        expanded: false
     }
}

  render() {
    const { report } = this.props;
    const expanded = this.props.actionOpenForScheduleId === report.id;

    // convert crontab to human readable string
    let reportTimeZone = moment.tz(report.timezone).zoneAbbr();
    let frequency = cronstrue.toString(report.crontab) + " (" + reportTimeZone + ")";

    // Looker time is at 0 offset so convert to correct timezone
    let localTimeZone = moment.tz(moment.tz.guess()).zoneAbbr();
    let lastRunAt = report.last_run_at;
    if (lastRunAt) {
        lastRunAt = moment(report.last_run_at).tz(moment.tz.guess()).format('MM-DD-YYYY  hh:mm:ss a z');
    }

    let updatedAt = moment(report.updated_at).tz(moment.tz.guess()).format('MM-DD-YYYY  hh:mm:ss a z');

    let type = '';
    if (report.look_id) {
        type = "Report";
    } else if (report.dashboard_id) {
        type = "Dashboard";
    }

    let recipients = '', maxRecipientsDisplay=3;

    for(let i = 0; i < report.scheduled_plan_destination.length && i<maxRecipientsDisplay; i++){
      recipients += report.scheduled_plan_destination[i].address + ', ';
    }
    if(report.scheduled_plan_destination.length > maxRecipientsDisplay){
      recipients += '& ' + (report.scheduled_plan_destination.length - maxRecipientsDisplay) + ' more';
    }
    else if(recipients.length > 0){
      recipients = recipients.substring(0,recipients.length-2);
    }

    return(
            <React.Fragment>
            <div
                className='criteriaListPanel row'
                onClick={this.actionDialog}
            >
                <div
                    className={'filterPanelCol col-sm-2 ' + ('namePanel')}
                >
                    <div className="filterName" title={report.name}>{report.name}</div>
                </div>
                <div className="filterPanelCol typePanel col-sm-1">
                    <div>{type}</div>
                </div>
                <div className="filterPanelCol updatePanel col-sm-2">
                    <div>{updatedAt}</div>
                </div>
                <div className="filterPanelCol recipientsPanel col-sm-3">
                    <div>{recipients}</div>
                </div>
                <div className="filterPanelCol frequencyPanel col-sm-2">
                    <div>{frequency}</div>
                </div>
                <div className="filterPanelCol lastRunPanel col-sm-2 group-update-panel">
                    <div className="pull-right">
                        <div className="menu-link">
                          <div className="menu-link-sub">
                            <div className="menu-link-action" onClick={this.actionDialog}>
                              <span className="custom-filters-text">Action</span>
                              {' '}
                              <span
                                  className={'link-icon fas ' + (expanded ? 'fa-chevron-up' : 'fa-chevron-down')}
                              />
                            </div>
                          </div>
                          <div className={'action-sub-links ' + (expanded ? 'show' : 'hide')}>
                            <div className="action-panel action-group-panel">
                              <span className="action-filters-text" onClick={() => this.openDeletePrompt(report.id)}>Delete</span>
                              {this.handleReportItemSelection(report)}
                            </div>
                          </div>
                        </div>
                    </div>
                    {lastRunAt ? lastRunAt : ''}
                </div>
            </div>
        </React.Fragment>
    )
}


    /**
     * Event handler for when an object is selected.
     */
    handleReportItemSelection = (selItem)=>{
        let reqUrl = '';
        let type;
        if(selItem.look_id){
            type = "Report"
            reqUrl = `/displayReport/${selItem.look_id}`;
        }
        else if(selItem.dashboard_id){
            type = "Dashboard"
            reqUrl = `/displayDashboard/${selItem.dashboard_id}`;
        }
        return (<Link to={reqUrl} onClick={() => this.props.dispatch(UserUIActions.dialogClose())} className="action-filters-text">Go To {type}</Link>);

    }


actionDialog = () => {
    if (this.props.actionOpenForScheduleId === this.props.report.id) {
        this.props.dispatch(SpaceManagementActions.handleIndividualActionClick(-1));
    } else {
        this.props.dispatch(SpaceManagementActions.handleIndividualActionClick(this.props.report.id));
    }
}

openDeletePrompt = (scheduleId) => {
    this.props.dispatch(DeleteDialogActions.openDeleteDialog(scheduleId, "schedule", () => this.deleteSchedule(scheduleId)));
}

deleteSchedule = (scheduleId) => {
    LookerService.deleteScheduledReports(scheduleId)
    .then(()=>{
        this.props.dispatch(UserUIActions.dialogClose());
        const dialogOptions = {
            title: 'My Scheduled Reports',
            content: <ScheduledReports />
        };
        this.props.dispatch(UserUIActions.dialogOpen(dialogOptions));
        // Close the delete dialog
        this.props.dispatch(DeleteDialogActions.closeDeleteDialog());
    }).catch((error)=>{
    });
  this.props.dispatch(DeleteDialogActions.closeDeleteDialog());
  }
}

const mapStateToProps = (state, props) => {
  return{
    store: state,
    actionOpenForScheduleId: state.spaceMgmnt.actionOpenForScheduleId
  }
}
export default connect(mapStateToProps)(ScheduledReportsItem);
