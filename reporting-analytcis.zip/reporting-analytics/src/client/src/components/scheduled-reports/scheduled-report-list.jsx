import React, { Component } from "react";
import autoBind from 'react-autobind';

import ScheduledReportsItem from './scheduled-reports-item';

export default class ScheduledReportList extends Component{
	constructor(props) {
        super(props);
        autoBind(this);
    }

    sortByFilter(solutions) {
                return solutions.sort(function(a, b){
                    if(a.name < b.name) { return -1; }
                    if(a.name > b.name) { return 1; }
                    return 0;
                });
    }

    render(){
	    let { reportItems } = this.props;
        reportItems = this.sortByFilter(reportItems);
	    return(
	        <div className="filterList">
                {(reportItems)
                ? reportItems.map((report, key) => <ScheduledReportsItem report={report} key={key} />)
                    : (
                    <div className="criteriaListPanelEmpty">
                        You have no Scheduled Reports.
                    </div>
                    )}
            </div>
        );
    }
}
