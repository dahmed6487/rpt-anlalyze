import React, {Component} from "react";
import autoBind from 'react-autobind';
import {connect} from "react-redux";
import * as Actions from '../../redux/actions/custom-filters-actions';
import {Helmet} from "react-helmet";
import LookerService from '../../services/looker-service';
import * as UserUIActions from '../../redux/actions/user-actions';
import ScheduledReportList from './scheduled-report-list';
import Loading from '../ui/loading';

class ScheduledReportsView extends Component{

    constructor(props) {
        super(props);
        autoBind(this);

        this.state = {
            loading: true,
            reports: [],
            msg: ''
        }
    }

    componentDidMount(){
        this.loadScheduledReports();
    }

    loadScheduledReports(){
        LookerService.getScheduledReports().then((res) => {
            if(res.data){
                this.setState({
                    reports: res.data,
                    loading: false
                });
            }
        }).catch((err) => {
           this.setState({
               loading: false,
               msg: 'Reports were unable to be retrieved, please try again.'
           });
        });
    }


    render(){
        const { loading = true, reports = [] } = this.state;

        return (
            <React.Fragment>
                <Helmet defer={false}>
                    <meta charSet="utf-8" />
                    <title>&quot;My Scheduled Reports&quot;</title>
                </Helmet>

                <div className="criteriaListWrap">
                    <div className="criteriaListHeader row" key="-1" value="-1">
                        <div className="namePanel col-sm-2"><div className="groupPanel">Name</div></div>
                        <div className="typePanel col-sm-1"><div className="groupPanel">Type</div></div>
                        <div className="updatePanel col-sm-2"><div className="groupPanel">Last Updated</div></div>
                        <div className="recipientsPanel col-sm-3"><div className="groupPanel">Recipients</div></div>
                        <div className="frequencyPanel col-sm-2"><div className="groupPanel">Frequency</div></div>
                        <div className="lastRunPanel col-sm-2"><div className="groupPanel">Last Run At</div></div>
                    </div>
                </div>
                {loading
                && <Loading />}
                {!loading
                && <ScheduledReportList reportItems={reports} />}
                <div className="dialog-footer">
                    <div className="row">
                        <div className="col-xs-6 text-right" style={{ float: 'right' }}>
                            <button type="button" className="btn btn-default" onClick={this.closeSchedulePanel}>Close</button>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        )
    }

    closeSchedulePanel = () => {
        this.props.dispatch(UserUIActions.dialogClose());
    }
}


const mapStateToProps = (state, ownProps) => {
    return {
        store: state,
    };
};


export default connect(mapStateToProps)(ScheduledReportsView);