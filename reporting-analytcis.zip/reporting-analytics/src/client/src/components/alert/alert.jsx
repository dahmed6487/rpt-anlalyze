import React, { useState } from "react";

function Alert(props) {
  const { type = "info", classes = "", dismiss = false } = props;
  const [dismissModal, setDismissModal] = useState(false);

  return (
    !dismissModal && (
      <div
        className={`alert alert-${type} ${classes} ${
          dismiss && "alert-dismissible"
        }`}
        role="alert"
      >
        {dismiss && (
          <button
            type="button"
            className="close"
            data-dismiss="alert"
            aria-label="Close"
            onClick={() => setDismissModal(true)}
          >
            <span className="fas fa-times" />
          </button>
        )}
        {props.children}
      </div>
    )
  );
}

export default Alert;
