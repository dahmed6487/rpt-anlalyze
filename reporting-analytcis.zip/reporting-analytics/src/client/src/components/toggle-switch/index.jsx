export { default } from "./ToggleSwitch";
