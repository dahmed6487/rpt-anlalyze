import React, { Component } from 'react';
import autoBind from 'react-autobind';
import { Helmet } from 'react-helmet';
import axios from 'axios';
import { connect } from 'react-redux';
import {
    CUSTOM_GROUPS_CHECK,
    RELOAD_DASHBOARD_EXPLORE_PANEL,
    RELOAD_SOLUTION_PANEL, SWITCH_IFRAME_URL_SOLUTION
} from '../../redux/constants/iframe-constants';
import Loading from '../ui/loading';
import lookerService from '../../services/looker-service';

class SolutionEmbedFrame extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);

        this.state = {
            solutionNumber: '',
            solutionLink: '',
            solutionName: '',
            customerName:'',
            isError:false
        };
    }

    componentDidMount() {
        this.getState();
        lookerService.loadFilters().then((res) => {
            if(res.data.length>0){
                this.props.dispatch({ type: CUSTOM_GROUPS_CHECK, payload: { isUserHasCustomGroups: true } });
            }
        })
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        let urlData = this.getUrlData();
            if (this.props.isLoaded) {
                if (prevState.solutionNumber !== '' || prevState.customerName !== '') {
                    if (prevState.solutionNumber !== urlData.solutionNumber) {
                        this.props.dispatch({ type: RELOAD_SOLUTION_PANEL, payload: { isLoaded: false } });
                        this.getState();
                    }
                    if (prevState.customerName !== localStorage.getItem('userAccount')) {
                        this.props.dispatch({ type: RELOAD_SOLUTION_PANEL, payload: { isLoaded: false } });
                        this.getState();
                    }
                }
            }
        }

    render() {
      if(this.state.isError) {
             return (<div>Unknown error occurred</div>)
         }
        if (this.props.data.type === 'explore:run:complete' && ! this.props.isDashBoardExploreLoaded && this.props.isUserHasCustomGroups ){
            return (
                <div><Loading /></div>
            )
        }
        if(this.props.data.type==='dashboard:tile:explore'){
            const tileExploreURL = this.props.data.url.split('?');
            let urlComponents = tileExploreURL[0].split('/');
            let merge = urlComponents[2];
            if(merge==='merge')
                this.tileExploreUrl(urlComponents,merge);
        }
        if (this.props.data.type === 'explore:ready' && this.props.isUserHasCustomGroups)
            this.exploreUrl();
            if (this.props.isLoaded) {
                return (
                    <div>
                        <Helmet defer={false}>
                            <meta charSet="utf-8" />
                            <title>{this.state.solutionName}</title>
                        </Helmet>
                        <div className="home" style={{ marginTop: '49px' }}>
                            <div className="row">
                                    <div className={this.props.isUserHasCustomGroups ? this.props.isDashBoardExploreLoaded === false ? 'iframe-placeholder' : 'outer-div' : 'outer-div'}>
                                    <iframe
                                       className={this.props.isUserHasCustomGroups ? this.props.isDashBoardExploreLoaded === false ? 'looker-explore-iframe' :'looker-iframe':'looker-iframe'}
                                        src={this.props.iframeUrlForSolution}
                                        scrolling="no"
                                        title="lookerIframe"
                                        id="embedDashboard"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                )
            } else {
                return (
                    <div><Loading /></div>
                )
            }
    }

    getState() {
        this.props.dispatch({ type: RELOAD_DASHBOARD_EXPLORE_PANEL, payload: { isDashBoardExploreLoaded: true } });
        let solutionsPanel = document.querySelector('#solutionsPanel');
        if(solutionsPanel===null){
            this.setState({ isLoaded:true });
            return;
        }
        solutionsPanel.style.display = 'none';
        let urlData = this.getUrlData();
        let finalUrl=''
        if (localStorage.getItem("finalUserAttribute") === null)
             finalUrl = `/looker/dashboard/${urlData.solutionNumber}?customerId=${localStorage.getItem('userAccount')}`;
        else
             finalUrl = `/looker/dashboard/${urlData.solutionNumber}?customerId=${localStorage.getItem('userAccount')}&finalUserAttribute=${localStorage.getItem("finalUserAttribute")}`;
        axios.get(finalUrl)
            .then((response) => {
                this.props.dispatch({type: SWITCH_IFRAME_URL_SOLUTION, payload: response.data});
                this.setState({
                    solutionLink: response.data,
                    solutionNumber: urlData.solutionNumber,
                    solutionName: decodeURIComponent(urlData.solutionName),
                    customerName: localStorage.getItem('userAccount'),
                    isError:false
                });
                this.props.dispatch({ type: RELOAD_SOLUTION_PANEL, payload: { isLoaded:true } });
            }).catch((err)=>{
            console.log('err'+JSON.stringify(err.response));
            this.setState({ isError:true })
        });
    }

    getUrlData() {
        let urlComponents = window.location.href.split('solutions/')[1].split(/-(.+)/);
        return {
            solutionNumber: urlComponents[0],
            solutionName: urlComponents[1]
        };
    }

    exploreUrl() {

        let solutionsPanel = document.querySelector('#solutionsPanel');
        solutionsPanel.style.display = 'none';
        let urlData = this.getUrlData();
        const exploreURL = this.props.data.explore.url.split('?');
        let urlComponents = exploreURL[0].split('/');
        let modelName = urlComponents[3], explore = urlComponents[4],
            qid = new URL('http://www.a.com/' + this.props.data.explore.url).searchParams.get('qid'),
            customerId = localStorage.getItem('userAccount');
        if(explore==='if_ra_fact_invc_purch_hist' || explore==='dt_contract_cust_buygroup' || explore==='idb' || explore==='physical_inventory') {
            lookerService.getDashboardExploreEmbedUrl(modelName, explore, qid, customerId, localStorage.getItem("finalUserAttribute"))
                .then((response) => {
                    this.props.dispatch({type: SWITCH_IFRAME_URL_SOLUTION, payload: response.data});
                    this.setState({
                        solutionLink: response.data,
                        solutionNumber: urlData.solutionNumber,
                        solutionName: decodeURIComponent(urlData.solutionName),
                        customerName: localStorage.getItem('userAccount'),
                        isError: false
                    });
                    this.props.dispatch({
                        type: RELOAD_DASHBOARD_EXPLORE_PANEL,
                        payload: { isDashBoardExploreLoaded: true }
                    });
                }).catch((err) => {
                console.log('err' + JSON.stringify(err.response));
                this.setState({ isError: true })
            });
        } else{
            this.props.dispatch({
                type: RELOAD_DASHBOARD_EXPLORE_PANEL,
                payload: { isDashBoardExploreLoaded: true }
            });
        }
    }

    tileExploreUrl(urlComponents, merge) {
        let solutionsPanel = document.querySelector('#solutionsPanel');
        solutionsPanel.style.display = 'none';
        let mid = new URL('http://www.a.com/' + this.props.data.url).searchParams.get('mid'),
            customerId = localStorage.getItem('userAccount');
        lookerService.getDashboardExploreEmbedUrl("modelName", "explore", mid, customerId, localStorage.getItem("finalUserAttribute"))
                .then((response) => {
                    this.setState({
                        customerName: localStorage.getItem('userAccount'),
                        isError: false
                    });
                    this.props.dispatch({
                        type: RELOAD_DASHBOARD_EXPLORE_PANEL,
                        payload: { isDashBoardExploreLoaded: true }
                    });
                }).catch((err) => {
                console.log('err' + JSON.stringify(err.response));
                this.setState({ isError: true })
            });
    }
}


const mapStateToProps = (state, props) => {
    return{
        currentUser: state.user.currentUser,
        iframeIndex: state.iframe.iframeIndex,
        iframeUrl: state.iframe.iframeUrl,
        reloadIframe: state.iframe.reloadIframe,
        editMode: state.customFilterCriteria.editMode,
        dashboardLoaded: state.customFilterCriteria.dashboardLoaded,
        filterMetaDataStatus: state.customFilterCriteria.filterMetaDataStatus,
        customGroupDialog: state.customFilterCriteria.customGroupDialog,
        data: state.iframe.data,
        path: state.iframe.path,
        filtersUrl: state.iframe.filtersUrl,
        isLoading: state.customFilters.isLoading,
        isLoaded:state.iframe.isLoaded,
        isDashBoardExploreLoaded:state.iframe.isDashBoardExploreLoaded,
        isUserHasCustomGroups:state.iframe.isUserHasCustomGroups,
        iframeUrlForSolution: state.iframe.iframeUrlForSolution,
    }
}

export default connect(mapStateToProps)(SolutionEmbedFrame);
