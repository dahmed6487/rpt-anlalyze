import React, { Component } from "react";
import autoBind from "react-autobind";
import { NavLink } from "react-router-dom";


class Header extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);

    }

    render() {
        const {handleLogoClick} = this.props;
        return (
             <div className="logo-container" onClick={handleLogoClick}>
               <div className="logo">
                 <NavLink to="/">
                   <span className="desktop visible-lg visible-md visible-xl" />
                   <span className="mobile visible-xs visible-sm" />
                 </NavLink>
                 <small className="hidden-xs hidden-sm">Enterprise Reporting &amp; Analytics</small>
               </div>
             </div>
        );
    }
}

export default Header;