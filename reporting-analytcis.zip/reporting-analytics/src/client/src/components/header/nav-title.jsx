import React, { Component } from 'react';
import autoBind from 'react-autobind';

export default class NavTitle extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);
    }

    render() {
        const { title } = this.props;
        return (
            <h3 className="inline no-margin">{title}</h3>
        );
    }
}
