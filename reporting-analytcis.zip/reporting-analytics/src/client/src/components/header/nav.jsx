import React, { Component } from "react";
import autoBind from "react-autobind";
import { connect } from "react-redux";
import * as AdminActions from '../../redux/actions/account-settings-actions';
import '@mckesson/com-mckesson-ui-bootstrap-3/src/js/scripts/menu-slideout';
import { SWITCH_ROUTE } from '../../redux/constants/iframe-constants'

// Components
import { NavLink } from "react-router-dom";
import * as CustomDashboardFilterActions from '../../redux/actions/custom-filter-criteria-actions';
import * as CustomGroupDasboardActions from '../../redux/actions/custom-group-actions';
import AccountSelection from "../accounts-selection/accounts-selection";
import FilterSelection from "../custom-filter-criteria/filter-selection";
import UserMenu from './user-menu';
import Header from './header';
import SecondaryAccountSelection from "../accounts-selection/secondary-account-selection";

class Nav extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);

    this.state = {
      totalRoutePaths: [],
      Notifications: false,
      expanded: false,
      Applications: false,
      filterSelection: false
    };
  }

  /**
    * Conditional check to determine if the user should have the ability to launch the filter configuration dialog. 
    * This functionality should not be enabled until the dashboard has completely loaded.
    */

  componentDidMount() {
    let localTotalRoutePaths = [];

    this.props.routes.forEach(route => {
      //1st level routes
      localTotalRoutePaths.push({
        path: route.path,
        header: route.header,
        exact: route.exact ? route.exact : true
      });

      if (route.routes && route.routes.length > 0) {
        //2nd level routes
        route.routes.forEach(route => {
          localTotalRoutePaths.push({
            path: route.path,
            header: route.header,
            exact: route.exact ? route.exact : true
          });

          if (route.routes && route.routes.length > 0) {
            //3rd level routes
            route.routes.forEach(route => {
              localTotalRoutePaths.push({
                path: route.path,
                header: route.header,
                exact: route.exact ? route.exact : true
              });
            });
          }
        });
      }
    });
    this.setState({ totalRoutePaths: localTotalRoutePaths });
  }

  launchFilterSelectionDialog = () => {
    //this.props.dispatch(CustomDashboardFilterActions.launchFilterSelectionDialog());
    this.props.dispatch(CustomDashboardFilterActions.filterPanelActive());
    this.props.dispatch(CustomGroupDasboardActions.panelActive());
    this.setState({
      expanded: !this.state.expanded
    });
  }

  adminHandler() {
    this.props.dispatch(AdminActions.adminHandler());
  }

  handleLogoClick(event) {
    event.preventDefault();
    //Clear out iframeUrl from redux so looker embed frame will rebuild it
    this.props.dispatch({ type: SWITCH_ROUTE, payload: { iframeUrl: "" } });
  }

  render() {
    const { expanded, currentUserName } = this.props;

    return (
      <nav className="navbar primary-nav navbar-default navbar-fixed-top" style={{ minHeight: '0' }}>
        <div className="container-fluid">
          <div className="row display-flex">
            <Header
              handleLogoClick={(event) => this.handleLogoClick(event)}
            />
            <div className="">
              <ul className="nav navbar-nav">
                <AccountSelection />
                <SecondaryAccountSelection/>

              </ul>
            </div>
            <div className="" style={{ position: 'absolute', right: '0', marginRight: '2rem' }}>
              <div className="desktop-menu hidden-sm hidden-xs text-right">
                <UserMenu classes="navbar-nav navbar-right top-nav" applications={this.state.Applications} notifications={this.state.Notifications} expanded={expanded} currentUserName={currentUserName} userName={this.props.userName} sudoUser={this.props.sudoUser} fullName={this.props.fullName} />
              </div>
              <div className="mobile-menu visible-sm visible-xs">
                <button type="button" className="btn btn-link slideout-toggle"><span className="fa fa-bars" /></button>
                <div id="mobile-menu-slideout">
                  <div className="navbar navbar-inverse mobile-header">
                    <div className="mobile-menu-navbar-header">
                      <button type="button" className="btn btn-link slideout-close"><span className="fa fa-bars" /></button>
                      <div className="pull-right">
                        <div className="logo navbar-brand">
                          <a href="/">
                            <span className="desktop" />
                          <span className="mobile" />
                          McKesson
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <nav className="mobile-main-menu" id="mobile-main-menu">
                    <UserMenu applications={this.state.Applications} notifications={this.state.Notifications} expanded={expanded} currentUserName={currentUserName} userName={this.props.userName} sudoUser={this.props.sudoUser} fullName={this.props.fullName} />
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    currentUserName: state.user.currentUserName,
    dashboardLoaded: state.customFilterCriteria.dashboardLoaded,
    filterPanelActive: state.customFilterCriteria.filterPanelActive,
    accountSelectionActive: state.user.accountSelectionActive,
    editMode: state.customFilterCriteria.editMode,
    expanded: state.accountSettings.expanded,
    userName: state.accountSettings.userName,
    fullName: state.accountSettings.fullName,
    sudoUser: state.accountSettings.sudoUser
  };
}

export default connect(mapStateToProps)(Nav);