/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { Component } from 'react';
import Admin from '../admin/admin';
import autoBind from "react-autobind";
import axios from "axios";

class UserMenu extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);

        this.wrapperRef = React.createRef();
        this.timeout = null;
        this.state = {
            dropdownOpen: false,
            ahaLink:null
        };
    }

    componentDidMount() {
        axios
            .get(`/api/user/aha/link`)
            .then(response =>{
                this.setState({ahaLink : response.data});
            });
        document.addEventListener('mousedown', this.handleClickOutside);
    }

    componentWillUnmount() {
        document.removeEventListener('mousedown', this.handleClickOutside);
    }

    handleClickOutside(event) {
        if (this.wrapperRef && !this.wrapperRef.current.contains(event.target)) {
            this.setState({ dropdownOpen: false });
        }

        if (this.timeOut) {
            clearTimeout(this.timeOut);
        }
    }

    onMouseEnter(event) {
        clearTimeout(this.timeOut);
    }

    onMouseLeave(event) {
        if (this.state.dropdownOpen) {
            this.timeOut = window.setTimeout(() => { this.setState({ dropdownOpen: false }) }, 5000);
        }
    }

    toggleDropdown(event) {
        event.preventDefault();
        if (this.timeOut) clearTimeout(this.timeOut);
        this.setState({ dropdownOpen: !this.state.dropdownOpen });
    }


    render() {
        const { notifications, applications, currentUserName, classes = '', userName, sudoUser, fullName } = this.props;

        return (
            <ul className={'nav ' + classes}>

                {notifications
                 && (
                    <li>
                        <a href={'#'} className="notifications header-link">
                            <span className={'menu-icon ' + (notifications ? 'fas fa-bell' : '')} />
                            <span className="link-text">{notifications ? "Notifications" : ''}</span>
                        </a>
                    </li>
                    )}
                {applications
                && (
                    <li>
                        <a href={'#'} className="applications header-link">
                            <span className={'menu-icon ' + (applications ? 'fas fa-th' : '')} />
                            <span className="link-text">{applications ? "Applications" : ''}</span>
                        </a>
                    </li>
                   )}
                <li className="user-account-li-link" ref={this.wrapperRef} onMouseEnter={(event) => this.onMouseEnter(event)} onMouseLeave={(event) => this.onMouseLeave(event)}>
                    <a href="#" title={sudoUser ? fullName + ' logged in as ' + userName : ' '} className="dropdown-toggle" onClick={(event) => this.toggleDropdown(event)}>
                        <i className="link-icon fas fa-user-circle" />
                        <span className="era-user-drop-down-text">{userName}</span>
                        <i className={this.state.dropdownOpen ? 'fas fa-angle-down' : 'fas fa-angle-up'} />

                    </a>

                    {this.state.dropdownOpen == true &&
                        <Admin currentUserName={currentUserName} />
                    }
                </li>
             {/*   <li className="my-guide-li-link">
                    <a href={'#'} onClick={(event) => window.launchMyGuide(event)}>
                        <span className="far fa-compass"></span>
                    </a>
                </li>*/}
            </ul>
        );
    }
}

export default UserMenu;