import React from "react";
import classnames from "classnames";
import "./Button.less";

const Button = ({ children, onClick, className, ...rest }) => {
  return (
    <button
      onClick={onClick}
      className={classnames("button", className)}
      {...rest}
    >
      {children}
    </button>
  );
};

export default Button;
