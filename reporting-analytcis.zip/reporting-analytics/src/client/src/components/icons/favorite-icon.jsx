
import React, { Component } from "react";

import { getClassNames } from './base-icon';
import targetIconSelected from '../../img/favorite-icon-selected.svg';


class FavoriteIcon extends Component {

    triggerFavoriteStatusAction = () => {
        this.props.eventHandler(this.props.index);
    }

    render() {
        return (
            <div className={getClassNames(this.props.float)}><img src={targetIconSelected} alt="Favorite" />
                {this.props.favoriteCount}
            </div>
        )
    }

}


export default FavoriteIcon;