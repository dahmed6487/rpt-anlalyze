
import React, { Component } from "react";

import { getClassNames, getTargetAction } from './base-icon';

class NewFolderIcon extends Component {

    render() {
        return (
            <div className="icon">
                <div
                    alt="Create New Folder"
                    className={getClassNames(this.props.float)}
                    style={{ transform: 'scale(2.2)', padding: '19px' }}
                    onClick={getTargetAction(this.props.eventHandler, this.props.enabled)}
                >
                    <i className="fas fa-folder-plus" title="Create New Folder" alt="Create New Folder" />
                </div>
            </div>
        )
    }

}


export default NewFolderIcon;