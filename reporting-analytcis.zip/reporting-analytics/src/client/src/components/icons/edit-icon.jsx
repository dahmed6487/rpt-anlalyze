
import React, { Component } from "react";

import { getClassNames, getTargetAction } from './base-icon';


class EditIcon extends Component {

    render() {
        return (
            <div className="icon">
                <div className={getClassNames(this.props.float)} title="Edit Item" className="glyphicon glyphicon-edit" onClick={getTargetAction(this.props.eventHandler, this.props.enabled)} />
            </div>
        )
    }

}



export default EditIcon;