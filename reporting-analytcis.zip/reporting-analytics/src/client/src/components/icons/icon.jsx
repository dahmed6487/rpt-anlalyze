import React from 'react';

function Icon(props){
    const { eventHandler = () => {} } = props;
    return (
        <span className={'icon ' + props.iconClass} onClick={(event) => eventHandler(event)}>{props.children}</span>
    );
}

export default Icon;