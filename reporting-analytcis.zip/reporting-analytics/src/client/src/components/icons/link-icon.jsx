
import React, { Component } from "react";

import { getTargetAction } from './base-icon';

class LinkIcon extends Component {

    render() {
        return (
            <div className="icon">
                <div title={this.props.title} className="glyphicon glyphicon-link" data-toggle="tooltip" data-placement="below" title="Click on Icon to Copy URL" onClick={getTargetAction(this.props.eventHandler, this.props.enabled)} />
            </div>
        )
    }

}

export default LinkIcon;