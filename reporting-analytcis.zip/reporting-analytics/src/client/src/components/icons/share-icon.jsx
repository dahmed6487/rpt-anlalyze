
import React, { Component } from "react";


import { getTargetAction } from './base-icon';


class ShareIcon extends Component {

    render() {
        return (
            <div className="icon">
                <div title="Share Report" className="glyphicon glyphicon-share" onClick={getTargetAction(this.props.eventHandler, this.props.enabled)} />
            </div>
        )
    }

}


export default ShareIcon;