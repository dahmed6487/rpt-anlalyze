
import React, { Component } from "react";

import { getTargetAction } from './base-icon';


class TrashIcon extends Component {

    render() {
        return (
            <div className="icon">
                <div title="Delete Report" className="glyphicon glyphicon-trash" onClick={getTargetAction(this.props.eventHandler, this.props.enabled)} />
            </div>
        )
    }

}

export default TrashIcon;