import React from "react";
import { ReactComponent as AccountSegmentationIcon } from "../../svg/AccountSegmentationIcon.svg";
import { ReactComponent as AdminstrationIcon } from "../../svg/AdminstrationIcon.svg";
import { ReactComponent as AtAGlance } from "../../svg/Ata-glance.svg";
import { ReactComponent as SolutionsIcon } from "../../svg/SolutionsIcon.svg";
import { ReactComponent as ExploreIcon } from "../../svg/ExploreIcon.svg";
import { ReactComponent as CustomGroupsIcon } from "../../svg/CustomGroupsIcon.svg";
import { ReactComponent as MyReportsIcon } from "../../svg/MyReportsIcon.svg";
import { ReactComponent as TeamReportsIcon } from "../../svg/TeamReportsIcon.svg";
import { ReactComponent as ScheduledReportsIcon } from "../../svg/ScheduledReportsIcon.svg";
import { ReactComponent as UserManagementIcon } from "../../svg/UserManagementIcon.svg";
import { ReactComponent as TeamManagementIcon } from "../../svg/TeamManagementIcon.svg";
import { ReactComponent as CustomerManagementIcon } from "../../svg/CustomerManagementIcon.svg";
import { ReactComponent as OtherVendorPurchasesIcon } from "../../svg/OtherVendorPurchasesIcon.svg";
import { ReactComponent as SubmitIdeasIcon } from "../../svg/SubmitIdeasIcon.svg";
import { ReactComponent as HelpIcon } from "../../svg/HelpIcon.svg";
import { ReactComponent as MenuOpen } from "../../svg/MenuOpen.svg";
import { ReactComponent as MenuClose } from "../../svg/MenuClose.svg";

export {
  AccountSegmentationIcon,
  AdminstrationIcon,
  HelpIcon,
  AtAGlance,
  SolutionsIcon,
  ExploreIcon,
  CustomGroupsIcon,
  MyReportsIcon,
  TeamReportsIcon,
  ScheduledReportsIcon,
  UserManagementIcon,
  TeamManagementIcon,
  CustomerManagementIcon,
  OtherVendorPurchasesIcon,
  SubmitIdeasIcon,
  MenuOpen,
  MenuClose
};
