
import React, { Component } from "react";
import { getClassNames, getTargetAction } from './base-icon';

class RenameIcon extends Component {

    render() {
        return (
            <div className="icon">
                <div className={getClassNames(this.props.float)} title="Rename" className="glyphicon glyphicon-font" onClick={getTargetAction(this.props.eventHandler, this.props.enabled)} />
            </div>

        )
    }

}


export default RenameIcon;