
import React, { Component } from "react";

import targetIcon from '../../../img/list-view-icon.svg';
import { getClassNames, getTargetAction } from './base-icon';

class ListViewIcon extends Component {

    render() {
        return (
            <div className={getClassNames(this.props.float)} onClick={getTargetAction(this.props.eventHandler, this.props.enabled)}><img src={targetIcon} alt="Switch to list view" /></div>
        )
    }

}


export default ListViewIcon;