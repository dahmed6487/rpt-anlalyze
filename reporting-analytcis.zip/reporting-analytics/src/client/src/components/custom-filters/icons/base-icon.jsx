export function getClassNames(float){
    var classNames = 'icon';
    if(float&&float=='right'){
        classNames += ' floatRight';
    }
    return classNames;
}

export function isEnabled(enabledProp){
    if(enabledProp&&enabledProp==true){
        return true;
    }
    return false;
}

export function getTargetAction(eventHandler, enabledProp){
    if(enabledProp==undefined||enabledProp==false){
        return null;
    }

    return eventHandler;
}
