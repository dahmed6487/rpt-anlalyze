
import React, { Component } from "react";

import { getClassNames, getTargetAction } from './base-icon';
import targetIcon from '../../../img/elipsis-icon.svg';


class ElipsisIcon extends Component {

    render() {
        return (
            <div className={getClassNames(this.props.float)} onClick={getTargetAction(this.props.eventHandler, this.props.enabled)}><img src={targetIcon} alt="?" /></div>
        )
    }

}


export default ElipsisIcon;