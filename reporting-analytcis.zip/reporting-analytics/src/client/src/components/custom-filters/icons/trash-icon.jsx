
import React, { Component } from "react";

import { getClassNames, getTargetAction } from './base-icon';
import targetIcon from '../../../img/trash-icon.svg';


class TrashIcon extends Component {

    render() {
        return (
            <div className={getClassNames(this.props.float)} onClick={getTargetAction(this.props.eventHandler, this.props.enabled)}><img src={targetIcon} alt="Trash" /></div>
        )
    }

}


export default TrashIcon;