
import React, { Component } from "react";

class FilterIcon extends Component{

    render(){
        return(
            <div className="filterIcon">
                NG
            </div>
        );
    }

}


export default FilterIcon;