import React, { Component } from "react";
import { connect } from "react-redux";

import * as Constants from '../../../constants/custom-filters-constants';

class ListItemPanel extends Component{
	
}

const mapStateToProps = (state, ownProps) => {
 

//return { store: state, displayModal: displayModal, existingFilters: state.customFilters.existingFilters  };
};

export default connect(mapStateToProps)(ListItemPanel);