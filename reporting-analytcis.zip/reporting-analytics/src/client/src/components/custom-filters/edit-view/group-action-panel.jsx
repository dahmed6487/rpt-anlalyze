import React, {Component} from "react";
import autoBind from "react-autobind";
import {connect} from 'react-redux';
import * as Actions from '../../../redux/actions/custom-filters-actions';
import * as DeleteDialogActions from "../../../redux/actions/delete-dialog-actions"
import * as SharingActions from "../../../redux/actions/sharing-actions"
import LookerService from '../../../services/looker-service';
import * as AppConstants from "../../../redux/constants/application-constants";
import TeamService from "../../../redux/services/team-service";
import * as CustomDashboardFilterActions from '../../../redux/actions/custom-filter-criteria-actions';
import GroupView from '../../custom-group/group/group-view';
import * as UserUIActions from '../../../redux/actions/user-actions';
import CustomGroupPanel from '../../../containers/custom-group-panel';

class GroupActionPanel extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);

    this.state = {

    };
  }

  render() {
    return  (
      <div className="action-panel action-group-panel">
        <span className="action-filters-text" onClick={this.editFilter.bind(this, this.props.filter)}>Edit</span>
        <span className="action-filters-text" onClick={this.openDeletePrompt.bind(this, this.props.filter)}>Delete</span>
      </div>
    );
  }

  openDeletePrompt = (filterId) => {
      this.props.dispatch(DeleteDialogActions.openDeleteDialog(filterId, "group", () => this.deleteFilter(filterId)));
  }

  deleteFilter = (filterId) => {
    this.props.dispatch(Actions.deleteFilter(filterId));

    LookerService.deleteFilter(filterId.id)
    .then(()=>{
        this.props.dispatch(UserUIActions.dialogClose());
        const dialogOptions = {
            title: 'Custom Groups',
            content: <CustomGroupPanel />
        };
        this.props.dispatch(UserUIActions.dialogOpen(dialogOptions));
        // Close the delete dialog
        this.props.dispatch(DeleteDialogActions.closeDeleteDialog());
    }).catch((error)=>{
        // Close the delete dialog maybe? would be better if there was error reporting in the app so don't for now
        // this.props.dispatch(DeleteDialogActions.closeDeleteDialog());
    });
  }

  getTeamsFromIds(filter) {
    let sharedTeams = filter.sharedTeams;
    if (!sharedTeams || sharedTeams.length === 0) {
        return;
    }

    TeamService.getTeamsForIds(sharedTeams)
        .then(response => {
            filter.teamNames = response.data.map(team => team.name);
        })
  }

  shareFilter = (filter) => {
    this.props.dispatch(SharingActions.shareElement(filter.id, filter.name,"Custom Group", filter.sharedTeams, this.updateSharedGroup));
  }

  updateSharedGroup = (groupId, sharedTeams) => {
    this.props.dispatch({type: AppConstants.API_CALL_TRIGGERED});
    let group = this.props.existingFilters.find(group => group.id === groupId);
    group.sharedTeams = sharedTeams;
    LookerService.shareFilter(groupId, sharedTeams)
        .then(() => {
            this.props.dispatch(SharingActions.finishSharing());
            LookerService.loadFilters()
                .then((filters)=>{
                    let groups = filters.data;
                    if (groups && groups.length) {
                        groups.forEach(group => {
                            this.getTeamsFromIds(group);
                        });
                    }
                    this.props.dispatch(Actions.fetchFiltersSuccess(groups));
                    this.props.dispatch({type: AppConstants.API_CALL_COMPLETED});
                    }
                ).catch((err)=>{
                    this.onLoadFilterResponseError(err);
                    this.props.dispatch({type: AppConstants.API_CALL_COMPLETED});
                });
        })
        .catch((err) => {
            this.props.dispatch({type: AppConstants.API_CALL_COMPLETED});
    });
  }

  editFilter = (group) => {
      const dialogOptions = {
          title: 'Edit Custom Group',
          content: <GroupView group={group} />
      };
      this.props.dispatch(UserUIActions.dialogOpen(dialogOptions));
  }

  /**
    * Retrieve action panel contents:
    *  When a 'new' filter is created through the action of adding/changing criteria in the Looker Iframe, the only available actions 
    * are to 'save/persist' or delete the new filter. The option to save the new filter is only enabled when a value is present for the 
    * 'name' attribute of the filter.
    * 
    *  When a 'saved' filter is presented, the user has the option of editing the name and updating the saved filter, or they may apply the filter.  
    * 
  */

}

const mapStateToProps = (state, props) => {
  return{
      store: state,
      currentUser: state.user.currentUser,
      deleteItemId: state.deleteDialog.deleteItemId,
      existingFilters: state.customFilters.existingFilters ? state.customFilters.existingFilters : []
  }
}

export default connect(mapStateToProps)(GroupActionPanel);