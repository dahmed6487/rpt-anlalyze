import React, {Component} from 'react';

import {connect} from 'react-redux';

class CriteriaAddPanel extends Component{

    addCriteriaHandler = () => {

        this.props.actionHandler();
    }

    render(){

        return (
            <button type="button" className="btn btn-link btn-xs" style={{ color: 'black', marginTop: '0.5rem' }}>Add Definition &#43;</button>
        )
    }
}

export default connect()(CriteriaAddPanel);