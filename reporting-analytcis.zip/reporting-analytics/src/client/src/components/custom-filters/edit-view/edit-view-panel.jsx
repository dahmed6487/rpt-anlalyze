import React, {Component} from "react";
import {connect} from "react-redux";
import * as Actions from '../../../redux/actions/custom-filters-actions';

import CriteriaAddPanel from './criteria-add-panel';
import CriteriaListPanel from './criteria-list-panel';
import GroupEditPanel from './group-edit-panel';
import * as CustomGroupDasboardActions from '../../../redux/actions/custom-group-actions';
import * as CustomDashboardFilterActions from '../../../redux/actions/custom-filter-criteria-actions';
import LookerService from "../../../services/looker-service";
import TeamService from "../../../redux/services/team-service";
import * as IframeActions from "../../../redux/actions/looker-embed-actions";

class EditViewPanel extends Component{

    constructor(props, context) {
        super(props, context);
    }

    isUserEditingGroup = () => {
        return this.props.isEditingFilter;
    }

    areCriteriaGroupsPresent = () => {
        return this.props.criteriaGroups.length > 0;
    }

    onFilterNameChange = (evt) => {
        this.props.dispatch(Actions.filterTitleUpdated(evt.target.value));
    }

    /**
     * Conditionally display panel enabling user initiate the process of entering in a new group. This panel
     * is only displayed when at least a single group has been entered, and when we are not actively editing an
     * existing group.
     */
    getGroupAdditionPanel = () =>{
        if (!this.areCriteriaGroupsPresent() || this.isUserEditingGroup()){
            return null;
        }

        return(
            <CriteriaAddPanel actionHandler={this.enterNewGroupHandler} />
        )
    }

    /**
     * Conditionally create a component which displays existing groups if any are present.
     */
    getCriteriaListPanel = () => {
        this.props.dispatch(CustomGroupDasboardActions.editPanelActive());
        if(!this.areCriteriaGroupsPresent() || this.isUserEditingGroup()){
            return null;
        }

        let groups = [];
        this.props.criteriaGroups.forEach((criteriaGroup, index) => {
            groups.push(
                <CriteriaListPanel
                                   name={criteriaGroup.name}
                                   criteriaGroupsIndex={index}
                                   associatedDimension={criteriaGroup.associatedDimension}
                                   key={index}
                                   criteria={criteriaGroup.value}
                                   defaultGrouping={criteriaGroup.defaultGrouping}
                />
            );
        });
        return(
            <div>
                {groups}
            </div>
        )
    }
    /**
     * Create a component that allows the user to edit/enter groups
     */
    getGroupEditPanel = () => {
        if(this.props.selectedGroupCriteriaIndex === undefined || this.props.selectedGroupCriteriaIndex === null){
            return null;
        }

        return(
            <GroupEditPanel />
        )
    }

    enterNewGroupHandler = ()=>{
        this.props.dispatch(Actions.enterNewFilterGroup());
    }

    getFilterFromStore = () => {
        return {
            name: this.props.selectedFilterTitle,
            id: this.props.selectedFilterId === -1 ? null : this.props.selectedFilterId,
            criteriaGroup: this.getGroupsFromStore()
        }
    }

    getGroupsFromStore = ()=>{
        return {
            id: this.props.filterGroup.id,
            name: this.props.filterGroup.name,
            filterCriteria: this.props.criteriaGroups
        };
    }

    getTeamsFromIds(filter) {
        let sharedTeams = filter.sharedTeams;
        if (!sharedTeams || sharedTeams.length === 0) {
            return;
        }

        TeamService.getTeamsForIds(sharedTeams)
            .then(response => {
                filter.teamNames = response.data.map(team => team.name);
            })
    }

    saveFilter = () => {
        //Event broadcast for save event
        this.props.dispatch(CustomDashboardFilterActions.customGroupAction());
        this.props.dispatch(Actions.saveFilter(this.getFilterFromStore()));

        //Trigger asyc save operation
        LookerService.saveFilter(this.getFilterFromStore())
            .then((filter)=>{
                //console.debug(filter);
                //Broadcasting event for successful save operation
                this.props.dispatch(Actions.filterSaved());
                this.props.dispatch(IframeActions.reloadIframe(this.props.iframeIndex + 1, true));

                //Retrieve updated filter list
                LookerService.loadFilters()
                    .then((filters)=>{
                            let groups = filters.data;
                            if (groups && groups.length) {
                                groups.forEach(group => {
                                    this.getTeamsFromIds(group);
                                });
                            }
                            this.props.dispatch(Actions.fetchFiltersSuccess(filters.data));
                        }
                    )

            })
    }


    getFilterPropertiesPanel = () =>{
        return(
            <div className="filterTitlePanel">
                <div className="filterTitlePanelInner">
                    <div className="form-group">
                        <label htmlFor="customGroupName">
                            CUSTOM GROUP NAME
                        <input
                               type="text"
                               className="form-control"
                               id="customGroupName"
                               value={this.props.selectedGroupTitle}
                               onChange={this.onFilterNameChange}
                               placeholder="Custom Group Name"
                        />
                        </label>
                    </div>
                </div>
            </div>
        )
    }

    getFooterContent = () => {
        /* Conditionally display footer element  */
        return(
            this.props.selectedFilterId
            ? (
                <div className="filter-footer">
                    <button type="button" onClick={this.cancelFilterEdit} className="btn btn-default">Cancel</button>
                    <button type="button" onClick={this.saveFilter} className="btn btn-primary" disabled={this.isSaveButtonDisabled()}>Save</button>
                </div>
                )
                : null
        );
    }

    isSaveButtonDisabled = () => {
        if(this.props.selectedGroupTitle.trim()==''){
            return true;
        }
    }

    cancelFilterEdit = () => {
        this.props.dispatch(Actions.cancelFilterEdit());
        this.props.dispatch(CustomDashboardFilterActions.customGroupAction());
    }

    /**
     * Panel presented when user is actively editing a group.
     */

    render(){
        return(
            <React.Fragment>
                {/* Controls for 'filter level data' */}
                {this.getFilterPropertiesPanel()}
                <div className="group-definition">Group Definitions</div>

                {/* Conditionally display group editor component. */}
                {this.getGroupEditPanel()}

                {/* Conditionally display group list component */}
                {this.getCriteriaListPanel()}

                {/* Conditionally display panel with call to action to enter an additional group. */}
                {this.getGroupAdditionPanel()}

                {this.getFooterContent()}
            </React.Fragment>
        );
    }

}

const mapStateToProps = (state, ownProps) => {
    return {
        store: state,
        filterGroup: state.customFilters.filterGroup,
        selectedFilterTitle: state.customFilters.selectedFilterTitle,
        selectedFilterId: state.customFilters.selectedFilterId,
        selectedGroupCriteriaIndex: state.customFilters.selectedGroupCriteriaIndex,
        selectedGroupTitle: state.customFilters.selectedGroupTitle ? state.customFilters.selectedGroupTitle : '',
        criteriaGroups: state.customFilters.criteriaGroups ? state.customFilters.criteriaGroups : [],
        isEditingFilter: state.customFilters.isEditingFilter ? state.customFilters.isEditingFilter : false,
        model: state.customFilters.model,
        currentUser: state.user.currentUser,
        iframeIndex: state.iframe.iframeIndex
    };
};

export default connect(mapStateToProps)(EditViewPanel)