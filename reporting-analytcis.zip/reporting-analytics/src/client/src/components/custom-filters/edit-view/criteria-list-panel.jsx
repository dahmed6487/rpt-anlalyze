import React, {Component} from "react";
import {connect} from "react-redux";
import * as Actions from '../../../redux/actions/custom-filters-actions';
import * as DeleteDialogActions from "../../../redux/actions/delete-dialog-actions"
import ActionPanel from "../../action-panel";

import Icon from '../../icons/icon';

class GroupingListPanel extends Component{

    editGrouping = (criteriaIndex) => {
        this.props.dispatch(Actions.editFilterGroupCriteria(criteriaIndex));
    }

    openDeletePrompt = (criteriaIndex) => {
        this.props.dispatch(DeleteDialogActions.openDeleteDialog(criteriaIndex, "criteria", this.deleteGrouping));
    }

    deleteGrouping = () => {
        this.props.dispatch(Actions.deleteFilterGroup(this.props.deleteItemId));
        this.props.dispatch(DeleteDialogActions.closeDeleteDialog());
    }

    formatCriteria = (criteria) => {
        return criteria.replace(/,/g, ", ");
    }

    render(){
        return (
            <div className="groupingListPanelInner">
                <div className="groupingHeader col-sm-1 col-md-1">{this.props.name}</div>
                <div className="groupingHeader col-sm-2 col-md-2">{this.props.associatedDimension}</div>
                <div className="valuePanel col-sm-8 col-md-8">
                    {this.props.criteria ? this.formatCriteria(this.props.criteria) : 'All Other'}
                </div>
                <span className="col-sm-2 col-md-2">
                    <ActionPanel criteriaGroupsIndex={this.props.criteriaGroupsIndex} />
                </span>
            </div>
        )
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        deleteItemId: state.deleteDialog.deleteItemId,
        criteriaGroups: state.customFilters.criteriaGroups ? state.customFilters.criteriaGroups : []
    };
};

export default connect(mapStateToProps)(GroupingListPanel);