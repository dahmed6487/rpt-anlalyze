import React, {Component} from "react";
import {connect} from "react-redux";
import * as CustomGroupingActions from '../../../redux/actions/custom-filters-actions';
import LookerService from "../../../services/looker-service";

import AutocompleteTextBox from "../../input/autocomplete-text";
import {LOADING_GROUPS} from '../../../constants/custom-filters-constants';
import Select from 'react-select';
import * as CustomGroupActions from '../../../redux/actions/custom-group-actions';

/**
 * Panel used for management of a new or selected 'criteria group'
 * 
 * 
 */
class GroupEditPanel extends Component{

    constructor(props){
        super(props);
        this.state = {
            criteriaInputValue: null,
            isEditing: false,
            isLoading: false,
            selectedOption:  {"label": this.props.associatedDimension}
        };
    }

    criteriaValueUpdated = (event) =>{
        this.setState({criteriaInputValue: event.target.value});
    }

    /*
        Event handler for when user elects to 'save' current changes to the group
    */
    saveCriteriaGroup = () => {
        var updatedGroup = this.getGroupFromEditState();
        this.props.dispatch(CustomGroupingActions.saveFilterGroup(updatedGroup));
    }

    /*
        Event handler for cancel operation for current group edits.
    */
    cancelCriteriaGroupEdit = () =>{
        this.props.dispatch(CustomGroupingActions.cancelFilterGroupEdit());
        this.props.dispatch(CustomGroupActions.panelActive());
    }

    titleChanged = (evt) =>{
        this.props.dispatch(CustomGroupingActions.filterGroupCriteriaTitleUpdated(evt.target.value));
    }

    /**
     * Take current draft version of group related edits and create a new criteria group object.
     */
    getGroupFromEditState = ()=>{

        let criteriaArray = [];

        //Map criteria to collection
        this.props.criteriaElements.forEach(
            (criteria, index)=>{
                criteriaArray.push(criteria);
            }
        );

        let criteriaGrouping = {
            name: this.props.selectedCriteriaTitle,
            criteriaGroupId: this.props.selectedGroup ? this.props.selectedGroup.id : null,
            dimension: this.props.selectedDimension,
            relationalOperator: "in", // Only support "in" for now
            value: criteriaArray.join(","),
            defaultGrouping: this.props.defaultGrouping,
            associatedDimension: this.props.associatedDimension
        }

        return criteriaGrouping;
    }

    addCriteria = (criteria) => {
        // const criteria = this.state.criteriaInputValue;
        this.setState({criteriaInputValue: ''})

        if (criteria == null || criteria === "") {
            return;
        }

        this.props.dispatch(CustomGroupingActions.addCriteria(criteria));
    }

    deleteCriteria = (criteria) => {
        this.props.dispatch(CustomGroupingActions.deleteCriteria(criteria));
    }

    handleAssociatedDimensionSelect = (selectedOption) => {
        this.setState({
            selectedOption: selectedOption
        })
        this.props.dispatch(CustomGroupingActions.userInput(''));
        this.props.dispatch(CustomGroupingActions.dimensionSelected(selectedOption.value));
        this.loadValuesForSelectedDimension(selectedOption.value);
    }

    handleSetDefaultGrouping = () => {
        this.props.dispatch(CustomGroupingActions.setGroupingDefault())
    }

    loadValuesForSelectedDimension = (selectedDimension) => {
        let viewAndDimension = selectedDimension ? selectedDimension : this.props.selectedDimension;
        if (!viewAndDimension) {
            // If this is the first time editing the group there may not be a selected dimension loaded via props or
            // otherwise
            return;
        }
        this.props.dispatch({type: LOADING_GROUPS, payload: true});
        // Currently this is hard-coded to the purchases explore
        LookerService.getValuesForDimension("r_a_connect", "if_ra_fact_invc_purch_hist", viewAndDimension, "csv")
            .then((values) => {
                let valuesArray = values.data.split("\n");
                if (!valuesArray.length) {
                    valuesArray = [];
                } else {
                    // Remove the header row from the response
                    valuesArray.slice(1);
                }
                this.props.dispatch(CustomGroupingActions.loadDimensionSuggestions(valuesArray));
            })
            .catch((err) => {
                this.props.dispatch(CustomGroupingActions.loadDimensionSuggestions([]));
            });
    }

    clearDimensions = (criteria) => {
        this.props.dispatch(CustomGroupingActions.clearDimensions(criteria));
    }

    /**
     * Retrieve panel defintion which allows user to manager associated filters for the group.
     */
    getCriteriaEditPanel = () => {
        if (this.props.defaultGrouping) {
            return null;
        }
        
        let criteriaDisplayElements = [];
        if (this.props.criteriaElements && this.props.criteriaElements.length > 0) {
            this.props.criteriaElements.forEach((element, index) => {
                criteriaDisplayElements.push(
                    (<span key={index} className="badge" style={{ marginRight: '0.5rem' }}>
                        {element}
                        <span style={{ cursor: 'pointer', marginLeft: '4px' }} onClick={this.deleteCriteria.bind(this, element)}>
                            X
                        </span>
                    </span>)
                );
            });
        }
        return (
            <div>
                <div className="form-group">
                    <label style={{ display: 'block' }}>ASSOCIATED DIMENSION</label>
                    { this.getAvailableDimensionControl() }
                    <div style={{ display: 'inline-block', margin: '0 1rem' }}>EQUAL TO</div>
                    <div className="criteriaValueTextBox-new">
                        <AutocompleteTextBox
                            suggestions={this.props.dimensionSuggestions}
                            submit={this.addCriteria}
                        />
                    </div>
                </div>
                {criteriaDisplayElements}
                <button type="button" onClick={this.clearDimensions.bind(this, this.props.criteriaElements)} className="btn btn-default">Clear All</button>
            </div>
        )
    }

    getSortedDimensions = () => {
        const results = this.props.visibleDimensions.sort(sortByDimensionLabel);
        return results;
    }

    getDefaultGroupingErrorMessage = () => {
        if (!this.props.defaultGroupingError) {
            return null;
        }

        return (
            <div className="alert alert-danger" role="alert">
                <strong>Error!</strong> 
                Cannot have multiple &quot;All Other&quot; groupings!
            </div>
        )
    }

    /**
     * A potentially large number of entries is returned from the API call, so it becomes necessary to group entries 
     * prior to display.   
     * 
     */
    getAvailableDimensionControl = () => {
        
        //A collection of top level option group names is established
            var optionGroups = [];
            for( var x=0; x<this.props.visibleDimensions.length;x++){
                var curDimension = this.props.visibleDimensions[x];
                if( !optionGroups.includes(curDimension.view_label) ){
                    optionGroups.push(curDimension.view_label);
                }
            }
            optionGroups = optionGroups.sort(this.sortValuesDescending);
  
        //Next, a map of all values is created with the name of each group as the key.
            var optGroupValues = [];
            var optGroupLabels = [];
            for( var curOptGroup of optionGroups ){
                optGroupValues[curOptGroup] = [];
                for( var curDimension of this.props.visibleDimensions){
                    if( curDimension.view_label==curOptGroup){
                        if(optGroupLabels[curOptGroup]==undefined){
                            optGroupLabels[curOptGroup] = [];
                            optGroupLabels[curOptGroup].push(curDimension.label_short);
                            optGroupValues[curOptGroup].push(curDimension);
                        }
                        else if(!optGroupLabels[curOptGroup].includes(curDimension.label_short)){
                            optGroupValues[curOptGroup].push(curDimension);
                        }
                    }
                }
            }

        var results = [];
        for( var curOptGroup of optionGroups ){
            var curOpts = [];
            var curLabels = [];
            for(var curOpt of optGroupValues[curOptGroup]){
                if(!curLabels.includes(curOpt.label_short)){
                    curLabels.push(curOpt.label_short);
                    curOpts.push(
                        {value: curOpt.name, label: curOpt.label_short}  
                    );
                }
            }
            results.push(
                {
                    label: curOptGroup,
                    options: curOpts
                }
            );
        }
        
        return (
            <div style={{ width: '40%', display: 'inline-block' }}>
                <Select
                    options={results}
                    value={this.state.selectedOption ? this.state.selectedOption : ''}
                    isClearable={true}
                    onChange={this.handleAssociatedDimensionSelect}
                />
            </div>

        );
    }

    sortValuesDescending = (a, b) => {
        var x = a.toLowerCase();
        var y = b.toLowerCase();
        if(x==y){
            return 0;
        }
        if(x<y){
            return -1;
        }
        return 1;
    }

    isSaveButtonDisabled = () => {
        if(this.props.selectedCriteriaTitle.trim()==''){ 
            return true; 
        }
        return false;
    }

    render(){
        return (
            <div className="groupEditPanel-new">
                {this.getDefaultGroupingErrorMessage()}
                <div>
                    <span className="edit-group-def">Edit Group Definition</span>
                </div>
                <div className="form-group" style={{ marginTop: '1rem' }}>
                    <label>
                        DEFINITION NAME
                    <input
                           type="text"
                           value={this.props.selectedCriteriaTitle}
                           onChange={this.titleChanged}
                           className="form-control"
                           placeholder="Definition Name"
                    />
                    </label>
                </div>
                <div className="defaultGroupingLabel">
                    <input type="checkbox"
                    className="defaultGroupingCheckbox"
                    checked={this.props.defaultGrouping}
                    onChange={this.handleSetDefaultGrouping}
                    />
                    <span className="defaultGroupingLabelText">All Other</span>
                </div>
                <div className="custom-group-conditions">Conditions</div>

                { this.getCriteriaEditPanel() }

                <div className="filter-footer">
                    <div className="row">
                        <div className="col-xs-6">
                            <button
                                type="button"
                                className="btn btn-primary"
                                onClick={this.saveCriteriaGroup}
                                disabled={this.props.defaultGroupingError || this.isSaveButtonDisabled()}
                            >
                                Save
                            </button>
                        </div>
                        <div className="col-xs-6 text-right">
                            <button type="button" className="btn btn-default" onClick={this.cancelCriteriaGroupEdit}>Cancel</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

}

function sortByDimensionLabel(a, b){
    var x = a.label_short.toLowerCase();
    var y = b.label_short.toLowerCase();
    //return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    if(x==y){
        return 0;
    }
    if(x<y){
        return -1;
    }
    return 1;
}

const mapStateToProps = (state, ownProps) => {
    return {
        store: state,
        selectedGroup: state.customFilters.filterGroup,
        selectedCriteriaTitle: state.customFilters.selectedCriteriaTitle ? state.customFilters.selectedCriteriaTitle : '',
        selectedGroupCriteriaIndex: state.customFilters.selectedGroupCriteriaIndex,
        criteriaElements: state.customFilters.criteriaElements ? state.customFilters.criteriaElements : [],
        selectedDimension: state.customFilters.selectedDimension,
        visibleDimensions: state.customFilters.visibleDimensions ? state.customFilters.visibleDimensions.sort(sortByDimensionLabel) : [],
        model: state.customFilters.model,
        exploreRef: state.customFilters.exploreRef,
        defaultGrouping: state.customFilters.defaultGrouping,
        associatedDimension: state.customFilters.associatedDimension,
        defaultGroupingError: state.customFilters.defaultGroupingError,
        currentUser: state.user.currentUser,
        dimensionSuggestions: state.customFilters.dimensionSuggestions,
        criteriaGroups: state.customFilters.criteriaGroups ? state.customFilters.criteriaGroups : [],
        isLoading: state.customFilters.isLoading,
        userInput: state.customFilters.userInput
    };
};

export default connect(mapStateToProps)(GroupEditPanel);