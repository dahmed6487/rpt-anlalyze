import React, {Component} from "react";
import autoBind from "react-autobind";
import {connect} from 'react-redux';
import * as Actions from '../../../redux/actions/custom-filters-actions';
import * as DeleteDialogActions from "../../../redux/actions/delete-dialog-actions"

class EditCustomGroupPanel extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);

    this.state = {

    };
  }

  render() {
    return  (
        <div className="action-panel">
            <span className="action-filters-text" onClick={this.editGrouping.bind(this, this.props.criteriaGroupsIndex)}>Edit</span>
            <span className="action-filters-text" onClick={this.openDeletePrompt.bind(this, this.props.criteriaGroupsIndex)}>Delete</span>
        </div>
    );
  }

  editGrouping = (criteriaIndex) => {
    this.props.dispatch(Actions.editFilterGroupCriteria(criteriaIndex));
  }

  openDeletePrompt = (criteriaIndex) => {
    this.props.dispatch(DeleteDialogActions.openDeleteDialog(criteriaIndex, "criteria", this.deleteGrouping));
  }

  deleteGrouping = () => {
    this.props.dispatch(Actions.deleteFilterGroup(this.props.deleteItemId));
    this.props.dispatch(DeleteDialogActions.closeDeleteDialog());
  }

  /**
    * Retrieve action panel contents:
    *  When a 'new' filter is created through the action of adding/changing criteria in the Looker Iframe, the only available actions 
    * are to 'save/persist' or delete the new filter. The option to save the new filter is only enabled when a value is present for the 
    * 'name' attribute of the filter.
    * 
    *  When a 'saved' filter is presented, the user has the option of editing the name and updating the saved filter, or they may apply the filter.  
    * 
  */

}

const mapStateToProps = (state, props) => {
  return{
      store: state,
      currentUser: state.user.currentUser
  }
}

export default connect(mapStateToProps)(EditCustomGroupPanel);