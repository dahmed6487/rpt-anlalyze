import React, { Component } from "react";
import autoBind from 'react-autobind';

import ListItemDisplay from './list-item-display';

export default class ListItemPanel extends Component{
	constructor(props) {
        super(props);
        autoBind(this);
    }

    render(){
	    const { filterItems } = this.props;
	    return(
	        <div className="filterList">
                {(filterItems.length > 0)
                ? filterItems.map((filter, key) => <ListItemDisplay filter={filter} key={key} />)
                    : (
                    <div className="criteriaListPanelEmpty">
                        You have no Custom Groups. You can create one using the button below.
                    </div>
                    )
                }
            </div>
        );
    }
}
