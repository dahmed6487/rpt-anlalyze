import React from 'react';
import ActionPanel from '../../action-panel';

import Timezone from '../../../helpers/timezone';

function ListItemDisplay(props){
    const { filter } = props;
    let sharedFilter = filter.sharedTeams && filter.sharedTeams.length > 0;
    return(
        <React.Fragment>
            <div
                className={sharedFilter ? 'criteriaListPanelNoBottomBorder row' : 'criteriaListPanel row'}
            >
                <div
                    className={'filterPanelCol col-sm-4 ' + (sharedFilter ? 'filterNamePanelNoBottomPadding' : 'filterNamePanel')}
                >
                    <div className="filterName">{filter.name}</div>
                    <div className="filterAuthor">
                        <b>Owner</b>
                        :
                        {filter.author}
                    </div>
                    <div className="filterAuthor">
                        <b>Customer</b>
                        :
                        {filter.userId}
                    </div>
                </div>
                <div className="filterPanelCol exploreTypePanel col-sm-4">
                    <div>{filter.filterType ? filter.filterType : 'All Explores'}</div>
                </div>
                <div className="filterPanelCol filterUpdatePanel col-sm-4 group-update-panel">
                    <div className="pull-right"><ActionPanel filter={filter} /></div>
                    {filter.lastUpdateDate ? Timezone.formatDate(filter.lastUpdateDate, ' - Updated') : Timezone.formatDate(filter.creationDate, ' - Created')}
                </div>
            </div>
            {sharedFilter
            && (
                <div className="filterSharedTeamsPanel">
                    <div className="filterSharedTeamsText">
                        <div className="filterAuthor shared-filter">
                            <b>Shared Teams</b>
                            :
                            {this.getSharedTeamsDisplay(filter.sharedTeams)}
                        </div>
                    </div>
                </div>
                )
            }
        </React.Fragment>
    )
}

export default ListItemDisplay;