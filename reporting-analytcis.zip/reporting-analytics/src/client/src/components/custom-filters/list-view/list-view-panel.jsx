import React, {Component} from "react";
import autoBind from 'react-autobind';
import {connect} from "react-redux";
import * as Actions from '../../../redux/actions/custom-filters-actions';
import 'moment-timezone';

import LookerService from '../../../services/looker-service';
import UserService from "../../../redux/services/user-service";
import * as CustomDashboardFilterActions from "../../../redux/actions/custom-filter-criteria-actions";
import ListItemPanel from './list-item';

class ListViewPanel extends Component{

    constructor(props) {
        super(props);
        autoBind(this);

    }

    componentDidMount(){
        this.getTeams();
    }

    getTeams(){
        UserService.getTeamsForCurrentUser()
            .then(
                (res)=>{
                    this.props.dispatch({type: "USER_TEAMS_LOADED", payload: res.data});
                    return res;
                }
            )
    }

    copyFilter = () => {

        /*
            Load selected filter,
            then triger action
        */
        this.props.dispatch(Actions.loadFilter());
        LookerService.getFilter(this.props.selectedFilters[0])
            .then(
                (filterResponse)=>{
                    this.props.dispatch(Actions.filterLoaded());
                    this.props.dispatch(Actions.cloneFilter(filterResponse.data));
                }
            )
    }

    isFilterSelected(){
        return this.props.selectedFilters && this.props.selectedFilters.length>0;
    }

    getSharedTeamsDisplay = (teamIds) =>{
        let results = '';

        for(var x=0;x<teamIds.length;x++){
            results += `${this.getTeamName(teamIds[x])}, `;
        }

        return results;
    }

    getTeamName = (teamId)=>{
        var curTeamId;
        var curTeamName;
        for(var x=0;x<this.props.userTeams.length;x++){
            curTeamId = this.props.userTeams[x].id;
            curTeamName = this.props.userTeams[x].name;
            if(curTeamId==teamId){
                return curTeamName;
            }
        }
        return '';
    }

    render(){
        const { existingFilters = [], loading = true } = this.props;

        return (
            <React.Fragment>
                <div className="group-recents">
                    <span className="group-status group-all">All</span>
                </div>

                <div className="search-container">
                    <input className="form-control search-input" type="text" placeholder="Search" aria-label="Search" /*onChange={e => this.handleSearchChange(e.target.value)}*/ />
                </div>
                <div className="criteriaListWrap">
                    <div className="criteriaListHeader row" key="-1" value="-1">
                        <div className="filterNamePanel col-sm-4"><div className="groupPanel">Custom Dimensions</div></div>
                        <div className="exploreTypePanel col-sm-4"><div className="groupPanel">Dimension</div></div>
                        <div className="filterUpdatePanel col-sm-4"><div className="groupPanel">Last Updated</div></div>
                    </div>
                </div>
                {!loading
                && <ListItemPanel filterItems={existingFilters} />}
                <div className="filter-footer">
                    <div className="row">
                        <div className="col-xs-6">
                            <button type="button" className="btn btn-primary" onClick={this.enterNewGroupHandler}>Create New Group</button>
                        </div>
                        <div className="col-xs-6 text-right">
                            <button type="button" className="btn btn-default" onClick={this.closeGroupPanel}>Close</button>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        )
    }

    enterNewGroupHandler = () => {
        this.props.dispatch(Actions.enterNewFilterGroup());
    }

    closeGroupPanel = () => {
        this.props.dispatch(CustomDashboardFilterActions.groupPanelClose());
    }
}


const mapStateToProps = (state, ownProps) => {

    return {
        store: state,
        existingFilters: state.customFilters.existingFilters ? state.customFilters.existingFilters : [],
        selectedFilters: state.customFilters.selectedFilters,
        deleteItemId: state.deleteDialog.deleteItemId,
        currentUser: state.user.currentUser,
        iframeIndex: state.iframe.iframeIndex,
        customGroupDialog: state.customFilterCriteria.customGroupDialog,
        userTeams: state.user.userTeams,
        loading: state.customFilters.existingFilters ? false : true
    };
};


export default connect(mapStateToProps)(ListViewPanel);