import React, {Component} from 'react';
import {connect} from 'react-redux';
import * as Actions from "../../../redux/actions/sharing-actions";
import Modal from "react-modal";

class ShareDialog extends Component {

    markTeam = (teamId) => {
        if (this.props.sharedTeams!=null&&this.props.sharedTeams.includes(teamId)) {
            this.props.dispatch(Actions.removeTeam(teamId));
        } else {
            this.props.dispatch(Actions.addTeam(teamId));
        }
    }

    isTeamShared = (teamId) => {
        return this.props.sharedTeams && this.props.sharedTeams.includes(teamId);
    }

    save = () => {
        if (this.props.saveFunction) {
            this.props.saveFunction(this.props.shareItemId, this.props.sharedTeams);
        }
    }

    getTableContents = () => {
        let rows = [];
        let header = (
            <tr className="row table-header" key={-1}>
                <td className="col-md-2">Selected</td>
                <td className="col-md-8">Team Name</td>
            </tr>
        );

        rows.push(header);

        this.props.userTeams.forEach((team) => {
            rows.push(
                <tr className="row table-row" key={team.id}>
                    <td className="col-md-2">
                        <input type="checkbox" checked={this.isTeamShared(String(team.id))} onClick={this.markTeam.bind(this, String(team.id))} />
                    </td>
                    <td className="col-md-10">{team.name}</td>
                </tr>
            )
        })

        return (
            <table className="team-grid">
                {rows}
            </table>
        )
    }

    render() {
        const modalStyles = {
            content : {
                top                   : '60%',
                left                  : '60%',
                right                 : '20%',
                width                 : '30%',
                height                : '35%',
                bottom                : '35%',
                background            : 'white',
                marginRight           : '-50%',
                border                : '0',
                transform             : 'translate(-50%, -50%)',
                padding               : 'none',
                boxShadow             : '1px 2px 20px 2px grey',
                overflow              : 'none',
            },
            // Display this modal above all other modals
            overlay: {
                zIndex                : '1060'
            }
        };
        return (
            <Modal
                id="shareModal"
                isOpen={this.props.displayShareDialog}
                style={modalStyles}
            >
                <div className="dialogTitlePanel">
                    <span className="dialogTitle">
                        Share
                        {this.props.shareItemType}
                        (
                            {this.props.shareItemName}
                        )
                    </span>
                    <span className="closeActionIcon" onClick={() => this.props.dispatch(Actions.finishSharing())}>X</span>
                </div>
                <div className="share-modal-content">
                    {this.getTableContents()}
                </div>
                <div className="footerElement rightAlignPanel shareActionPanel">
                    <span>
                        <button type="button" onClick={() => { this.props.dispatch(Actions.finishSharing()); }} className="btn btn-default">Cancel</button>
                        <button
                            type="button"
                            onClick={this.save}
                            className="btn btn-default"
                        >
                            Ok
                        </button>
                    </span>
                </div>
            </Modal>
        );
    }
}

const mapStateToProps = (state) => {
   return {
       displayShareDialog: state.sharing.displayShareDialog,
       shareItemId: state.sharing.shareItemId,
       shareItemName: state.sharing.shareItemName,
       sharedTeams: state.sharing.sharedTeams,
       shareItemType: state.sharing.shareItemType,
       saveFunction: state.sharing.saveFunction,
       userTeams: state.user.currentUserTeams
   }
}

export default connect(mapStateToProps)(ShareDialog);