import React, {Component} from 'react';
import {connect} from 'react-redux';
import * as Actions from "../../../redux/actions/delete-dialog-actions";
import FancyModal from '../../modal/FancyModal';


/**
 * A generic "Delete" dialog.
 *
 * To use this component
 */
class DeleteDialog extends Component {

    render() {
        const options = {
            modalId: 'delete-modal',
            modalTitle: `Delete ${this.props.type || ''}?`,
            modalHeaderIcon: 'fas fa-exclamation-triangle',
        };
        const buttons = [
            {
                disabled: false,
                type: 'button',
                label: 'Cancel',
                classes: 'btn btn-sm btn-link',
                handle: () => this.props.dispatch(Actions.closeDeleteDialog())
            },
            {
                disabled: false,
                type: 'button',
                label: 'Delete',
                classes: 'btn btn-sm btn-primary',
                handle: () => this.props.delete()
            }
        ];

        return (
            <FancyModal options={options} buttons={buttons} isOpen={this.props.displayDeleteDialog}>
                <p>
                    Are you sure you want to delete this {this.props.type}?
                </p>
            </FancyModal>
        );
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        displayDeleteDialog: state.deleteDialog.displayDeleteDialog,
        type: state.deleteDialog.deleteDialogType,
        deleteItemId: state.deleteDialog.deleteItemId,
        delete: state.deleteDialog.deleteFunction
    };
};

export default connect(mapStateToProps)(DeleteDialog);