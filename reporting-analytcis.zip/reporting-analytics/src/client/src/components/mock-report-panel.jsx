import React, { Component } from "react";

class MockReportPanel{


    render(){
        return (
            <div>Mock Report Panel</div>
        );
    }

};

export default MockReportPanel;
