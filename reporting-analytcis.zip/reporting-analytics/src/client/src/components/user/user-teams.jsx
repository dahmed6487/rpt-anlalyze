import React, { Component } from "react";
import autoBind from "react-autobind";
import RecordRow from "../record/RecordRow";
import RecordMeta from "../record/RecordMeta";
import axios from 'axios';
import Alert from "../alert/alert";

class UserTeams extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);

        this.state = {
            user: "",
            teams: [],
            error: null,
            loading: true
        }
    }

    componentDidMount() {
        this.setState({
            user: this.props.user
        }, () => this.getTeams());
    }

    componentDidUpdate(prevProps) {
        if (this.props.user !== prevProps.user) {
            this.setState({
                user: this.props.user
            });
        }
    }

    render() {
        let { teams, loading, error } = this.state;

        return (
            <div>
                {error
                    && (
                    <Alert type={error.type}>
                        {error.text}
                    </Alert>
                    )}
                {loading
                    && <div>Loading...</div>}

                {(teams.length > 0 && loading === false)
                    && (
                    <div className="era-user-teams">
                        {teams.map((team, key) => (
                            <RecordRow key={key}>
                                <RecordMeta classes="col-md-4" label="Name" meta={team.name} />
                            </RecordRow>
                          ))}
                    </div>
                        )}

            </div>
        )
    }

    getTeams() {
        axios.get(`/api/user/teams?userId=${this.state.user}`)
            .then((response) => {
                this.setState({
                    teams: response.data,
                    error: null,
                    loading: false
                });
            })
            .catch((error) => {
                this.setState({
                    error: { text: 'There was an error getting teams for this user, please try again', type: 'warning' },
                    loading: false
                });
            });
    }
}

export default UserTeams;
