import React, { Component } from 'react';
import autoBind from 'react-autobind';
import { connect } from 'react-redux';
import axios from 'axios';
import Alert from '../alert/alert';
import Loading from '../ui/loading';
import { Link } from 'react-router-dom';
import { GetHumanReadableStatus } from '../../pages/administrator/admin-team-members-edit';
import { GetHumanReadableRole } from '../../pages/administrator/admin-users';
import UserService from '../../redux/services/user-service';

class UserForm extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);

        this.state = {
            originalUser: {},
            user: {},
            save: false,
            loading: false,
            error: null
        }
    }

    componentDidMount() {
        let userCategory = new Map();
        userCategory.set('Internal',[{key:'SA', name: 'Super Admin'}, {key:'IA', name: 'Internal Admin'}, {key:'IU', name: 'Internal User'}, {key:'ISA', name: 'Internal Sales'}, {key:'ISU', name: 'Internal Support'}]);
        userCategory.set('External',[{key:'CA', name: 'Customer Admin'},{key:'CU', name: 'Customer User'}]);
        this.setState({
            originalUser: this.props.user,
            user: this.props.user,
            userCategory: userCategory
        });
    }

    componentDidUpdate(prevProps) {
        if(this.props.user !== prevProps.user) {
            this.setState({
                user: this.props.user
            });
        }
    }

    // Disables Sudo login button if logged in user is accessing their own user profile
    isSudoLoginDisabled() {
        if (this.props.user.username.toUpperCase() === this.props.username.toUpperCase()) {
            return true;
        }
    }

    render() {
        const { save, loading, error, user, userCategory } = this.state;
        const categories = userCategory && userCategory.get(user.internal === "true" ? "Internal" : "External") || [];
        const editUserDiff = this.generateEditUserDiff();
        const sudoLoginDisabled = this.isSudoLoginDisabled();

        return (
          <div>
              {error
                    && (
                    <Alert type={error.type}>
                        {error.text}
                    </Alert>
                    )}
              {loading
                    && <Loading />}
              {save
                    && (
                    <Alert type="success">
                      User
                        {' '}
                        {this.username}
                        {' '}
                      has been saved.
                    </Alert>
)}
              <div className="form-group">
                  <label htmlFor="firstName">First Name</label>
                  <input
                        type="text"
                        name="firstName"
                        className="form-control"
                        value={user.firstName}
                        onChange={(e) => this.handleInputChange(e)}
                        placeholder="First Name"
                        disabled
                    />
                </div>
              <div className="form-group">
                  <label htmlFor="lastName">Last Name</label>
                  <input
                        type="text"
                        name="lastName"
                        className="form-control"
                        value={user.lastName}
                        onChange={(e) => this.handleInputChange(e)}
                        placeholder="Last Name"
                        disabled
                    />
                </div>
              <div className="form-group">
                  <label htmlFor="email">User Email Address</label>
                  <input
                        type="email"
                        name="email"
                        className="form-control"
                        value={user.email}
                        onChange={(e) => this.handleInputChange(e)}
                        placeholder="email@email.com"
                        disabled
                    />
                </div>
              <div className="form-group">
                  <label htmlFor="active">User Status</label>
                  <select
                        name="active"
                        value={user.active}
                        className="form-control"
                        onChange={(e) => this.handleInputChange(e)}
                    >
                      <option value="Y">User Enabled</option>
                      <option value="N">User Disabled</option>
                    </select>
                </div>
              <div className="form-group">
                  <label htmlFor="userRole">User Role</label>
                  <select
                        name="userRole"
                        value={user.userRole}
                        className="form-control"
                        onChange={(e) => this.handleInputChange(e)}
                    >
                    {
                    categories.map((category)=><option value={category.key}>{category.name}</option>)
                    }
                    </select>
                </div>

              <div id="eraEditUserModal" className="modal" style={{ height: 'fit-content' }} tabIndex="-1" role="dialog">
                  <div className="modal-dialog" role="document">
                      <div className="modal-content">
                          <div className="modal-header no-icon">
                              <button type="button" onClick={() => this.closeEditUserModal()} className="close" data-dismiss="modal" aria-label="Close">
                                  <span className="fa fa-times" />
                              </button>
                              <h4 className="modal-title">Confirm Edit</h4>
                            </div>
                          <div className="modal-body">
                              <p>Are you sure you want to make the following edits?</p>
                              {editUserDiff}
                            </div>
                          <div className="modal-footer">
                              <button type="button" onClick={() => this.closeEditUserModal()} className="btn btn-link btn-sm" data-dismiss="modal">Cancel</button>
                              <button type="button" onClick={() => this.confirmEditUser()} className="btn btn-primary btn-sm">Confirm</button>
                          </div>
                      </div>
                  </div>
              </div>

              <div id="eraSudoUserModal" className="modal" style={{ height: 'fit-content' }} tabIndex="-1" role="dialog">
                  <div className="modal-dialog" role="document">
                      <div className="modal-content">
                          <div className="modal-header no-icon">
                              <button type="button" onClick={() => this.closeLoginAsUserModal()} className="close" data-dismiss="modal" aria-label="Close">
                                  <span className="fa fa-times" />
                              </button>
                              <h4 className="modal-title">Confirm login as</h4>
                          </div>
                          <div className="modal-body">
                              <p>
                                  Are you sure you want to login as
                                  {' '}
                                  {(this.state.user).firstName + ' ' + (this.state.user).lastName}
                                  {' '}
                                  ?
                              </p>
                          </div>
                          <div className="modal-footer">
                              <button type="button" onClick={() => this.closeLoginAsUserModal()} className="btn btn-link btn-sm" data-dismiss="modal">Cancel</button>
                              <button type="button" onClick={() => this.confirmLoginAsUser()} className="btn btn-primary btn-sm">Confirm</button>
                          </div>
                      </div>
                  </div>
              </div>

                <div className={'form-footer'}>
                    <div className={'row'}>
                   <div className={'col-sm-6'}>
                       {this.props.originalUserSudoFlag===true && this.props.canSudo &&
                        <div className={'text-left'}>
                            <button disabled={sudoLoginDisabled} onClick={() => this.openLoginAsUserModal()} style={{"margin-left":"5px"}}
                            className={sudoLoginDisabled ? 'btn btn-default':'btn btn-primary'}>Login as this User</button>
                        </div>}
                    </div>
                    <div className={'col-sm-6'}>
                    <div className={'text-right'}>
                        <Link to={'/admin/users'} className={'btn btn-link'}>Cancel</Link>
                        <button onClick={() => this.openEditUserModal()} className={'btn btn-primary'}>Save</button>
                    </div>
                     </div>
                    </div>
                </div>
            </div>
        )
    }

    handleInputChange(e) {
        const value = e.target.value;
        const key = e.target.name;

        this.setState(prevState => ({
            user: {
                ...prevState.user,
                [key]: value
            }
        }))
    }

    saveUser() {
        axios.put('/api/user/update', this.state.user)
            .then((response) => {
                this.closeEditUserModal();
                this.setState({
                    error: null,
                    save: true
                }, () => PauseAndRedirect('#/admin/users'));
            }).catch((error) => {
                this.closeEditUserModal();
                this.setState({
                    error: { text: 'There was an error while updating this user, please try again.', type: 'warning' },
                    save: false
                });
            });
    }

    LoginAsUser() {
        UserService.getSudoUser((this.state.user).username)
            .then((response) => {
                localStorage.removeItem('finalUserAttribute');
                localStorage.removeItem('setViewAppliedDimensions');
                localStorage.removeItem('userAccount');
                window.location.reload();
              if(response.data === 'success'){
                  localStorage.removeItem('userAccount');
                  window.location.reload();
                  window.location = '/'
              }
                this.closeLoginAsUserModal();
            }).catch((error) => {
            this.closeLoginAsUserModal();
            this.setState({
                error: { text: 'There was an error while updating login as, please try again.', type: 'warning' },
                save: false
            });
        });
    }

    openLoginAsUserModal() {
        let modal = document.getElementById('eraSudoUserModal');
        if (modal) {
            modal.style.display = 'flex';
        }
    }

    closeLoginAsUserModal() {
        let modal = document.getElementById('eraSudoUserModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    openEditUserModal() {
        let modal = document.getElementById('eraEditUserModal');
        if (modal) {
            modal.style.display = 'flex';
        }
    }

    closeEditUserModal() {
        let modal = document.getElementById('eraEditUserModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    confirmEditUser() {
        this.saveUser();
    }

    confirmLoginAsUser() {
        this.LoginAsUser();
    }
    generateEditUserDiff() {
        const { user, originalUser } = this.state;
        let editUserElements = [];

        for (const property in user) {
            let originalValue = originalUser[property];
            let value = user[property];

            if (originalValue != undefined && originalValue !== value) {

                if (property == 'active' && originalValue != '') {
                    originalValue = GetHumanReadableStatus(originalValue);
                    value = GetHumanReadableStatus(value);
                }

                if (property == 'userRole' && originalValue != '') {
                    originalValue = GetHumanReadableRole(originalValue);
                    value = GetHumanReadableRole(value);
                }

                let hRProperty = CamelCaseToHumanReadable(property);
                if (originalValue == '') {
                    editUserElements.push(<p>
                      <b>{hRProperty}: </b>
                      {value}
                    </p>);
                } else {
                    editUserElements.push(<p>
                      <b>{hRProperty}: </b>
                      {originalValue}
                      {' '}
                      &#8594;
                      {' '}
                      {value}
                    </p>);
                }
            }
        }

        return editUserElements;
    }
}


export function PauseAndRedirect(href) {
    setTimeout(function () {
        window.location.href = href;
    }, 4000);
}

/**
 * @return {string}
 */
export function CamelCaseToHumanReadable(string) {
    if (string) {
        let result = string.replace( /([A-Z])/g, ' $1' );
        return result.charAt(0).toUpperCase() + result.slice(1);
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        userRole: state.accountSettings.userRole,
        username: state.accountSettings.username,
        canSudo: state.accountSettings.canSudo
    };
}
export default connect(mapStateToProps)(UserForm);
