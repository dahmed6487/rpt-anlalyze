import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Alert from '../alert/alert';

class UserPermissions extends Component {

    constructor(props) {
        super(props);
        this.state = {
            isSudoEnabled: props.user.isSudoEnabled,
            dataHistoryMonths: props.user.dataHistoryMonths,
            error: null,
            loading: false,
            success: false,
            showModal: false,
            contentChange: [],
            user: props.user
        }
    }

    handleSudoClick = (event) => {
        event.preventDefault();
        let isSudoEnabled = event.target.checked ? 'true' : 'false';
        this.setState({ isSudoEnabled });
    }

    handleDataHistoryMonthsClick = (event) => {
        event.preventDefault();
        let dataHistoryMonths = event.target.checked ? '60' : null;
        this.setState({ dataHistoryMonths });
    }

    handleCloseModal = (event) => {
        event.preventDefault();
        this.setState({ showModal: false, contentChange: [] });
    }

    handleSaveButton = (event) => {
        event.preventDefault();
        axios.get(`/api/user/username/${this.props.username}`).then((response) => {
            if (response.data.isSudoEnabled === this.state.isSudoEnabled && response.data.dataHistoryMonths === this.state.dataHistoryMonths) {
                this.setState({ error: { text: 'There were no changes made to save', type: 'warning' } })
            } else {
                if (response.data.isSudoEnabled !== this.state.isSudoEnabled) {
                    let sudoDifference = <p> Sudo Enabled: {response.data.isSudoEnabled} → {this.state.isSudoEnabled}</p>
                    let contentChange = this.state.contentChange;
                    contentChange.push(sudoDifference);
                    this.setState({ contentChange });
                }
                if (response.data.dataHistoryMonths !== this.state.dataHistoryMonths) {
                    let dataHistoryMonthsChange = <p>
                    {' '}
                    Data History
                                            Months:
                    {' '}
                    {response.data.dataHistoryMonths ? response.data.dataHistoryMonths : '36'}
                    {' '}
                    →
                    {' '}
                    {this.state.dataHistoryMonths ? this.state.dataHistoryMonths : '36'}
                                                  </p>
                    let contentChange = this.state.contentChange;
                    contentChange.push(dataHistoryMonthsChange);
                    this.setState({ contentChange });
                }

                this.setState({
                    showModal: true,
                    error: null,
                    loading: false,
                    success: false,
                    user: response.data
                });
            }
        })
    }

    handleUserPermissionsSave = () => {
        this.setState({
            contentChange: [],
            showModal: false,
            error: null,
            loading: true,
            success: false
        });

        let userProfile = {
            ...this.state.user,
            isSudoEnabled: this.state.isSudoEnabled,
            dataHistoryMonths: this.state.dataHistoryMonths
        }

        axios.put('/api/user/update', userProfile).then((response) => {
            this.setState({
                error: null,
                loading: false,
                success: true,
                contentChange: [],
                showModal: false
            })
        }).catch(error => {
            this.setState({
                success: false,
                error: { text: 'There was an error saving user permissions, please try again', type: 'warning' },
                loading: false,
                contentChange: [],
                showModal: false
            })
        })
    }


    render() {
        const { error, loading, success } = this.state;
        return (
            <div>
                {this.state.showModal && (
                                        <div
                                            className="modal"
                                              style={{ height: 'fit-content', display: 'flex' }}
                                              role="dialog"
                                        >
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header no-icon">
                                <button
                                        type="button"
                                        onClick={(event) => this.handleCloseModal(event)}
                                        className="close"
                                        data-dismiss="modal"
                                        aria-label="Close"
                                >
                                    <span className="fa fa-times" />
                                </button>
                                <h4 className="modal-title">Confirm Edit</h4>
                            </div>
                            <div className="modal-body">
                                <p>Are you sure you want to make the following edits?</p>
                                {this.state.contentChange.map((item) => {
                                    return item
                                })}
                            </div>
                            <div className="modal-footer">
                                <button
                                        type="button"
                                        onClick={(event) => this.handleCloseModal(event)}
                                        className="btn btn-link btn-sm"
                                        data-dismiss="modal"
                                >
                                Cancel
                                </button>
                                <button
                                        type="button"
                                        onClick={() => this.handleUserPermissionsSave()}
                                        className="btn btn-primary btn-sm"
                                >
                                Confirm
                                </button>
                            </div>
                        </div>
                    </div>
                                        </div>
                    )}
                <br />
                {error
                && (
                <Alert type={error.type}>
                    {error.text}
                </Alert>
                    )}
                {success
                && (
                <Alert type="success">
                    User Permissions for
                    {' '}
                    {this.props.user.username}
                    {' '}
                    has been saved.
                </Alert>
                    )}
                {loading
                && (
                <Alert type="info">
                    Saving, please wait...
                </Alert>
                    )}
                <div className="checkbox" style={{ display: 'flex', flexDirection: 'column' }}>
                    <label style={{ marginBottom: '5px' }}>
                      <input
                                type="checkbox"
                                checked={this.state.isSudoEnabled === 'true'}
                               onChange={(event) => this.handleSudoClick(event)}
                      />
                        Sudo Enabled
                    </label>
                    {'\n'}
                    <label>
                        <input
                                type="checkbox"
                                checked={this.state.dataHistoryMonths === '60'}
                               onChange={(event) => this.handleDataHistoryMonthsClick(event)}
                        />
                        Data History Months
                    </label>
                </div>
                <br />
                <div className="form-footer">
                    <div className="text-right">
                        <Link to="/admin/users" className="btn btn-link">Cancel</Link>
                        <button type="button" onClick={(event) => this.handleSaveButton(event)} className="btn btn-primary">
                        Save
                        </button>
                    </div>
                </div>
            </div>
        )
    }

}

export default UserPermissions;


//Notes

// Need both labels
// Need tab name
// Need tab tooltip