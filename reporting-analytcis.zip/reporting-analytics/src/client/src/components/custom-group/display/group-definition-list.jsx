import React from 'react';
import {connect} from 'react-redux';
import GroupDefinitionItem from './group-definition-item';
import * as UserUIActions from '../../../redux/actions/user-actions';
import LookerService from '../../../services/looker-service';

function GroupDefinitionList(props){
    const { group = {}, definitions = [] } = props;
    return(
        <React.Fragment>
            <div className="filterList">
                {(definitions.length > 0)
                && definitions.map((definition, key) => <GroupDefinitionItem definition={definition} key={key} group={group} />)
                }
           </div>
        </React.Fragment>
    );
}



const mapStateToProps = (state, ownProps) => {
    return {
        store: state
    };
};

export default connect(mapStateToProps)(GroupDefinitionList);