import React, {Component} from "react";
import autoBind from "react-autobind";
import Timezone from '../../../helpers/timezone';
import GroupDefinitionList from './group-definition-list';

export default class GroupViewFields extends Component{
    constructor(props){
        super(props);
        autoBind(this);

        this.state = {
            useOtherAsDefaultGroup: false
        };
    }

    componentDidMount() {
        this.setState({useOtherAsDefaultGroup: this.props.group.useOtherAsDefaultGroup || false});
    }

    componentDidUpdate(prevProps) {
        if(this.props.group.useOtherAsDefaultGroup !== prevProps.group.useOtherAsDefaultGroup) {
            this.setState({useOtherAsDefaultGroup: this.props.group.useOtherAsDefaultGroup  || false});
        }
    }

    render(){
        const { group = {}, saveValues, contentAccesses} = this.props;
        const { criteriaGroup = {} } = group;
        return (
            <React.Fragment>
                <div className="row">
                    <div className="col-md-6">
                        <div className="form-group">
                            <label htmlFor="name">Custom Group Name</label>
                            <input
                                   type="text"
                                   name="name"
                                   defaultValue={group.name || ''}
                                   onChange={saveValues}
                                   className="form-control"
                            />
                        </div>
                    </div>
                    <div className="col-md-2">
                        <div className="form-group">
                            <label htmlFor="explore">Explore</label>
                            <select
                                   name="explore"
                                   defaultValue={group.explore || 'if_ra_fact_invc_purch_hist'}
                                   onChange={saveValues}
                                   className="form-control"
                            >
                            {contentAccesses.map((item, index) => {
                                return <option value={item.host.replace('/explore/','')}>{item.title}</option>
                            })}
                            </select>
                        </div>
                    </div>
                </div>
                <div className="checkbox">
                    <label htmlFor="useOtherAsDefaultGroup">
                        <input
                               type="checkbox"
                               onChange={(e) => this.onUseOtherAsDefaultGroupChange(e)}
                               name="useOtherAsDefaultGroup"
                               defaultChecked={group.useOtherAsDefaultGroup}
                        />
                        Create a Definition for All Other
                    </label>
                </div>
                <div className="row">
                    <div className="col-md-12">
                        {this.state.useOtherAsDefaultGroup
                        && (
                            <div className="form-group col-md-6">
                                <label htmlFor="otherDefinition">All Other Alias</label>
                                <input type="text" name="otherDefinition" onChange={saveValues} className="form-control" defaultValue={group.otherDefinition || 'Other'} />
                            </div>
                        )}

                    </div>
                </div>
                <p><b>Group Definitions</b></p>
                <GroupDefinitionList group={group} definitions={criteriaGroup.filterCriteria || []} />
                {(group && group.lastUpdateDate)
                && (
                    <p className="xtra-top">
                    <b>Last Updated:</b>
                    {
                        Timezone.formatDateString(group.lastUpdateDate)
                    }
                    </p>
                   )}
            </React.Fragment>
        )
    }

    onUseOtherAsDefaultGroupChange(e) {
        this.setState({useOtherAsDefaultGroup : e.target.checked});
        this.props.saveValues(e);
    }
}
