import React, { Component } from "react";
import autoBind from 'react-autobind';

import CustomGroupItem from './custom-group-item';

export default class CustomGroupList extends Component{
	constructor(props) {
        super(props);
        autoBind(this);
    }

    sortByFilter(solutions) {
                return solutions.sort(function(a, b){
                    if(a.name < b.name) { return -1; }
                    if(a.name > b.name) { return 1; }
                    return 0;
                });
    }
    render(){
	    let { groupItems } = this.props;
        groupItems = this.sortByFilter(groupItems);
	    return(
	        <div className="filterList">
                {(groupItems.length > 0)
                ? groupItems.map((group, key) => <CustomGroupItem group={group} key={key} />)
                    : (
                    <div className="criteriaListPanelEmpty">
                        You have no Custom Groups. You can create one using the button below.
                    </div>
                    )}
            </div>
        );
    }
}
