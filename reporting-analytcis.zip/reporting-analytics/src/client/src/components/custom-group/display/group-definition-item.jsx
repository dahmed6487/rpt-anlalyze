import React, {Component} from 'react';
import {connect} from 'react-redux';
import autoBind from "react-autobind";
import ActionPanel from '../../action-panel';
import FilterActionPanel from '../../custom-filter-criteria/filter-action-panel';
import * as MyCustomGroupActions from '../../../redux/actions/custom-group-actions';

class GroupDefinitionItem extends Component{
 constructor(props, context) {
    super(props, context);
    autoBind(this);
  }

 render() {
    const { definition = {}, group = {} } = this.props;
    return(
        <div className="group-definition" onClick={this.actionDialog}>
            <div className="row">
                <div className="col-md-2">
                    <h4 className="no-margin">{definition.name}</h4>
                </div>
                <div className="col-md-3">
                    <p className="no-margin">{definition.associatedDimension}</p>
                </div>
                <div className="col-md-5">
                    <p className="era-def-value no-margin">{(definition.value ? definition.value.replace(/,/g, ', ') : '')}</p>
                </div>
                <div className="col-md-2">
                    <div className="pull-right">
                        <ActionPanel actionDialog={this.actionDialog} expanded={this.props.actionOpenForGroupId === this.props.definition.id}>
                            <FilterActionPanel group={group} curFilter={definition} />
                        </ActionPanel>
                    </div>
                </div>
            </div>
        </div>
    );
    }
    actionDialog = () => {
    if (this.props.actionOpenForGroupId === this.props.definition.id) {
        this.props.dispatch(MyCustomGroupActions.handleIndividualDefinitionClick(-1));
    } else {
        this.props.dispatch(MyCustomGroupActions.handleIndividualDefinitionClick(this.props.definition.id));
    }
          }
}

const mapStateToProps = (state, props) => {
  return{
       actionOpenForGroupId: state.customGroupCriteria.actionOpenForGroupId
  }
}

export default connect(mapStateToProps)(GroupDefinitionItem);