import React, {Component} from 'react';
import autoBind from "react-autobind";
import ActionPanel from '../../action-panel';
import {connect} from 'react-redux';
import Timezone from '../../../helpers/timezone';
import GroupActionPanel from '../../custom-filters/edit-view/group-action-panel';
import * as MyCustomGroupActions from '../../../redux/actions/custom-group-actions';

class CustomGroupItem extends Component{
constructor(props, context){
     super(props, context);
     autoBind(this);
}
  render() {
    const { group } = this.props;
    let sharedFilter = group.sharedTeams && group.sharedTeams.length > 0;

    let displayExplore = group.explore;    /* default */
    if (displayExplore === 'if_ra_fact_invc_purch_hist') {
        displayExplore = 'Purchase History';
    } else if (displayExplore === 'idb') {
        displayExplore = 'IDB';
    } else if (displayExplore === 'physical_inventory') {
        displayExplore = 'Physical Inventory';
    }else if (displayExplore === 'cust_acct_current') {
        displayExplore = 'Rebates';
    }else if (displayExplore === 'v_if_ra_dim_cust_acct_item') {
        displayExplore = 'Pricing Catalog';
    }

    return(
        <React.Fragment>
            <div
                className={sharedFilter ? 'criteriaListPanelNoBottomBorder row' : 'criteriaListPanel row'}
                onClick={this.actionDialog}
            >
                <div
                    className={'filterPanelCol col-sm-4 ' + (sharedFilter ? 'filterNamePanelNoBottomPadding' : 'filterNamePanel')}
                >
                    <div className="filterName">{group.name}</div>
                    <div className="filterAuthor">
                        <b>Owner</b>
                        : {group.author}
                    </div>
                </div>
                <div className="filterPanelCol exploreTypePanel col-sm-4">
                    <div>{displayExplore}</div>
                </div>
                <div className="filterPanelCol filterUpdatePanel col-sm-4 group-update-panel">
                    <div className="pull-right">
                        <ActionPanel actionDialog={this.actionDialog} expanded={this.props.actionOpenForCustomId === this.props.group.id}>
                            <GroupActionPanel filter={group} />
                        </ActionPanel>
                    </div>
                    {group.lastUpdateDate ? Timezone.formatDate(group.lastUpdateDate, ' - Updated') : Timezone.formatDate(group.creationDate, ' - Created')}
                </div>
            </div>
            {sharedFilter
            && (
                <div className="filterSharedTeamsPanel">
                    <div className="filterSharedTeamsText">
                        <div className="filterAuthor shared-filter">
                            <b>Shared Teams</b>
                            :
                            {getSharedTeamsDisplay(group.sharedTeams)}
                        </div>
                    </div>
                </div>
            )}
        </React.Fragment>
    )
}
    actionDialog = () => {
     if (this.props.actionOpenForCustomId === this.props.group.id) {
                this.props.dispatch(MyCustomGroupActions.handleIndividualActionClick(-1));
            } else {
                this.props.dispatch(MyCustomGroupActions.handleIndividualActionClick(this.props.group.id));
            }
      }
}

const getSharedTeamsDisplay = (teamIds) => {
    let results = '';

    for(var x=0;x<teamIds.length;x++){
        results += `${getTeamName(teamIds[x])}, `;
    }

    return results;
}

const getTeamName = (teamId) => {
    var curTeamId;
    var curTeamName;
    for(var x=0;x<this.props.userTeams.length;x++){
        curTeamId = this.props.userTeams[x].id;
        curTeamName = this.props.userTeams[x].name;
        if(curTeamId==teamId){
            return curTeamName;
        }
    }
    return '';
}

const mapStateToProps = (state, props) => {
  return{
       actionOpenForCustomId: state.customGroupCriteria.actionOpenForCustomId
  }
}
export default connect(mapStateToProps)(CustomGroupItem);