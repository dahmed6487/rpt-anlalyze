import React, {Component} from "react";
import autoBind from 'react-autobind';
import {connect} from "react-redux";
import * as Actions from '../../redux/actions/custom-filters-actions';
import {Helmet} from "react-helmet";
import LookerService from '../../services/looker-service';
import * as UserUIActions from '../../redux/actions/user-actions';
import CustomGroupList from './display/custom-group-list';
import GroupView from './group/group-view';
import Loading from '../ui/loading';
import {CUSTOM_GROUPS_CHECK} from "../../redux/constants/iframe-constants";

class CustomGroupView extends Component{

    constructor(props) {
        super(props);
        autoBind(this);

        this.state = {
            loading: true,
            groups: [],
            msg: ''
        }
    }

    componentDidMount(){
        this.loadGroups();
    }

    loadGroups(){
        LookerService.loadFilters().then((res) => {
            if(res.data){
                if(res.data.length>0){
                    this.props.dispatch({type: CUSTOM_GROUPS_CHECK, payload: {isUserHasCustomGroups: true}});
                } else {
                    this.props.dispatch({type: CUSTOM_GROUPS_CHECK, payload: {isUserHasCustomGroups: false}});
                }
                this.setState({
                    groups: res.data,
                    loading: false
                });
            }
        }).catch((err) => {
           this.setState({
               loading: false,
               msg: 'Groups were unable to be retrieved, please try again.'
           });
        });
    }

    copyFilter = () => {

        /*
            Load selected filter,
            then triger action
        */
        this.props.dispatch(Actions.loadFilter());
        LookerService.getFilter(this.props.selectedFilters[0])
            .then(
                (filterResponse)=>{
                    this.props.dispatch(Actions.filterLoaded());
                    this.props.dispatch(Actions.cloneFilter(filterResponse.data));
                }
            )
    }

    searchGroups(event){
        const value = event.target.value || null;
        this.setState({
            loading: true
        }, () => {
            if(value === null){
                this.loadGroups();
            } else {
                this.getSearchQuery(value);
            }
        })
    }

    getSearchQuery(value){
        LookerService.searchFilters(value).then((res) => {
            if(res.data){
                this.setState({
                    groups: res.data,
                    loading: false
                });
            }
        }).catch((err) => {
            this.setState({
                loading: false,
                msg: 'Groups were unable to be retrieved, please try again.'
            });
        });
    }

    isFilterSelected(){
        return this.props.selectedFilters && this.props.selectedFilters.length>0;
    }

    render(){
        const { loading = true, groups = [] } = this.state;

        return (
            <React.Fragment>
                <Helmet defer={false}>
                    <meta charSet="utf-8" />
                    <title>&quot;Custom Groups&quot;</title>
                </Helmet>
                <div className="group-recents">
                    <span className="group-status group-all">All</span>
                </div>

                <div className="search-container">
                    <input
                           className="form-control search-input"
                           type="text"
                           placeholder="Search"
                           aria-label="Search"
                           onChange={this.searchGroups}
                    />
                </div>
                <div className="criteriaListWrap">
                    <div className="criteriaListHeader row" key="-1" value="-1">
                        <div className="filterNamePanel col-sm-4"><div className="groupPanel">Custom Dimensions</div></div>
                        <div className="exploreTypePanel col-sm-4"><div className="groupPanel">Explore</div></div>
                        <div className="filterUpdatePanel col-sm-4"><div className="groupPanel">Last Updated</div></div>
                    </div>
                </div>
                {loading
                && <Loading />}
                {!loading
                && <CustomGroupList groupItems={groups} />}
                <div className="dialog-footer">
                    <div className="row">
                        <div className="col-xs-6">
                            <button type="button" className="btn btn-primary" onClick={this.enterNewGroupHandler}>Create New Group</button>
                        </div>
                        <div className="col-xs-6 text-right">
                            <button type="button" className="btn btn-default" onClick={this.closeGroupPanel}>Close</button>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        )
    }

    enterNewGroupHandler = () => {
        const dialogOptions = {
            title: 'Create New Group',
            content: <GroupView />
        };
        this.props.dispatch(UserUIActions.dialogOpen(dialogOptions));
    }

    closeGroupPanel = () => {
        this.props.dispatch(UserUIActions.dialogClose());
    }
}


const mapStateToProps = (state, ownProps) => {
    return {
        store: state,
        isUserHasCustomGroups:state.iframe.isUserHasCustomGroups
    };
};


export default connect(mapStateToProps)(CustomGroupView);