import React, { Component } from 'react';
import autoBind from 'react-autobind';
import Select from 'react-select';
import LookerService from '../../../services/looker-service';
import { connect } from 'react-redux';
import * as UserUIActions from '../../../redux/actions/user-actions';
import GroupView from './group-view';
import Loading from '../../ui/loading';
import {Helmet} from "react-helmet";

class GroupDefinitionView extends Component {
    constructor(props) {
        super(props);
        autoBind(this);

        this.searchTimeout = 0;

        this.state = {
            definition: {
                relationalOperator: 'in',
                value: [],
                name: ''
            },
            saving: false,
            error: '',
            loading: true,
            visibleDimensions: [],
            suggestions: [],
            criteriaUserInput: "",
            selectedDimension: "",
            loadingSuggestions: false,
            showSuggestions: false,
            emptySuggestions: false
        }
    }

    componentDidMount() {
        const { definition } = this.props;
        this.getDimensions(this.props.group.explore);

        if (definition && definition.id) {
            this.getDefinition(definition.id);
        } else {
            this.setState({
                loading: false
            });
        }
    }

    render() {
        const { saving, error, loading, definition, showSuggestions, loadingSuggestions, emptySuggestions } = this.state;

        const reactSelectStyles = { control: styles => ({ ...styles, minHeight: '43px' }) };

        const associatedDimensionSelectOptions = this.getAvailableDimensionControl();

        const criteria = definition.value.length > 0 ? Array.isArray(definition.value) ? definition.value : definition.value.split(',') : definition.value;

        const suggestionsElements = this.generateSuggestionsElements();
        return (
            <React.Fragment>
                <Helmet defer={false}>
                    <meta charSet="utf-8" />
                    <title>{this.props.title}</title>
                </Helmet>
                {loading
                && <Loading />}

                {!loading
                && (
                    <div className="group-definition-view">
                        <div className="row">
                            <div className="col-md-6">
                                <div className="form-group">
                                    <label htmlFor="name">Definition Name</label>
                                    <input
                                        name="name"
                                        type="text"
                                        defaultValue={definition.name || ''}
                                        className="form-control"
                                        onChange={(e) => this.onDefinitionNameChange(e.target.value)}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-12">
                                <div className="form-group">
                                    <label>Associated Dimension</label>

                                    <div className="era-associated-dimension-form">
                                        <div>
                                            <Select
                                                styles={reactSelectStyles}
                                                options={associatedDimensionSelectOptions}
                                                value={definition.dimension ? { label: definition.associatedDimension, value: definition.dimension } : ''}
                                                isClearable
                                                isSearchable
                                                cacheOptions
                                                onChange={this.handleAssociatedDimensionSelect}
                                                isLoading={associatedDimensionSelectOptions.length === 0}
                                                loadingMessage={() => { return 'Loading...'; }}
                                            />
                                        </div>
                                        <div>
                                            <select className="form-control" disabled>
                                                <option value="equalTo">is equal to</option>
                                            </select>
                                        </div>
                                        <form onSubmit={this.addCriteria}>
                                            <div className="era-suggestions-textbox-container">
                                                <div className="era-textarea-container">
                                                    <textarea
                                                        className="era-textarea form-control"
                                                        required
                                                        rows="1"
                                                        value={this.state.criteriaUserInput}
                                                        onChange={(e) => this.handleTextAreaChange(e)}
                                                    />
                                                    {showSuggestions
                                                    && (
                                                        <div className="era-textarea-suggestions">
                                                            {loadingSuggestions && <div className="era-loading-suggestions">loading...</div>}
                                                            {emptySuggestions && <div className="era-no-suggestions">no results</div>}
                                                            {suggestionsElements}
                                                        </div>
                                                        )}
                                                </div>
                                                <button type="submit" className="btn btn-primary btn-inverted" onClick={() => {this.setState({showSuggestions: false})}}>Add</button>
                                            </div>
                                        </form>
                                    </div>

                                </div>
                            </div>
                        </div>

                        {(criteria.length > 0)
                        && (
                            <div className="selected-values">
                                {criteria.map((value, key) => (
                                <span key={key} className="bubble" onClick={() => this.removeCriteria(value)}>
                                    {value}
                                    <i className="era-times-icon fas fa-times" />
                                </span>
                                    ))}
                            </div>
                            )}

                        {error
                        && <p className="red text-right">{error}</p>}
                    </div>
                    )}

                <div className="dialog-footer">
                    <div className="row">
                        <div className="col-xs-12 text-right">
                            <button
                                type="button"
                                className="btn btn-link"
                                onClick={() => this.cancelDefinitionEdit()}
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                className="btn btn-primary"
                                onClick={() => this.saveDefinition()}
                                disabled={saving}
                            >
                                Save
                            </button>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }

    onDefinitionNameChange(value) {
        this.setState((prevState) => ({
            definition: { ...prevState.definition, name: value }
        }));
    }

sortByFilter(solutions) {
        return solutions.sort(function(a, b){
            if(a.label < b.label) { return -1; }
            if(a.label > b.label) { return 1; }
            return 0;
        });
    }

    /**
     * A potentially large number of entries is returned from the API call, so it becomes necessary to group entries
     * prior to display.
     */
    getAvailableDimensionControl() {
        const { visibleDimensions } = this.state;

        //A collection of top level option group names is established
        let optionGroups = [];
        for (let x = 0; x < visibleDimensions.length; x++) {
            var curDimension = visibleDimensions[x];
            if (!optionGroups.includes(curDimension.view_label)) {
                optionGroups.push(curDimension.view_label);
            }
        }
        optionGroups = optionGroups.sort(this.sortValuesDescending);

        //Next, a map of all values is created with the name of each group as the key.
        let optGroupValues = [];
        let optGroupLabels = [];
        for (let curOptGroup of optionGroups) {
            optGroupValues[curOptGroup] = [];
            for (let curDimension of visibleDimensions) {
                if (curDimension.view_label == curOptGroup) {
                    if (optGroupLabels[curOptGroup] == undefined) {
                        optGroupLabels[curOptGroup] = [];
                        optGroupLabels[curOptGroup].push(curDimension.label_short);
                        optGroupValues[curOptGroup].push(curDimension);
                    }
                    else if (!optGroupLabels[curOptGroup].includes(curDimension.label_short)) {
                        optGroupValues[curOptGroup].push(curDimension);
                    }
                }
            }
        }

        let results = [];
        for (let curOptGroup of optionGroups) {
            let curOpts = [];
            let curLabels = [];
            for (let curOpt of optGroupValues[curOptGroup]) {
                if (!curLabels.includes(curOpt.label_short)) {
                    curLabels.push(curOpt.label_short);
                    curOpts.push(
                        {
                            value: curOpt.name,
                            label: curOpt.label_short
                        }
                    );
                }
            }
            curOpts = this.sortByFilter(curOpts);
            results.push(
                {
                    label: curOptGroup,
                    options: curOpts
                }
            );
        }

        return results;
    }

    getDimensions(explore) {
        LookerService.getVisibleDimensions(explore)
            .then((res) => {
                this.setState({
                    visibleDimensions: res.data
                });
            });
    }

    getDefinition(definitionId) {
        LookerService.getCriteria(definitionId).then((res) => {
            this.setState({
                definition: res.data,
                loading: false
            });
        });
    }

    addCriteria(event) {
        event.preventDefault();
        let criteriaUserInputArray = this.state.criteriaUserInput.split("\n");

        criteriaUserInputArray = criteriaUserInputArray.filter((v) => {
            return v !== "";
        });
        if (criteriaUserInputArray.length === 1)
            criteriaUserInputArray = criteriaUserInputArray[0].split(',');
        else
            criteriaUserInputArray = Array.isArray(criteriaUserInputArray) ? criteriaUserInputArray : criteriaUserInputArray.split(',');
        const definitionValues = this.state.definition.value;
        const result = criteriaUserInputArray.concat(Array.isArray(definitionValues) ? definitionValues : definitionValues.split(','));
        this.setState((prevState) => ({
            definition: { ...prevState.definition, value: result }
        }), () => this.setState({ criteriaUserInput: "" }));
    }

    removeCriteria(value) {
        const values = Array.isArray(this.state.definition.value) ? this.state.definition.value : this.state.definition.value.split(',');

        let filteredValues = values.filter((v) => {
            return v !== value;
        });

        this.setState((prevState) => ({
            definition: { ...prevState.definition, value: filteredValues }
        }));
    }

    handleAssociatedDimensionSelect(selectedOption) {
        if (selectedOption) {
            this.setState((prevState) => ({
                definition: { ...prevState.definition, associatedDimension: selectedOption.label, dimension: selectedOption.value },
                selectedDimension: selectedOption.value
            }));
        } else {
            this.setState((prevState) => ({
                definition: { ...prevState.definition, associatedDimension: null, dimension: null }
            }));
        }
    }

    cancelDefinitionEdit() {
        this.returnToGroup(this.props.group);
    }

    returnToGroup(group) {
        const dialogOptions = {
            title: 'Edit Custom Group',
            content: <GroupView group={group} />
        };
        this.props.dispatch(UserUIActions.dialogOpen(dialogOptions));
    }

    saveDefinition() {
        const { group } = this.props;
        const { definition } = this.state;
        if (!(definition.associatedDimension && definition.name && definition.value.length > 0)) {
            this.setState({error: 'Error: The required definition fields are missing. Please add Definition Name, Dimensions and try again.'});
            return;
        }

        if (Array.isArray(definition.value)) {
            definition.value = definition.value.join(",");
        }

        if (definition.id) {
            this.updateDefinition(group, definition);
            return;
        }

        this.createDefinition(group, definition);
    }

    createDefinition(group, definition) {
        LookerService.createCriteria(group.criteriaGroup.id, definition)
            .then(() => this.returnToGroup(group))
            .catch(this.definitionError);
    }

    updateDefinition(group, definition) {
        definition['group'] = group.criteriaGroup;
        LookerService.updateCriteria(definition.id, definition)
            .then(() => this.returnToGroup(group))
            .catch(this.definitionError);

    }

    definitionError() {
        this.setState({
            error: 'There was an error saving your definition, please try again.'
        });
    }

    handleTextAreaChange(e) {
        const textAreaValue = e.target.value;
        if (this.searchTimeout) clearTimeout(this.searchTimeout);
        this.setState({ criteriaUserInput: e.target.value });
        this.searchTimeout = setTimeout(() => {
            if (this.state.criteriaUserInput.length >= 2) {
                if (this.state.selectedDimension && textAreaValue) {
                    this.setState({
                        suggestions: [],
                        loadingSuggestions: true,
                        showSuggestions: true,
                        emptySuggestions: false
                    });
                    LookerService.getValuesForDimension(this.props.group.explore, this.state.selectedDimension, textAreaValue)
                        .then((response) => {
                            this.setState({
                                suggestions: response.data,
                                loadingSuggestions: false
                            });

                            if (response.data.length === 0) {
                                this.setState({ emptySuggestions: true });
                            } else {
                                this.setState({ emptySuggestions: false });
                            }
                        });
                }
            } else {
                this.setState({
                    suggestions: [],
                    showSuggestions: false
                });
            }
        }, 300);
    }

    generateSuggestionsElements() {
        let suggestionsElements = [];

        for (let suggestion of this.state.suggestions) {
            suggestionsElements.push(
                <div
                    className="era-suggestion-row"
                    onClick={() => {
                        this.setState({
                            suggestions: [],
                            loadingSuggestions: false,
                            emptySuggestions: false,
                            criteriaUserInput: suggestion,
                            showSuggestions: false
                        })
                    }}
                >
                    {suggestion}
                </div>
            );
        }

        return suggestionsElements;
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        store: state
    };
};

export default connect(mapStateToProps)(GroupDefinitionView);
