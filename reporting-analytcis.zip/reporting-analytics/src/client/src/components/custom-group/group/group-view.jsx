import React, {Component} from "react";
import {connect} from 'react-redux';
import autoBind from 'react-autobind';
import {Helmet} from "react-helmet";
import * as UserUIActions from '../../../redux/actions/user-actions';
import LookerService from '../../../services/looker-service';
import CustomGroupPanel from '../../../containers/custom-group-panel';
import Loading from '../../ui/loading';
import GroupViewFields from '../display/group-view-fields';
import GroupDefinitionView from './group-definition-view';

class GroupView extends Component{

    constructor(props, context) {
        super(props, context);
        autoBind(this);

        this.state = {
            saving: false,
            loading: true,
            error: null,
            group: {}
        };
    }

    componentDidMount() {
        const { group } = this.props;
        if(group && group.id){
            this.loadGroup(group);
        } else {
            this.loading(false);
        }
    }

    loading(isLoading){
        this.setState({loading: isLoading});
    }

    loadGroup(group){
        LookerService.getFilter(group.id).then((res) => {
            this.setState({
                group: res.data,
                loading: false
            })
        });
    }

    saveGroup(event){
        if(event) event.preventDefault();
        const { group } = this.state;

        if (!group.useOtherAsDefaultGroup && (!group.criteriaGroup || group.criteriaGroup.filterCriteria.length === 0)) {
            this.setState({error: 'Error: Your custom group is empty. Please Add a Definition using the + button to the left.'});
        } else {
            this.setState({
                saving: true
            }, () => {
                LookerService.saveFilter(group).then(this.cancelCriteriaGroupEdit)
                    .catch(() => {
                        this.setState({
                            saving: false,
                            error: 'There was an error saving your group, please try again.'
                        })
                    });
            });
        }
    }

    /*
        Event handler for cancel operation for current group edits.
    */
    cancelCriteriaGroupEdit = () =>{
        const dialogOptions = {
            title: 'Custom Groups',
            content: <CustomGroupPanel />
        };
        this.props.dispatch(UserUIActions.dialogOpen(dialogOptions));
    }

    addDefinition(event, group){
        if(event) event.preventDefault();

        LookerService.saveFilter(group).then((res) => {
            const title = `Add Group Definition to ${group.name}`;
                const dialogOptions = {
                    title: title ,
                    content: <GroupDefinitionView group={res.data} title={title}/>
                };
                this.props.dispatch(UserUIActions.dialogOpen(dialogOptions));
            }).catch(() => {
            })
    }

    /**
     * Panel presented when user is actively editing a group.
     */

    render(){
        const { saving, group = {}, loading, error = null } = this.state;
        return(
            <React.Fragment>
                <Helmet defer={false}>
                    <meta charSet="utf-8" />
                    <title>&quot;Edit Custom Group&quot;</title>
                </Helmet>
                {loading
                && <Loading />}
                {!loading
                && <GroupViewFields group={group} saveValues={this.saveValues} contentAccesses={this.props.contentAccesses} />}
                {error
                && <p className="red text-right">{error}</p>}
                <div className="dialog-footer">
                    <div className="row">
                    <div className="col-xs-6 text-left">
                    <a href="#" className="btn btn-default" onClick={(event) => this.addDefinition(event, group)}>Add Definition</a>
                    </div>
                        <div className="col-xs-6 text-right">
                            <button
                                type="button"
                                className="btn btn-link"
                                onClick={this.cancelCriteriaGroupEdit}
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                className="btn btn-primary"
                                onClick={this.saveGroup}
                                disabled={saving}
                            >
                                Save
                            </button>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }

    saveValues(event){
        const key = event.target.name;
        let value = event.target.value;

        if(event.target.type == 'checkbox'){
            value = event.target.checked;
        }

        this.setState((prevState) => ({
            group: { ...prevState.group, [key]: value }
        }));
    }

}

const mapStateToProps = (state, ownProps) => {
    return {
        store: state,
        contentAccesses: state.user.exploreContentAccesses
    };
};

export default connect(mapStateToProps)(GroupView);
