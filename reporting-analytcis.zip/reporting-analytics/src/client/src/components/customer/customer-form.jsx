import React, { Component } from "react";
import autoBind from "react-autobind";
import {Link} from "react-router-dom";
import axios from 'axios';

import Alert from "../alert/alert";
import {PauseAndRedirect} from "../user/user-form";

class CustomerForm extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);

        this.state = {
            customer: {},
            editedName: "",
            error: null,
            save: false
        }
    }

    componentDidMount() {
        this.setState({customer: this.props.customer});
    }

    componentDidUpdate(prevProps) {
         if(this.props.customer !== prevProps.customer) {
            this.setState({customer: this.props.customer});
        }
    }

    render() {
        const { customer, error, save } = this.state;
        let customerName = customer.customerName || customer.amdmEraOwnrName;

        return (
            <div className="user-form">
                {error
                && (
                    <Alert type={error.type}>
                        {error.text}
                    </Alert>
                    )}
                {save
                && (
                    <Alert type="success">
                        Customer
                         {customerName}
                          has been saved.
                    </Alert>
                    )}
                <div className="row">
                    <div className="col-md-6">
                        <div className="form-group">
                            <label htmlFor="customerName">Name</label>
                            <input
                                className="form-control"
                                type="text"
                                defaultValue={customerName || ''}
                                onChange={(event) => this.handleNameChange(event)}
                            />
                        </div>
                    </div>
                </div>

                <div id="eraSaveCustomerModal" className="modal" style={{ height: 'fit-content' }} tabIndex="-1" role="dialog">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header no-icon">
                                <button type="button" onClick={() => this.closeSaveCustomerModal()} className="close" data-dismiss="modal" aria-label="Close">
                                    <span className="fa fa-times" />
                                </button>
                                <h4 className="modal-title">Confirm Edit</h4>
                                </div>
                            <div className="modal-body">
                                <p>Are you sure you want to make the following edits?</p>
                                <p>
                                    {customerName}
                                    &#8594;
                                    {this.state.editedName}
                                </p>
                            </div>
                            <div className="modal-footer">
                                <button type="button" onClick={() => this.closeSaveCustomerModal()} className="btn btn-link btn-sm" data-dismiss="modal">Cancel</button>
                                <button type="button" onClick={() => this.confirmSaveCustomer()} className="btn btn-primary btn-sm">Confirm</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="form-footer">
                    <div className="text-right">
                        <Link to="/admin/customers" className="btn btn-link">Cancel</Link>
                        <button type="button" onClick={() => this.onSave()} className="btn btn-primary">Save</button>
                    </div>
                </div>

            </div>
        );
    }

    handleNameChange(event) {
        this.setState({editedName: event.target.value});
    }

    onSave() {
        let modal = document.getElementById("eraSaveCustomerModal");
        if (modal) {
            modal.style.display = "flex";
        }
    }

    saveCustomer(){
        let editedCustomer = this.state.customer;
        editedCustomer.customerName = this.state.editedName;
        axios.put('/api/customer/update', editedCustomer)
            .then(() => {
                this.setState({
                    error: null,
                    save: true
                }, () => PauseAndRedirect("#/admin/customers"))
            }).catch((error) => {
                this.setState({
                    error: { text: 'There was an error saving this customer, please try again', type: 'warning' },
                    save: false
                });
        });
    }

    closeSaveCustomerModal() {
        let modal = document.getElementById("eraSaveCustomerModal");
        if (modal) {
            modal.style.display = "none";
        }
    }

    confirmSaveCustomer() {
        this.saveCustomer();
        this.closeSaveCustomerModal();
    }
}

export default CustomerForm;
