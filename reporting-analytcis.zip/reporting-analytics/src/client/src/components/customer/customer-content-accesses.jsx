import React, { Component } from "react";
import autoBind from "react-autobind";
import axios from 'axios';
import Alert from "../alert/alert";
import {Link} from "react-router-dom";
import * as UserActions from "../../redux/actions/user-actions";

// React-Redux
import { connect } from 'react-redux';

class CustomerContentAccesses extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);

        this.state = {
            modules: [],
            contentAccesses: [],
            editedContentAccesses: [],
            error: null,
            save: false,
            saving: false,
            userAccount: null
        }
    }

    componentDidMount() {
        this.getModules();
        this.setState({userAccount: localStorage.getItem('userAccount')});
    }

    render() {
        const { error, save, saving } = this.state;
        const customerName = this.props.customer.customerName || this.props.customer.amdmEraOwnrName;
        const modules = this.generateModules();
        const contentAccessesDiff = this.generateContentAccessesDiff();

        return (
            <div>
                {error
                && (
                    <Alert type={error.type}>
                        {error.text}
                    </Alert>
                   )}
                {save
                && (
                    <Alert type="success">
                        Customer
                         {' '}
                         {customerName}
                         {' '}
                         has been saved.
                    </Alert>
                    )}
                {saving
                && (
                    <Alert type="info">
                        Saving, please wait...
                    </Alert>
                    )}

                {modules}

                <div id="eraSaveCustomerContentAccessesModal" className="modal" style={{ height: 'fit-content' }} tabIndex="-1" role="dialog">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header no-icon">
                                <button type="button" onClick={() => this.closeSaveCustomerContentAccessesModal()} className="close" data-dismiss="modal" aria-label="Close">
                                    <span className="fa fa-times" />
                                </button>
                                <h4 className="modal-title">Confirm Edit</h4>
                                </div>
                            <div className="modal-body">
                                <p>Are you sure you want to make the following edits?</p>
                                {contentAccessesDiff}
                            </div>
                            <div className="modal-footer">
                                <button type="button" onClick={() => this.closeSaveCustomerContentAccessesModal()} className="btn btn-link btn-sm" data-dismiss="modal">Cancel</button>
                                <button type="button" onClick={() => this.confirmSaveCustomerContentAccesses()} className="btn btn-primary btn-sm">Confirm</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="form-footer">
                    <div className="text-right">
                        <Link to="/admin/customers" className="btn btn-link">Cancel</Link>
                        <button type="button" onClick={() => this.onContentAccessesSave()} className="btn btn-primary">Save</button>
                    </div>
                </div>

            </div>
        )
    }

    getModules() {
        axios.get(`/api/module/get?moduleType=${this.props.moduleType}`)
            .then((response) => {
                this.setState({
                   modules: response.data
                }, () => this.getContentAccesses());
            })
            .catch((error) => {
                this.setState({
                    error: { text: 'There was an error getting content accesses, please try again', type: 'warning' },
                    save: false
                });
            });
    }

    getContentAccesses() {
        const id = this.props.customer.amdmEraOwnrPartyId;
        axios.get(`/api/customer/get/content-accesses?id=${id}&moduleType=${this.props.moduleType}`)
            .then((response) => {
                this.setState({
                    contentAccesses: response.data
                }, () => this.checkModulesByContentAccesses());
            })
            .catch((error) => {
                this.setState({
                    error: { text: 'There was an error getting this customer\'s content accesses, please try again', type: 'warning' },
                    save: false
                });
            });
    }

    checkModulesByContentAccesses() {
        for (const contentAccess of this.state.contentAccesses) {
            let module = document.getElementById(`era-${contentAccess}`);
            if (module) {
                module.checked = true;
            }
        }
    }

    generateModules() {
        let modules = [];

        for (const module of this.state.modules) {
            modules.push(
                <div className="checkbox">
                    <label>
                        <input id={`era-${module.title}`} type="checkbox" value={module.title} />
                        {module.title}
                    </label>
                </div>
            );
        }

        return modules;
    }

    generateContentAccessesDiff() {
        const { contentAccesses, editedContentAccesses } = this.state;
        const removedContentAccesses = contentAccesses.filter(module => !editedContentAccesses.includes(module));
        const addedContentAccesses = editedContentAccesses.filter(module => !contentAccesses.includes(module));

        const removedContentAccessesString = removedContentAccesses.length === 1 ? removedContentAccesses[0] : [ removedContentAccesses.slice(0, removedContentAccesses.length - 1).join(", "), removedContentAccesses[removedContentAccesses.length - 1] ].join(", ");
        const addedContentAccessesString = addedContentAccesses && (addedContentAccesses.length === 1 ? addedContentAccesses[0] : [ addedContentAccesses.slice(0, addedContentAccesses.length - 1).join(", "), addedContentAccesses[addedContentAccesses.length - 1] ].join(", "));

        return (
            <div>
                {removedContentAccesses.length > 0 && (
                    <div>
                        <span style={{ color: 'black' }}>Removed: </span>
                        {removedContentAccessesString}
                    </div>
                )}
                {addedContentAccesses.length > 0 && (
                    <div>
                        <span style={{ color: 'black' }}>Added: </span>
                        {addedContentAccessesString}
                    </div>
                )}
            </div>
        )
    }

    onContentAccessesSave() {
        this.setState({save: false});
        this.gatherEditedContentAccessesState();
        let modal = document.getElementById("eraSaveCustomerContentAccessesModal");
        if (modal) {
            modal.style.display = "flex";
        }
    }

    gatherEditedContentAccessesState() {
        let editedContentAccesses = [];

        for (const module of this.state.modules) {
            const inputElement = document.getElementById(`era-${module.title}`);
            if (inputElement.checked) {
                editedContentAccesses.push(module.title);
            }
        }

        this.setState({editedContentAccesses: editedContentAccesses});
    }

    getContentAccessesRequestBody() {
        let requestBody = [];

        for (const module of this.state.modules) {
            requestBody.push({
                module: module.title,
                accessible: this.state.editedContentAccesses.includes(module.title)
            });
        }

        return requestBody;
    }

    closeSaveCustomerContentAccessesModal() {
        const modal = document.getElementById("eraSaveCustomerContentAccessesModal");
        if (modal) {
            modal.style.display = "none";
        }
    }

    confirmSaveCustomerContentAccesses() {
        this.saveCustomerContentAccesses();
        this.closeSaveCustomerContentAccessesModal();
    }

    saveCustomerContentAccesses() {
        const id = this.props.customer.amdmEraOwnrPartyId;
        const contentAccessesRequestBody = this.getContentAccessesRequestBody();
        if (this.state.editedContentAccesses.length === 0) {
            this.setState({
                error: { text: 'User should have at least one access', type: 'warning' },
                save: false,
                saving: false
            });
        } else {
            this.setState({
                saving: true,
                save: false,
                error: null
            });

            axios.put(`/api/customer/update/content-accesses?id=${id}&moduleType=${this.props.moduleType}`, contentAccessesRequestBody)
                .then((response) => {
                    this.setState({
                        error: null,
                        save: true,
                        saving: false
                    }, () => this.getModules());

                    // Chain axios request to get updated contentAccesses
                    return axios.get(`/api/customer/get/content-accesses/${this.state.userAccount}`);
                }).then((rep) => {
                    // If the edited customer is the same as the account selected, dispatch current content accesses and update in real time
                    if (this.state.userAccount === this.props.customer.customerName || this.state.userAccount === this.props.customer.amdmEraOwnrName){
                        this.props.dispatch(UserActions.getExploreContentAccesses(rep.data));
                    }
                })
                .catch((error) => {
                    this.setState({
                        error: {
                            text: 'There was an error saving this customer\'s content accesses, please try again',
                            type: 'warning'
                        },
                        save: false,
                        saving: false
                    });
                });
        }
    }
}

const mapStateToProps = (state, ownProps) => {
    return { store: state };
};

export default connect(mapStateToProps)(CustomerContentAccesses)

