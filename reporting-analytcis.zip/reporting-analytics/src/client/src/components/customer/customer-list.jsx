import React, { Component } from 'react';
import RecordRow from '../record/RecordRow';
import RecordMeta from '../record/RecordMeta';
import autoBind from 'react-autobind';
import axios from 'axios';
import Alert from '../alert/alert';
import Loading from '../ui/loading';

export default class CustomerList extends Component{
    constructor(props) {
        super(props);
        autoBind(this);

        this.state = {
            customers: [],
            error: null,
            loading: true
        }
    }

    componentDidMount(){
        this.getCustomers();
    }

    render() {
        const { customers, loading, error } = this.state;
        return (
            <div className="customer-list">
                {error
                && <Alert type={error.type}>{error.text}</Alert>}
                {loading
                && <Loading />}
                {(customers.length > 0 && !loading && !error)
                && (
                    <div className="admin-era-list">
                        {customers.map((customer, key) =>
                            (
                            <RecordRow key={key}>
                                <RecordMeta classes="col-md-4" label="ID" meta={customer.customerId} />
                                <RecordMeta classes="col-md-4" label="ERA Owner Name" meta={customer.amdmEraOwnrName} />
                                <RecordMeta classes="col-md-4" label="ERA Owner ID" meta={customer.amdmEraOwnrPartyId} />
                                {/*<RecordMeta classes="col-md-2" label="Common Group ID" meta={customer.commonGroupId} />
                                <RecordMeta classes="col-md-2" label="Common Group Name" meta={customer.commonGroupName} />
                                <RecordMeta classes="col-md-2" label="Buying Group ID" meta={customer.buyingGroupId} />
                                <RecordMeta classes="col-md-2" label="Buying Group Name" meta={customer.buyingGroupName} />*/}
                            </RecordRow>
                            ))}
                    </div>
                )}
            </div>
        );
    }

    deleteCustomer(event){
        if(event) event.preventDefault();
        axios.get(`/api/customer/remove/${this.username}`).then((response) => {
            this.setState({
                error: null,
                customer: response.data,
                loading: false
            })
        }).catch(() => {
            this.setState({
                error: {text: 'There was an error while removing this customer, please try again.', type: 'danger'},
                save: false,
                loading: false
            });
        });
    }

    getCustomers(){
        axios.get(`/api/user/customers/${this.props.user}`).then((response) => {
            let customers = [];

            for (let r of response.data) {
                let customer = {
                    amdmEraOwnrPartyId: r.amdmEraOwnrPartyId,
                    amdmEraOwnrName   : r.amdmEraOwnrName,
                    commonGroupId     : r.commonGroupId,
                    commonGroupName   : r.commonGroupName,
                    buyingGroupId     : r.buyingGroupId,
                    buyingGroupName   : r.buyingGroupName,
                    customerId        : r.customerId
                };
                customers.push(customer);
            }

            if (customers.length === 0) {
                this.setState({
                    error: {text: 'No customers were found for this user.', type: 'info'},
                    customers: customers,
                    loading: false
                })
            } else {
                this.setState({
                    error: null,
                    customers: customers,
                    loading: false
                })
            }
        }).catch(() => {
            this.setState({
                error: {text: 'There was an error while loading customers, please try again.', type: 'danger'},
                loading: false
            });
        });
    }
}
