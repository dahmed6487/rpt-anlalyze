import React, { Component } from "react";
import autoBind from "react-autobind";
import axios from 'axios';
import Alert from "../alert/alert";

class CustomerAccounts extends Component {
    constructor(props) {
        super(props);
        autoBind(this);

        this.state = {
            accounts: [],
            error: null,
            loading: true
        }
    }

    componentDidMount() {
        this.getAccounts();
    }

    render() {
        const { error, loading } = this.state;
        let accounts = this.generateAccounts();

        return (
            <div className="era-customer-accounts-container">
                {error
                && (
                    <Alert type={error.type}>
                        {error.text}
                    </Alert>
                )}
                {loading
                && <div>Loading...</div>}
                <div className="era-customer-accounts-header" />
                <div className="era-customer-accounts">
                    {accounts}
                </div>
            </div>
        )
    }

    getAccounts() {
        axios.get(`/api/customer/get/accounts?id=${this.props.customer.amdmEraOwnrPartyId}`)
            .then((response) => {
                this.setState({
                    accounts: response.data,
                    error: null,
                    loading: false
                })
            }).catch((error) => {
                this.setState({
                    error: { text: `There was an error while getting accounts for this customer, please try again.`, type: 'warning' }
                });
            });
    }

    generateAccounts() {
        let accounts = [];

        for (let account of this.state.accounts) {
            accounts.push(
                <div className="era-account-row">
                    <div className="era-account-id">{account.customerAccountId}</div>
                    <div className="era-account-name">{account.customerAccountName}</div>
                    <div className="era-account-address">{account.address}</div>
                    <div className="era-account-city-state">
                        {account.city}
                        ,
                        {account.state}
                    </div>
                    <div className="era-account-zip">{account.zip}</div>
                </div>
            );
        }

        return accounts;
    }
}

export default CustomerAccounts;
