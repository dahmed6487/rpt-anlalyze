import React, {Component} from "react";

import axios from "axios";
import autoBind from "react-autobind";
import {connect} from 'react-redux';
import DefaultPanel from '../default-panel';
import {Helmet} from "react-helmet";


class WordpressEmbedFrame extends Component {

    constructor(props, context) {
        super(props, context);
        autoBind(this);
        this.actions = props.actions;
        this.state = {
            wordPressHelpLink :null
        };
    }

    componentDidMount() {
        axios
            .get(`/api/user/help/link`)
            .then(response =>{
                this.setState({wordPressHelpLink : response.data});
            });
    }


    render() {

        return (
            <div>
                <Helmet defer={false}>
                    <meta charSet="utf-8" />
                    <title>&apos;Need Help&apos;</title>
                </Helmet>
                <div className="home" style={{ marginTop: '49px' }}>
                    <div className="row">
                        <div className="outer-div">
                            {this.props.customGroupDialog && <DefaultPanel close={this.state.close} />}
                            <iframe
                                key={this.props.iframeIndex}
                                className="looker-iframe"
                                src={this.state.wordPressHelpLink}
                                scrolling="yes"
                                title="lookerIframe"
                                id="embedDashboard"
                            />
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state, props) => {
    return {}
}

export default connect(mapStateToProps)(WordpressEmbedFrame);