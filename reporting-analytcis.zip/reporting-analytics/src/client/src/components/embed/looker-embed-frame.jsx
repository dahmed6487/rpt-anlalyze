import React, {Component} from "react";

import axios from "axios";
import autoBind from "react-autobind";
import {SET_MOCK_USER} from '../../redux/constants/user-constants';
import {
    CUSTOM_GROUPS_CHECK,
    DASHBOARD_VALUES,
    INITIAL_ACCOUNT,
    RELOAD_DASHBOARD_EXPLORE_PANEL,
    SWITCH_ACCOUNT
} from '../../redux/constants/iframe-constants';
import {getIframeContentByUrl} from '../../redux/services/menu-service';
import {connect} from 'react-redux';
import * as CustomFilterCriteriaConstants from '../../redux/constants/custom-filter-criteria-constants';
import * as Actions from '../../redux/actions/looker-embed-actions';
import CustomFilterMgmntService from '../../redux/services/custom-filter-criteria-service';
import UserService from "../../redux/services/user-service";
import * as UserActions from "../../redux/actions/user-actions";
import * as SpaceManagementActions from '../../redux/actions/space-mgmnt-actions';
import DefaultPanel from '../default-panel';
import {Helmet} from "react-helmet";
import AsyncSelect from 'react-select/async';
import CustomerService from "../../redux/services/customer-service";
import Loading from "../ui/loading";
import lookerService from "../../services/looker-service";

class LookerEmbedFrame extends Component{

    constructor(props, context) {
        super(props, context);
        autoBind(this);
        this.actions = props.actions;
        this.state = {
            iframeUrl: "",
            allAccounts:[],
            isDropLoading :true,
            dashboardData:null,
            isExploreLoaded:false,
            top12Acc:[],
        };
    }

    componentDidMount() {
        this.props.dispatch({type: SWITCH_ACCOUNT, payload: ""});

        let acc = [],allAcc=[],top12Accs=[];
        CustomerService.getCustomersForUser()
            .then((response) => {
                    response.data.map((item, index) => {
                        if(this.props.userRole !=='SuperAdmin') {
                            if (index < 12) {
                                top12Accs.push({value: item.totalAccounts, label: item.amdmEraOwnrName})
                            }
                        }
                        allAcc.push({value: item.totalAccounts, label: item.amdmEraOwnrName})
                    });
                    this.setState({allAccounts:allAcc,isDropLoading:false,isExploreLoaded:true,top12Acc:top12Accs})
                }
            ).catch((err) => {
            this.setState({allAccounts:allAcc,isDropLoading:false,top12Acc:top12Accs})
        });

        axios
            .get(`/looker/dashboard/ids`)
            .then(response =>{
                this.setState({dashboardData : response.data});
            });
            lookerService.loadFilters().then((res) => {
                if(res.data.length>0){
                    this.props.dispatch({type: CUSTOM_GROUPS_CHECK, payload: {isUserHasCustomGroups: true}});
                }
            })
    }

    handleUserSelection = (event) => {
        let userId;
        let accounts = this.state.allAccounts;
        if(accounts.length === 1 ) {
            userId =  accounts[0][1];
        } else {
            userId = event==null || event===undefined ? null: event.label;
        }
        if(userId){
            this.props.dispatch({type: SET_MOCK_USER, payload: userId});
            this.loadTeamsForUser(userId);
            localStorage.setItem('userAccount', userId);
            this.getContentAccesses(userId);
        }
    }

    // Get explore content accessses when a customer is selected
    getContentAccesses(userAccount){
        axios.get(`/api/customer/get/content-accesses/${userAccount}`)
            .then((response) => {
                this.props.dispatch(UserActions.getExploreContentAccesses(response.data))
            }).catch((error) => {
                this.setState({
                    error: { text: 'There was an error getting this customer\'s content accesses, please try again', type: 'warning' },
                    save: false
                });
            });
    }

    loadTeamsForUser = (userId) => {
        if (!userId) {
            return () => {};
        }

        UserService.getTeamsForUser(userId)
            .then((teamsResponse) => {
                    this.props.dispatch(UserActions.loadTeamsForUser(teamsResponse.data));
                }
            ).catch((err) => {
        });
    }

    /*
        Display dialog which allows user to select which filters to apply to a dashboard.
    */

    getIframeContent = () => {
            return (
                <div className="home" style={{ marginTop: '49px' }}>
                    <div className="row">
                        <div className={this.props.isUserHasCustomGroups ? this.props.isDashBoardExploreLoaded === false ? 'iframe-placeholder' : 'outer-div' : 'outer-div'}>
                            {this.props.customGroupDialog && <DefaultPanel close={this.state.close} />}
                            <iframe
                                key={this.props.iframeIndex}
                                className={this.props.isUserHasCustomGroups ? this.props.isDashBoardExploreLoaded === false ? 'looker-explore-iframe' : 'looker-iframe' : 'looker-iframe'}
                                src={this.props.iframeUrl}
                                scrolling="no"
                                title="lookerIframe"
                                id="embedDashboard"
                            />
                        </div>
                    </div>
                </div>
            );

    }

    getReportContent = () => {

        if(this.state.allAccounts.length===1)
            localStorage.setItem('userAccount', this.state.allAccounts[0].label);
        const userAccount = localStorage.getItem('userAccount')
        this.props.dispatch({type: SET_MOCK_USER, payload: userAccount});
        if(userAccount=== null && this.state.allAccounts.length===0)
            return;
        if(userAccount){

                    if(this.state.dashboardData) {
                        !this.props.dashboardValues && this.props.dispatch({type: DASHBOARD_VALUES, payload: this.state.dashboardData});
                        let baseUrl;
                        if (this.props.match.url.startsWith("/explore")) {
                            let explore = this.props.contentAccesses.find(r => r.host === this.props.match.url);
                            baseUrl = explore.url;
                            console.log(baseUrl);
                        } else {
                            baseUrl = getIframeContentByUrl(this.props.match.url, this.state.dashboardData);
                        }
                        let urlComponents = this.props.match.url.split("/");
                        let embedComponents = baseUrl.split("/");
                        let exploreType, model, exploreRef;

                        if (urlComponents.find(element => element === "explore") && urlComponents.length > 2) {
                            exploreType = urlComponents[2];
                        }

                        if (embedComponents.find(element => element === "explore") && embedComponents.length > 4) {
                            model = embedComponents[3];
                            exploreRef = embedComponents[4];
                            this.props.dispatch(Actions.setEmbedRefs(model, exploreRef));
                        }

                        let reqUrl = baseUrl, finalUrl = '';
                        if (exploreType) {
                            if (urlComponents[1] === 'my-reports' || urlComponents[1] === 'team-reports') {
                                if (localStorage.getItem("finalUserAttribute") === null)
                                    reqUrl = reqUrl.indexOf("?") > -1 ? `${reqUrl}&exploreType=${exploreType}&customerId=${this.props.currentUser}&qid=${urlComponents[4]}` : `${reqUrl}?exploreType=${exploreType}&customerId=${this.props.currentUser}&qid=${urlComponents[4]}`;
                                else
                                    reqUrl = reqUrl.indexOf("?") > -1 ? `${reqUrl}&exploreType=${exploreType}&customerId=${this.props.currentUser}&qid=${urlComponents[4]}&finalUserAttribute=${localStorage.getItem("finalUserAttribute")}` : `${reqUrl}?exploreType=${exploreType}&customerId=${this.props.currentUser}&qid=${urlComponents[4]}&finalUserAttribute=${localStorage.getItem("finalUserAttribute")}`;
                            } else {
                                if (localStorage.getItem("finalUserAttribute") === null)
                                    reqUrl = reqUrl.indexOf("?") > -1 ? `${reqUrl}&exploreType=${exploreType}&customerId=${this.props.currentUser}` : `${reqUrl}?exploreType=${exploreType}&customerId=${this.props.currentUser}`;
                                else
                                    reqUrl = reqUrl.indexOf("?") > -1 ? `${reqUrl}&exploreType=${exploreType}&customerId=${this.props.currentUser}&finalUserAttribute=${localStorage.getItem("finalUserAttribute")}` : `${reqUrl}?exploreType=${exploreType}&customerId=${this.props.currentUser}&finalUserAttribute=${localStorage.getItem("finalUserAttribute")}`;
                            }
                        }

                        //Dashboard load operations will be in the format '/looker/dashboard/17'
                        const dashboardId = this.getSelectedDashboardId(reqUrl);
                        // If meta data has not been loaded for the selected dashboard, then perform API operation to fetch it prior to rendering the
                        // Iframe. The ordering is important here as model/explore/dimension data will need to be retrieved prior to to loading the iframe
                        // content as the act of loading the dashboard will fire an event related to the state of the dashboard filters. When this event
                        // is handled, the filter information will need to be updated with the contents of the first API call used to retrieve dashboard information.
                        // Basically, filter related events do not contain the model/explore/dimension related attributes that the 'save' filter funtionality is dependent
                        // upon.
                        if(dashboardId!=null&&this.props.filterMetaDataStatus==="none"){
                            this.props.dispatch({type: CustomFilterCriteriaConstants.ACTION_LOAD_DASHBOARD_META});
                            CustomFilterMgmntService.loadDashboardMetaData(dashboardId)
                                .then(
                                    (result)=>{
                                        this.props.dispatch({type: CustomFilterCriteriaConstants.EVENT_DASHBOARD_META_LOADED, payload: result.data });
                                        if (!this.props.iframeUrl||this.props.reloadIframe) {
                                            this.getEmbedUrl(reqUrl+"?customerId="+this.props.currentUser);
                                        }
                                    }
                                )
                        }
                        else{
                            if (!this.props.iframeUrl||this.props.reloadIframe) {
                                if (exploreType) {
                                    this.getEmbedUrl(reqUrl);
                                }else {
                                    if(localStorage.getItem("finalUserAttribute")===null){
                                        this.getEmbedUrl(reqUrl + "?customerId=" + this.props.currentUser);
                                    } else {
                                        this.getEmbedUrl(reqUrl + "?customerId=" + this.props.currentUser+"&finalUserAttribute="+localStorage.getItem("finalUserAttribute"));
                                    }
                                }
                            }
                        }
                    }

                    return this.getIframeContent();
                }
        else{
                /** TODO: Migrate to common component. */
                return (
                    <div className="select-user ">
                        <div>
                            <span className="far fa-user-circle user-icon" />
                            <div className="select-user-text ">Select Customer</div>
                        </div>
                        <hr />
                        <div>
                            <div className="select-user-account ">Please Enter a Customer Name or Six Digit Account Number</div>
                            <AsyncSelect
                                autoFocus={true}
                                cacheOptions
                                defaultOptions={this.state.top12Acc}
                                placeholder="Search"
                                className="select-customer-dropdown"
                                onChange={this.handleUserSelection}
                                loadOptions={this.filterAcc}
                                isSearchable={true}
                                isClearable={true}
                                isLoading={this.state.isDropLoading}
                                noOptionsMessage={this.noOptionsMessage}
                                theme={theme => ({
                                    ...theme,
                                    borderRadius: 0,
                                    colors: {
                                        ...theme.colors,
                                        primary25: '#ddd',
                                        primary: '#ddd',
                                    },
                                })}
                            />
                        </div>
                    </div>

                );
                this.handleUserSelection();
            }

        }

    filterAcc = async (inputValue) => {
        if (inputValue.length > 1) {
            if (isNaN(inputValue)) {

                let accounts = this.state.allAccounts;
                accounts = accounts.filter(i =>
                    i.label.toLowerCase().startsWith(inputValue.toLowerCase())
                );
                accounts = accounts.sort(function (a, b) {
                    return b.value - a.value
                });
                return accounts;
            } else {
                const response = await CustomerService.getCustomerByAccount(inputValue);
                const json = await response;
                if (json.data.length === 0) {
                    return null;
                } else {
                    /*  let temp=[];
                     json.data.map((item, index) => {
                         temp.push({value: item.amdmEraOwnrName, label: item.amdmEraOwnrName})
                     });*/
                    let accounts = this.state.allAccounts;
                    accounts = accounts.filter(i =>
                        i.label.toLowerCase().startsWith(json.data[0].amdmEraOwnrName.toLowerCase())
                    );
                    accounts = accounts.sort(function (a, b) {
                        return b.value - a.value
                    });
                    return accounts;
                }
            }

        }
    };

    noOptionsMessage = (inputValue) => {
        if (inputValue["inputValue"].length > 1) {
            let searchStrin = inputValue["inputValue"].toLowerCase();
            searchStrin = this.state.allAccounts.filter(acc => {
                return acc["label"].toLowerCase().indexOf(searchStrin) === 0;
            });
            if (searchStrin.length === 0) {
                return 'No Customers available';
            }
        } else {
            return 'Please type two characters or more to generate a list or type “All Accounts” to select all customers.';
        }
    }

        /**
         * Trigger async call to load the url that will be presented in the iframe.
         */
        getEmbedUrl = (reqUrl) => {
            this.props.dispatch({type: RELOAD_DASHBOARD_EXPLORE_PANEL, payload: {isDashBoardExploreLoaded: true}});
            axios
                .get(reqUrl)
                .then(res => {
                        this.props.dispatch({type: INITIAL_ACCOUNT,
                            payload: {iframeUrl: res.data,
                                reloadIframe: false}});
                    }
                )
        }

        getSelectedDashboardId = (reqUrl) => {
            if(reqUrl.startsWith('/looker/dashboard')){
                const urlTokens = reqUrl.split("/");
                return urlTokens[3];
            }
            return null;
        }

        /**
         * Prevent uncessary triggering of calls to the render() method, which in turn will trigger dashboard refreshes. The basic functionality
         * required by this component is to check for a selected account, and then conditionally display the iframe containing the selected dashboard.
         * The iframe interface will additionally feature the ability to launch a dialog used to managed 'applied' filters. Events such as
         * opening and closing the filter selection dialog should not trigger the rendering of the iframe/dashboard report component.
         *
         * Filter selection operations performed within the dialog will be broadcasted via the Looker API approach
         * (https://docs.looker.com/reference/embedding/embed-javascript-events#dashboard:filters:update). And any operations such as
         * opening/closing the dialog, or applying filters should not trigger re-rendering of the iframe component.
         *
         *
         *
         */
        shouldComponentUpdate = (nextProps, nextState) => {
            if(this.props.path && this.props.data.type &&this.props.data.type=="dashboard:run:start"){
                localStorage.setItem('filtersUrl', this.props.data.dashboard.absoluteUrl);
                this.props.dispatch(SpaceManagementActions.getValuesForFiltersUrl(this.props.data.dashboard.absoluteUrl));
                this.props.history.push(`?exploreType=${this.props.data.dashboard.absoluteUrl.slice(124, -1)}`);
            }
            //Initially the action item used to launch the 'custom filters' dialog will be disabled. Upon completion of the dashboard load,
            //we need to enable it.
            if(this.props.dashboardLoaded==false&&nextProps.dashboardLoaded==true){
                return true;
            }

            //Change in dialog display state should not trigger render of this component; instead the dialog component itself
            //is responsible for managing it's visibility.
            if(nextProps.editMode!=this.props.editMode){
                return false;
            }
            return true;
        }

        render() {
            if (this.props.data.type === 'explore:ready' && this.props.isUserHasCustomGroups)
                this.getExploreUrl()
            let title =(this.props.data.type=="dashboard:tile:start" || this.props.data.type=="dashboard:run:complete" || this.props.data.type=="page:properties:changed") && (this.props.data.dashboard===undefined?'':this.props.data.dashboard.title);
            if (this.props.match.path.startsWith("/explore")) {
                let explore = this.props.contentAccesses.find(r => r.host === this.props.match.url);
                title = explore.title;
            }
            if (this.props.data.type === 'explore:run:complete' && this.props.isDashBoardExploreLoaded===false && this.props.isUserHasCustomGroups){
                return (
                    <div><Loading/></div>
                )
            }
            if(this.state.isExploreLoaded) {
                return (
                    <div>
                        <Helmet defer={false}>
                            <meta charSet="utf-8" />
                            <title>{title}</title>
                        </Helmet>
                        {this.getReportContent()}
                    </div>
                );
            } else{
                return (
                    <div><Loading/></div>
                )
            }
        }

    getExploreUrl() {
        const exploreURL = this.props.data.explore.url.split("?");
        let urlComponents = exploreURL[0].split("/");
        let modelName=urlComponents[3], explore=urlComponents[4],
            qid=new URL("http://www.a.com/"+this.props.data.explore.url).searchParams.get("qid"), customerId=localStorage.getItem('userAccount');
        if(explore==='if_ra_fact_invc_purch_hist' || explore==='dt_contract_cust_buygroup' || explore==='idb' || explore==='physical_inventory') {
            lookerService.getDashboardExploreEmbedUrl(modelName, explore, qid, customerId)
                .then((res) => {
                    this.props.dispatch({
                        type: INITIAL_ACCOUNT,
                        payload: {
                            iframeUrl: res.data,
                            reloadIframe: false
                        }
                    });
                    this.props.dispatch({
                        type: RELOAD_DASHBOARD_EXPLORE_PANEL,
                        payload: {isDashBoardExploreLoaded: true}
                    });
                });
        } else{
            this.props.dispatch({
                type: RELOAD_DASHBOARD_EXPLORE_PANEL,
                payload: {isDashBoardExploreLoaded: true}
            });
        }
    }
}

    const mapStateToProps = (state, props) => {
    /*
        - appliedFilters: Tracks which filters have been 'selected' for the current screen. Initially, this array will be empty, and will
        only contain values after the user has launched the 'filter configuration' dialog, and making selections accordingly.
    */
    return{
        currentUser: state.user.currentUser,
        iframeIndex: state.iframe.iframeIndex,
        iframeUrl: state.iframe.iframeUrl,
        reloadIframe: state.iframe.reloadIframe,
        editMode: state.customFilterCriteria.editMode,
        dashboardLoaded: state.customFilterCriteria.dashboardLoaded,
        filterMetaDataStatus: state.customFilterCriteria.filterMetaDataStatus,
        customGroupDialog: state.customFilterCriteria.customGroupDialog,
        data: state.iframe.data,
        path: state.iframe.path,
        filtersUrl: state.iframe.filtersUrl,
        isLoading: state.customFilters.isLoading,
        isDashBoardExploreLoaded:state.iframe.isDashBoardExploreLoaded,
        isUserHasCustomGroups:state.iframe.isUserHasCustomGroups,
        userRole: state.accountSettings.userRole,
        contentAccesses: state.user.exploreContentAccesses,

    }
}

    export default connect(mapStateToProps)(LookerEmbedFrame);