import React, {Component} from 'react';
import autoBind from 'react-autobind';
import {connect} from 'react-redux';
import EditCustomGroupPanel from '../components/custom-filters/edit-view/edit-custom-group-panel';

class ActionPanel extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);
  }

  render() {
    const { expanded } = this.props;
    let action = ''
    if(this.props.editPanelActive){
        action = <EditCustomGroupPanel criteriaGroupsIndex={this.props.criteriaGroupsIndex}/>
    } else {
        action = this.props.children;
    }
    return  (
        <React.Fragment>
            <div className="menu-link">
              <div className="menu-link-sub">
                <div className="menu-link-action" onClick={this.props.actionDialog}>
                  <span className="custom-filters-text">Action</span>
                  {' '}
                  <span
                      className={'link-icon fas ' + (expanded ? 'fa-chevron-up' : 'fa-chevron-down') + ' ' + (this.props.customGroupDialog ? 'group-down' : 'link-down-user link-down-action')}
                  />
                </div>
              </div>
              <div className={'action-sub-links ' + (expanded ? 'show' : 'hide')}>
                {action}
              </div>
            </div>
        </React.Fragment>
    );
  }
}

const mapStateToProps = (state, props) => {
  return{
      store: state,
      currentUser: state.user.currentUser,
      customGroupDialog: state.customFilterCriteria.customGroupDialog,
      filterPanelActive: state.customFilterCriteria.filterPanelActive,
      editPanelActive: state.customFilterCriteria.editPanelActive
  }
}

export default connect(mapStateToProps)(ActionPanel);