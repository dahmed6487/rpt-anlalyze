import React from "react";
import {
  Divider,
  Space,
  Panels,
  List,
  Menu as LookerMenu,
} from "@looker/components";

import {MenuOpen, MenuClose} from "./../icons/svg"

// Components
import Menu from "../menu/menu";
import { connect } from "react-redux";
import cn from "classnames";

const Sidebar = ({ menuHandler, routes, isOpen, adminAccess }) => {
  const MenuComponent = isOpen ? MenuOpen : MenuClose;
  return (
    <Panels
      className={cn("sidebar", {
        "sidebar-open": isOpen,
        "sidebar-closed": !isOpen,
      })}
      style={{
        overflowY: "auto",
      }}
    >
      <Space
        mt="14px"
        mb="14px"
        ml="10px"
        style={{
          cursor: "pointer",
        }}
      >
        <MenuComponent
          id="leftNavCollapseButton"
          width="24"
          height="24"
          color="#386A9F"
          onClick={menuHandler}
        />
      </Space>
      <Divider
        mt="6px"
        mb="14px"
        ml="u2"
        mr="u2"
        style={{
          width: "235px",
          height: "0.5px",
        }}
      />
      <div className="sidebar-body">
      <List className="nav">
          {routes.length > 0 &&
            routes.map((route, key) => {
              if (route.menu === "sidebar") {
                if (route.role === "all")
                  return <Menu links={route} key={key} isOpen={isOpen} />;
                if (adminAccess)
                  return <Menu links={route} key={key} isOpen={isOpen} />;
              }
            })}
        </List>
      </div>
    </Panels>
  );
};

const mapStateToProps = (state, ownProps) => {
  return {
    adminAccess: state.accountSettings.adminAccess,
  };
};

export default connect(mapStateToProps)(Sidebar);
