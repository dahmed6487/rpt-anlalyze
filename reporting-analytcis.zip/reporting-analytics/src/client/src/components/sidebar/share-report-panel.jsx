import React, {Component} from "react";
import autoBind from "react-autobind";
import {connect} from 'react-redux';
import * as ReportActions from "../../redux/actions/space-mgmnt-actions";
import ReportManagementService from "../../redux/services/report-mgmnt-service";
import "../../less/components/bread-crumb.less";
let selectFolderMap = new Map();

class ShareReportPanel extends Component {

    constructor(props, context) {
        super(props, context);
        autoBind(this);
        this.actions = props.actions;
        this.state = {
            data: null,
            visible: props.visible,
            dataLoaded: false,
            breadCrumClicked:false,
            errorMsg:""
        };
    }

    componentDidMount() {
        let id;
        let mapLen=selectFolderMap.size===undefined?selectFolderMap.length:selectFolderMap.size;
        if (mapLen !== 0) {
            id = Array.from(selectFolderMap.keys())[mapLen - 1];
        } else {
            id = this.props.selectedFolderId
        }
        ReportManagementService.getChildFolders(id, false)
            .then((response) => {
                this.setState({data: response.data, dataLoaded: true,dataLoadError:false,errorMsg:""});
            })
            .catch((err) => {
                this.setState({errorMsg: "Error description : " + err.response.data.error_desc + ", Error id : " + err.response.data.error_id});
            });
    }

    handleFolderSelection = (selItem) => {
        this.setState({dataLoaded: false});
        let id = selItem.id === undefined ? selItem.externalId : selItem.id;
        ReportManagementService.getChildFolders(id, false)
            .then((response) => {
                this.setState({data: response.data, dataLoaded: true,breadCrumClicked:false,errorMsg:""});
            })
            .catch(this.setState({dataLoadError: true}));
        this.props.dispatch(ReportActions.displayFolderStructure(selItem), false);
    }

    displayFolderPath = () => {
        let breadCrumbs = [];
        let selectedSubFolderId = null;
        if (this.state.breadCrumClicked === true) {

        } else {
            if (this.props.selectedSubFolder === null) {  // folder not clicked and cancel and save after
                if(this.props.selectedFolderRow.selectedFolderMap==='') {
                    selectFolderMap.set(this.props.selectedFolderRow.externalId, this.props.selectedFolderRow);
                    selectedSubFolderId = this.props.selectedFolderRow.externalId;
                }
            else{
                let sdlf=JSON.parse(this.props.selectedFolderRow.selectedFolderMap);
                    for (var key in sdlf) {
                        selectFolderMap.set(sdlf[key][0],sdlf[key][1])
                    }
                }

            } else {
                let id = this.props.selectedSubFolder.id === undefined ? this.props.selectedSubFolder.externalId : this.props.selectedSubFolder.id;
                selectFolderMap.set(id, this.props.selectedSubFolder);
                selectedSubFolderId = this.props.selectedFolderRow.id;
            }
        }
        if (selectFolderMap.size !== 0) {
            selectFolderMap.forEach((item, index) => {
                if (index !== selectedSubFolderId) {
                    breadCrumbs.push(
                        <li
                            className="breadcrumb-item active"
                            style={{ color: '#333' }}
                            aria-current="page"
                            key={index}
                            onClick={() => this.handlebreadcrumbClick(item)}
                        >
                            <span className="selectableBreadcrumbLink">
                           <span className="generic-dialog-title">{item.name}</span>
                            </span>
                        </li>
                    );
                } else {
                    breadCrumbs.push(
                        <li className="breadcrumb-item" aria-current="page" key={index}>
                            <span className="selectableBreadcrumbLink">
                                <span
                                    className="generic-dialog-title"
                                >
                                    {item.name}
                                </span>
                            </span>
                        </li>
                    );
                }
            });
        }
        return (
            <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                    {breadCrumbs}
                </ol>
            </nav>
        );
    }

    handlebreadcrumbClick(selItem) {
        this.setState({dataLoaded: false,dataLoadError:false});
        let id = selItem.id === undefined ? selItem.externalId : selItem.id;
        ReportManagementService.getChildFolders(id, false)
            .then((response) => {
                this.setState({data: response.data, dataLoaded: true,dataLoadError:false,errorMsg:""});
            })
            .catch(this.setState({dataLoadError: true}));
        let found = false;

        if (selectFolderMap.size !== 0) {
            selectFolderMap.forEach((item, index) => {
                if (index === id) {
                    found = true;
                } else {
                    if (found)
                        selectFolderMap.delete(index);
                }
            });
        }
        this.setState({breadCrumClicked:true})
    }

    getTypeLabel = (item) => {
        return (
            <div>
                <a className="btn btn-info btn-sm" style={{ marginTop: '10px' }}>
                    <span className="glyphicon glyphicon-folder-close" />
{' '}
{item}
                </a>
            </div>
        );
    };

    closeFolderPathModal = (event) => {
        selectFolderMap.clear();
        event.preventDefault();
        this.props.dispatch(ReportActions.closeUserEditModal());
    };
    saveFolderPath = (event) => {
    let finalFolderPath="";
        if (selectFolderMap.size !== 0) {
            selectFolderMap.forEach((item, index) => {
                finalFolderPath=finalFolderPath+"/"+item.name;
            });
        }
        let updateTeamTemp=this.updatedSharedTeams(this.props.sharedTeams,this.props.selectedFolderRow.finalFolderPath,finalFolderPath);
        selectFolderMap.clear();
        this.props.dispatch(ReportActions.saveFolderPath(updateTeamTemp));
    };

    updatedSharedTeams = (sharedTeams, oldPath, newPath) => {
        var jsonObj=[];
         return sharedTeams.map(item => {
             let temp = Object.assign({}, item);
             if (temp.finalFolderPath === oldPath) {
                 temp.finalFolderPath = newPath;
                 temp.selectedFolderMap=JSON.stringify(selectFolderMap);
             }
             return temp;
         });
     }

    render() {
        return (
            <div className="">
                <div className="modal-header">
                    {' '}
                    {this.displayFolderPath()}
                    {' '}
                </div>
                <div className="modal-body" style={{ height: '330px' }}>
                    {this.state.dataLoaded === true
                        ? this.state.data.map((rep, i) => (
                            <div className="col-lg-3"
                                onClick={() => {
                                this.handleFolderSelection(rep)
                            }}
                            >
                                {this.getTypeLabel(rep.name)}
                            </div>
                          )) : (
                        <div>
                            {this.state.errorMsg === '' ? <div> Loading please wait...... </div> : (
                            <div>
                                {' '}
                                {this.state.errorMsg}
                                {' '}
                            </div>
                            )}
                        </div>
                      )}
                </div>
                <div className="filter-footer">
                    <button type="button" className="btn btn-default close-btn" onClick={this.closeFolderPathModal}>Cancel</button>
                    <button type="button" className="btn btn-primary" onClick={this.saveFolderPath}>Save</button>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state, props) => {
    return {
        store: state,
        currentUser: state.user.currentUser,
        selectedFolderId: state.spaceMgmnt.selectedFolderId,
        selectedSubFolder: state.spaceMgmnt.selectedSubFolder,
        folderPathUpdateMode: state.spaceMgmnt.folderPathUpdateMode,
        sharedTeams:state.spaceMgmnt.sharedTeams,
    }
};
export default connect(mapStateToProps)(ShareReportPanel);
