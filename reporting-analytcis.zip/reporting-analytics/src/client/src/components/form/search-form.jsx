import React, { Component } from "react";
import autoBind from 'react-autobind';

class SearchForm extends Component {
    constructor(props) {
        super(props);
        autoBind(this);

        this.searchTimeout =  0;

        this.state = {
            searchTerm: ""
        }
    }

    render() {
        this.toggleClearButton();

        return (
            <div className="form-group searchInput">
                <label htmlFor="search" className="hide">Search</label>
                <input
                    id="era-search-bar"
                    type="text"
                    name="search"
                    placeholder={this.props.placeHolder}
                    className="form-control"
                    value={this.state.searchTerm}
                    onChange={(e) => this.handleSearchValueChange(e)}
                />
                <button id="era-search-bar-clear-button" type="button" className="era-search-clear-button btn bg-transparent" onClick={() => this.clearInput()}>
                    <i className="fa fa-times" />
                </button>
            </div>
        );
    }

    toggleClearButton() {
        let clearButton = document.getElementById("era-search-bar-clear-button");
        if (clearButton) {
            if (this.state.searchTerm === "") {
                clearButton.style.display = "none";
            } else {
                clearButton.style.display = "inline";
            }
        }
    }

    clearInput() {
        this.setState({searchTerm: ""});
        this.props.onChange("");
    }

    handleSearchValueChange(e) {
        e.persist();
        this.setState({ searchTerm: e.target.value});

        if (this.searchTimeout) clearTimeout(this.searchTimeout);
        this.searchTimeout = setTimeout(() => {
            this.props.onChange(e.target.value);
        }, 300);
    }
}

export default SearchForm;
