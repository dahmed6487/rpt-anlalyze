import React, { Component } from 'react';
import { HashRouter, Route, Redirect } from 'react-router-dom';
import autoBind from 'react-autobind';

import routes from '../../routes';
import Nav from '../../components/header/nav';
import Sidebar from '../../components/sidebar/sidebar';
import IFrameEventListener from '../../components/embed/iframe-event-listener'

import { connect } from 'react-redux';
import * as UserActions from "../../redux/actions/user-actions";
import axios from "axios";

import ShareDialog from '../../components/custom-filters/dialog/share-dialog';
import DeleteDialog from '../../components/custom-filters/dialog/delete-dialog';
import Spinner from '../../components/ui/spinner';
import LookerEmbedFrame from '../../components/embed/looker-embed-frame';
import Dialog from '../../components/modal/Dialog';

class DefaultLayout extends Component {
  constructor(props) {
    super(props);
    autoBind(this);

    this.state = {
      sidebar: true
    };
  }

  componentDidMount() {
  // Dispatch content accesses on initial mounting and every time the page refreshes
    let userAccount = localStorage.getItem('userAccount') || this.props.currentUser;
    if (userAccount) {
        axios.get(`/api/customer/get/content-accesses/${userAccount}`)
        .then((response) => {
            this.props.dispatch(UserActions.getExploreContentAccesses(response.data))
        }).catch((error) => {
            this.setState({
                error: { text: 'There was an error getting this customer\'s content accesses, please try again', type: 'warning' },
                save: false
            });
        });
    }
  }

  // Deep copy routes so there are no changes to original array when filtering the second level/ Explore routes
  copyRoutes(item) {
    if (typeof item === 'object') {
        let copiedItem = Array.isArray(item) ? [] : {};
        for (const key in item) {
            let value = item[key];
            copiedItem[key] = this.copyRoutes(value);
        }
        return copiedItem;
    } else {
        return item;
    }
  }


  renderRoutes(filteredRoutes) {
    let adminAccess = this.props.adminAccess;
    let routeArr =[];
    filteredRoutes.forEach(function (route) {
      if (route.role === 'all') {
        routeArr.push(route);
      }
      if (adminAccess && route.role === 'Admin') {
        routeArr.push(route);
      }
    });
    filteredRoutes.forEach(function (item) {
      item.routes &&
        item.routes.forEach(function (route) {
          routeArr.push(route);
        });
    });
    filteredRoutes.forEach(function (item) {
      item.routes &&
        item.routes.forEach(function (subitem) {
          subitem.routes &&
            subitem.routes.forEach(function (route) {
              routeArr.push(route);
            });
        });
    });
    return routeArr.map((route, index) => {
      if (this.props.authenticated) {
        const routeProps = route.props || {};
        return (<Route
          key={index}
          path={route.path}
          exact={route.exact}
          render={(props) => (React.createElement(route.component, { ...props, ...routeProps }))}
          authenticated={this.props.authenticated}
        />)
      } else {
        return (<Route
          path='/'
          exact={true}
          component={LookerEmbedFrame}
        />)
      }
    });
  }

// Filter routes based off of Explore Content Accesses. Customers without access to specific modules will not be able to access the routes
  filterRoutes(filterArray) {
      let contentAccesses = this.props.contentAccesses;
      filterArray.forEach((item) => {
          if (item.header === 'Explore'){
              let filter = [];

//            By iterating through contentAccesses, we can skip inaccessible routes and add missing routes that may be in the Module table
              contentAccesses.forEach((access, index) => {
                  let match = item.routes.find(r => r.menuTitle === access.title);
                   if (match)
                   {
                      filter.push(match);
                  }
                  else {
                      filter.push({
                             path: access.host,
                             menuTitle: access.title,
                             exact: true,
                             header: access.title,
                             component: LookerEmbedFrame
                      });
                  }
              });
//            Replace Explore routes with the accessible routes
              item.routes = filter;
          }
      });
      return filterArray;
  }

  render() {
    const { sidebar } = this.state;
    let solutionsPanel = document.getElementById('solutionsPanel');
    let routeCopy = this.copyRoutes(routes);
    const filteredRoutes = this.filterRoutes(routeCopy);

    if (solutionsPanel) {
      if (sidebar) {
        solutionsPanel.style.left = '250px';
      } else {
        solutionsPanel.style.left = '50px';
      }
    }

    let pagerefreshed = null;

    if (localStorage.getItem('_session_expired_windowLocation') === 'null')
      localStorage.setItem('_session_expired_windowLocation', '');

    if (document.cookie.indexOf('pagerefreshedcookie') == -1) {
      document.cookie = 'pagerefreshedcookie=1';
      pagerefreshed = false;
    } else {
      pagerefreshed = true;
    }
    return (
      <React.Fragment>
        <IFrameEventListener />
        <HashRouter>
          <div
            id="page-content"
            className="default-layout"
          >
            <Nav
              menuHandler={this.menuHandler}
              routes={filteredRoutes}
              sidebar={sidebar}
            />
            <div className={'main-content ' + (sidebar ? 'sidebar-open' : 'sidebar-closed')}>
              <div className="main-content-wrapper">
                {this.props.eraAccess ?
                <Sidebar
                  menuHandler={this.menuHandler}
                  routes={filteredRoutes}
                  isOpen={sidebar}
                /> :"" }
                <div className="page-display">
                  <div className="page-body">
                    {this.props.eraAccess ?
                    <div className="page-body-content">
                      {this.props.isLoading && <Spinner />}
                      <ShareDialog />
                      <DeleteDialog />
                      {this.renderRoutes(filteredRoutes)}
                      {!pagerefreshed && (
                      <Redirect
                        to={{
                          pathname: localStorage.getItem('_session_expired_windowLocation') === null ? '' : localStorage.getItem('_session_expired_windowLocation')
                        }}
                      />
                      )}
                    </div> :<div className="error_page-body-content">{this.props.errorMsg}</div>}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Dialog sidebar={sidebar} />
        </HashRouter>
      </React.Fragment>
    );
  }

  menuHandler() {
    this.setState(state => ({
      sidebar: !state.sidebar
    }));
  }
}

const mapStateToProps = (state, ownProps) => {
  return {
    isLoading: state.application.isLoading,
    adminAccess: state.accountSettings.adminAccess,
    contentAccesses: state.user.exploreContentAccesses,
    currentUser: state.user.currentUser
  }
}

export default connect(mapStateToProps)(DefaultLayout);