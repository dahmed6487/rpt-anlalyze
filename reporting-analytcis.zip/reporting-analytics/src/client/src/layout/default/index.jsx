import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import {HashRouter} from 'react-router-dom';
import {store} from '../../redux/state/index';
import {Provider} from 'react-redux';
import Login from '../../components/login/login';
import BrowserError from '../../components/login/browser-error';
import axios from 'axios';
import { isIE } from 'react-device-detect';
import {  ComponentsProvider } from '@looker/components';


if (true) {
    axios.interceptors.response.use(function (response) {
        function validHTML(html) {
            let openingTags, closingTags;
            html = html.replace(/<[^>]*\/\s?>/g, '');
            html = html.replace(/<(br|hr|img).*?>/g, '');
            openingTags = html.match(/<[^\/].*?>/g) || [];
            closingTags = html.match(/<\/.+?>/g) || [];
            return openingTags.length === closingTags.length ? true : false;
        }

        if (typeof response.data === 'string') {
            if (!validHTML(response.data)) {
                localStorage.setItem('_session_expired_windowLocation', localStorage.getItem('_windowLocation'));
                document.cookie = 'pagerefreshedcookie=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
                window.location.reload();
            }
        } else {
            localStorage.setItem('_windowLocation', window.location.hash.replace('#/',''));
        }
        return response;
    }, function (error) {
        if (error.response != null && error.response.status === 401) {
           // window.location = "/";
        }
        return Promise.reject(error);
    });
}
if (isIE) {
    ReactDOM.render(<HashRouter><ComponentsProvider><BrowserError /></ComponentsProvider></HashRouter>, document.getElementById('root'));
}
else {
    ReactDOM.render(<Provider store={store}><HashRouter><ComponentsProvider><Login /></ComponentsProvider></HashRouter></Provider>, document.getElementById('root'));
}