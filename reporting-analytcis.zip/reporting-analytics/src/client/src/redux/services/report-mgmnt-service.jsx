import axios from 'axios';
import * as SpaceManagementConstants from '../../constants/space-mgmnt-constants';

const API_ENDPOINT = '/report-management/user';
const TEAM_API_ENDPOINT = '/report-management/team';
const DASHBOARD_API_ENDPOINT = '/looker';

const ReportManagementService = {

    getApiPrefix(isTeamMode){
        if(!isTeamMode||isTeamMode===false){
            return API_ENDPOINT;
        }
        return TEAM_API_ENDPOINT;
    },

    shareReport: function (id, title, description,teams,teamIds, isTeamMode,overWriteFlag){
        const reqUrl = `${this.getApiPrefix(isTeamMode)}/report/share/${id}`;
        return axios.post(reqUrl, {id:id,title: title, description: description,teams:teams, teamIds:teamIds, overWriteFlag :overWriteFlag});
    },

    shareDashboard: function (id, title, description,teams, isTeamMode,overWriteFlag){
        const reqUrl = `${this.getApiPrefix(isTeamMode)}/dashboard/share/${id}`;
        return axios.post(reqUrl, {id:id,title: title, description: description,teams:teams, overWriteFlag :overWriteFlag});
    },

    getChildFolders: function (folderId, isTeamMode){
        return axios.get(`${this.getApiPrefix(isTeamMode)}/folder/${folderId}/children`);
    },

    getReportObjects: function(currentCustomer, selectedFolder, isTeamMode){
        let reqUrl = "";
        if(selectedFolder && selectedFolder>0){
            reqUrl = this.getApiPrefix(isTeamMode) +"/objects/"+ selectedFolder;
        }
        else{
            if(isTeamMode)
                   reqUrl = `/report-management/team/`+currentCustomer+`/objects`;
            else
            reqUrl = this.getApiPrefix(isTeamMode) + `/objects`;
        }
        return axios.get(reqUrl);
    },

    /**
     * 
     * @param {*} ids 
     */
    deleteFolder: function(folderId, isTeamMode){
        return axios.delete(`${this.getApiPrefix(isTeamMode)}/folder/${folderId}`);
    },

    /**
     * 
     * @param {*} ids 
     */
    deleteReport: function(reportId, isTeamMode){
        return axios.delete(`${this.getApiPrefix(isTeamMode)}/report/${reportId}`);
    },

    /**
     * 
     * @param {*} ids 
     */
    deleteDashboard: function(dashboardId, isTeamMode){
        return axios.delete(`${this.getApiPrefix(isTeamMode)}/dashboard/${dashboardId}`);
    },

    /**
     * 
     * @param {*} id 
     * @param {*} isFavorite 
     */
    toggleSelectedFolderFavoriteStatus: function(id, isFavorite, isTeamMode){
        const reqUrl = `${this.getApiPrefix(isTeamMode)}/folders/${id}`;
        return axios.put(reqUrl, { id: id, favorite: isFavorite});
    },

    /**
     * 
     * @param {*} id 
     * @param {*} isFavorite 
     */
    toggleSelectedReportFavoriteStatus: function(id, isFavorite, isTeamMode){
        const reqUrl = `${this.getApiPrefix(isTeamMode)}/folders/${id}`;
        return axios.put(reqUrl, { id: id, favorite: isFavorite});
    },

    /**
     * 
     * @param {*} id 
     * @param {*} isFavorite 
     */
    toggleSelectedDashboardFavoriteStatus: function(id, isFavorite, isTeamMode){
        const reqUrl = `${this.getApiPrefix(isTeamMode)}/folders/${id}`;
        return axios.put(reqUrl, { id: id, favorite: isFavorite});
    },

    saveDashboardChanges: function(id, name, description, isTeamMode){
        const reqUrl = `${this.getApiPrefix(isTeamMode)}/dashboards/${id}`;
        return axios.put(reqUrl, {name: name, description: description});
    },

    saveReportChanges: function (id, name, description, isTeamMode){
        const reqUrl = `${this.getApiPrefix(isTeamMode)}/reports/${id}`;
        return axios.put(reqUrl, {name: name, description: description});
    },

    saveNewFolderChanges: function(title, parentFolder, isTeamMode,customerName){
        let reqUrl =null;
        if(isTeamMode)
             reqUrl = `${this.getApiPrefix(isTeamMode)}`+`/`+customerName+`/folders`;
        else
         reqUrl = `${this.getApiPrefix(isTeamMode)}/folders`;
            
        if(parentFolder){
            return axios.post(`${reqUrl}/${parentFolder.id}/children`, {name: title});
        }
        else{
            return axios.post(`${reqUrl}/children`, {name: title});
        }
    },

    /**
     * Given a selected folder id, retrieve dashboard references within the selected 
     * folder. 
     * 
     * @param {*} folderId
     */
    getDashboardsForFolder: function(folderId){
        return axios.get(`${this.getApiPrefix(false)}/folder/${folderId}/dashboards`);
    },

    getValuesForDashboard: function(model) {
        let reqUrl = `${DASHBOARD_API_ENDPOINT}/session?model=${model}`;
        return axios.get(reqUrl);
    },

    saveFolderChanges: function(id, title, parentId, isTeamMode,customerName){
        let reqUrl= `${this.getApiPrefix(isTeamMode)}/folders/${id}`;
            return axios.put(`${reqUrl}`, {id: id, name: title, parentId: parentId});
    },

    deleteItem: function(itemId, itemType, isTeamMode){
        switch(itemType){
            case SpaceManagementConstants.ITEM_TYPE_FOLDER:
                return this.deleteFolder(itemId, isTeamMode);
            case SpaceManagementConstants.ITEM_TYPE_REPORT:
                return this.deleteReport(itemId, isTeamMode);
            default:
                return this.deleteDashboard(itemId, isTeamMode);
        }   
    }
}

export default ReportManagementService;