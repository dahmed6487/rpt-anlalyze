import * as CustomFilterConfigConstants from '../constants/custom-filter-criteria-constants';
import axios from 'axios';

/**
 * custom-filter-criteria-service
 *      Used to perform API operations related to 'custom filters' which are used across users and dashboards to control or filter 
 * 
 */

const CustomFilterCriteriaService = {
    
    /**
     * Load available filters for selected dashboard/explore
     * 
     * @param {*} dashboardRef 
     */
	loadFilters: function(dashboardId){
        var requestUrl = `/filters/dashboard/${dashboardId}`;
       return axios.get(requestUrl);
    },

    createFilter: function(filter){
        return axios.post(`/filters/dashboard/filters`, filter);
    },

    updateFilter: function(filter){
        return axios.put(`/filters/dashboard/filters/${filter.id}`, filter);
    },

    deleteFilter: function(filterId){
        return axios.delete(`/filters/dashboard/filters/${filterId}`);

    },

    /**
     * Retrieve available dimensions for a given dashboard/explore. This is required in order to 
     * allow the user to select which dimension a filter is associated with.
     * 
     * @param {*} id 
     */
    getCurrentDimensionSet: function(dashboardId){
        return axios.get(`/dashboards/${dashboardId}/dimensions`);
    },

    loadDashboardMetaData: function(dashboardId){
        return axios.get(`/filters/dashboard/${dashboardId}`);
    },

    saveSharedFilterConfiuration: function(itemId, selectedTeams){
        const reqUrl = `/filters/dashboard/filters/${itemId}/sharedTeams`;

        return axios.post(reqUrl, selectedTeams);
    }
}

export default CustomFilterCriteriaService;