import axios from 'axios';

const API_ENDPOINT = "/api/customer";

const CustomerService = {

    getCustomersForUser: function() {
        return axios.get(`${API_ENDPOINT}/get/user`);
    },

     getCustomerByAccount: function(accountNumber) {
        return axios.get(`${API_ENDPOINT}/get/user?accountNumber=${accountNumber}`);
    },

    getAccountDimensions: function(accDimension,accDimensionValue,customerName) {
        let data = new FormData()
        data.append('accDimension', accDimension)
        data.append('accDimensionValue', accDimensionValue);
        data.append('customerName', customerName);
        return axios({
            method: "POST",
            url: `${API_ENDPOINT}/get/account/dimensions`,
            dataType: "json",
            data: data
        });
    }

}

export default CustomerService;