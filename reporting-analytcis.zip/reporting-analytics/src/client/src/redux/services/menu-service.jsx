
export function getIframeContentByUrl(url, dashboardId){
    //TODO: Make API call to retrieve content, probably should be cached after initial retrieval.
    const urlMappings = {
        "/": `/looker/dashboard/${dashboardId.home}`,
        "/solutions/purchases/time-series-by-item" : `/looker/dashboard/${dashboardId.timeSeriesByItem}`,
        "/solutions/purchases/time-series-by-account" : `/looker/dashboard/${dashboardId.timeSeriesByAccount}`,
        "/solutions/omits/top-omitted-items" : `/looker/dashboard/${dashboardId.topOmittedItems}`,
        "/solutions/omits/omits-trend-by-account" : `/looker/dashboard/${dashboardId.omitsTrendByAccount}`,
        "/solutions/contracts/contract-item-price-comparison": `looker/dashboard/${dashboardId.contractItemPriceComparison}`,
        "/solutions/contracts/contracts-by-account": `looker/dashboard/${dashboardId.contractsByAccount}`,
        "/explore/purchases" : "/looker/explore/r_a_connect/if_ra_fact_invc_purch_hist",
        "/explore/contracts" : "/looker/explore/r_a_connect/dt_contract_cust_buygroup",
        "/recent-activity" : "/looker/dashboard/7KmJJNgaAIRk34oQKfSQnx",
        "/explore/idb" : "/looker/explore/r_a_connect/idb",
        "/explore/physical-inventory" : "/looker/explore/r_a_connect/physical_inventory",
        "/explore/cust_acct_current" : "/looker/explore/r_a_connect/cust_acct_current",
        "/explore/v_if_ra_dim_cust_acct_item" : "/looker/explore/r_a_connect/v_if_ra_dim_cust_acct_item",
        "if_ra_fact_invc_purch_hist":"purchases",
        "dt_contract_cust_buygroup":"contracts",
        "physical_inventory":"physical-inventory",
        "idb":"idb",
        "cust_acct_current":"rebates",
        "v_if_ra_dim_cust_acct_item":"pricing-catalog"
    }

    let sArray=[]

    /**
     * Handle operations where a link is provided under team/my reports.
     */
    if(url.startsWith('/displayDashboard')){
        const dashboardId = url.replace('/displayDashboard/','');
        return `/looker/dashboard/${dashboardId}`;
    }

    if(url.startsWith('/displayReport')){
        const dashboardId = url.replace('/displayReport/','');
        return `/looker/look/${dashboardId}`;
    }

    if(url.startsWith('/dashboard')){
        const id = url.replace('/dashboard/','');
        return `/looker/dashboard/${id}`;
    }

    if(url.startsWith('/my-reports/') || url.startsWith('/team-reports/')){
        sArray = url.split("/");
        const embedUrl = urlMappings['/'+sArray[2]+'/'+sArray[3]];
         if (!embedUrl) {
            return 'mock';
        }
        return embedUrl;
    } else {
        /**
         * Default behavior, generate link based on env. specific IDs passed from API.
         */
        const embedUrl = urlMappings[url];

        if (!embedUrl) {
            return 'mock';
        }
        return embedUrl;
    }
}
