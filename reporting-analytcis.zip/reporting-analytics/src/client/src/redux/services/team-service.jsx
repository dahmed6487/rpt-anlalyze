import axios from 'axios';

const API_ENDPOINT = "/api/teams";

const TeamService = {

    getTeamsForIds: function(teamIds) {
        return axios.get(`${API_ENDPOINT}/${teamIds}`);
    },

    searchTeams: function(searchVal){
        return axios.get(`${API_ENDPOINT}/search/${searchVal}`);
    },

    loadTeamsByPage: function(){
        return axios.get(`${API_ENDPOINT}/get/page`);
    }
}

export default TeamService;