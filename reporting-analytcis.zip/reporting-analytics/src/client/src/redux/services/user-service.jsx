import axios from 'axios';

const API_ENDPOINT = "/api/user";

const UserService = {

    getTeamsForUser: function(userId) {
        return axios.get(`${API_ENDPOINT}/teams?userId=${userId}`);
    },

    getTeamsForCurrentUser: function () {
        return axios.get(`${API_ENDPOINT}/teams`);
    },

    getReportUser: function() {
        return axios.get(`${API_ENDPOINT}/get/login-user`);
    },

    getSudoUser: function(username) {
        return axios.get(`/api/sudo/login-as/${username}`);
    },

    updateSudoFlag: function(username, isSudoEnabled){
        return axios.put(`/api/sudo/update?username=${username}`, isSudoEnabled);
    },
    checkERAAccess() {
        return axios.get(`${API_ENDPOINT}/check/era-access`);
    },
    
    filterOwnerValue: function(searchText) {
        return axios.get(`/api/customer/search/owner?searchText=${searchText}`);
    },

    filterAccountCodeValue: function(accountCode, searchText) {
        return axios.get(`/api/customer/search/account/code/${accountCode}?searchText=${searchText}`);
    },

    createOrUpdateCustomerInfo: function(customerInfo) {
        return axios.post(`/api/customer/create/customer`, customerInfo);
    },
}

export default UserService;