import axios from 'axios';

const API_ENDPOINT = "/looker/admin";

const UserManagementService = {

    createEmbedUser: function(){
        const reqUrl = `${API_ENDPOINT}/users`;
        return axios.get(reqUrl);
    },
    
    deleteEmbedUser: function(userId){
        const reqUrl = `${API_ENDPOINT}/users/${userId}`;
        return axios.delete(reqUrl);
    },
    
    updateEmbedUser: function(user){
        const reqUrl = `${API_ENDPOINT}/users/${user.id}`;
        return axios.put(reqUrl, user);	
    },

    listRoles: function(){
        const reqUrl = `${API_ENDPOINT}/roles`;
        return axios.get(reqUrl);
    },

    listGroups: function(){
        const reqUrl = `${API_ENDPOINT}/groups`;
        return axios.get(reqUrl);
    },

    getUsersByGroup: function(groupId){
        const reqUrl = `${API_ENDPOINT}/groups/${groupId}/users`;
        return axios.get(reqUrl);
    },

    getUsers: function(){
        const reqUrl = `${API_ENDPOINT}/users`;
        return axios.get(reqUrl);
    },
    
    updateGroup: function(group){
        const reqUrl = `${API_ENDPOINT}/groups/${group.id}`;
        return axios.post(reqUrl, group);
    }, 
    
    deleteGroup: function(groupId){
        const reqUrl = `${API_ENDPOINT}/groups/${groupId}`;
        return axios.delete(reqUrl);
    }, 
    
    addUserToGroup: function(groupId, user){
        const reqUrl = `${API_ENDPOINT}/groups/${groupId}`;
        return axios.put(reqUrl, user);
    }, 
    
    removeUserFromGroup: function(groupId, externalUserId){
        const reqUrl = `${API_ENDPOINT}/groups/${groupId}/users`;
        return axios.delete(reqUrl);
    }, 
    
    getUserByExternalId: function(externalUserId){
        const reqUrl = `${API_ENDPOINT}/users/${externalUserId}`;
        return axios.get(reqUrl);
    } 
}
export default UserManagementService;
