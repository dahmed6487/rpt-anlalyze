import 'regenerator-runtime/runtime'; // For browsers without generator support (redux-saga)?
import {applyMiddleware, combineReducers, compose, createStore} from 'redux';
import createSagaMiddleware, {END} from 'redux-saga';
import thunk from 'redux-thunk';
// Import Reducers
//import * as reducers from '../reducers';
import user from '../reducers/user-reducer';
import iframe from '../reducers/iframe-reducer';
import spaceMgmnt from '../reducers/space-mgmnt-reducer';
import lookerAdmin from '../reducers/looker-reducer';
import userMgmnt from '../reducers/user-mgmnt-reducer';
import accountSettings from '../reducers/account-settings-reducer';
import customFilters from '../reducers/custom-filter-reducer';
import customFilterCriteria from '../reducers/custom-filter-criteria-reducer';
import customGroupCriteria from '../reducers/custom-group-reducer';

// Import Actions
import { actions as userActions } from '../actions/user-actions';
import application from '../reducers/application-reducer';
import deleteDialog from '../reducers/delete-dialog-reducer';
import sharing from '../reducers/sharing-reducer';

import sagas from '../sagas';

// Reducer
// =============================================================================
// Redux reducers are "pure functions" whose sole purpose is to update the state
// within a Redux store without causing any intermediate mutations of the state
// or any other "side effects" (such as making HTTP requests, manipulating the
// DOM, etc.) that would break time travel debugging.
// See: https://redux.js.org/basics/reducers

// Assemble the root reducer for the Redux store. Each individual reducer
// corresponds to an entry in the store's state object.
//const reducer = combineReducers(reducers.default);
const rootReducer = combineReducers({sharing, deleteDialog, spaceMgmnt, lookerAdmin, userMgmnt, user, iframe, accountSettings, customFilters, application, customFilterCriteria, customGroupCriteria});

// Middleware
// =============================================================================
// Redux-Saga is Redux middleware for handling behavior that needs to occur
// after a Redux action is fired, but doesn't belong in the reducers (which must
// purely transform the store's state). Making HTTP requests, reading or writing
// from cookies/sessionStorage/localStorage, and redirecting the page would be
// just a few examples of these kind of behaviors.
// See: https://redux-saga.js.org/

const sagaMw = createSagaMiddleware();
let middleware = applyMiddleware(sagaMw, thunk);

// If the Redux DevTools browser extension is installed in the user's browser,
// add the corresponding Redux middleware exposed by the extension.
if (window.__REDUX_DEVTOOLS_EXTENSION__) {
  middleware = compose(
    // Add the Redux middleware for Redux-Saga.
    middleware,
    // If the Redux DevTools browser extension is installed in the user's browser,
    // add the corresponding Redux middleware exposed by the extension.
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
  );
}


// Store
// =============================================================================
// Create the Redux store.
export const store = createStore(rootReducer, middleware);

// Sagas
// =============================================================================
// Run all of the relevant Redux-Saga watcher methods.
store.runSaga = sagaMw.run(sagas);
// Dispatch Redux-Saga's built-in END action.
store.close = () => store.dispatch(END);


// Actions
// =============================================================================
// Assemble an object that provides any relevant Redux action creator methods.
export const actions = {};


// Default Export
// =============================================================================
export default { store, actions };
