
import { fork, /*select,*/ all } from 'redux-saga/effects';

// Import Sagas, Place in watchers with spread operator.
import userWatchers from './user-sagas';

// Assemble the Redux-Saga watchers that need to be run.
export default function* root () {
  const watchers = { ...userWatchers };
  let forkedWatchers = [];

  for (let key in watchers) {
    forkedWatchers.push(fork(watchers[key]));
  }

  yield all(forkedWatchers);
}
