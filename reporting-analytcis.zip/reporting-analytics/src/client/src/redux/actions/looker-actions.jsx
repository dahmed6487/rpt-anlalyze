import * as SpaceManagementConstants from '../../constants/space-mgmnt-constants';
import * as AppConstants from '../constants/application-constants';

import UserManagementService from '../services/looker-service';

/**
 * Display dialog box where user may enter in information for a new folder.
 */

export const createEmbedUser = () =>{

    return function(dispatch){
        UserManagementService.createEmbedUser()
        .then((result)=>{
            dispatch(adminResultsLoaded(result.data));
        });
    }
}

export const adminResultsLoaded = (result) => {
    return {type: SpaceManagementConstants.USER_ADMIN_RESULTS, payload: result}
}

export const listRoles = () =>{
    return function(dispatch){
        UserManagementService.listRoles()
        .then((result)=>{
            dispatch(roleResultsLoaded(result.data));
        });
    }
}

export const roleResultsLoaded = (result) => {
    return {type: SpaceManagementConstants.USER_ROLE_RESULTS, payload: result}
}

export const getUsersByGroup = (groupId) =>{
    return function(dispatch){
        UserManagementService.getUsersByGroup(groupId)
        .then((result)=>{
            dispatch({type: SpaceManagementConstants.USER_RESULTS, payload: result.data});
        });
    }
}

export const getUsers = () =>{
    return function(dispatch){
        UserManagementService.getUsers()
        .then((result)=>{
            dispatch({type: SpaceManagementConstants.USER_GROUP_RESULTS, payload: result.data});
        });
    }
}

export const listGroups = () =>{
    return function(dispatch){
        UserManagementService.listGroups()
        .then((result)=>{
            dispatch({type: SpaceManagementConstants.GROUP_RESULTS, payload: result.data});
        });
    }
}

