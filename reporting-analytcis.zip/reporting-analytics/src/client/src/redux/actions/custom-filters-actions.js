import * as FilterConstants from '../../constants/custom-filters-constants';

/*
    User requests to display custom filters (top level use case)
*/
export function displayDialog(){
    return {
        type: FilterConstants.DIALOG_MODE_VISIBLE,
        payload: {}
    }
}

/*
    User requests to close custom filters dialog (top level use case)
*/
export function closeDialog(){
    return{
        type: FilterConstants.ACTION_CLOSE_DIALOG,
        payload: {}
    }
}

export function loadFilters(exploreRef){
    return { type: FilterConstants.ACTION_LOAD_FILTERS, payload: {}};
}

export function fetchFiltersSuccess(filters){
    return { type: FilterConstants.EVENT_FILTERS_LOADED, payload: filters};
}

export function enterNewFilter(){
    return {
        type: FilterConstants.ACTION_ENTER_FILTER,
        payload: {}
    }
}


export function loadFilter(){
    return {
        type: FilterConstants.ACTION_LOAD_FILTER,
        payload: {}
    }
}

export function filterLoaded(){
    return {
        type: FilterConstants.EVENT_FILTER_LOADED,
        payload: {}
    }
}



export function editFilter(filter, group, criteriaGroups){
    return {
        type: FilterConstants.ACTION_EDIT_FILTER,
        payload: {filter: filter, group: group, criteriaGroups: criteriaGroups}
    }
    
}

export function cancelFilterEdit(){
    return {
        type: FilterConstants.ACTION_CANCEL_EDIT_FILTER,
        payload: {}
    }
}

export function saveFilter(){
    return {
        type: FilterConstants.ACTION_SAVE_FILTER,
        payload: {}
    }
}

export function filterSaved(){
    return {
        type: FilterConstants.EVENT_FILTER_SAVED ,
        payload: {}
    }
}

export function deleteFilter(filterId){
    return {
        type: FilterConstants.ACTION_DELETE_FILTER,
        payload: { filterId: filterId}
    }
}

export function filterDeleted(filterId){
    return {
        type: FilterConstants.EVENT_FILTER_DELETED,
        payload: {filterId: filterId}
    }
}

export function filterTitleUpdated(title){
    return {
        type: FilterConstants.EVENT_FILTER_TITLE_UPDATED,
        payload: {title: title}
    }
}


export function filterSelected(index){
    return {
        type: FilterConstants.EVENT_FILTER_SELECTED,
        payload: index
    }
} 

export function filterDeselected(index){
    return {
        type: FilterConstants.EVENT_FILTER_DESELECTED,
        payload: index
    }
} 

export function cloneFilter(filter){
    return {
        type: FilterConstants.ACTION_CLONE_FILTER,
        payload: filter
    }
}

/*****************************************************************************************
 * Group related actions
 * 
 *****************************************************************************************/
export function enterNewFilterGroup(){
    return {
        type: FilterConstants.ACTION_ENTER_GROUP,
        payload: {selectedGroupCriteriaIndex: -1}
    }
}

export function editFilterGroupCriteria(index){
    return {
        type: FilterConstants.ACTION_EDIT_GROUP,
        payload: index
    }
}

export function filterGroupCriteriaTitleUpdated(title){
    return {
        type: FilterConstants.EVENT_GROUP_TITLE_UPDATED,
        payload: title
    }
}

export function deleteFilterGroup(index){
    return {
        type: FilterConstants.ACTION_DELETE_GROUP,
        payload: index
    }
}

export function saveFilterGroup(group){
    return {
        type: FilterConstants.ACTION_SAVE_GROUP,
        payload: group
    }
}

export function cancelFilterGroupEdit(){
    return {
        type: FilterConstants.ACTION_CANCEL_EDIT_GROUP,
        payload: {}
    }
}

export function addCriteria(criteria){

    return {
        type: FilterConstants.ACTION_ADD_CRITERIA,
        payload: criteria 
    }
}

export function deleteCriteria(criteria){
    return {
        type: FilterConstants.ACTION_DELETE_CRITERIA,
        payload: criteria
    }
}

export function clearDimensions(criteria){
    return {
        type: FilterConstants.ACTION_CLEAR_DIMENSIONS,
        payload: criteria
    }
}

export function dimensionSelected(dimension) {
    return {
        type: FilterConstants.ACTION_DIMENSION_SELECTED,
        payload: dimension
    }
}

export function userInput(input) {
    return {
        type: FilterConstants.ACTION_INPUT_SELECTED,
        payload: input
    }
}

export function setVisibleDimensionOptions(visibleDimensions) {
    return {
        type: FilterConstants.ACTION_VISIBLE_DIMENSIONS_LOADED,
        payload: visibleDimensions
    }
}

export function setGroupingDefault() {
    return {
        type: FilterConstants.ACTION_SET_GROUPING_DEFAULT,
        payload: {}
    }
}

export function loadDimensionSuggestions(suggestions) {
    return {
        type: FilterConstants.ACTION_DIMENSION_SUGGESTIONS_LOADED,
        payload: suggestions
    }
}
