import * as CustomGroupConfigConstants from '../constants/custom-group-constants';

export const panelActive = () => {
	return {type: CustomGroupConfigConstants.CUSTOM_PANEL_ACTIVE};	
}

export const editPanelActive = () => {
	return {type: CustomGroupConfigConstants.CUSTOM_EDIT_PANEL_ACTIVE};	
}

export const handleIndividualActionClick = (filterId) => {
    return { type: CustomGroupConfigConstants.ACTION_HANDLE_INDIVIDUAL_ACTION_CLICK, payload: filterId };
}

export const handleIndividualDefinitionClick = (filterId) => {
    return { type: CustomGroupConfigConstants.ACTION_HANDLE_INDIVIDUAL_DEFINITION_CLICK, payload: filterId };
}