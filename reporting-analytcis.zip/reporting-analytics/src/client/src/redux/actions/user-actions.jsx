import * as UserConstants from '../constants/user-constants'
import * as AccountSettingsConstants from "../../constants/account-settings-constants";

export const loadTeamsForUser = (teams) => {
    return {
        type: UserConstants.SET_USER_TEAMS,
        payload: teams
    }
}

export const accountSelectionActive = () => {
    return {
        type: UserConstants.ACCOUNT_SELECTION_ACTIVE
    }
}

export const dialogOpen = (dialog) => {
    return {
        type: "DIALOG_OPEN",
        payload: {
            isOpen: true,
            ...dialog
        }
    }
}

export const dialogClose = () => {
    return {
        type: "DIALOG_CLOSE",
        payload: {
            isOpen: false
        }
    }
}

export const solutionData = (response) =>{
    return {type: UserConstants.SOLUTION_DATA, payload: response};
};

export const getExploreContentAccesses = (response) => {
    return {
        type: UserConstants.SET_CONTENT_ACCESSES,
        payload: response
    }
}

