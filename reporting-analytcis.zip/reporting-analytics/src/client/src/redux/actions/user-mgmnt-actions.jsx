import * as UserManagementConstants from '../../constants/user-mgmnt-constants';
import ReportManagementService from '../services/report-mgmnt-service';



/**
 * Display dialog box where user may enter in information for a new folder.
 */
export const enterNewFolder = () =>{
    return {type: UserManagementConstants.ACTION_ENTER_NEW_FOLDER};
}

export const cancelNewFolderEntry = () =>{
    return {type: UserManagementConstants.ACTION_CANCEL_ENTER_NEW_FOLDER};
}

export const editUser = (firstName, lastName) =>{
    return {type: UserManagementConstants.ACTION_EDIT_USER, payload: {firstName: firstName, lastName: lastName}};
}

export const closeModal = () =>{
    return {type: UserManagementConstants.ACTION_CLOSE_MODAL};
}

export const closeUserEditModal = () =>{
    return {type: UserManagementConstants.ACTION_CLOSE_EDIT_MODAL};
}

export const showModal = () =>{
    return {type: UserManagementConstants.ACTION_SHOW_MODAL};
}
