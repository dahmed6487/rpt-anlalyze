import * as AccountSettingsConstants from '../../constants/account-settings-constants';
import ReportManagementService from '../services/report-mgmnt-service';



/**
 * Display dialog box where user may enter in information for a new folder.
 */
export const editAccount = () =>{
    return {type: AccountSettingsConstants.ACTION_EDIT_ACCOUNT};
}

export const closeAdminModal = () =>{
    return {type: AccountSettingsConstants.ACTION_CLOSE_ACCOUNT};
}

export const adminHandler = () =>{
    return {type: AccountSettingsConstants.ACTION_ADMIN_ACCOUNT};
}

export const userName = (response) =>{
    return {type: AccountSettingsConstants.ACTION_USER_NAME, payload: response};
}

export const userRole = (response) =>{
    return {type: AccountSettingsConstants.ACTION_USER_ROLE, payload: response};
}

export const loginUserInfo = (originalUserSudoFlag, fullName,sudoUser ) =>{
    return {type: AccountSettingsConstants.ACTION_LOGIN_USER_INFO, payload : {originalUserSudoFlag, fullName, sudoUser}};
}

export const userType = (response) =>{
    return {type: AccountSettingsConstants.ACTION_USER_TYPE, payload: response};
}

export const username = (response) =>{
    return {type: AccountSettingsConstants.ACTION_LOGIN_USERNAME, payload: response};
}

export const roleAccessInfo = (adminAccess, userManagementAccess, customerManagementAccess, teamManagementAccess, accountSegmentationAccess, vendorPurchasesAccess) =>{
    return {type: AccountSettingsConstants.ACTION_ROLE_ACCESS_INFO, payload : {adminAccess, userManagementAccess,customerManagementAccess, teamManagementAccess, accountSegmentationAccess, vendorPurchasesAccess}};
}

export const canSudo = (response) =>{
    return {type: AccountSettingsConstants.ACTION_CAN_SUDO, payload: response};
}
