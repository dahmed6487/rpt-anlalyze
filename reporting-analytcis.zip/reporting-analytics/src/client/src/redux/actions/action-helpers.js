export function requestAction(actionType){
    return ['REQUEST', 'LOADING', 'SUCCESS', 'FAILURE'].reduce((actionGroup, requestStatus) => {
        actionGroup[requestStatus] = `${actionType}_${requestStatus}`;
        return actionGroup;
    }, {});
}

export default { requestAction }
