import * as SpaceManagementConstants from '../../constants/space-mgmnt-constants';
import * as AppConstants from '../../redux/constants/application-constants';

import ReportManagementService from '../services/report-mgmnt-service';
import TeamService from "../services/team-service";
import dialog from 'yesno-dialog';

export const closeUserEditModal = (selectedFolderName, selectedFolderId,editFolderModel) =>{
    return {type: SpaceManagementConstants.ACTION_CLOSE_FOLDER_PATH};
}


export const editFolderPath = (selectedFolderName, selectedFolderId,editFolderModel,selectedFolderRow) =>{
    return {type: SpaceManagementConstants.ACTION_EDIT_FOLDER_PATH, payload: {selectedFolderName: selectedFolderName, selectedFolderId: selectedFolderId,editFolderModel:editFolderModel,selectedFolderRow:selectedFolderRow}};
}


export const loadSharedTeams = (currentUserAccount) =>{
    return function(dispatch){
        return TeamService.loadTeamsByPage()
            .then((response)=>{
                 response.data.forEach((item, index) => {
                    response.data[index]['finalFolderPath'] = "/"+item.name+"/";
                    response.data[index]['selectedFolderMap'] = "";
                });

                dispatch({type: SpaceManagementConstants.EVENT_SHARED_OBJECTS_LOADED, payload: response.data});
            })
    }
}

export const loadReportObjects = (currentUserAccount, parentFolder, isTeamMode) => {
    if (!currentUserAccount) {
        return () => {};
    }
    return function(dispatch){
        dispatch({type: AppConstants.API_CALL_TRIGGERED});
		dispatch({type: SpaceManagementConstants.ACTION_LOAD_REPORT_OBJECTS});
        return ReportManagementService.getReportObjects(currentUserAccount, parentFolder, isTeamMode)
		.then((response)=>{ 
            dispatch({type: AppConstants.API_CALL_COMPLETED});
            dispatch({type: SpaceManagementConstants.EVENT_REPORT_OBJECTS_LOADED,
                payload: response.data});
        })
        .catch((err)=>{
            dispatch({type: AppConstants.API_CALL_COMPLETED});
            dispatch({type: SpaceManagementConstants.EVENT_REPORT_OBJECTS_ERROR,
                payload: err.response.data});
        });
	}
}

/**
 * Display dialog box where user may enter in information for a new folder.
 */
export const enterNewFolder = () =>{
    return {type: SpaceManagementConstants.ACTION_ENTER_NEW_FOLDER};
}

export const cancelNewFolderEntry = () =>{
    return {type: SpaceManagementConstants.ACTION_CANCEL_ENTER_NEW_FOLDER};
}

export const filterByReportType = (selType) =>{    
    var type;
    if(selType=="View All"){
        type = SpaceManagementConstants.ITEM_TYPE_DEFAULT;
    }
    else if(selType=="View Reports"){
        type = SpaceManagementConstants.ITEM_TYPE_REPORT;
    }
    else if(selType=="View Dashboards"){
        type = SpaceManagementConstants.ITEM_TYPE_DASHBOARD;
    } 
    else if(selType=="View Folders"){
        type = SpaceManagementConstants.ITEM_TYPE_FOLDER;
    } 
    return {type: SpaceManagementConstants.ACTION_FILTER_VIEW_BY_TYPE, payload: type};
}

export const sortDisplayByNameAsc = () =>{
    return {type: SpaceManagementConstants.ACTION_CHANGE_SORT_ORDER, payload: SpaceManagementConstants.SORT_BY_ITEM_NAME_ASC}
}

export const sortDisplayByNameDesc = () =>{
    return {type: SpaceManagementConstants.ACTION_CHANGE_SORT_ORDER, payload: SpaceManagementConstants.SORT_BY_ITEM_NAME_DESC}
}

export const sortByLastModificationDateAsc = () =>{
    return {type: SpaceManagementConstants.ACTION_CHANGE_SORT_ORDER, payload: SpaceManagementConstants.SORT_BY_ITEM_LAST_MODIFIED_ASC}
}

export const sortByLastModificationDateDesc = () =>{
    return {type: SpaceManagementConstants.ACTION_CHANGE_SORT_ORDER, payload: SpaceManagementConstants.SORT_BY_ITEM_LAST_MODIFIED_DESC}
}

export const sortByFavoriteAttributeAsc = () =>{
    return {type: SpaceManagementConstants.ACTION_CHANGE_SORT_ORDER, payload: SpaceManagementConstants.SORT_BY_ITEM_FAVORITE_STATUS_ASC}
}

export const sortByFavoriteAttributeDesc = () =>{
    return {type: SpaceManagementConstants.ACTION_CHANGE_SORT_ORDER, payload: SpaceManagementConstants.SORT_BY_ITEM_FAVORITE_STATUS_DESC}
}

export const sortByObjectTypeAsc = () =>{
    return {type: SpaceManagementConstants.ACTION_CHANGE_SORT_ORDER, payload: SpaceManagementConstants.SORT_BY_ITEM_TYPE_ASC}
}

export const sortByObjectTypeDesc = () =>{
    return {type: SpaceManagementConstants.ACTION_CHANGE_SORT_ORDER, payload: SpaceManagementConstants.SORT_BY_ITEM_TYPE_DESC}
}

export const saveNewFolderChanges = (title, parentFolder, isTeamMode, customerName) =>{
    return function(dispatch){
        ReportManagementService.saveNewFolderChanges(title, parentFolder, isTeamMode, customerName)
        .then((result)=>{
            dispatch({type: SpaceManagementConstants.EVENT_FOLDER_CREATED, payload: result.data });
        })
    }
}

/**
 * Retrieve contents of a selected folder. This call will attempt to authenticate agaisnt the looker API as the selected user, 
 * which will require that the user has explicit access to the selected folder. In the event that the selected does not have the required 
 * permissions, then the call will result in and 401 (unathorized) response. 
 * 
 * @param {*} folderId 
 * @param {*} currentUserAccount 
 */
export const getDashboardsForFolder = (folderId) =>{
    return function(dispatch){
        ReportManagementService.getDashboardsForFolder(folderId)
        .then((result)=>{
            dispatch(dashboardsLoaded(result.data, folderId));
        });
    }
}

export const dashboardsLoaded = (result, folderId) => {
    if(folderId === '102' || folderId === '20' || folderId === '12') {
        return {type: SpaceManagementConstants.DASHBOARD_FOLDER_PURCHASEHISTORY, payload: result}
    }else if(folderId === '103' || folderId === '19' || folderId === '11'){
        return {type: SpaceManagementConstants.DASHBOARD_FOLDER_CONTRACTS, payload: result}
    }else if(folderId === '174' || folderId === '55' || folderId === '15'){
        return {type: SpaceManagementConstants.DASHBOARD_FOLDER_CONTROLLEDSUBSTANCES, payload: result}
    }else if(folderId === '137' || folderId === '25' || folderId === '14'){
        return {type: SpaceManagementConstants.DASHBOARD_FOLDER_OMITS, payload: result}
    }else if(folderId === '185' || folderId === '61'){
        return {type: SpaceManagementConstants.DASHBOARD_FOLDER_VA, payload: result}
    }else if(folderId === '184' || folderId === '60' || folderId === '17'){
        return {type: SpaceManagementConstants.DASHBOARD_FOLDER_REFERENCE, payload: result}
    }else if(folderId === '234'){
        return {type: SpaceManagementConstants.DASHBOARD_FOLDER_USAGEDETAIL, payload: result}
    }else if(folderId === '238' || folderId === '107' || folderId === '32'){
        return {type: SpaceManagementConstants.DASHBOARD_FOLDER_NEWLYPURCHASEDITEMS, payload: result}
    }
}

export const toggleFolderFavoriteStatus = (id, isFavorite) => {
    return function(dispatch){
        return ReportManagementService.toggleSelectedFolderFavoriteStatus(id, isFavorite);
    };
}

export const toggleReportFavoriteStatus = (id, isFavorite) => {
    return function(dispatch){
        return ReportManagementService.toggleSelectedReportFavoriteStatus(id, isFavorite);
    };
}

export const toggleDashboardFavoriteStatus = (id, isFavorite) => {
    return function(dispatch){
        return ReportManagementService.toggleSelectedDashboardFavoriteStatus(id, isFavorite);
    };
}

export const updateItemName = (newVal) => {
    return { type:SpaceManagementConstants.EVENT_FOLDER_NAME_UPDATED, payload: newVal}
}

export const updateItemDescription = (newVal) => {
	return { type:SpaceManagementConstants.EVENT_ITEM_DESCRIPTION_UPDATED, payload: newVal}
}

export const shareUpdateItemName = (newVal) => {
    return { type:SpaceManagementConstants.EVENT_SHARED_NAME_UPDATED, payload: newVal}
}

export const shareUpdateItemDescription = (newVal) => {
    return { type:SpaceManagementConstants.EVENT_SHARED_DESCRIPTION_UPDATED, payload: newVal}
}

export const editSelectedItem = (item, itemType, index) => {
    return { type:SpaceManagementConstants.ACTION_EDIT_SELECTED_ITEM, payload: {item: item, itemType: itemType, index: index}};
}

export const shareSelectedItem = (item, itemType, index) => {
    return { type:SpaceManagementConstants.ACTION_SHARE_SELECTED_ITEM, payload: {item: item, itemType: itemType, index: index}};
}

export const saveFolderChanges = (id, title, parentId, isTeamMode, customerName) =>{
    return function(dispatch){
        ReportManagementService.saveFolderChanges(id, title, parentId,isTeamMode,customerName).
        then((result)=>{
            dispatch({type: SpaceManagementConstants.EVENT_REPORT_ITEM_UPDATED, 
                payload: {id: id, type: SpaceManagementConstants.ITEM_TYPE_FOLDER, name: title}});
        });
    }
}

export const saveDashboardChanges = (id, title, description) =>{
    return function(dispatch){
        ReportManagementService.saveDashboardChanges(id, title, description).
        then((result)=>{
            dispatch({type: SpaceManagementConstants.EVENT_REPORT_ITEM_UPDATED, 
                payload: {id: id, type: SpaceManagementConstants.ITEM_TYPE_DASHBOARD, name: title, description: description }});
        });
    }
}

export const saveReportChanges = (id, title, description) =>{
    return function(dispatch){
        ReportManagementService.saveReportChanges(id, title, description).
        then((result)=>{
            dispatch({type: SpaceManagementConstants.EVENT_REPORT_ITEM_UPDATED, 
                payload: {id: id, type: SpaceManagementConstants.ITEM_TYPE_REPORT, name: title, description: description}});
        });
    }
}

export const saveFolderPath = (uppdatedTeamsData) => {
    return { type: SpaceManagementConstants.EVENT_SHARED_OBJECTS_LOADED, payload: uppdatedTeamsData};
}

export const shareReport = (item, id, title, description, externalId, teamIds, isTeamMode) => {
    return  function (dispatch) {
        ReportManagementService.shareReport(id, title, description, externalId,teamIds, isTeamMode,false).then(async (result) => {
            dispatch(loadSharedTeams());
            if (result.data === '' || result.data === null)
                dispatch({
                    type: SpaceManagementConstants.EVENT_REPORT_ITEM_UPDATED,
                    payload: {
                        id: id,
                        type: SpaceManagementConstants.ITEM_TYPE_REPORT,
                        name: title,
                        description: description
                    }
                });
            else{
                const yes = await dialog({
                        labelYes: "Yes",
                        labelNo: "No",
                        bodyText: result.data['VALIDATION_MSG'][0][0]
                    })
                   if (yes){
                       ReportManagementService.shareReport(id, title, description, result.data['FAILED_TEAMS'], teamIds, isTeamMode,true).then((result) => {
                           dispatch(loadSharedTeams());
                           if (result.data === '' || result.data === null)
                               dispatch({
                                   type: SpaceManagementConstants.EVENT_REPORT_ITEM_UPDATED,
                                   payload: {
                                       id: id,
                                       type: SpaceManagementConstants.ITEM_TYPE_REPORT,
                                       name: title,
                                       description: description
                                   }
                               });
                           else{
                           alert(JSON.stringify(result.data));
                           }
                       });
                    }
            }
        });
    }
}

export const cancelDeleteReportItem = () => {
    return { type: SpaceManagementConstants.ACTION_CANCEL_DELETE_ITEM_ACTION };
}

export const initializeItemDeletion = (item, index) => {
    return({
        type: SpaceManagementConstants.ACTION_INITIATE_ITEM_DELETION,
        payload: {
            item: item,
            selectedItemIndex: index
        }
    });
}

/**
 * When user elects to delete an item, a confirmation dialog is presented prior to the delete operation.
 */
export const deleteSelectedItem = (item, isTeamMode) => {
    return function(dispatch){
        dispatch({type: SpaceManagementConstants.ACTION_DELETE_ITEM});
        ReportManagementService.deleteItem(item.id, item.type, isTeamMode)
        .then(()=>{
            switch(item.type){
                case SpaceManagementConstants.ITEM_TYPE_FOLDER:
                    dispatch({type: SpaceManagementConstants.EVENT_FOLDER_DELETED, payload: {id: item.id, type: item.type} });
                case SpaceManagementConstants.ITEM_TYPE_REPORT:
                    dispatch({type: SpaceManagementConstants.EVENT_REPORT_DELETED, payload: {id: item.id, type: item.type} });
                default:
                    dispatch({type: SpaceManagementConstants.EVENT_FOLDER_DELETED, payload: {id: item.id, type: item.type} });    
            }
        })
    }

}

export const displayFolderContents = (folderId, isTeamMode=false) => {
    return function(dispatch){
        dispatch({type: SpaceManagementConstants.ACTION_DISPLAY_FOLDER_CONTENTS, payload: folderId});
    }
}

export const displayFolderStructure = (selItem, isTeamMode=false) => {
    return function(dispatch){
        dispatch({type: SpaceManagementConstants.ACTION_DISPLAY_FOLDER_STRUCTURE, payload: selItem});
    }
}

export const updateFolderPath = (selItem, updateTeamTemp) => {
    return function(dispatch){
        dispatch({type: SpaceManagementConstants.ACTION_UPDATE_FOLDER_STRUCTURE, payload: selItem,updateTeamTemp:updateTeamTemp});
    }
}

export const reloadReportObjects = (currentUserAccount, parentFolder, isTeamMode) => {
    return function(dispatch){
        dispatch({type: SpaceManagementConstants.ACTION_REPORT_OBJECTS_RELOAD });
        ReportManagementService.getReportObjects(currentUserAccount, parentFolder, isTeamMode)
        .then(
            (reports)=>{
                dispatch({type: SpaceManagementConstants.EVENT_REPORT_OBJECTS_RELOADED, payload: reports.data })
            }
        )
    }
    
}

export const clearSpacesdCache = () => {
    return {type: SpaceManagementConstants.CLEAR_SPACES_CACHE};
}

export const getValuesForDashboard = (data) =>{
    return {type: SpaceManagementConstants.DASHBOARD_URL, payload: data};
}

export const getValuesForFiltersUrl = (data) =>{
    return {type: SpaceManagementConstants.DASHBOARD_FILTERS_URL, payload: data};
}

export const getDashboardEventData = (data) =>{
    return {type: SpaceManagementConstants.DASHBOARD_EVENT_DATA, payload: data};
}

export const handleIndividualActionClick = (scheduleId) => {
    return { type: SpaceManagementConstants.ACTION_HANDLE_INDIVIDUAL_ACTION_CLICK, payload: scheduleId };
}