import * as CustomFilterConfigConstants from '../constants/custom-filter-criteria-constants';
import CustomFilterMgmntService from '../services/custom-filter-criteria-service';
import * as SharingActions from '../actions/sharing-actions';

/*
    Action handler for when the dialog window used to 'apply filters' dialog is launched. 

*/
export const customGroupDialog = () => {
	return {type: CustomFilterConfigConstants.CUSTOM_GROUP_DIALOG };
}

/*
  User has elected to cancel operations for dialog, and confirmed the action from the confirmation dialog.
 */
export const cancelFilterSelectionAction = () => {
	return {type: CustomFilterConfigConstants.ACTION_CANCEL_CUSTOM_FILTER_SELECTION_DIALOG };
}

/** Initiate the request to cancel 'applied' filters, resulting in the display of the confirmation dialog */
export const initiateCancelFilterSelectionAction = () => {
    return {type: CustomFilterConfigConstants.ACTION_CANCEL_CUSTOM_FILTER_SELECTION_DIALOG_INITIATED };
}

/*
    Event handler for when user elects to add a new filter.
*/
export const addFilter = (filter) => {
    return {type: CustomFilterConfigConstants.ACTION_ADD_FILTER, payload: filter};
}

/*
    Event handler for when a 'new' filter is deleted.
*/
export const deleteFilter = (title) => {
    return {type: CustomFilterConfigConstants.EVENT_FILTER_DELETED, payload: title};
}

export const changeFilterName = (newValue, index, title) =>{
    return {type: CustomFilterConfigConstants.ACTION_CHANGE_FILTER_NAME , payload: {index: index, name: newValue, title: title}};
}

export const triggerDashboardFilterConfigChange = (filterConfig) => {    
    return {type: CustomFilterConfigConstants.EVENT_FILTER_CRITERIA_CHANGED, payload: filterConfig};
}

export const deleteSavedFilter = (filter) => {
    return function(dispatch){
        if(filter.id!=null||filter.id!=""){
            CustomFilterMgmntService.deleteFilter(filter.id)
            .then(()=>{
                dispatch({type: CustomFilterConfigConstants.EVENT_FILTER_DELETED, payload: filter});
            })
        }
        else{
            return {type: CustomFilterConfigConstants.EVENT_FILTER_DELETED, payload: filter};
        }
        
    }
}

export const saveFilter = (selFilter, index) => {
    return function (dispatch){
        dispatch({type: CustomFilterConfigConstants.ACTION_SAVE_FILTER});
        if(selFilter.id==null){
            CustomFilterMgmntService.createFilter(selFilter)
            .then((result)=>{
                const filter = result.data;
                dispatch({type: CustomFilterConfigConstants.EVENT_FILTER_CREATED, payload: {index: index, id: filter.id} });
            })
        }
        else{
            CustomFilterMgmntService.updateFilter(selFilter)
            .then((result)=>{
                const filter = result.data;
                dispatch({type: CustomFilterConfigConstants.EVENT_FILTER_SAVED, payload: {index: index} });
            })
        }
    }   
}

export const dashboardLoaded = () => {
    return {type: CustomFilterConfigConstants.EVENT_DASHBOARD_LOADED};
}

export const selectFilter = (filter) => {
    return {type: CustomFilterConfigConstants.ACTION_SELECT_FILTER , payload: filter};
}

export const deselectFilter = (filter) => {
	return {type: CustomFilterConfigConstants.ACTION_DESELECT_FILTER , payload: filter };	
}

export const filterPanelActive = () => {
	return {type: CustomFilterConfigConstants.ACTION_FILTER_PANEL_ACTIVE};	
}

export const filterPanelClose = () => {
	return {type: CustomFilterConfigConstants.ACTION_FILTER_PANEL_CLOSE};	
}

export const customGroupAction = () => {
	return {type: CustomFilterConfigConstants.CUSTOM_GROUP_ACTION};	
}

export const groupPanelClose = () => {
	return {type: CustomFilterConfigConstants.ACTION_GROUP_PANEL_CLOSE};	
}

export const createFilter = () => {
	return {type: CustomFilterConfigConstants.ACTION_CREATE_FILTER};	
}

export const closeDialog = () => {
    return {type: CustomFilterConfigConstants.DIALOG_CLOSED};
}

export const saveSharedTeams = (itemId, sharedTeams) => {
    return function(dispatch){
        CustomFilterMgmntService.saveSharedFilterConfiuration(itemId, sharedTeams)
        .then(dispatch(SharingActions.finishSharing()))
        .then(dispatch({
            type: CustomFilterConfigConstants.EVENT_SHARED_FILTER_GROUPS_UPDATED, 
            payload: { itemId: itemId, sharedTeams: sharedTeams }
        }))
    }
}
