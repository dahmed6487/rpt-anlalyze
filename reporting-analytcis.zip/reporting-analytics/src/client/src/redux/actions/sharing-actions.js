import {
    ACTION_ADD_TEAM,
    ACTION_CLOSE_SHARE_DIALOG,
    ACTION_OPEN_SHARE_DIALOG,
    ACTION_REMOVE_TEAM
} from "../../constants/sharing-constants";


export function shareElement(elementId, elementName, elementType, sharedTeams, saveFunction) {
    return {
        type: ACTION_OPEN_SHARE_DIALOG,
        payload: {elementId: elementId, elementName: elementName, elementType: elementType, sharedTeams: sharedTeams, saveFunction: saveFunction}
    }
}

export function finishSharing() {
    return {
        type: ACTION_CLOSE_SHARE_DIALOG,
        payload: {}
    }
}

export function addTeam(teamId) {
    return {
        type: ACTION_ADD_TEAM,
        payload: {teamId: teamId}
    }
}

export function removeTeam(teamId) {
    return {
        type: ACTION_REMOVE_TEAM,
        payload: {teamId: teamId}
    }
}