import {DELETE_DIALOG_CLOSE, DELETE_DIALOG_OPEN} from "../constants/delete-dialog-constants";


export function openDeleteDialog(itemId, type, deleteFunction) {
    return {
        type: DELETE_DIALOG_OPEN,
        payload: {itemId: itemId, type: type, deleteFunction: deleteFunction}
    }
}


export function closeDeleteDialog() {
    return {
        type: DELETE_DIALOG_CLOSE,
        payload: {}
    }
}