import * as IFrameConstants from '../constants/iframe-constants'

export const setEmbedRefs = (model, explore) => {
    return {
        type: IFrameConstants.SET_EMBED_URL,
        payload: {model: model, explore: explore}
    }
}

export const reloadIframe = (index, reloadIframe) => {
    return {
        type: IFrameConstants.SET_IFRAME_INDEX,
        payload: {iframeIndex: index, reloadIframe: reloadIframe}
    }
}