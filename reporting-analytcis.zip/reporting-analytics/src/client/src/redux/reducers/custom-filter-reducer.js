import produce from 'immer';

import * as FilterConstants from '../../constants/custom-filters-constants';
import * as IFrameConstants from '../constants/iframe-constants';

const customFilterReducer = (state = [], action) => {

    if(state==undefined){
        return {
            customFiltersDisplayDialogModal: false,
            existingFilters: null,
            selectedFilterTitle: null,
            selectedFilterIndex: null,
            selectedFilterId: null,
            filterGroup: getDefaultFilterGroupState(),
            viewMode: FilterConstants.DIALOG_VIEW_MODE_LIST,
            dialogState: FilterConstants.DIALOG_STATE_INITIAL_STATE,
            selectedGroupTitle: null,
            selectedGroupCriteriaIndex: null,
            selectedCriteriaTitle: null,
            selectedDimension: null,
            relationalOperator: null,
            defaultGrouping: false,
            associatedDimension: null,
            defaultGroupingError: false,
            criteriaGroups: [],
            model: null,
            exploreRef: null,
            visibleDimensions: [],
            dimensionSuggestions: [],
            isLoading: false,
            userInput: ''
          };
    }

    var filterConfig;
    switch(action.type){
        /****************************************************************************************  
         'top level' operations, i.e. opening/closing dialog
        ****************************************************************************************/
        /*
            Action issued when top level dialog needs to be opened.
        */
        case FilterConstants.DIALOG_MODE_VISIBLE:
            return Object.assign({}, state, {customFiltersDisplayDialogModal: true});

        /*
            Event handler for when request to close 'custom groups' dialog is triggered.
        */
       case FilterConstants.ACTION_CLOSE_DIALOG:
            return Object.assign({}, state, {customFiltersDisplayDialogModal: false});


        /* 
            Request to change filter view mode (list/card)
        */    
        case FilterConstants.SET_FILTER_VIEW_MODE:
            return Object.assign({}, state, {});

        /****************************************************************************************  
         Filter list load operations: Note, all filter data is not loaded due to the potential 
         overall size. Instead an initiate request is made for a summary of filter data (name, id, 
            last update date) for which these events/actions are related. Upon selection of a 
            given filter, a lazy load operation is performed for the selection.
        ****************************************************************************************/
        /*
            Triggered when request to load filters is executed (either initially or when a filter is saved)
        */
       case FilterConstants.ACTION_LOAD_FILTERS:
            return Object.assign({}, state, {});
            
         /*
             Event handler for when list of existing (if any) filters are loaded.
         */
         case FilterConstants.EVENT_FILTERS_LOADED:
             return Object.assign({}, state, {dialogState: FilterConstants.DIALOG_STATE_INITIAL_STATE, existingFilters: action.payload});

        /****************************************************************************************  
         'filter level' operations, loading, saving...
        ****************************************************************************************/
        /*
            Action triggered when user initiates entry of a new group.
        */
        case FilterConstants.ACTION_ENTER_FILTER:
            var updatedState = getDefaultFilterState();
            updatedState.dialogState = FilterConstants.DIALOG_STATE_EDIT_FILTER;
            return Object.assign({}, state, {...updatedState, selectedFilterId: -1});

        /*
            Event handler for when a request to edit an existing filter is made.
        */  
        case FilterConstants.ACTION_EDIT_FILTER:
            const group = action.payload.group;
            const filter = action.payload.filter;
            const criteriaGroups = action.payload.criteriaGroups;

            return Object.assign({}, state, {
                dialogState: FilterConstants.DIALOG_STATE_EDIT_FILTER, 
                selectedFilterId: filter.id,
                selectedFilterTitle: filter.name,
                filterGroup: group,
                selectedGroupTitle: group.name,
                criteriaGroups: criteriaGroups ? criteriaGroups: [],
                isEditingFilter: false,
                selectedDimension: null,
                dimensionSuggestions: [],
            });
        
        /*
            Action triggered when user 
        */
       case FilterConstants.ACTION_CANCEL_EDIT_FILTER:
           var newState =  getDefaultFilterState();
           newState.dialogState = FilterConstants.DIALOG_STATE_INITIAL_STATE;

           return Object.assign({}, state, newState);

        /*
         
        */
         case FilterConstants.ACTION_CLONE_FILTER:
            var newState =  getDefaultFilterState();
            newState.selectedFilterTitle = action.payload.name;
            newState.filterGroups = action.payload.filterGroups;
            newState.dialogState = FilterConstants.DIALOG_STATE_EDIT_FILTER;
            newState.isEditingFilter = false;

           return Object.assign({}, state, newState);

        /*
            Action triggered when user initiates a save operation.
        */
       case FilterConstants.ACTION_SAVE_FILTER:
           return Object.assign({}, state, {}); //Trigger state

        /*
            Event handler for when a filter save operation is successful.
        
        */
        case FilterConstants.EVENT_FILTER_SAVED:
            return Object.assign({}, state, {selectedFilterTitle: null, selectedFilterId: null, filterGroup: getDefaultFilterGroupState(), selectedFilterIndex: null});

        /**
         * Triggered when request to delete an filter is issued.
         */
        case FilterConstants.ACTION_DELETE_FILTER:
            return Object.assign({}, state, getDefaultFilterState());

        /**
         * Triggered when response from deletion request is returned. 
         */    
        case FilterConstants.EVENT_FILTER_DELETED:
            return Object.assign({}, state, {selectedFilterTitle: null, filterGroup: getDefaultFilterGroupState(), selectedFilterIndex: null });

        
        case FilterConstants.EVENT_FILTER_TITLE_UPDATED:
            return Object.assign({}, state, {selectedFilterTitle: action.payload.title, selectedGroupTitle: action.payload.title, filterGroup: {name: action.payload.title}});

        case FilterConstants.EVENT_FILTER_SELECTED:
            var selections = state.selectedFilters ? state.selectedFilters : [];
            selections.push(action.payload);
            return Object.assign({}, state, {selectedFilters: selections});

        case FilterConstants.EVENT_FILTER_DESELECTED:
                var selections = state.selectedFilters ? state.selectedFilters : [];
                selections.splice(selections.indexOf(action.payload),1);
                return Object.assign({}, state, {selectedFilters: selections});

        /****************************************************************************************  
         'group level' operations, i.e. adding, editing, saving, deleting...
        ****************************************************************************************/
       case FilterConstants.ACTION_ENTER_GROUP:
            return  Object.assign({}, state, {
                selectedGroupCriteriaIndex: -1,
                selectedCriteriaTitle: null,
                criteriaElements: [],
                isEditingFilter: true
            });
    
        case FilterConstants.ACTION_EDIT_GROUP:
            const selectedGroupCriteriaIndex = action.payload;
            const selectedGroup = state.filterGroup;
            const selectedGroupCriteria = state.criteriaGroups[selectedGroupCriteriaIndex];


            return Object.assign({}, state, {
                selectedGroupCriteriaIndex: selectedGroupCriteriaIndex,
                selectedGroupTitle: selectedGroup.name,
                selectedGroup: selectedGroup,
                criteriaElements: selectedGroupCriteria.value ? selectedGroupCriteria.value.replace(/"/g, "").split(",") : [],
                selectedCriteriaTitle: selectedGroupCriteria.name,
                selectedDimension: selectedGroupCriteria.dimension,
                relationalOperator: selectedGroupCriteria.relationalOperator,
                defaultGrouping: selectedGroupCriteria.defaultGrouping,
                associatedDimension: selectedGroupCriteria.associatedDimension,
                defaultGroupingError: false,
                isEditingFilter: true,
                dimensionSuggestions: []
            });
    
        case FilterConstants.ACTION_CANCEL_EDIT_GROUP:
            return Object.assign({}, state, {
                selectedGroupCriteriaIndex: null,
                criteriaElements: [],
                dimensionSuggestions: [],
                defaultGrouping: false,
                defaultGroupingError: false,
                isEditingFilter: false
            });
            
        /* Triggered when user saves a group. This will be an operation within the set of 
        filter operations which are all persisted as part of a single transaction. */    
        case FilterConstants.ACTION_SAVE_GROUP:
            if(state.selectedGroupCriteriaIndex === -1){
                return produce(state, draft => {
                    if (draft.criteriaGroups) {
                        draft.criteriaGroups.push(action.payload);
                    } else {
                        var groups = [];
                        groups.push(action.payload);
                        draft.criteriaGroups = groups;
                    }
                    draft.selectedGroupCriteriaIndex = null;
                    draft.selectedCriteriaTitle = null;
                    draft.criteriaElements = null;
                    draft.defaultGrouping = false;
                    draft.isEditingFilter = false;

                });
            }
            else{
                return produce(state, draft=>{
                    draft.criteriaGroups[draft.selectedGroupCriteriaIndex] = action.payload;
                    draft.selectedGroupCriteriaIndex = null;
                    draft.selectedCriteriaTitle = null;
                    draft.criteriaElements = null;
                    draft.defaultGrouping = false;
                    draft.isEditingFilter = false;
                });
            }

            //return Object.assign({}, state, {});

        //case FilterConstants.EVENT_GROUP_SAVED:
            //console.log(`Recieved event indicating group was saved ${id=>}`);
            //return objectHash.assign({}, state, {});
        case FilterConstants.ACTION_DELETE_GROUP:
            return produce(state, draft=>{
                //draft.criteriaGroups[action.payload] = draft.criteriaGroups.slice(action.payload, 1);
                draft.criteriaGroups.splice(action.payload, 1);
            }); 
            //return Object.assign({}, state, {});
        case FilterConstants.EVENT_GROUP_TITLE_UPDATED:
            return Object.assign({}, state, {selectedCriteriaTitle: action.payload});

        case FilterConstants.ACTION_ADD_CRITERIA:
            var criteria = action.payload;
            return produce(state, draft=>{
                draft.criteriaElements.push(criteria);
            });
        case FilterConstants.ACTION_CLEAR_DIMENSIONS:
            var criteria = action.payload;
            return produce(state, draft=>{
                draft.criteriaElements.splice(criteria);
            });
        case FilterConstants.ACTION_DELETE_CRITERIA:
            var criteria = action.payload;
            return produce(state, draft=>{
                draft.criteriaElements.splice(draft.criteriaElements.indexOf(criteria),1);
            });
        case FilterConstants.ACTION_VISIBLE_DIMENSIONS_LOADED:
            let visibleDimensions = action.payload;
            return Object.assign({}, state, {
                visibleDimensions: visibleDimensions
            });
        case FilterConstants.ACTION_DIMENSION_SELECTED:
            let dimension = action.payload;
            return Object.assign({}, state, {
                selectedDimension: dimension
            });
        case FilterConstants.ACTION_INPUT_SELECTED:
            let userInput = action.payload;
            return Object.assign({}, state, {
                userInput: userInput
            });
        case  IFrameConstants.SET_EMBED_URL:
            let model = action.payload.model;
            let exploreRef = action.payload.explore;
            return Object.assign({}, state, {
                model: model,
                exploreRef: exploreRef
            });
        case FilterConstants.ACTION_SET_GROUPING_DEFAULT:
            let existsDefaultGrouping = false;
            let defaultGroupingIndex = -1;
            state.criteriaGroups.forEach((group, index) => {
                if(group.defaultGrouping && !existsDefaultGrouping) {
                    existsDefaultGrouping = true;
                    defaultGroupingIndex = index;
                }
            });

            let canSetDefaultGroup = (!existsDefaultGrouping || defaultGroupingIndex === state.selectedGroupCriteriaIndex);

            return Object.assign({}, state, {
                defaultGrouping: !state.defaultGrouping,
                defaultGroupingError: !state.defaultGrouping ? !canSetDefaultGroup : false
            });
        case FilterConstants.ACTION_DIMENSION_SUGGESTIONS_LOADED:
            let suggestions = action.payload;
            return Object.assign({}, state, {
                dimensionSuggestions: suggestions,
                isLoading: !state.dimensionSuggestions? true : false
            });
        case FilterConstants.LOADING_GROUPS:
                var criteria = action.payload;
                return produce(state, draft=>{
                    draft.isLoading =criteria;
                });
        default:
            return state;

    }

    return state;
}

/* Get filter related properties intended for storage. Used to reset values set during selection/edit operations. */ 
function getDefaultFilterState(){
    return {
        selectedFilterTitle: null,
        selectedFilterIndex: null,
        selectedFilterId: null,
        filterGroup: getDefaultFilterGroupState(),
        selectedGroupCriteriaIndex: null, //Used to track the currently selected group
        selectedGroupTitle: null,
        criteriaGroups: [],
        criteriaElements: [],
        defaultGrouping: false,
        defaultGroupingError: false,
        isEditingFilter: false
    }
}

/* Get default state of groups related attributes for storage. Used to reset values set during selection/edit operations.*/
function getDefaultFilterGroupState(){
    return {
        name: null,
        id: null,
    };
    
}

export default customFilterReducer;