import * as Constants from '../../constants/space-mgmnt-constants';
import produce from 'immer';

/**
 * viewMode: is the user viewing items in the card or list view?
 * selectedFolder: reference to the selected folder for which contents are displayed (if selected, otherwise 'root' level)
 * userSpace: copy of entire user space. 
 * selectedUserGroupFolder
 * selItem: Stores reference to selected item for edit operations. 
 * displayNewFolderForm: Flag used to conditionally display folder/dashboard/look entry/edit form.
 * sortOrder: Controls directional sort per column
 * displayConfirmationDialog: Determines is confirmation dialog for delete operation is displayed.
 * selectedItemForDeletion: Reference to id of selected 'thing' pending delete operation.
 * selectedItemType: Reference to type of thing pending delete operation.
 * 
 */
const initialState = {
    groupResults: null,
    adminResults: null,
    roleResults: null,
    userResults: null,
    userGroupResults: null
};

const actions = (state = initialState, action) => {
    switch(action.type){
        case Constants.GROUP_RESULTS:
            return produce(state, draft=>{
                draft.groupResults = action.payload;
            });
        case Constants.USER_ADMIN_RESULTS:
            return produce(state, draft=>{
                draft.adminResults = action.payload;
            });
        case Constants.USER_ROLE_RESULTS:
            return produce(state, draft=>{
                draft.roleResults = action.payload;
            });
        case Constants.USER_RESULTS:
            return produce(state, draft=>{
                draft.userResults = action.payload;
            });
        case Constants.USER_GROUP_RESULTS:
            return produce(state, draft=>{
                draft.userGroupResults = action.payload;
            });
        /*
            Event handler for operations where the local cached contents of the user's space 
            is invalidated and need to be reloaded.
        */
        default:
            return state;
    }
};

/**
 * Given a data structure representing the current user's space, and a reference to a folder (some given 
 * point in the structure, i.e. a folder id), return the reference to the folder at the point in the structure. 
 * For example, upon initial load operation for the user, the entire structure is loaded into a reference. 
 * Upon selection of a given point in the folder navigation structure, this method would provide the ability to 
 * return the selected folder, for which to display items, based on a given folder id.  
 * 
 * @param {*} spaceRef 
 * @param {*} folderId 
 */


export default actions;