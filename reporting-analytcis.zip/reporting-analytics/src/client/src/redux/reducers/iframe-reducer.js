import produce from 'immer';

import * as IframeConstants from '../constants/iframe-constants';
import * as CustomFilterConstants from '../constants/custom-filter-criteria-constants';
import * as SpaceManagementConstants from '../../constants/space-mgmnt-constants';
import {SWITCH_IFRAME_URL_SOLUTION} from "../constants/iframe-constants";

/**
 * iframeUrl: Target location for Iframe URL.
 * embedType:
 * dashboardValues:
 * reloadIframe:
 */
const initialState = {
    iframeUrl: "",
    embedType: "",
    dashboardValues: "",
    reloadIframe: false,
    path: false,
    filtersUrl: '',
    data: '',
    isLoaded:false,
    isDashBoardExploreLoaded:false,
    isUserHasCustomGroups:false,
    iframeUrlForSolution :""
};

const iframe = (state = initialState, action) => {
    let iframeUrl = action.payload;
    let urlFragments = [];

    switch(action.type) {
        case IframeConstants.INITIAL_ACCOUNT:
            let reloadIframe = action.payload.reloadIframe;
            iframeUrl = action.payload.iframeUrl;
            // If the action's payload contains an iFrame url split it so we can extract the pieces of it if needed
            urlFragments = (iframeUrl && Object.keys(iframeUrl).length > 0) ? iframeUrl.split('%2F') : [];
            if (urlFragments && urlFragments.length > 2) {
                // urlFragments[2] will be, if it exists, the looker embed type (explore, look, dashboard)
                return Object.assign({}, state, {iframeUrl: iframeUrl, embedType: urlFragments[2], reloadIframe: reloadIframe});
            } else {
                return Object.assign({}, state, {iframeUrl: iframeUrl, reloadIframe: reloadIframe});
            }
        case IframeConstants.RELOAD_SOLUTION_PANEL:
            return Object.assign({}, state, {isLoaded: action.payload.isLoaded});
        case IframeConstants.RELOAD_DASHBOARD_EXPLORE_PANEL:
            return Object.assign({}, state, {isDashBoardExploreLoaded: action.payload.isDashBoardExploreLoaded});
        case IframeConstants.CUSTOM_GROUPS_CHECK:
            return Object.assign({}, state, {isUserHasCustomGroups: action.payload.isUserHasCustomGroups});
        case IframeConstants.SWITCH_ACCOUNT:
            // If the action's payload contains an iFrame url split it so we can extract the pieces of it if needed
            urlFragments = (iframeUrl && Object.keys(iframeUrl).length > 0) ? iframeUrl.split('%2F') : [];
            if (urlFragments && urlFragments.length > 2) {
                // urlFragments[2] will be, if it exists, the looker embed type (explore, look, dashboard)
                return Object.assign({}, state, {iframeUrl: iframeUrl, embedType: urlFragments[2]});
            } else {
                return Object.assign({}, state, {iframeUrl: iframeUrl});
            }
        case IframeConstants.SWITCH_IFRAME_URL_SOLUTION:
            // If the action's payload contains an iFrame url split it so we can extract the pieces of it if needed
            urlFragments = (iframeUrl && Object.keys(iframeUrl).length > 0) ? iframeUrl.split('%2F') : [];
            if (urlFragments && urlFragments.length > 2) {
                // urlFragments[2] will be, if it exists, the looker embed type (explore, look, dashboard)
                return Object.assign({}, state, {iframeUrlForSolution: iframeUrl, embedType: urlFragments[2]});
            } else {
                return Object.assign({}, state, {iframeUrlForSolution: iframeUrl});
            }
        case IframeConstants.SET_IFRAME_INDEX:
            return Object.assign({}, state, {iframeIndex: action.payload.iframeIndex, reloadIframe: action.payload.reloadIframe});
        case IframeConstants.DASHBOARD_VALUES:
            return Object.assign({}, state, {dashboardValues: action.payload});
        case IframeConstants.SWITCH_ROUTE:
            return Object.assign({}, state, {iframeUrl: action.payload.iframeUrl});
        case CustomFilterConstants.DIALOG_CLOSED:
            return produce(state, draft=>{
                draft.reloadIframe = true;
            });
        /*
            Event handler for when meta information has been retrieved from the API for the currently selected dashboard. This is required as 
            filter change events triggered from the embed frame only contain a 'title/alias' and criteria values. This information must be 'mapped' 
            with filter related data produced from the looker API required to get full details (including filter related data) about a selected dashboard.
        */
        case CustomFilterConstants.EVENT_DASHBOARD_META_LOADED:
            return produce(state, draft=>{
                
            });
        case CustomFilterConstants.ACTION_LOAD_DASHBOARD_META:
            return produce(state, draft=>{
                
            });
        case SpaceManagementConstants.DASHBOARD_URL:
            return produce(state, draft=>{
                draft.path= action.payload;
            });
        case SpaceManagementConstants.DASHBOARD_FILTERS_URL:
            return produce(state, draft=>{
                draft.filtersUrl= action.payload;
            });
        case SpaceManagementConstants.DASHBOARD_EVENT_DATA:
            return produce(state, draft=>{
                draft.data= action.payload;
            }); 
        default:
            return state;
    }
};

export default iframe;