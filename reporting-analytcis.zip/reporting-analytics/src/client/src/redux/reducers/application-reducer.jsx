import * as Constants from '../constants/application-constants';
import produce from 'immer';

const initialState = {
    isLoading: false,
    supportPhoneNumber: "800-829-3444"
};

const actions = (state = initialState, action) => {
    switch(action.type){
        case Constants.API_CALL_TRIGGERED:
            return produce(state, draft=>{
                draft.isLoading = true;
            });
        case Constants.API_CALL_COMPLETED:
            return produce(state, draft=>{
                draft.isLoading = false;
            });
        default:
            return state;
    }
};

export default actions;