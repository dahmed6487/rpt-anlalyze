import {
    ACTION_ADD_TEAM,
    ACTION_CLOSE_SHARE_DIALOG,
    ACTION_OPEN_SHARE_DIALOG,
    ACTION_REMOVE_TEAM
} from "../../constants/sharing-constants";
import produce from "immer";

const sharingReducer = (state = [], action) => {

    if(state === undefined){
        return {
            displayShareDialog: false,
            shareItemId: null,
            shareItemName: null,
            shareItemType: null,
            sharedTeams: [],
            saveFunction: () => {}
        };
    }

    switch(action.type) {
        case ACTION_OPEN_SHARE_DIALOG:
            return Object.assign({}, state, {
                displayShareDialog: true,
                shareItemId: action.payload.elementId,
                shareItemName: action.payload.elementName,
                shareItemType: action.payload.elementType,
                sharedTeams: action.payload.sharedTeams,
                saveFunction: action.payload.saveFunction
            });
        case ACTION_CLOSE_SHARE_DIALOG:
            return Object.assign({}, state, {
                displayShareDialog: false,
                shareItemId: null,
                shareItemName: null,
                shareItemType: null,
                sharedTeams: [],
                saveFunction: () => {}
            });
        case ACTION_ADD_TEAM:
            return produce(state, draft => {
                if(draft.sharedTeams!=null){
                    draft.sharedTeams.push(action.payload.teamId);
                }
                else{
                    var sharedTeams = [];
                    sharedTeams.push(action.payload.teamId);
                    draft.sharedTeams = sharedTeams;
                }
            });
        case ACTION_REMOVE_TEAM:
            return Object.assign({}, state, {
                sharedTeams: state.sharedTeams.filter(team => team !== action.payload.teamId)
            });
        default:
            return state;
    }

    return state;
}

export default sharingReducer;