import * as CustFilterConfigConstants from '../constants/custom-filter-criteria-constants';
import {SWITCH_ROUTE} from '../constants/iframe-constants';
import produce from 'immer';
import * as SpaceManagementConstants from '../../constants/space-mgmnt-constants';

/**
 * - editMode: Tracks state of filter related operations (which dialog elected display)
 * - availableFilters: Set of filters that may be managed or applied to a dashboard.
 * 
 * - filterQualifiers: collection of available 'qualifiers' that are used with filters
 * 
 * - selectedFiltersForDeletion: Used to track id's of filters that have been selected for deletion.
 * - loadingDimensions: Used to track if an active request to load available dimensions for the selected dashboard is present.
 * - selectedDashboardId: Reference to selected dashboard.
 * - availableFilterSet: Collection of filters to display in dialog. This will be a combination of previousy saved filters that are 
 * - applicable for selected dashboard and representations of any filters that have been configured in the Looker IFrame. 
 * - filterMap: Stores information associating filters defined on the dashboard with their model/explore/dimension. This is required to 
 * compare previously saved filters with events broadcasted from the Iframe. 
 * - appliedFilters: Contains filters that have been 'applied' for the current dashboard. Filters that are created by configuration in the 
 * Looker iframe and those that have been saved from previous sessions may be 'applied' to the selected dashbaord. Although filters may be 
 * named and persisted to a database for future sessions, we do not store information about if and where they have been applied, requiring the 
 * user to select and apply filters as needed on a session by session basis.
 *  - appliedfilters: Array of indexes of 'applied' filters. These are filter that have been explicitly selected by the current user for the current 
 * working session and will need to be applied to the selected dashboard/explore.
 */
const initialState = {
    editMode: CustFilterConfigConstants.EDIT_MODE_NONE,
	isLoadingFilters: false,
	isSaveOperationPending: false,
	isCancelRequested: false,
	filterSet: null,
	selectedFiltersForDeletion: [],
	loadingDimensions: false,
	availableFiltersLoaded: false,
	dimensionsLoaded: false,
	selectedDashboardId: 17,
	availableFilterSet: [],
	filterMap: [],
	filterMetaDataStatus: "none",
	appliedfilters: [],
	lookerHost: null,
	defaultFilters: null,
	dashboardMetaDataLoaded: false,
	dashboardLoaded: false,
	panelActive: false,
	editPanelActive: false,
	filterPanelActive: false,
	isInitialFilterEvent: true,
	customGroupDialog: false,
	customGroupAction: false,
	createFilter: false
};

const actions = (state = initialState, action) => {
	switch(action.type){
		//Launch dialog
		case CustFilterConfigConstants.CUSTOM_GROUP_DIALOG:
			return produce(state, draft=>{
                draft.customGroupDialog = !draft.customGroupDialog;
			});
		case CustFilterConfigConstants.ACTION_GROUP_PANEL_CLOSE:
			return produce(state, draft=>{
                draft.customGroupDialog = !draft.customGroupDialog;
			});
		case CustFilterConfigConstants.ACTION_CREATE_FILTER:
			return produce(state, draft=>{
                draft.createFilter = true;
			});
		case CustFilterConfigConstants.CUSTOM_GROUP_ACTION:
			return produce(state, draft=>{
                draft.customGroupAction = !draft.customGroupAction;
			});
		// Close dialog after confirmation window presented
		case CustFilterConfigConstants.ACTION_CANCEL_CUSTOM_FILTER_MGMNT_DIALOG:
			return initialState;
		// Close dialog after confirmation window presented
		case CustFilterConfigConstants.ACTION_CANCEL_CUSTOM_FILTER_SELECTION_DIALOG:
			return initialState;
		// Use is attempting to save changes
		case CustFilterConfigConstants.ACTION_SAVE_CUSTOM_FILTER_SELECTION_CONFIG:
			return produce(state, draft=>{
				draft.isSaveOperationPending = true;
			});
		// Request to load filters initiated
		case CustFilterConfigConstants.ACTION_LOAD_FILTERS:{
			return produce(state, draft=>{
				draft.isLoadingFilters = true;
			});
		}
		// Response returned from API to save changes.	
		case CustFilterConfigConstants.EVENT_FILTER_CHANGES_SAVED:
			return produce(state, draft=>{
				draft.isSaveOperationPending = false;
				draft.editMode = CustFilterConfigConstants.EDIT_MODE_NONE;
			});
		// Response returned from API to save changes.
		case CustFilterConfigConstants.ACTION_CANCEL_CUSTOM_FILTER_MGMNT_DIALOG_INITIATED:
			return produce(state, draft=>{
				draft.isCancelRequested = true;
			});
		// 'Cancel' button on dialog intially selected, confirmation dialog displayed.	
		case CustFilterConfigConstants.ACTION_CANCEL_CUSTOM_FILTER_SELECTION_DIALOG_INITIATED:
			return produce(state, draft=>{
				draft.isCancelRequested = true;
			});
		case CustFilterConfigConstants.ACTION_RESUME_EDIT:
				return produce(state, draft=>{  
					draft.isCancelRequested = false;
				});
		/**
		 * Filter selection event, all selection/deselection events are immediately applied.
		 */
		case CustFilterConfigConstants.ACTION_SELECT_FILTER:
				
			return produce(state, draft=>{
				var selFilterRef = action.payload;
				var selectedFilterIndex;
				var availableFilterSet = draft.availableFilterSet;
				if(selFilterRef.id==undefined){
					
					for(var x=0;x<availableFilterSet.length;x++){
						
						if(availableFilterSet[x].title==selFilterRef.title){
							selectedFilterIndex = x;
							break;
						}
					}
				}
				else{
					
					for(var x=0;x<availableFilterSet.length;x++){
						if(availableFilterSet[x].id==selFilterRef.id){
							selectedFilterIndex = x;
							break;
						}
					}
				}

				//Perform update to internal filter set
				var filters = draft.availableFilterSet;
				filters[selectedFilterIndex].applied = true;
				draft.availableFilterSet = filters;
			});
		/**
		 * Filter selection event, all selection/deselection events are immediately applied.
		 */
		case CustFilterConfigConstants.ACTION_DESELECT_FILTER:
			return produce(state, draft=>{
				var selFilterRef = action.payload;

				var selectedFilterIndex;
				var availableFilterSet = draft.availableFilterSet;
				if(selFilterRef.id==null||selFilterRef.id==""){
					
					for(var x=0;x<availableFilterSet.length;x++){
						
						if(availableFilterSet[x].title==selFilterRef.title){
							selectedFilterIndex = x;
							break;
						}
					}
				}
				else{
					for(var x=0;x<availableFilterSet.length;x++){
						if(availableFilterSet[x].id==selFilterRef.id){
							selectedFilterIndex = x;
							break;
						}
					}
				}

				//Perform update to internal filter set
				var filters = draft.availableFilterSet;
				filters[selectedFilterIndex].applied = false;
				draft.availableFilterSet = filters;


			});
		case CustFilterConfigConstants.ACTION_ADD_FILTER:
			return produce(state, draft=>{
				var curFilters = draft.filterSet;
				curFilters.push(action.payload);
				draft.filterSet = curFilters;
			});
		case CustFilterConfigConstants.EVENT_AVAILABLE_DIMENSIONS_LOADED:
			return produce(state, draft=>{
				draft.availableDimensions = action.payload;
				draft.loadingDimensions = false;
				draft.dimensionsLoaded = true;
			});

		case CustFilterConfigConstants.ACTION_CHANGE_FILTER_NAME: 
			return produce(state, draft=>{
				//Perform update to cached reference
					var availableFilterSet = draft.availableFilterSet;
					//availableFilterSet[action.payload.index].name = action.payload.name;

					for(var x=0;x<availableFilterSet.length;x++){
						if(availableFilterSet[x].title==action.payload.title&&availableFilterSet[x].sharedWithUser==false){
							
							availableFilterSet[x].name = action.payload.name;
							break;
						}
					}

					draft.availableFilterSet = availableFilterSet;

			});
		/**
		 * An 'unsaved' filter has been selected for deletion. 
		 */
		case CustFilterConfigConstants.EVENT_FILTER_DELETED:
			return produce(state, draft=>{

				var selFilter = action.payload;
				var availableFilterSet = draft.availableFilterSet;
				var curFilter; 

				//Saved filters from previous sessions may be identified by their unique id.
				if(selFilter.id!=null||selFilter.id==""){
					for( var x=0;x<availableFilterSet.length;x++){
						curFilter = availableFilterSet[x];
						if(curFilter.id == selFilter.id){
							availableFilterSet.splice(x,1);
							break;
						}
					}
				}
				else{
					//Unsaved filters, which are produced by the process of entering in criteria within the iframe
					//are identified by the 'title' attribute, which should be unique as the title is unique across
					//the set.
					for( var x=0;x<availableFilterSet.length;x++){
						curFilter = availableFilterSet[x];
						if(curFilter.title == selFilter.title && selFilter.id==null){
							availableFilterSet.splice(x,1);
							break;
						}
					}
				}

				//Update internal state
				draft.availableFilterSet=availableFilterSet;

				//Applied filters are identified, additionally we add in a reference to the deleted filter such that the 
				//iframe removes it.
				var appliedFilters = getAppliedFilters(availableFilterSet); //??
				appliedFilters.push({
					name: selFilter.title,
					value: null
				});

				//Update iframe with new filters
				updateIframeWithFilterSelections(appliedFilters, draft.lookerHost)
			});
		/**
		 * Event handler for API response from save/update operation.
		 */
		case CustFilterConfigConstants.EVENT_FILTER_CREATED:
			return produce(state, draft=>{
				var existingFilters = draft.availableFilterSet;
				existingFilters[action.payload.index].id = action.payload.id;
				draft.availableFilterSet = existingFilters;
			});

		case CustFilterConfigConstants.EVENT_FILTER_SAVED:
			return produce(state, draft=>{				

			});
		case CustFilterConfigConstants.EVENT_FILTER_DELETED:
			return produce(state, draft=>{
				var existingFilters = draft.availableFilterSet;
				existingFilters.splice(action.payload.index, 1);
				draft.availableFilterSet = existingFilters;
			});
		case CustFilterConfigConstants.ACTION_SAVE_FILTER:
			return produce(state, draft=>{});
		case CustFilterConfigConstants.EVENT_DASHBOARD_LOADED:
			return produce(state, draft=>{
				draft.dashboardLoaded = true;
			});
		case CustFilterConfigConstants.ACTION_SELECT_FILTER:
			return produce(state, draft=>{
				let availableFilterSet = draft.availableFilterSet;
				availableFilterSet[action.payload].applied = true;	
				draft.availableFilterSet = availableFilterSet;
			});
		case CustFilterConfigConstants.ACTION_DESELECT_FILTER:
			return produce(state, draft=>{
				let availableFilterSet = draft.availableFilterSet;
				availableFilterSet[action.payload].applied = false;	
				draft.availableFilterSet = availableFilterSet;
			});
		case CustFilterConfigConstants.ACTION_FILTER_PANEL_ACTIVE:
			return produce(state, draft=>{
				draft.filterPanelActive = !draft.filterPanelActive;
			});
		case CustFilterConfigConstants.ACTION_FILTER_PANEL_CLOSE:
			return produce(state, draft=>{
				draft.filterPanelActive = !draft.filterPanelActive;
			});
		case CustFilterConfigConstants.CUSTOM_PANEL_ACTIVE:
				return produce(state, draft=>{
					draft.panelActive = true;
					draft.panelTitle = 'Custom Groups';
				});
		case CustFilterConfigConstants.CUSTOM_EDIT_PANEL_ACTIVE:
				return produce(state, draft=>{
					draft.editPanelActive = true;
					draft.panelTitle = 'Edit Group'
				});
		case CustFilterConfigConstants.DIALOG_CLOSED:
			return produce(state, draft=>{
				draft.editMode = CustFilterConfigConstants.EDIT_MODE_NONE;
				//Generate filter criteria based on 'selected' filters and set reference into reduce store
				let appliedFilters = getAppliedFilters(draft.availableFilterSet);
			
				updateIframeWithFilterSelections(appliedFilters, draft.lookerHost);
			});
		case CustFilterConfigConstants.ACTION_LOAD_DASHBOARD_META:
			return produce(state, draft=>{
				draft.dashboardMetaDataLoaded = false;
				draft.filterMetaDataStatus="loading";
			});
		/**
		 * Event handler for when a filter is modified in the Looker Iframe. Event information will contain 
		 * only dimension/criteria value information. This will be triggered each time filter criteria is modified.
		 * Additionally, this will be triggered upon initial dashboard load.
		 *   	
		 */
		case CustFilterConfigConstants.EVENT_FILTER_CRITERIA_CHANGED:
			
			if(state.dashboardMetaDataLoaded==false){
				return state;
			}

			return produce(state, draft=>{

				draft.currentFilterConfig = action.payload;
				var existingFilters = draft.availableFilterSet;
	
				if(draft.isInitialFilterEvent==true){
					draft.lastFilterEvent = action.payload;
					//console.debug(draft.lastFilterEvent);
					//After the dashboard loads, an initial event is triggered that will reflect the default filters. 
					//For this case, we can safely ignore the event.
				}
				else{
					//Otherwise, we will need to update the set of filter data based on the event. Each time a criteria
					//value is updated, an event will trigger containing the entire set (not just what had changed)  


					//Changed filter value is identified
					var updatedFilter, newCriteriaValue;
					
					var eventData = action.payload;
					for(var key in eventData){
						if(eventData[key]!=draft.lastFilterEvent[key]){
							updatedFilter = key;
							newCriteriaValue = eventData[key];
							break;
						}
					}
					
					/* Now we perform the update:
					If the filter is a default filter, then the value is simply updated
					If it is shared with the user, the changed value is ignored
					For events that do not have a value assigned
						if the filter is unsaved, then it is removed from the 'available filter set'
						otherwise the value is updated on the unsaved filter
					Otherwise we are updating/inserting
						if a record exists (not shared) in 'available set' then update
						else perform insert operation
					*/
						var isEventDefaultFilter = false;
						var isCriteriaPresent = newCriteriaValue=="" ? false: true ;
						if(isEventDefaultFilter==true){

							for(var x=0;x<existingFilters.length;x++){
								if(existingFilters[x].title==updatedFilter){
									existingFilters[x].criteriaValue = newCriteriaValue;
									break;
								}
							}
						}
						else{
							var curFilter;
							if(isCriteriaPresent==false){
								for(var x=0;x<existingFilters.length;x++){
									curFilter = existingFilters[x]; 
									if(curFilter.title==updatedFilter&&curFilter.applied&&curFilter.id==null){
										existingFilters.splice(x,1);
										break;
									}
									else{
										existingFilters[x].criteriaValue="";
										break;
									}
								}
							}
							else{
								var targetIndex; 
								var isTargetFilterApplied;
								for(var x=0;x<existingFilters.length;x++){
									curFilter = existingFilters[x]; 
									if(curFilter.title==updatedFilter&&curFilter.applied&&curFilter.sharedWithUser==false){
										targetIndex=x;
										isTargetFilterApplied=curFilter.applied;
										break;
									}
								}
								if(targetIndex==null){
									var filterMapping = getFilterMapping(key, draft.filterMap);
									var	newFilter = {
										id: null,
										name: "",
										title: updatedFilter,
										applied: true,
										criteriaValue: newCriteriaValue,
										model: filterMapping.model,
										explore: filterMapping.explore,
										dimension: filterMapping.dimension,
										editable: true,
										sharedWithUser: false
									};		
									existingFilters.push(newFilter);
								}
								else{
									//Finally, we only update the existing filter value if it has been applied. 
									if(isTargetFilterApplied){
										existingFilters[x].criteriaValue=newCriteriaValue;
									}
								}
							}
						}

					//
					draft.availableFilterSet = existingFilters;

					//And finally we store the event for future comparisons.
					draft.lastFilterEvent = action.payload;
				}

				draft.isInitialFilterEvent = false;

			});
		/**
		 * Event handler for when intitial request for extended dashboard information and filters 
		 * from previously saved sessions have been loaded.
		 */
		case CustFilterConfigConstants.EVENT_DASHBOARD_META_LOADED:
			return produce(state, draft=>{

				//Reset flag indicating that we have not received initial filter change event.
				draft.isInitialFilterEvent = true; 

				//References to filter model/explore/dimension are stored.
				var filterMap = action.payload.dashboardFilters;
				draft.filterMap = filterMap;

				//Reference to previously saved filters are stored in the collection of filters.
				var availableFilterSet = [];
				for(var x=0;x<action.payload.savedFilters.length;x++){
					var filter = action.payload.savedFilters[x];
					availableFilterSet.push(filter);
				}				

				//Status flags are updated.
				draft.filterMetaDataStatus="loaded";
				draft.lookerHost = action.payload.lookerHost;

				var defaultFilters = [];
					 
				for(var x=0;x<filterMap.length;x++){
					var filter = filterMap[x]; 
					
					if(filter.default_value!=undefined && filter.default_value!=""){
						
						//Reference to 'default' filter tracked, these are not displayed within the dialog.
						defaultFilters.push(filter.name);
						var	curDefaultFilter = {
							id: null,
							name: "",
							title: filter.name,
							applied: true,
							criteriaValue: filter.default_value,
							model: filter.model,
							explore: filter.explore,
							dimension: filter.dimension,
							editable: true,
							sharedWithUser: false
						};
						availableFilterSet.push(curDefaultFilter);
					}

				}

				draft.defaultFilters = defaultFilters;
				draft.availableFilterSet = availableFilterSet;
				draft.dashboardMetaDataLoaded=true;
			});
		case SpaceManagementConstants.CLEAR_SPACES_CACHE:
		case SWITCH_ROUTE:
			return produce(state, draft=>{
				draft.filterMetaDataStatus = "none";
				draft.availableFilterSet = [];
				draft.filterMap = null;
				draft.editMode = CustFilterConfigConstants.EDIT_MODE_NONE;
				draft.appliedfilters = [];
				draft.dashboardLoaded = false;
				draft.filterMetaDataStatus = 'none';
				draft.defaultFilters = [];
				draft.appliedfilters = [];
				draft.dashboardMetaDataLoaded = false;
			});
		case CustFilterConfigConstants.EVENT_SHARED_FILTER_GROUPS_UPDATED:
				return produce(state, draft=>{

					var targetFilter;
					var filterSet = draft.availableFilterSet;
					for(var x=0;x<filterSet.length;x++){
						if( filterSet[x].id == action.payload.itemId ){ 
							filterSet[x].sharedTeams = action.payload.sharedTeams;		
							targetFilter = filterSet[x];
							break;
						}
					}
					draft.availableFilterSet = filterSet;

					var displayFilters = draft.displayFilters;
					for(var x=0;x<displayFilters.length;x++){
						if(displayFilters[x].id==targetFilter.id){
							displayFilters[x] = targetFilter;
							break;
						}
					}
					draft.displayFilters = displayFilters;
				});
		default:
			return state;
	}
	
};

/**
	Given a collection of filters and collection of indexes that have been 'selected'
*/
const getAppliedFilters = (filterRefs) => {
	let results = Array();
	for(var x=0;x<filterRefs.length;x++){
		if(filterRefs[x].applied==true){
			results.push({
				name: filterRefs[x].title,
				value: filterRefs[x].criteriaValue
			});
		}
		else{
			results.push({
				name: filterRefs[x].title,
				value: null
			});
		}
	}

	return results;
}

/**
 * Get modified set of which filters for display purposes; default filters, or filters defined at the 
 * dashboard level are included in the edit UI.
 *  
 * @param {*} allFilters 
 * @param {*} defaultFilters 
 */
const getFiltersForDisplay = (allFilters, defaultFilters = []) => {
	var results = [];
	for( var x=0;x<allFilters.length;x++){
		var filter = allFilters[x];
		if(!defaultFilters.includes(filter.title)){
			results.push(filter);
		}
	}
	return results;
}

/**
 * Calculate the new 'state' of filters based on updated information. 
 * 	- Any filters with values that are present in the criteria attribute which are already present in the 
 * current set of 'available' filters are updated with information contained in the event.
 * -  Any filters without criteria present, which are represented in the set of 'available' filters 
 * are removed. 
 * - Any filters produced by the event which do not contain criteria, and for which are not repersented in the 
 * set of 'available' filters are ignored.
 * - Any filters produced from the event which do contain criteria, and are not represented within the set of 
 * 'available' filters are added to the final set. 
 * 
 * Resulting structure represents all filters that contain criteria.
 * 
 * @param {*} eventFilters Filters that represent new state as reported from the Iframe.
 * @param {*} allFilters Current state of filters.
 */
const getUpdatedFilterSet = (eventFilters, availableFilters, rawEventData) => {
	var results = [];

	//Create map containing name value pairs representing event filter data
		var filterMap = [];
		for(var x=0;x<eventFilters.length;x++){
			if(eventFilters[x].criteriaValue==""){
				continue;
			}
			filterMap[eventFilters[x].title] = eventFilters[x].criteriaValue;
		}

	// Delete any (managed) filters that are not present in the filter event, but are present in the existing set 
		var deletedFilterRefs = getDeletedFilterRefs(rawEventData, availableFilters);
		for(var x=0;x<deletedFilterRefs.length;x++){
			availableFilters = deleteManagedFilter(deletedFilterRefs[x], availableFilters);	
		}

	// Add any (managed) filters that are present in the filter event, and not in the existing set.
		var newFilterRefs = getNewFilterRefs(filterMap, availableFilters);
		var newFilter;
		for(var x=0;x<newFilterRefs.length;x++){
			newFilter = getFilterByTitle(newFilterRefs[x], eventFilters);
			availableFilters.push(newFilter);
		}

	// Update (managed) filters that are present in both the existing and event (perform updates)
		var updateFilterRefs = getUpdatedFilterRefs(rawEventData, availableFilters);
		for(var x=0;x<updateFilterRefs.length;x++){
			updateManagedFilter(updateFilterRefs[x], availableFilters , rawEventData[updateFilterRefs[x]]);
		}	

	return availableFilters;
}

/**
 * Retrieve the names of filters that will need to be updated.
 */
const getUpdatedFilterRefs = ( rawFilterMap, existingFilters ) => {
	var results = [];
	
	var existingFilterTitles = getExistingFilterTitles(existingFilters);

	for( var key in rawFilterMap ){
		if(rawFilterMap[key]!="" && existingFilterTitles.includes(key)){
			results.push(key);
		}
	}
	return results;
}

const getFilterByTitle = (title, filters) => {
	for(var x=0;x<filters.length;x++){
		if(filters[x].title==title){
			return filters[x];
		}
	}
	return null;
}

const getFilterByDimension = (dimension, filters) => {
	
	for(var x=0;x<filters.length;x++){
		if(filters[x].dimension==filters){
			return filters[x];
		}
	}
	return null;
}

const getFilterFromSet = (dimension, filterSet) => {
	for(var filter in filterSet){
		if(filter.dimension==dimension){
			return filter;
		}
	}
	return null;
}

const filterExists = (dimension, filterSet) => {
	for(var filter in filterSet){
		if(filter.dimension==dimension){
			return true;
		}
	}
	return false;
}

/**
 * When events are broadcasted from the Looker Iframe, they contain minimal information ( associated dimension and 
 * criteria value). This method will take complete information (model/explore/dimension) values and create a 
 * representative set of filters with complete information for all filters originating from the event which contain 
 * values. 
 * 
 * @param {*} eventFilters 
 * @param {*} filterMapping 
 */
const populateFiltersFromEvent = (eventFilters, filterMap) => {
	var results = [];

	for(var key in eventFilters){
		if(eventFilters[key]==undefined||eventFilters[key]==""){
			continue; 
		}
		
		var filterMapping = getFilterMapping(key, filterMap);
		var	curEventFilter = {
				id: null,
				name: "",
				title: key,
				applied: true,
				criteriaValue: eventFilters[key],
				model: filterMapping.model,
				explore: filterMapping.explore,
				dimension: filterMapping.dimension,
				editable: true,
				sharedWithUser: false
			};
			results.push(curEventFilter);
	}
	return results;
}

const getFilterMapping = (title, filterMap=[]) => {	

	if(filterMap==undefined){
		filterMap = [];
	}

	for( var x=0;x<filterMap.length;x++ ){
		if(filterMap[x].name==title){
			return filterMap[x];
		}
	}	
	return null;
}

/**
 * Broadcast new filter configuration into  
 * @param {*} selectedFilters 
 */
const updateIframeWithFilterSelections = (selectedFilters, lookerHost) => {
	var selFiltersObj = {};
	for(var x=0;x<selectedFilters.length;x++){
		selFiltersObj[selectedFilters[x].name] = selectedFilters[x].value 
	}

	//Initial request for filter update operation on dashboard.
	var filterReq = JSON.stringify(
		{
		"type": "dashboard:filters:update",
		"filters": selFiltersObj
	  });
	  
	  if(!lookerHost.startsWith("https://")){
	  	lookerHost = 'https://'+ lookerHost;
	  }
	  var embedDashboard = document.getElementById("embedDashboard"); //TODO: Externalize lookup url, pull from dashboard meta lookup operation
	  embedDashboard.contentWindow.postMessage(filterReq, lookerHost);

	  //Additional call required to refresh contents of dashboard to reflect filter changes.
	  filterReq = JSON.stringify(
		{
		"type": "dashboard:run"
	  });
	  var embedDashboard = document.getElementById("embedDashboard"); //TODO: Externalize lookup url, pull from dashboard meta lookup operation
	  embedDashboard.contentWindow.postMessage(filterReq, lookerHost);
}

const getManagedFilterByDimension = (dimension, existing)=>{
	for(var x=0;x<existing.length;x++){
		if(existing[x].dimension==dimension&& !existing[x].sharedWithUser){
			return existing[x];
		}
	}
	return null;
}

/*
	Identify any filters appearing in the event with 'no' value for the criteria element, which have 
	a correlating 'managed' filter in the existing set. 
*/
const getDeletedFilterRefs = (event, existing)=>{
	var results = [];

	for(var key in event){
		if(event[key]=="" && getManagedFilterByTitle(key, existing)!=null){
			results.push(key);
		}
	}

	return results;
}

/*
	Any filters present in the 'event', however not represented in the existing filter set 
	are considered 'new'.

	Returns a string containing the names of the filters that would be considered new. 
*/
const getNewFilterRefs = (event, existing) => {
	var results = [];
	var eventFilterTitles = getMapKeysAsArray(event);
	var existingFilterTitles = getExistingFilterTitles(existing);

	for(var x=0;x<eventFilterTitles.length;x++){
		if(!existingFilterTitles.includes(eventFilterTitles[x])){
			results.push(eventFilterTitles[x]);
		}
	}
	return results;
}

const getExistingFilterTitles = (existing) => {
	var results = [];

	for(var x=0;x<existing.length;x++){
		results.push(existing[x].title);
	}
	return results;
}

/*

*/
const getManagedFilter = (dimension, existing) => {
	var curFilter;
	for(var x=0;x<existing.length;x++){
		curFilter = existing[x];
		if(curFilter.dimension==dimension&&!curFilter.sharedWithUser){
			return curFilter;
		}
	}
	return null;
}

const getManagedFilterByTitle = (title, existing) => {
	var curFilter;
	for(var x=0;x<existing.length;x++){
		curFilter = existing[x];
		if(curFilter.title==title&&!curFilter.sharedWithUser){
			return curFilter;
		}
	}
	return null;
}

/*
	
*/
const deleteManagedFilter = (title, existing) => {
	var results = [];
	var curFilter;
	for(var x=0;x<existing.length;x++){
		curFilter = existing[x];
		if (curFilter.title==title&&!curFilter.sharedWithUser){
			
		}
		else{
			results.push(curFilter);
		}
	}
	return results;
}

/*

*/
const updateManagedFilter = (title, existing, criteria)=>{
	var curFilter;
	for( var x=0;x<existing.length;x++){
		curFilter = existing[x];
		if(curFilter.title==title&&!curFilter.sharedWithUser){
			curFilter.criteriaValue = criteria;
			break;
		}
	}
	return existing;
}

const getMapKeysAsArray = (inputMap)=>{
	var results = [];
	for(var key in inputMap){
		results.push(key);
	}
	return results;
}

export default actions;