import * as Constants from '../../constants/space-mgmnt-constants';
import produce from 'immer';
import { combineReducers } from 'redux';

/**
 * viewMode: is the user viewing items in the card or list view?
 * selectedFolder: reference to the selected folder for which contents are displayed (if selected, otherwise 'root' level)
 * userSpace: copy of entire user space. 
 * selectedUserGroupFolder
 * selItem: Stores reference to selected item for edit operations. 
 * displayNewFolderForm: Flag used to conditionally display folder/dashboard/look entry/edit form.
 * sortOrder: Controls directional sort per column
 * displayConfirmationDialog: Determines is confirmation dialog for delete operation is displayed.
 * selectedItemForDeletion: Reference to id of selected 'thing' pending delete operation.
 * selectedItemType: Reference to type of thing pending delete operation.
 * 
 */
const initialState = {
    viewMode: Constants.VIEW_MODE_LIST_VIEW,
    displayNewFolderForm: false,
    newFolderTitle: "",
    selectedFolder: null,
    userSpace: null,
    selItem: null,
    sortOrder: Constants.SORT_BY_ITEM_LAST_MODIFIED_ASC,
    displayConfirmationDialog: false,
    selectedItemForDeletion: null,
    selectedItemType: null,
    isOperationPending: false,
    reloadingContents: false,
    isEnteringNewFolder: false,
    isEditingItem: false,
    selectedItemTitle: "",
    selectedItemDescription: "",
    selectedItemIndex: -1,
    mode: Constants.EDIT_MODE_NONE,
    dashboardPurchaseHistory: null,
    dashboardContracts: null,
    dashboardControlledSubstances: null,
    dashboardOmits: null,
    dashboardVa: null,
    dashboardReference: null,
    dashboardUsageDetail: null,
    dashboardNewlyPurchased: null,
    filterMode: Constants.ITEM_TYPE_DEFAULT,
    sharedTeams:null,
    selectedFolderName : null,
    selectedFolderId : null,
    sharedFolderEditor : false,
    selectedFolderRow:null,
    selectedSubFolder:null,
    folderPathUpdateMode:null,
    finalFolderPath:null,
    selectFolderMap:null,
    collaborationTeamId:null,
    teamReportsError:false,
    actionOpenForScheduleId: -1,

};

const actions = (state = initialState, action) => {
    switch(action.type){

        case Constants.EVENT_REPORT_OBJECTS_LOADED:
            return produce(state, 
                draft=>{
                    draft.userSpace = action.payload;
                    draft.selectedFolder = getDisplayItemReference(action.payload, null, Constants.ITEM_TYPE_FOLDER);
                    draft.isOperationPending = false;
                    draft.teamReportsError=false;
                }
            );
        case Constants.EVENT_REPORT_OBJECTS_ERROR:
            return produce(state,
                draft=>{
                    draft.userSpace = action.payload;
                    draft.selectedFolder = getDisplayItemReference(action.payload, null, Constants.ITEM_TYPE_FOLDER);
                    draft.isOperationPending = false;
                    draft.teamReportsError=true;
                }
            );
        case Constants.ACTION_ENTER_NEW_FOLDER:
            return produce(state, draft=>{
                draft.displayNewFolderForm = true;
                draft.isOperationPending = true;
                draft.selectedItemType = Constants.ITEM_TYPE_FOLDER;
                draft.selectedItemId = -1;
                draft.selectedItemTitle = "";
                draft.selItem = null;
                draft.mode = Constants.ENTER_NEW_FOLDER            });
        case Constants.ACTION_CANCEL_ENTER_NEW_FOLDER:
                return produce(state, draft=>{
                    draft.displayNewFolderForm = false;
                    draft.selectedItemTitle = "";
                    draft.selectedItemDescription = "";
                    draft.selectedItem = null;
                    draft.selectedItemIndex = -1;
                    draft.selItem = null;
                    draft.isOperationPending = false;
                    draft.mode = Constants.EDIT_MODE_NONE;
                });
        case Constants.ACTION_FILTER_VIEW_BY_TYPE:
            return produce(state,draft=>{
                draft.filterMode = action.payload;
                //draft.displayItems = filterDisplayItemsByType(action.payload, draft.allReportObjects);
                //?
            });
        /**
         * Event produced by typing in a value in the 'name' field of the edit item dialog.
         */
        case Constants.EVENT_FOLDER_NAME_UPDATED:
            return produce(state, draft=>{
                draft.selectedItemTitle = action.payload
            });
        /**
         * Event produced by typing in value for the 'description' field for the edit item dialog.
         */
        case Constants.EVENT_ITEM_DESCRIPTION_UPDATED:
            return produce(state, draft=>{
                draft.selectedItemDescription = action.payload
            });
        case Constants.EVENT_SHARED_OBJECTS_LOADED:
            return produce(state, draft=>{
                draft.sharedTeams = action.payload;
                draft.sharedFolderEditor = false;
                draft.selectedSubFolder=null;
            });
        case Constants.ACTION_EDIT_FOLDER_PATH:
            return produce(state, draft=>{
                draft.selectedFolderName = action.payload.selectedFolderName;
                draft.selectedFolderId = action.payload.selectedFolderId;
                draft.selectedFolderRow = action.payload.editFolderModel;
                draft.sharedFolderEditor = true;
            });
        case Constants.ACTION_CLOSE_FOLDER_PATH:
            return produce(state, draft=>{
                draft.sharedFolderEditor = false;
                draft.selectedSubFolder=null;
                draft.folderPathUpdateMode=null;
            });
        case Constants.ACTION_SAVE_FOLDER_PATH:
            return produce(state, draft=>{
                draft.selectFolderMap= action.payload.selectFolderMap;
                draft.finalFolderPath= action.payload.finalFolderPath;
                draft.collaborationTeamId= action.payload.collaborationTeamId;
            });
        case Constants.SWITCH_ACCOUNT_REPORTS:
            return produce(state, draft=>{
                draft.selectedFolder = action.payload
            });
        case Constants.SWITCH_ACCOUNT_USERSPACE:
            return produce(state, draft=>{
                draft.userSpace = action.payload
            });
        case Constants.DASHBOARD_FOLDER_PURCHASEHISTORY:
            return produce(state, draft=>{
                draft.dashboardPurchaseHistory = action.payload;
            });
        case Constants.DASHBOARD_FOLDER_CONTRACTS:
            return produce(state, draft=>{
                draft.dashboardContracts = action.payload;
            });
        case Constants.DASHBOARD_FOLDER_CONTROLLEDSUBSTANCES:
            return produce(state, draft=>{
                draft.dashboardControlledSubstances = action.payload;
            });
        case Constants.DASHBOARD_FOLDER_OMITS:
            return produce(state, draft=>{
                draft.dashboardOmits = action.payload;
            });
        case Constants.DASHBOARD_FOLDER_VA:
            return produce(state, draft=>{
                draft.dashboardVa = action.payload;
            });
        case Constants.DASHBOARD_FOLDER_REFERENCE:
            return produce(state, draft=>{
                draft.dashboardReference = action.payload;
            });
        case Constants.DASHBOARD_FOLDER_USAGEDETAIL:
            return produce(state, draft=>{
                draft.dashboardUsageDetail = action.payload;
            });
        case Constants.DASHBOARD_FOLDER_NEWLYPURCHASEDITEMS:
            return produce(state, draft=>{
                draft.dashboardNewlyPurchased = action.payload;
            });
        case Constants.EVENT_FOLDER_CREATED:
            return produce(state, draft=>{
                draft.selectedFolderTitle = "";  //Reset edit fields
                draft.selectedItemDescription = "";
                draft.displayNewFolderForm = false; //Entry form is hidden
                draft.isOperationPending = false;
                //New folder is added to in memory data structure referencing user's space.
                let selFolder = draft.selectedFolder;
                if(selFolder.children==null){
                    selFolder.cilldren = [];
                }
                selFolder.children.push(action.payload);
                draft.selectedFolder = selFolder;
                draft.mode = Constants.EDIT_MODE_NONE;
                getDisplayItemReference(draft.userSpace, draft.selectedFolder.id, Constants.ITEM_TYPE_FOLDER).children.push(action.payload);

            });
        case Constants.EVENT_FOLDER_DELETED:
            return produce(state, draft=>{
                var selFolderContents = draft.selectedFolder.children; 
                //Selected report item is removed from collection of selected items.
                for(var x=0;x<selFolderContents.length;x++){
                    if(selFolderContents[x].id==action.payload.id){
                        selFolderContents.splice(x,1);
                        draft.selFolderContents = selFolderContents;
                        draft.isOperationPending = false;
                        draft.displayConfirmationDialog=false; 
                        draft.selectedItemForDeletion=null;
                        draft.selectedItemType=null;
                        draft.selectedItem = null;
                        draft.selectedItemIndex = -1;
                        draft.mode = Constants.EDIT_MODE_NONE;
                        break;
                    }
                }
            });
        case Constants.EVENT_REPORT_DELETED:
            return produce(state, draft=>{
                var selFolderContents = draft.selectedFolder.children; 
                //Selected report item is removed from collection of selected items.
                for(var x=0;x<selFolderContents.length;x++){
                    if(selFolderContents[x].id==action.payload.id){
                        selFolderContents.splice(x,1);
                        draft.selFolderContents = selFolderContents;
                        draft.isOperationPending = false;
                        draft.displayConfirmationDialog=false; 
                        draft.selectedItemForDeletion=null;
                        draft.selectedItemType=null;
                        draft.selectedItem = null;
                        draft.selectedItemIndex = -1;
                        draft.mode = Constants.EDIT_MODE_NONE;
                        break;
                    }
                }
            });
        case Constants.EVENT_DASHBOARD_DELETED:
            return produce(state, draft=>{
                var selFolderContents = draft.selectedFolder.children; 
                //Selected report item is removed from collection of selected items.
                for(var x=0;x<selFolderContents.length;x++){
                    if(selFolderContents[x].id==action.payload.id){
                        selFolderContents.splice(x,1);
                        draft.selFolderContents = selFolderContents;
                        draft.isOperationPending = false;
                        draft.displayConfirmationDialog=false; 
                        draft.selectedItemForDeletion=null;
                        draft.selectedItemType=null;
                        draft.selectedItem = null;
                        draft.selectedItemIndex = -1;
                        draft.mode = Constants.EDIT_MODE_NONE;
                        break;
                    }
                }
            });
        case Constants.ACTION_CHANGE_SORT_ORDER:
            return produce(state, draft=>{
                draft.sortOrder = action.payload;
            });
        case Constants.ACTION_DISPLAY_FOLDER_CONTENTS:
            return produce(state, draft=>{
                draft.filterMode = Constants.ITEM_TYPE_DEFAULT;
                const selFolder = getDisplayItemReference(draft.userSpace, action.payload, Constants.ITEM_TYPE_FOLDER);
                draft.selectedFolder = selFolder;
            });
        case Constants.ACTION_DISPLAY_FOLDER_STRUCTURE:
            return produce(state, draft=>{
                draft.selectedSubFolder = action.payload;
                draft.folderPathUpdateMode=null;
            });
        case Constants.ACTION_UPDATE_FOLDER_STRUCTURE:
            return produce(state, draft=>{
                draft.folderPathUpdateMode = Constants.ACTION_UPDATE_FOLDER_PATH;
                draft.sharedTeams = action.payload.updateTeamTemp;
            });
        case Constants.ACTION_EDIT_SELECTED_ITEM:
            return produce(state, draft=>{
                draft.selItem = action.payload.item;
                draft.displayNewFolderForm = true;
                draft.isOperationPending = true;
                draft.selectedItemType = action.payload.itemType;
                draft.selectedItemTitle = action.payload.item.name;
                draft.selectedItemDescription = action.payload.item.description;
                draft.selectedItemIndex = action.payload.index;
                if(action.payload.itemType==Constants.ITEM_TYPE_FOLDER){
                    draft.mode = Constants.EDIT_MODE_EDIT_FOLDER;
                }
                else if(action.payload.itemType==Constants.ITEM_TYPE_DASHBOARD){
                    draft.mode = Constants.EDIT_MODE_EDIT_DASHBOARD;
                }
                else{
                    draft.mode = Constants.EDIT_MODE_EDIT_REPORT;
                }
                

            });
        case Constants.ACTION_SHARE_SELECTED_ITEM:
            return produce(state, draft=>{
                draft.selItem = action.payload.item;
                draft.displayNewFolderForm = true;
                draft.isOperationPending = true;
                draft.selectedItemType = action.payload.itemType;
                draft.selectedItemTitle = action.payload.item.name;
                draft.selectedItemDescription = action.payload.item.description;
                draft.selectedItemIndex = action.payload.index;
                if(action.payload.itemType==Constants.ITEM_TYPE_FOLDER){
                    draft.mode = Constants.SHARE_MODE_SHARE_FOLDER;
                }
                else if(action.payload.itemType==Constants.ITEM_TYPE_DASHBOARD){
                    draft.mode = Constants.SHARE_MODE_SHARE_DASHBOARD;
                }
                else{
                    draft.mode = Constants.SHARE_MODE_SHARE_REPORT;
                }

            });
        case Constants.EVENT_REPORT_ITEM_UPDATED:
            return produce(state, draft=>{

                //Perform update of selected item within the set of items currently displayed within the current screen. 
                //This collection is a copy of the contents of the currently selected parent folder.
                var displayItems = draft.selectedFolder.children;
                for(var x=0; x<displayItems.length;x++){
                    var item = displayItems[x];
                    if(item.id==action.payload.id && item.type==action.payload.type){
                        item.name = action.payload.name;
                        item.description = action.payload.description;
                        break;
                    }
                }

                //Updates performed in the above set will not be reflected in the cached set of content, so an 
                //additional update operation will need to be performed there as well.
                    var allItems = draft.userSpace;
                    var targetItem = getDisplayItemReference(allItems, action.payload.id, action.payload.type);
                    targetItem.name = action.payload.name;
                    targetItem.description = action.payload.description;
                    draft.userSpace = allItems;

                draft.selectedItemTitle = "";
                draft.selectedItemDescription = "";
                draft.selectedItemIndex = -1;
                draft.selectedFolder.children = displayItems;
                draft.selItem = null;
                draft.displayNewFolderForm = false;
                draft.isOperationPending = false;
                draft.mode = Constants.EDIT_MODE_NONE;
            });
        /* User elects to delete a selected item. */
        case Constants.ACTION_INITIATE_ITEM_DELETION: 
            return produce(state, draft=>{
                draft.displayConfirmationDialog = true; //Enables display of confirmation dialog
                draft.selectedItemIndex = action.payload.selectedItemIndex;
                draft.selItem = action.payload.item;
                draft.selectedItemType = action.payload.item.type;
                draft.mode=Constants.EDIT_MODE_DELETE;
            });
        case Constants.ACTION_CANCEL_DELETE_ITEM_ACTION:
            return produce(state, draft=>{
                draft.displayConfirmationDialog = false;
                draft.selectedItemForDeletion = null;
                draft.selectedItemType = null;
                draft.isOperationPending = false;
                draft.selectedItemIndex = -1;
            });
        case Constants.ACTION_DELETE_ITEM:
            return produce(state, draft=>{
                draft.isOperationPending = true;
            })
        case Constants.ACTION_REPORT_OBJECTS_RELOAD: 	
            return produce(state, draft=>{
                draft.reloadingContents = true;
            });
        
        case Constants.EVENT_REPORT_OBJECTS_RELOADED:
            return produce(state, draft=>{
                draft.reloadingContents = false;
                draft.userSpace = action.payload;
            });
        case Constants.ACTION_LOAD_REPORT_OBJECTS:
            return produce(state, draft=>{
                draft.isOperationPending = true;
            });
        /*
            Event handler for operations where the local cached contents of the user's space 
            is invalidated and need to be reloaded.
        */
        case Constants.CLEAR_SPACES_CACHE:
            return produce(state, draft=>{
                draft.selectedFolder=false;
	            draft.isOperationPending=false;
            });
        case Constants.ACTION_HANDLE_INDIVIDUAL_ACTION_CLICK:
             return produce(state, draft => {
                 draft.actionOpenForScheduleId = action.payload;
             });
        default:
            return state;
    }
};

/**
 * Given a data structure representing the current user's space, and a reference to a folder (some given 
 * point in the structure, i.e. a folder id), return the reference to the folder at the point in the structure. 
 * For example, upon initial load operation for the user, the entire structure is loaded into a reference. 
 * Upon selection of a given point in the folder navigation structure, this method would provide the ability to 
 * return the selected folder, for which to display items, based on a given folder id.  
 * 
 * @param {*} spaceRef 
 * @param {*} folderId 
 */
const getDisplayItemReference = (spaceRef, id, itemType) => {
    if(!id){
        return spaceRef;
    }
    if(spaceRef.id==id && spaceRef.type==itemType){
        return spaceRef;
    }
    
    if(!spaceRef.children||spaceRef.children.length==0){
        return null;
    }

    let ref = null;
    for(var x=0;x<spaceRef.children.length;x++){
        ref = getDisplayItemReference(spaceRef.children[x], id, itemType);
        if(ref!=null){
            return ref;
        }
    }
    return null;
};

const getDisplayItemReferenceRecursive = (item, id) => {
    if(item.id==id){
        return item;
    }
    if(!item.children||item.children.length==0){
        return null;
    }

    let ref = null;
    for(var x=0;x<item.children.length;x++){
        ref = getDisplayItemReferenceRecursive(item.children[x], id);
        if(ref!=null){
            return ref;
        }
    }

}

export default actions;