import * as Constants from '../../constants/account-settings-constants';
import produce, { produceWithPatches } from 'immer';

/**
 * displayItems: collection of what is displayed in 'view' mode, possibly filtered by type.
 * allReportObjects: collection of all objects (spaces, reports, and dashboards) returned by API.
 * viewMode: is the user viewing items in the card or list view?
 * selectedItems: collection of indexes that have been selected by the user.
 * selectedFolder: reference to the selected folder (if selected, otherwise 'root' level)
 */
const initialState = {
    editAccount: false,
    userName: '',
    userRole:'',
    originalUserSudoFlag:false,
    sudoUser:false,
    fullName:'',
    userType:false,
    loginUsername:'',
    adminAccess: false,
    userManagementAccess: false,
    customerManagementAccess: false,
    teamManagementAccess: false,
    accountSegmentationAccess: false,
    vendorPurchasesAccess: false,
    canSudo: false
};

const actions = (state = initialState, action) => {
    switch(action.type){
        case Constants.ACTION_EDIT_ACCOUNT:
            return produce(state, draft=>{
                draft.editAccount = true;
            });
        case Constants.ACTION_CLOSE_ACCOUNT:
            return produce(state, draft=>{
                draft.editAccount = false;
            });
        case Constants.ACTION_ADMIN_ACCOUNT:
            return produce(state, draft=>{
                draft.expanded = !draft.expanded;
            });
        case Constants.ACTION_USER_NAME:
            return produce(state, draft=>{
                draft.userName = action.payload;
            });
        case Constants.ACTION_USER_ROLE:
            return produce(state, draft=>{
                draft.userRole = action.payload;
            });
        case Constants.ACTION_USER_TYPE:
            return produce(state, draft=>{
                draft.userType = action.payload;
            });
        case Constants.ACTION_LOGIN_USER_INFO:
            return produce(state, draft=>{
                draft.originalUserSudoFlag = action.payload.originalUserSudoFlag;
                draft.fullName = action.payload.fullName;
                draft.sudoUser = action.payload.sudoUser;
            });
        case Constants.ACTION_LOGIN_USERNAME:
            return produce(state, draft=>{
                draft.username = action.payload;
            });
        case Constants.ACTION_ROLE_ACCESS_INFO:
            return produce(state, draft=>{
                draft.adminAccess = action.payload.adminAccess;
                draft.userManagementAccess = action.payload.userManagementAccess;
                draft.customerManagementAccess = action.payload.customerManagementAccess;
                draft.teamManagementAccess = action.payload.teamManagementAccess;
                draft.accountSegmentationAccess = action.payload.accountSegmentationAccess;
                draft.vendorPurchasesAccess = action.payload.vendorPurchasesAccess;
            });
        case Constants.ACTION_CAN_SUDO:
            return produce(state, draft=>{
                draft.canSudo = action.payload;
            });
        default:
            return state;
    }
};

export default actions;