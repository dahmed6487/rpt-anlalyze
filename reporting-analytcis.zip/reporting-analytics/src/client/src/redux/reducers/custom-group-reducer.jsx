import * as CustomGroupConfigConstants from '../constants/custom-group-constants';
import produce from 'immer';

const initialState = {
	panelActive: false,
	editPanelActive: false,
	actionOpenForCustomId: -1,
	actionOpenForGroupId: -1
};

const actions = (state = initialState, action) => {
	switch(action.type){
        case CustomGroupConfigConstants.CUSTOM_PANEL_ACTIVE:
			return produce(state, draft=>{
				draft.panelActive = true;
			});
		case CustomGroupConfigConstants.CUSTOM_EDIT_PANEL_ACTIVE:
			return produce(state, draft=>{
				draft.editPanelActive = true;
			});
        case CustomGroupConfigConstants.ACTION_HANDLE_INDIVIDUAL_ACTION_CLICK:
             return produce(state, draft => {
                 draft.actionOpenForCustomId = action.payload;
             });
         case CustomGroupConfigConstants.ACTION_HANDLE_INDIVIDUAL_DEFINITION_CLICK:
              return produce(state, draft => {
                  draft.actionOpenForGroupId = action.payload;
              });
        default:
			return state;
	}
	
};

export default actions;