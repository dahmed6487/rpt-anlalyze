// Reducers 
import user from './user-reducer';
import customFilters from './custom-filter-reducer';
import space from './space-mgmnt-reducer';
import deleteDialog from './delete-dialog-reducer';
import sharing from './sharing-reducer';

export default { sharing, deleteDialog, user, customFilters, space };
