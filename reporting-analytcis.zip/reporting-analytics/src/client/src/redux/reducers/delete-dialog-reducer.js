import {DELETE_DIALOG_CLOSE, DELETE_DIALOG_OPEN} from "../constants/delete-dialog-constants";

const deleteDialogReducer = (state = [], action) => {

    if (state === undefined) {
        return {
            displayDeleteDialog: false,
            deleteDialogType: null,
            deleteItemId: null,
            deleteFunction: () => {}
        }
    }

    switch(action.type){
        case DELETE_DIALOG_OPEN:
            let itemId = action.payload.itemId;
            let type = action.payload.type;
            let deleteFunction = action.payload.deleteFunction;
            return Object.assign({}, state, {displayDeleteDialog: true, deleteDialogType: type, deleteItemId: itemId, deleteFunction: deleteFunction});
        case DELETE_DIALOG_CLOSE:
            return Object.assign({}, state, {displayDeleteDialog: false, deleteDialogType: null, deleteItemId: null, deleteFunction: () => {}});
        default:
          //  console.debug(`delete-dialog-reducer: Event type ${action.type} not handled!`)

        return state;
    }
}

export default deleteDialogReducer;