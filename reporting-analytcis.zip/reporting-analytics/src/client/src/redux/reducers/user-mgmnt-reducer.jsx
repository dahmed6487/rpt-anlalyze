import * as Constants from '../../constants/user-mgmnt-constants';
import produce, { produceWithPatches } from 'immer';

/**
 * displayItems: collection of what is displayed in 'view' mode, possibly filtered by type.
 * allReportObjects: collection of all objects (spaces, reports, and dashboards) returned by API.
 * viewMode: is the user viewing items in the card or list view?
 * selectedItems: collection of indexes that have been selected by the user.
 * selectedFolder: reference to the selected folder (if selected, otherwise 'root' level)
 */
const initialState = {
    displayNewFolderForm: false,
    userEditor: false,
    showModal: false,
    firstName: '',
    lastName: ''
};

const actions = (state = initialState, action) => {
    switch(action.type){
        case Constants.ACTION_ENTER_NEW_FOLDER:
            return produce(state, draft=>{
                draft.displayNewFolderForm = true;
            });
        case Constants.ACTION_CANCEL_ENTER_NEW_FOLDER:
            return produce(state, draft=>{
                draft.displayNewFolderForm = false;
                draft.newFolderTitle = null;
            });
        case Constants.ACTION_EDIT_USER:
            return produce(state, draft=>{
                draft.userEditor = true;
                draft.firstName = action.payload.firstName;
                draft.lastName = action.payload.lastName;
            });
        case Constants.ACTION_CLOSE_MODAL:
            return produce(state, draft=>{
                draft.showModal = false;
            });
        case Constants.ACTION_CLOSE_EDIT_MODAL:
            return produce(state, draft=>{
                draft.userEditor = false;
            });
        case Constants.ACTION_SHOW_MODAL:
            return produce(state, draft=>{
                draft.showModal = true;
            });
        default:
            return state;
    }
};

export default actions;