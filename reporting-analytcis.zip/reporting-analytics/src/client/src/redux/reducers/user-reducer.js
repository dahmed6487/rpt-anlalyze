import * as UserConstants from '../constants/user-constants';

/**
 * currentUserName: Name of active user, for display purposes 
 * currentSelectedAccount: Indicates scope of account currently in use
 */
const initialState = {
    currentUserName: '',
    currentSelectedAccount: 'sample account',
    currentUserTeams: [],
    userTeams: [],
    accountSelectionActive: false,
    dialog: {
        isOpen: false
    },
    currentUserProfile: '',
    solutionData:'',
    customersData: [],
    exploreContentAccesses: [],
};

const user = (state = initialState, action) => {
    switch(action.type){
        case UserConstants.SET_MOCK_USER:
            return Object.assign({}, state, {currentUser: action.payload, currentUserTeams: []});
        case UserConstants.SET_CUSTOMERS_DATA:
            return Object.assign({}, state, {
                customersData: action.payload
            });
        case UserConstants.SET_USER_TEAMS:
            return Object.assign({}, state, {
                currentUserTeams: action.payload
            });
        case UserConstants.SET_CONTENT_ACCESSES:
            return Object.assign({}, state, {
                exploreContentAccesses: action.payload
            });
        case "USER_TEAMS_LOADED":
            return Object.assign({}, state, {
                userTeams: action.payload
            });
        case "USER_PROFILE_LOADED":
            return Object.assign({}, state, {
                currentUserProfile: action.payload
            });
        case "ACCOUNT_SELECTION_ACTIVE":
            return Object.assign({}, state, {
                accountSelectionActive: !state.accountSelectionActive
            });
        case "DIALOG_OPEN":
            return { ...state, dialog: action.payload};
        case "DIALOG_CLOSE":
            return { ...state, dialog: { isOpen: false }};
        case UserConstants.SOLUTION_DATA:
            return Object.assign({}, state, {
                solutionData: action.payload
            });
        default:
            return state;
    }
};

export default user;