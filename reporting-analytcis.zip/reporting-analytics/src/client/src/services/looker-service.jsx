import axios from 'axios';

const CUSTOM_FILTERS_API_ENDPOINT = '/custom-filters';
const LOOKER_API_ENDPOINT = '/looker'; 

const LookerService = {

    loadFilters: function() {
      return axios.get(CUSTOM_FILTERS_API_ENDPOINT);
    },

    searchFilters: function(search){
        const params = {
            params: {
                page: 0,
                search: search
            }
        };
        return axios.get(`${CUSTOM_FILTERS_API_ENDPOINT}/search`, params);
    },

    saveFilter: function(filter){
        //console.debug(filter);
        if(filter.id==null){
          return axios.post(`${CUSTOM_FILTERS_API_ENDPOINT}`, filter);
        }
        else{
          return axios.put(`${CUSTOM_FILTERS_API_ENDPOINT}/${filter.id}`, filter);
        }
    },

    shareFilter: function(groupId, teams) {
        return axios.put(`${CUSTOM_FILTERS_API_ENDPOINT}/share/${groupId}`, teams)
    },

    getFilter: function(filterId){
        return axios.get(`${CUSTOM_FILTERS_API_ENDPOINT}/${filterId}`);
    },

    deleteFilter: function(filterId){
      return axios.delete(`${CUSTOM_FILTERS_API_ENDPOINT}/${filterId}`);
    },

    loadGroup: function(filterId) {
        return axios.get(`${CUSTOM_FILTERS_API_ENDPOINT}/groups/${filterId}`);
    },

    getCriteria: function(id) {
        return axios.get(`${CUSTOM_FILTERS_API_ENDPOINT}/criteria/${id}`);
    },

    createCriteria: function (groupId, criteria) {
        return axios.post(`${CUSTOM_FILTERS_API_ENDPOINT}/criteria?groupId=${groupId}`, criteria);
    },

    updateCriteria: function (id, criteria) {
        return axios.put(`${CUSTOM_FILTERS_API_ENDPOINT}/criteria/${id}`, criteria);
    },

    deleteCriteria: function (id) {
        return axios.delete(`${CUSTOM_FILTERS_API_ENDPOINT}/criteria/${id}`);
    },

    getVisibleDimensions: function(explore) {
        if (explore == null) {
            return axios.get(`${LOOKER_API_ENDPOINT}/visible/dimensions`);
        } else {
            return axios.get(`${LOOKER_API_ENDPOINT}/visible/dimensions?explore=${explore}`);
        }
    },

    getValuesForDimension: function(view, field, userInput) {
        return axios.get(`${LOOKER_API_ENDPOINT}/dimension/values?view=${view}&field=${field}&userInput=${userInput}`);
    },

    getDashboardExploreEmbedUrl: function (modelName, explore, qid, customerId, finalUserAttribute) {
        if (finalUserAttribute === null)
            return axios.get(`${LOOKER_API_ENDPOINT}/dashboard/explore/${modelName}/${explore}?qid=${qid}&customerId=${customerId}`);
        else
            return axios.get(`${LOOKER_API_ENDPOINT}/dashboard/explore/${modelName}/${explore}?qid=${qid}&customerId=${customerId}&finalUserAttribute=${finalUserAttribute}`);
    },

    getSolutionData: function() {
        return axios.get(`${LOOKER_API_ENDPOINT}/get/solutions?customerName=${localStorage.getItem('userAccount')}`);
    },

    getScheduledReports: function() {
        return axios.get(`${LOOKER_API_ENDPOINT}/get/schedules`);
    },

    deleteScheduledReports: function(scheduledPlanId) {
        return axios.delete(`${LOOKER_API_ENDPOINT}/schedules/${scheduledPlanId}`);
    },

};

export default LookerService;