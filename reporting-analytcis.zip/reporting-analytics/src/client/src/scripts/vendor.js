window.$ = require('jquery');
window.jQuery = require('jquery');
