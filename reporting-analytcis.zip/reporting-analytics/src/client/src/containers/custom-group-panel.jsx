import React, { Component } from "react";
import CustomGroupView from '../components/custom-group/custom-group-view';

export default class CustomGroupPanel extends Component {
    constructor(props, context) {
        super(props, context);
    }

    render() {
        return (
            <CustomGroupView />
        );
    }
}
