import React, { Component } from "react";
import ScheduledReportsView from '../components/scheduled-reports/scheduled-reports-view';

export default class ScheduledReports extends Component {
    constructor(props, context) {
        super(props, context);
    }

    render() {
        return (
            <ScheduledReportsView />
        );
    }
}