import React, { Component } from "react";
import { connect } from "react-redux";

import UserPermissionContainer from './user-permsn-container';
import SubMenuAdminFolder from './sub-menu-admin-folder';


class UserRolesContainer extends Component{

    constructor(props) {
        super(props);
        const { dispatch } = props;
        this.actions = props.actions;
    }

    componentDidMount = () => {
    }
   
    render() {
        return (
            <div className="panel user-mgmnt-panel">
                <div>
                    <div className="reportListSortPanel editUser">
                        <div className="user-id-text">
                            <span className="user-text-id">ID/USERNAME</span>
                            <input
                                type="text"
                                className="form-control search-input user-name-search user-edit-search"
                                placeholder="VVandusictson"
                                value={this.props.firstName.charAt(0).toUpperCase()
                                                                + this.props.lastName}
                                readOnly
                            />
                            &nbsp;&nbsp;
                            </div>
                        <div className="first-last-name">
                            <div className="first-name">
                                <span className="first-name-id user-text-id">FIRST NAME</span>
                                <input type="text" className="form-control search-input first-name-text" placeholder="Valentina" value={this.props.firstName} readOnly />
                            &nbsp;&nbsp;
                            </div>
                            <div className="last-name">
                                <span className="last-name-id user-text-id">LAST NAME</span>
                                <input type="text" className="form-control search-input lastname-text" placeholder="Van Dusictson" value={this.props.lastName} readOnly />
                        &nbsp;&nbsp;
                        </div>
                        </div>
                        <div className="user-email-text">
                            <span className="email-id user-text-id">EMAIL</span>
                            <input type="text" className="form-control search-input user-name-search user-edit-search" placeholder="Search Users" />
                    &nbsp;&nbsp;
                        </div>
                    </div>
                </div>
                &nbsp;&nbsp;
                <hr className="user-mgmnt-divider user-roles-divider" />
                <div>
                    <div className="first-name-id user-text-id"> INDIVIDUAL ROLES</div>
                    <div className="individual-roles-text user-text-id">  Use the Roles tab to create new roles with specific permissions and access</div>
                    <div className="col-lg-2 admin-checkbox">
                        <span>
                            { this.props.roleResults && this.props.roleResults.map((rep, i)=> {
                              return <SubMenuAdminFolder rep={rep} />;
                            })}
                        </span>
                    </div>
                    <div className="groups">
                        <div className="first-name-id user-text-id"> Teams</div>
                        <div className="individual-roles-text user-text-id">Use the Groups tab to create new groups</div>
                        <div className="col-lg-2 grp-admin">
                            <span className="admin-id user-text-id">
                            { this.props.groupResults && this.props.groupResults.map((rep, i)=> {
                              return <SubMenuAdminFolder rep={rep} />;
                            })}
                            </span>
                        </div>
                    </div>
                    <hr className="user-delete-divider" />
                </div>
            </div>
        );
    }
};

const mapStateToProps = (state, ownProps) => {
    return {
        currentUserName: state.user.currentUserName,
        groupResults: state.lookerAdmin.groupResults,
        roleResults: state.lookerAdmin.roleResults,
        userResults: state.lookerAdmin.userResults,
        userGroupResults: state.lookerAdmin.userGroupResults,
        firstName: state.userMgmnt.firstName,
        lastName: state.userMgmnt.lastName,
    };
};

export default connect(mapStateToProps)(UserRolesContainer);