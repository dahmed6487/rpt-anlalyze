import React, { Component } from 'react';
import { connect } from 'react-redux';

import * as UserMgmntActions from '../redux/actions/user-mgmnt-actions';
import UserPermissionContainer from './user-permsn-container';
import UserRolesContainer from './user-roles-container';


class EditUserContainer extends Component{

    constructor(props) {
        super(props)
        const { dispatch } = props;
        this.actions = props.actions;
        this.state = {
            userRoles: true
          };
    }

    componentDidMount = () => {
    }
    
    closeUserEditModal = (event) => {
        event.preventDefault();
        this.props.dispatch(UserMgmntActions.closeUserEditModal());
    }

    userRoles = (event) => {
        event.preventDefault();
        this.setState({
            userRoles: true
        })
    }

    userPermissions = (event) => {
        event.preventDefault();
        this.setState({
            userRoles: false
        })
    }  

    render(){
        let user_roles = this.state.userRoles ? 'user-roles-groups' : '';
        let user_permissions = !this.state.userRoles ? 'user-roles-groups' : '';
        let edit_divider = this.state.userRoles ? 'user-roles-divider' : 'user-permissions-divider';
        return (
          <div id="myModal" role="dialog">
              <div className="modal-dialog modal-sm">
                  <div className="user-modal">
                      <div className="modal-header user-mgmnt-header">
                          <h4 className="modal-title">Edit User</h4>
                          <button type="button" onClick={this.closeUserEditModal} className="close user-mgmnt-close" data-dismiss="modal">&times;</button>
                      </div>
                      <div className="modal-body edit-modal-body">
                          <div className="titlePanel user-mgmnt-title edit-mgmnt-title">
                              <div className="userNameElement col-lg-11 edit-user-header">
                                  <div className="edit-user-roles">
                                      <span className={user_roles} onClick={this.userRoles}> User Roles & Groups</span>
                                    {' '}
                                    &nbsp; &nbsp;
                                    {this.state.userRoles ? <hr className="edit-roles-divider" /> : ''}
                                  </div>
                                  <div className="edit-user-permissions">
                                      <span className={user_permissions} onClick={this.userPermissions}>User Permissions</span>
                                      {!this.state.userRoles ? <hr className="edit-permissions-divider" /> : ''}
                                  </div>
                              </div>
                          </div>
                          {this.state.userRoles
                              ? <UserRolesContainer />
                            : <UserPermissionContainer />}
                      </div>
                      <button type="button" className="btn btn-default save-btn">
                        <span className="save-lbl">Save</span>
                        {' '}
                      </button>
                  </div>
              </div>
          </div>
        );
    }
};

const mapStateToProps = (state, ownProps) => {
    return {
        currentUserName: state.user.currentUserName
    };
}

export default connect(mapStateToProps)(EditUserContainer);