import React, { Component } from "react";
import autoBind from "react-autobind";
import { NavLink } from "react-router-dom";
import {connect} from 'react-redux';

class SubMenuAdminFolder extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);
    this.actions = props.actions;
  }

  render() {
    return (
        <div className="menu-link-sub-child roles-groups">
            <input type="checkbox" className="role-checkbox" />
            <span className="link-text">{this.props.rep.name}</span>
        </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
    return {
      store: state
    };
  }
  
export default connect(mapStateToProps)(SubMenuAdminFolder);
