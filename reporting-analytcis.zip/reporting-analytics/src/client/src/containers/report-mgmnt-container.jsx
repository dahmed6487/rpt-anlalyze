import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom'

import * as ReportActions from '../redux/actions/space-mgmnt-actions';
import TrashIcon from '../components/icons/trash-icon';
import DashboardIcon from '../components/icons/dashbboard-icon';
import ReportIcon from '../components/icons/report-icon';
import FolderIcon from '../components/icons/folder-icon';
import ShareIcon from '../components/icons/share-icon';
import NewFolderIcon from '../components/icons/new-folder-icon';
import EditIcon from '../components/icons/edit-icon';
import RenameIcon from '../components/icons/rename-icon';

import {SET_MOCK_USER} from '../redux/constants/user-constants';
import * as AppConstants from '../redux/constants/application-constants';
import Modal from 'react-modal';

import {Helmet} from 'react-helmet';
import DefaultPanel from '../components/default-panel';

import * as Constants from '../constants/space-mgmnt-constants';
import ShareReportPanel from '../components/sidebar/share-report-panel';
import LinkIcon from '../components/icons/link-icon';
import SearchForm from '../components/form/search-form';
import TeamService from '../redux/services/team-service';
import Moment from 'react-moment';
import jstz from 'jstz';


const exploreUrlMappings = {
    'if_ra_fact_invc_purch_hist':'purchases',
    'dt_contract_cust_buygroup':'contracts',
    'physical_inventory':'physical-inventory',
    'idb':'idb'
}
const customStyles = {
    content : {
        top                   : '50%',
        left                  : '50%',
        right                 : 'auto',
        bottom                : 'auto',
        marginRight           : '-50%',
        transform             : 'translate(-50%, -50%)',
        width                 : '500px'
    }
};

const editDialog = {
    content : {
        top                   : '50%',
        left                  : '50%',
        right                 : 'auto',
        bottom                : 'auto',
        marginRight           : '-50%',
        transform             : 'translate(-50%, -50%)',
        width                 : '750px',
    }
};

const editShareDialog = {
    content : {
        top                   : '50%',
        left                  : '50%',
        right                 : 'auto',
        bottom                : 'auto',
        marginRight           : '-50%',
        transform             : 'translate(-50%, -50%)',
        width                 : '1000px'
    }
};

const folderCustomStyles = {
    content : {
        top                   : '44.5%',
        left                  : '53%',
        right                 : 'auto',
        width                 : '70%',
        height                : '100%',
        bottom                : 'auto',
        background            : 'none',
        marginRight           : '-50%',
        border                : '0',
        overflow              : 'auto',
        transform             : 'translate(-50%, -50%)'
    },
    overlay: {
        position: 'fixed',
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
        width: '100%',
        height: '100%',
        backgroundColor: 'rgba(0,0,0,0)',
        zIndex: 1050
    }
};

let isModalOpen = true,teamsGridData = null,externalId = new Map();

class ReportManagementContainer extends Component {

    constructor(props) {
        super(props)
        const { dispatch } = props;
        this.state = {
            iframeUrl: '',
            mode: 'default',
            shareTitleUpdated : '',
            shareDescriptionUpdated : '',
            expanded: false,
            isShareReportPanelVisible : false,
            selectExternalId : '',
            reportSharedTeams:this.props.sharedTeams,
            customerName:localStorage.getItem('userAccount')
        }
    }

    sortByNameAsc = () => {
        this.props.dispatch(ReportActions.sortDisplayByNameAsc());
    }

    sortByNameDesc = () => {
        this.props.dispatch(ReportActions.sortDisplayByNameDesc());
    }

    sortByReportTypeAsc = () => {
        this.props.dispatch(ReportActions.sortByObjectTypeAsc());

    }
    sortByReportTypeDesc = () => {
        this.props.dispatch(ReportActions.sortByObjectTypeDesc());

    }

    sortByLastModificationDateAsc = () => {
        this.props.dispatch(ReportActions.sortByLastModificationDateAsc());
    }

    sortByLastModificationDateDesc = () => {
        this.props.dispatch(ReportActions.sortByLastModificationDateDesc());
    }

    sortByFavoriteAttributeAsc = () => {
        this.props.dispatch(ReportActions.sortByFavoriteAttributeAsc());
    }

    sortByFavoriteAttributeDesc = () => {
        this.props.dispatch(ReportActions.sortByFavoriteAttributeDesc());
    }

    handleAccount = (event) => {
        const SWITCH_ACCOUNT = 'SWITCH_ACCOUNT';
        this.props.dispatch({type: SWITCH_ACCOUNT, payload: this.state.iframeUrl});
    }

    getItemSummary = (item) => {
        return (
          <div>
            <div className="itemName">{item.name}</div>
            <div className="itemDescription">{item.description === 'null' ? '' : item.description}</div>
          </div>
        );
    }

    getLastModifiedLabel = (item) =>{
        if (!sessionStorage.getItem('timeZone')) {
            let timeZone = jstz.determine() || 'UTC';
            sessionStorage.setItem('timeZone', timeZone.name());
        }
        let timeZone = sessionStorage.getItem('timeZone');
        let temp = item.createdAt === undefined || item.createdAt === '' ? item.lastUpdated : item.createdAt;
        if(temp){
            return <Moment parse="YYYY-MM-DDTHH:mm:ssZ"
                    format="MM-DD-YYYY  hh:mm:ss a"
                    tz={timeZone}
            >
              {temp}
                   </Moment>
        }
        return '';
    }

    getTypeLabel = (item) => {
        if(item.type == Constants.ITEM_TYPE_FOLDER) {
            return (
              <div>
                <FolderIcon />
                {' '}
                Folder
              </div>
            );
        }
        else if(item.type == Constants.ITEM_TYPE_DASHBOARD){
            return (
              <div>
                <DashboardIcon />
                {' '}
                Dashboard
              </div>
            );
        } else if(item.type == Constants.ITEM_TYPE_REPORT){
            return (
              <div>
                <ReportIcon />
                {' '}
                Report
              </div>
            );
        }
        return 'UNDEFINED';
    }

    /**
     * Determine which icon to display based on item type.
     */
    getLookerThumbnailIcon = (item) => {
        if(item.type == Constants.ITEM_TYPE_FOLDER){
            return (
              <div className="reportIconIcon" onClick={()=>{ this.handleReportItemSelection(item) }}>
                <img src={require('../img/mock/mock-folder.svg')} className='looker-icon'/>
              </div>
            );
        }
        else if(item.type == Constants.ITEM_TYPE_DASHBOARD){
            return (
              <div className="reportIconIcon" onClick={()=>{ this.handleReportItemSelection(item) }}>
                <img src={require('../img/mock/mock-dashboard.svg')} className='looker-icon'/>
              </div>
            );
        }
        else if(item.type == Constants.ITEM_TYPE_REPORT){
            return (
              <div className="reportIconIcon" onClick={()=>{ this.handleReportItemSelection(item) }}>
                <img src={require('../img/mock/mock-report.svg')} className='looker-icon'/>
              </div>
            );
        }
    }

    /**
     * Event handler for when an object is selected.
     */
    handleReportItemSelection = (selItem)=>{

        if(selItem.type === Constants.ITEM_TYPE_REPORT){
            const reqUrl = `/displayReport/${selItem.id}`;
            this.props.history.push(reqUrl);
        }
        else if(selItem.type === Constants.ITEM_TYPE_DASHBOARD){
            const reqUrl = `/displayDashboard/${selItem.id}`;
            this.props.history.push(reqUrl);
        }
        else if(selItem.type === Constants.ITEM_TYPE_FOLDER){
            this.handleSelectedFolderEvent(selItem.id);
        }
    }

    /**
     * Event handler for when an object is selected.
     */
    handleReportItemExploreSelection = (selItem)=>{
        let reqUrl = '';
        if(selItem.type === Constants.ITEM_TYPE_REPORT){
            if(this.isTeamMode())
             reqUrl = '/team-reports/explore/' + exploreUrlMappings[selItem.view] + '/' + selItem.clientId;
            else
             reqUrl = '/my-reports/explore/' + exploreUrlMappings[selItem.view] + '/' + selItem.clientId;
            this.props.history.push(reqUrl);
        }

        else if(selItem.type === Constants.ITEM_TYPE_DASHBOARD){
            if(this.isTeamMode())
             reqUrl = '/team-reports/explore/' + exploreUrlMappings[selItem.view] + '/' + selItem.clientId;
            else
             reqUrl = '/my-reports/explore/' + exploreUrlMappings[selItem.view] + '/' + selItem.clientId;
            this.props.history.push(reqUrl);
        }
        else if(selItem.type === Constants.ITEM_TYPE_FOLDER){
            this.handleSelectedFolderEvent(selItem.id);
        }
    }

    getDisplayItemByById = (id) => {
        const curDisplayItems = this.props.selectedFolder.children;
        for(var x = 0;x < curDisplayItems.length;x++){
            if(curDisplayItems[x].id === id){
                return curDisplayItems[x];
            }
        }
        return null
    }

    handleSelectedFolderEvent(folderId){
        if(this.props.isOperationPending){
            return;
        }
        this.props.dispatch(ReportActions.displayFolderContents(folderId), this.isTeamMode());
    }

    initiateItemDeletion = (item, index) => {
        if(this.props.isOperationPending){
            return;
        }

        this.props.dispatch(ReportActions.initializeItemDeletion(item, index));
    }

    getDeleteConfirmationContent(){
        if(!this.props.selectedItemType){
            return '';
        }

        switch(this.props.selectedItemType){
            case Constants.ITEM_TYPE_FOLDER:
                return `Delete selected folder \'${this.props.selItem.name}\' ?`;
            case Constants.ITEM_TYPE_DASHBOARD:
                return `Delete selected dashboard \'${this.props.selItem.name}\' ?`;
            case Constants.ITEM_TYPE_REPORT:
                return `Delete selected report \'${this.props.selItem.name}\' ?`;
        }

        return '';
    }

    getEditDialogTitle = () => {
        if(this.props.selItem != null){
            switch(this.props.selectedItem.type){
                case Constants.ITEM_TYPE_FOLDER:
                    return 'Edit Folder';
                case Constants.ITEM_TYPE_DASHBOARD:
                    return 'Edit Dashboard';
                case Constants.ITEM_TYPE_REPORT:
                    return 'Edit Report';
                default:
                    return '';
            }
        }
        else{
            return 'Add New Folder';
        }
    }

    getEditIcon = (item, index) => {
        if(item.type === Constants.ITEM_TYPE_FOLDER){
            return(<div className="icon" style={{height: '0px'}}/>);
        }
        if(this.props.adminAccess){
            return (<EditIcon eventHandler={()=>{ this.handleReportItemExploreSelection(item, index) }}></EditIcon>);
        } else {
            if (item.currentUserMayEdit) {
                return (<EditIcon eventHandler={() => {
                    this.handleReportItemExploreSelection(item, index)
                }}
                >
                        </EditIcon>);
            }
        }
        return(<div className="icon" style={{height: '0px'}}/>);
    }

    getRenameIcon = (item, index) => {
        if(this.props.adminAccess){
            return (<RenameIcon eventHandler={()=>{ this.editSelectedItem(item, index) }}></RenameIcon>);
        } else {
            if (item.currentUserMayEdit) {
                return (<RenameIcon eventHandler={() => {
                    this.editSelectedItem(item, index)
                }}
                >
                        </RenameIcon>);
            }
        }
        return(<div className="icon" style={{height: '0px'}}/>);
    }

    getDeleteIcon = (item, index) => {

        if(item.type === Constants.ITEM_TYPE_FOLDER && (item.children && item.children.length > 0)){
            return(<div className="icon" style={{height: '0px'}}/>);
        }

        if(this.props.adminAccess){
            return(
              <TrashIcon eventHandler={()=>{ this.initiateItemDeletion(item, index) }}></TrashIcon>
            );
        } else {
            if (item.currentUserMayEdit) {
                return (
                  <TrashIcon eventHandler={() => {
                        this.initiateItemDeletion(item, index)
                    }}
                  >
                  </TrashIcon>
                );
            }
        }
        return(<div className="icon" style={{height: '0px'}}/>);
    }

    getShareLinkIcon = (item, index) => {
        if(item.type === Constants.ITEM_TYPE_FOLDER){
            return(<div className="icon" style={{height: '0px'}}/>);
        }

        if(this.isTeamMode() ){
            return(
              <LinkIcon eventHandler={()=>{ this.copyReportUrl(item, index) }}></LinkIcon>
            );
        }

        return(<div className="icon" style={{height: '0px'}}/>);
    }

    getShareIcon = (item, index) => {
        if (item.type === Constants.ITEM_TYPE_FOLDER) {
            return(<div className="icon" style={{height: '0px'}}/>);
        }
        if (item.type === Constants.ITEM_TYPE_REPORT){
            if (!this.isTeamMode() || item.currentUserMayEdit) {
                return (<ShareIcon eventHandler={() => { this.shareSelectedItem(item, index) }}></ShareIcon>);
            }
        }
        return(<div className="icon" style={{height: '0px'}}/>);
    }

    getListPanelContent = () => {
        const panelContent = [];
        if(!this.props.selectedFolder){
            return(
              <div>
                <div></div>
              </div>
            );
        }

        //const items = this.props.selectedFolder.children;
        const items = this.getFilterItems();
        const sortedItems = this.sortDisplayItems(items);
        sortedItems.forEach((item, index)=>{
            panelContent.push(
                (
                  <div className={'row reportListRow ' + (this.props.selectedItemIndex == index ? 'selectedRow' : '')} key={index} onDoubleClick={()=>this.handleReportItemSelection(index)}>
                    <div onClick={this.handleAccount} className="col-lg-1">
                        {this.getLookerThumbnailIcon(item)}
                    </div>
                    <div className={this.isTeamMode() ? 'col-lg-4' : 'col-lg-4'} style={{'paddingTop': '14px'}} onClick={()=>{ this.handleReportItemSelection(item) }}>
                        {this.getItemSummary(item)}
                    </div>
                    <div className="col-lg-2 col-align-left" onClick={()=>{ this.handleReportItemSelection(item) }}>
                        {this.getTypeLabel(item)}
                    </div>
                    <div className="col-lg-2" style={{'paddingTop': '14px'}}>
                        {this.getLastModifiedLabel(item)}
                    </div>
                    <div className="col-lg-3" style={{'text-align': 'center'}}>
                        { this.getEditIcon(item, index)}
                        { this.getRenameIcon(item, index)}
                        {this.getDeleteIcon(item, index)}
                        {!this.isTeamMode() && this.getShareIcon(item, index)}
                        { this.isTeamMode() && this.getShareLinkIcon(item, index)}
                    </div>

                  </div>

                )
            );
        })
        return panelContent;
    }

    enterNewFolder = () => {
        this.props.dispatch(ReportActions.enterNewFolder());
    }

    editSelectedItem = (item, index) => {
        this.props.dispatch(ReportActions.editSelectedItem(item, item.type, index));
    }

    shareSelectedItem = (item, index) => {
        externalId.clear();
        this.setState({reportSharedTeams:this.props.sharedTeams});
        this.props.dispatch(ReportActions.shareSelectedItem(item, item.type, index));
    }

    cancelAddFolderAction = () => {
        externalId.clear();
        this.props.dispatch(ReportActions.cancelNewFolderEntry());
        this.setState({shareTitleUpdated :'', shareDescriptionUpdated:''})
    }

    cancelDeleteItemAction = () => {
        this.props.dispatch(ReportActions.cancelDeleteReportItem());
    }

    confirmDeleteItemAction = () => {
        const itemId = this.props.selectedItemForDeletion;
        this.props.dispatch(ReportActions.deleteSelectedItem(this.props.selItem, this.isTeamMode));
    }

    createNewFolder = () => {
        let temp = localStorage.getItem('userAccount');
        this.props.dispatch(ReportActions.saveNewFolderChanges(this.props.selectedItemTitle, this.props.selectedFolder,this.isTeamMode,temp));
    }

    /**
     * Event handler for when user is creating or save changes to an existing folder.
     */
    saveItemChanges = () => {
        let temp = localStorage.getItem('userAccount');
        if(this.props.selItem){
            switch(this.props.selItem.type){
                case Constants.ITEM_TYPE_REPORT:
                    this.props.dispatch(ReportActions.saveReportChanges(this.props.selItem.id, this.props.selectedItemTitle,
                        this.props.selectedItemDescription));
                    break;
                case Constants.ITEM_TYPE_DASHBOARD:
                    this.props.dispatch(ReportActions.saveDashboardChanges(this.props.selItem.id, this.props.selectedItemTitle,
                        this.props.selectedItemDescription));
                    break;
                case Constants.ITEM_TYPE_FOLDER:

                    this.props.dispatch(ReportActions.saveFolderChanges(this.props.selItem.id, this.props.selectedItemTitle,
                        this.props.selItem.parentId,this.isTeamMode(),temp));
                    break;
            }
            return;
        }
        else{
            this.props.dispatch(ReportActions.saveNewFolderChanges(this.props.selectedItemTitle, this.props.selectedFolder, this.isTeamMode()));
        }

    }

    shareItemReport = () => {
        let title = this.state.shareTitleUpdated == '' ? this.props.selectedItemTitle : this.state.shareTitleUpdated;
        let desc = this.state.shareDescriptionUpdated == '' ? this.props.selectedItemDescription : this.state.shareDescriptionUpdated;
        if(externalId.size === 0)
            alert('Please select a team')
        else{
            let temp = new Map();
            let teamIds = new Map();
            externalId.forEach((rep, i) =>{
                this.props.sharedTeams.forEach(element =>
                    {
                        if (parseInt(i) === element.externalId){
                            if(element.selectedFolderMap === ''){
                                temp.set(i,rep)
                            } else {
                                let sdlf = JSON.parse(element.selectedFolderMap);
                                let lengthArry = sdlf.length;
                                temp.set(sdlf[lengthArry - 1][0],sdlf[lengthArry - 1][1].name)
                            }
                            teamIds.set(element.collaborationTeamId,element.collaborationTeamId)
                        }
                    }

                );


                //temp.set(rep.externalId.toString(),rep.name);
            })
            this.props.dispatch(ReportActions.shareReport(this.props.selItem, this.props.selItem.id, title, desc, temp, teamIds, false));
        }
        return;
    }

    folderNameUpdated = (newVal) => {
        this.props.dispatch(ReportActions.updateItemName(newVal));
    }

    itemDescriptionUpdated = (newVal) => {
        this.props.dispatch(ReportActions.updateItemDescription(newVal));
    }

    itemShareTitleUpdated = (newVal) => {
        this.setState({shareTitleUpdated:newVal})
    }

    itemShareDescriptionUpdated = (newVal) => {
        this.setState({shareDescriptionUpdated:newVal})
    }

    handleUserSelection = (event) => {
        this.props.dispatch({type: SET_MOCK_USER, payload: event.target.value});
    }

    /** Retrieve contents  */
    getEditDialog = () => {
        if (this.props.mode == Constants.EDIT_MODE_NONE || this.props.mode == Constants.EDIT_MODE_DELETE) {
            return null;
        }
        var item = this.props.selectedItem;
        var selItemTitle;
        var selItemDescription;
        var dialogTitle;
        if (this.props.mode == Constants.EDIT_MODE_EDIT_DASHBOARD || this.props.mode == Constants.EDIT_MODE_EDIT_FOLDER || this.props.mode == Constants.EDIT_MODE_EDIT_REPORT) {
            selItemTitle = this.props.selectedItemTitle;
            selItemDescription = this.props.selectedItemDescription;
            var reportType;
            if (this.props.selectedItemType == Constants.ITEM_TYPE_FOLDER) {
                reportType = 'Folder';
            } else if (this.props.selectedItemType == Constants.ITEM_TYPE_REPORT) {
                reportType = 'Report';
            } else {
                reportType = 'Dashboard';
            }
            dialogTitle = `Edit ${reportType}: \'${selItemTitle}\'`;
        } else {
            selItemTitle = this.props.selectedItemTitle;
            dialogTitle = this.props.mode == Constants.SHARE_MODE_SHARE_REPORT ? `Share Report: \'${selItemTitle}\'` : 'Enter New Folder';
        }

        if (this.state.mode == Constants.ENTER_NEW_FOLDER) {
            selItemTitle = '';
            selItemDescription = '';
            dialogTitle = 'Add New Folder';
        }

        var titleVal = this.props.selectedItemTitle ? this.props.selectedItemTitle : '';
        var titleDesc = this.props.selectedItemDescription ? this.props.selectedItemDescription : '';

        if (this.props.mode == Constants.SHARE_MODE_SHARE_REPORT) {
            if (document.getElementById('itemDescriptionId') !== null && document.getElementById('itemNameId') !== null) {
                if (document.getElementById('itemNameId').value !== this.props.selectedItemTitle)
                    titleVal = this.state.shareTitleUpdated;
                if (document.getElementById('itemDescriptionId').value !== this.props.selectedItemDescription)
                    titleDesc = this.state.shareDescriptionUpdated
            }
        }

        if (this.props.sharedFolderEditor) {
            return (
              <div className="">
                <Modal isOpen={this.props.sharedFolderEditor} style={editShareDialog}
                           onCancel={this.cancelAddFolderAction}
                ><ShareReportPanel selectedFolderRow={this.props.selectedFolderRow}/>
                </Modal>
              </div>)
        } else {

            return (
              <div className="">
                <Modal isOpen={true}
                           style={this.props.mode == Constants.SHARE_MODE_SHARE_REPORT ? editShareDialog : editDialog}
                >
                    <div className="modal-header">
                        <span className="generic-dialog-title">{dialogTitle}</span>
                        <button type="button" className="close" data-dismiss="modal" aria-label="Close"
                                    onClick={this.cancelAddFolderAction}
                        >
                            <span aria-hidden="true">&times;</span>
                        </button>
                        {this.props.mode == Constants.SHARE_MODE_SHARE_REPORT ?
                            <div className="row">
                                <div className="col-md-4">
                                    <label htmlFor="itemNameId">
                                        Title:
                                    </label>
                                    <input type="text" className="form-control" value={titleVal}
                                               onChange={(e) => this.itemShareTitleUpdated(e.target.value)}
                                               id="itemNameId" maxLength="99"
                                    />
                                </div>
                                <div className="col-md-8">
                                    <label htmlFor="itemDescriptionId">
                                        Description:
                                    </label>
                                    <textarea id="itemDescriptionId" className="form-control" rows="2"
                                                  onChange={(e) => this.itemShareDescriptionUpdated(e.target.value)}
                                                  value={titleDesc}
                                    />
                                </div>
                            </div> : ''}
                    </div>
                    <div className="modal-body">
                        {this.props.mode == Constants.SHARE_MODE_SHARE_REPORT ?
                            <div className="container">
                                <SearchForm classes={'xtra-bottom'} onChange={(searchString) => this.callSearchTeams(searchString)} placeHolder={'Search a Team by name'}/>
                                <div className="row">
                                    <div className="col-md-12">
                                        <div className="form-group">
                                            <div className={'criteriaListPanel col-sm-12 col-md-12'}>
                                                <div className={'filterNamePanel col-sm-1 col-md-1'}><input
                                                        type="checkbox" onChange={(event) => this.checkAll(event)}
                                                />
                                                </div>
                                                <div className={'filterNamePanel col-sm-3 col-md-3'}><label
                                                        style={{'fontSize': '17px', 'textTransform': 'none'}}
                                                >
                                                    <b>Team</b>
                                                                                                     </label>
                                                </div>
                                                <div className={'filterNamePanel col-sm-3 col-md-3'}><label
                                                        style={{'fontSize': '17px', 'textTransform': 'none'}}
                                                >
                                                    <b>Customer</b>
                                                                                                     </label>
                                                </div>
                                                <div className={'filterNamePanel col-sm-5 col-md-5'}><label
                                                        style={{'fontSize': '17px', 'textTransform': 'none'}}
                                                >
                                                    <b>Selected Folder Path</b>
                                                                                                     </label>
                                                </div>
                                            </div>
                                            {this.loadReportShareGrid(this.props.sharedTeams)}
                                        </div>
                                    </div>
                                </div>
                            </div>
                                :
                              <div className="container">
                                  <div className="row">
                                    <div className="col-md-12">

                                        <div className="form-group">
                                            <label htmlFor="itemName">
                                                Title:
                                            </label>
                                            <input type="text" className="form-control" value={titleVal}
                                                       onChange={(e) => this.folderNameUpdated(e.target.value)}
                                                       id="itemName" maxLength="99"
                                            />
                                        </div>

                                    </div>
                                  </div>
                                  {this.props.selectedItemType == Constants.ITEM_TYPE_FOLDER ? '' :
                                  <div className="row">
                                      <div className="col-md-12">
                                            <label htmlFor="itemDescription">
                                                Description:
                                            </label>
                                            <textarea id="itemDescription" className="form-control" rows="5"
                                                          onChange={(e) => this.itemDescriptionUpdated(e.target.value)}
                                                          value={titleDesc}
                                            />
                                      </div>
                                  </div>
                                    }
                              </div>
                            }  
                    </div>

                    <div className={'dialog-footer'}>
                        <div className={'text-right'}>
                            <button onClick={this.cancelAddFolderAction} className={'btn btn-link'}>Cancel</button>
                            {this.props.mode == Constants.SHARE_MODE_SHARE_REPORT ?
                                <button type="button" class="btn btn-primary"
                                            onClick={this.shareItemReport}
                                >Share
                                </button> :
                                  <button type="button" class="btn btn-primary"
                                            onClick={this.props.mode == Constants.ENTER_NEW_FOLDER ? this.createNewFolder : this.saveItemChanges}
                                  >Save
                                  </button>}
                        </div>
                    </div>

                </Modal>}
              </div>
            );
        }
    }

    /**
     * Confirmation dialog for delete operations.
     */
    getItemConfirmationDialog = () => {
        if(this.props.mode != Constants.EDIT_MODE_DELETE){
            return null;
        }
        return (
          <div className="">
            <Modal isOpen={this.props.displayConfirmationDialog} style={customStyles}>
                <div className="modal-header">
                    <span className="generic-dialog-title">Delete Item</span>
                    <button type="button" className="close" data-dismiss="modal" aria-label="Close" onClick={this.cancelDeleteItemAction}>
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div className="modal-body">
                    {this.getDeleteConfirmationContent()}
                </div>
                <div className="modal-footer">
                    <button type="button" className="btn btn-default" onClick={this.cancelDeleteItemAction}>Cancel</button>
                    <a className="btn btn-danger btn-ok" onClick={this.confirmDeleteItemAction}>Delete</a>
                </div>
            </Modal>
          </div>
        );
    }

    /**
     * Main routine to get UI layout for component.
     */
    getReportMgmntContent = () => {
        //Conditionally load report items, if they have not been loaded, this would be an condition of either an initial load
        //or if the cached contents have been invalidated via an embed iframe operation.
        if (!this.props.selectedFolder && this.props.isOperationPending == false) {
            this.props.dispatch({type: AppConstants.API_CALL_TRIGGERED});
            this.props.dispatch(ReportActions.loadReportObjects(localStorage.getItem('userAccount'), this.props.selectedFolder, this.isTeamMode()));
            this.props.dispatch(ReportActions.loadSharedTeams());
        }

        if (!this.props.teamReportsError) {
            return (
              <div className="home">
                <div className="row">
                    <div className="col-xs-12">
                        <div className="home" style={{marginTop: '49px'}}>
                            <div className="well">
                                {this.props.customGroupDialog && <DefaultPanel close={this.state.close}/>}
                                <div>
                                    {this.getLocationHistoryContent()}
                                </div>

                                {this.getEditDialog()}

                                <div className="report-management-panel">
                                    {this.getNewFolderActionItem()}
                                    <div>
                                        <div className="reportListSortPanel">
                                            <div className="row">
                                                <div className="col-lg-1">

                                                </div>
                                                <div className={this.isTeamMode() ? 'col-lg-4' : 'col-lg-4'}>
                                                    <span className="glyphicon glyphicon-triangle-bottom"
                                                              onClick={this.sortByNameAsc}
                                                    >
                                                    </span>
                                                    <span className="glyphicon glyphicon-triangle-top"
                                                              onClick={this.sortByNameDesc}
                                                    >
                                                    </span>
                                                    <span>
                                                        Name
                                                    </span>
                                                </div>
                                                <div className="col-lg-2">
                                                    <span className="glyphicon glyphicon-triangle-bottom"
                                                              onClick={this.sortByReportTypeAsc}
                                                    >
                                                    </span>
                                                    <span className="glyphicon glyphicon-triangle-top"
                                                              onClick={this.sortByReportTypeDesc}
                                                    >
                                                    </span>
                                                    <span>
                                                        Type
                                                    </span>
                                                </div>
                                                <div className="col-lg-2">
                                                    <span className="glyphicon glyphicon-triangle-bottom"
                                                              onClick={this.sortByLastModificationDateAsc}
                                                    >
                                                    </span>
                                                    <span className="glyphicon glyphicon-triangle-top"
                                                              onClick={this.sortByLastModificationDateDesc}
                                                    >
                                                    </span>
                                                    <span>
                                                        Last Modified
                                                    </span>
                                                </div>
                                                <div className="col-lg-2">
                                                    <span>

                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="container-fluid reportListPanel">
                                        {this.getListPanelContent()}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
            );
        } else{
            return (<div className="home">
              <div className="row">
                <div className="col-xs-12">
                    <div className="home" style={{marginTop: '100px'}}>
                        <div className="alert alert-warning  false" role="alert"> {this.props.userSpace === null ? '' : this.props.userSpace.error_desc} </div>
                    </div>
                </div>
              </div>
                    </div>);
        }
    }
    /**
     * UI component representing the current navigation position.
     */
    getLocationHistoryContent = () =>{
        if(!this.props.userSpace){
            return null;
        }

        let locationHistory = this.getPath(this.props.userSpace, this.props.selectedFolder.id);
        let breadCrumbs = [];

        if(locationHistory != null){
            locationHistory.forEach((item, index)=>{
                if(index < (locationHistory.length - 1)){
                    breadCrumbs.push(
                      <li className='breadcrumb-item active' aria-current="page" key={index} onClick={()=>this.handleSelectedFolderEvent(item.id)}>
                        <span className="selectableBreadcrumbLink">
                            {item.title}
                        </span>
                      </li>
                    );
                }
                else{
                    breadCrumbs.push(
                      <li className='breadcrumb-item' aria-current="page" key={index}>{item.title}</li>
                    );
                }

            });
        }

        return (
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
                {breadCrumbs}
            </ol>
          </nav>
        );
    }

    /**
     * Given a heirchal structure representing all content and a navigable space, and a current location within that space,
     * return an array representing the path from the top level to the current navigation point. This is required in order
     * to build a navigational display element (breadcrumbs).
     */
    getPath = (reportStruct, id) => {
        let results = [];
        results.push({id: reportStruct.id, title: reportStruct.name});

        if(reportStruct.id == id){
            return results;
        }

        if(reportStruct.children && reportStruct.children.length > 0){

            for(const child of reportStruct.children){
                if(child.type == Constants.ITEM_TYPE_FOLDER){
                    let result = this.getPathRecursive(child, id);
                    if(result != null){
                        return results.concat(result);
                    }
                }
            }

        }
    }

    /**
     * Supporting method for getPath(..) which is used recursively to build a navigation path within a space structure.
     */
    getPathRecursive = (nodeRef, id) => {
        let results = [];
        let curNode = {
            id: nodeRef.id,
            title: nodeRef.name
        };

        if(nodeRef.type != Constants.ITEM_TYPE_FOLDER){
            return null;
        }

        if(nodeRef.id == id && nodeRef.type == Constants.ITEM_TYPE_FOLDER){
            results.push(curNode);
            return results;
        }

        if(!nodeRef.children || nodeRef.children.length == 0){
            return null;
        }

        for(var x = 0;x < nodeRef.children.length;x++){
            let childPath = this.getPathRecursive(nodeRef.children[x], id);
            if(childPath != null){
                results.push(curNode);
                return results.concat(childPath);
            }
        }
    }

    isTeamMode = () =>{
        return this.props.match.path == '/team-reports';
    }

    userHasEditAccess = (reportItem)=>{
        if(!this.isTeamMode()){
            return true;
        }
        return reportItem
    }

    getNewFolderActionItem = () => {
        if(!this.isTeamMode() || this.props.adminAccess)	{
            return (!this.props.isOperationPending ? <NewFolderIcon eventHandler={this.enterNewFolder}></NewFolderIcon> : '');
        }
        return null;
    }

    applyLastUpdatedSort = (ascending) => {

        return function (a, b){
            // equal items sort equally
            if (a.lastUpdated === b.lastUpdated) {
                return 0;
            }
            // nulls sort after anything else
            else if (!a.lastUpdated ) {
                return 1;
            }
            else if (!b.lastUpdated) {
                return -1;
            }
            // otherwise, if we're ascending, lowest sorts first
            else if (ascending) {
                return a.lastUpdated < b.lastUpdated ? -1 : 1;
            }
            // if descending, highest sorts first
            else {
                return a.lastUpdated > b.lastUpdated ? -1 : 1;
            }
        };

        return 1;
    }

    /**
     * Apply sorting to dates:
     *
     */
    sortDates = (items, ascending) => {

        var results = [];
        var itemsWithDates = [];

        for(var x = 0;x < items.length;x++){
            if(items[x].lastUpdated === undefined || items[x].lastUpdated === ''){
                let newItem = {...items[x], lastUpdated: items[x].createdAt}
                itemsWithDates.push(newItem);
            }
            else{
                itemsWithDates.push(items[x]);
            }
        }

        var sortedDates;
        sortedDates = itemsWithDates.sort((a, b) => new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime());
        if(!ascending){
            sortedDates.reverse();
        }

        for(var x = 0;x < sortedDates.length;x++){
            results.unshift(sortedDates[x]);
        }

        return results;
    }

    sortDisplayItems = (items) => {
        if(items == null){
            return [];
        }

        const sortOrder = this.props.sortOrder;
        let newItems = items.slice();

        switch(sortOrder){
            case Constants.SORT_BY_ITEM_NAME_ASC:
                return newItems.sort((a,b)=>(a.name.toLowerCase() > b.name.toLowerCase()) ? 1 : -1 );
            case Constants.SORT_BY_ITEM_NAME_DESC:
                return newItems.sort((a,b)=>(a.name.toLowerCase() > b.name.toLowerCase()) ? -1 : 1 );
            case Constants.SORT_BY_ITEM_LAST_MODIFIED_ASC:
                //return newItems.sort(this.applyLastUpdatedSort(true));
                return this.sortDates(newItems, false);
            case Constants.SORT_BY_ITEM_LAST_MODIFIED_DESC:
                //return newItems.sort(this.applyLastUpdatedSort(false));
                return this.sortDates(newItems, true);
            case Constants.SORT_BY_ITEM_FAVORITE_STATUS_ASC:
                return newItems.sort((a,b)=>(a.favorite > b.favorite) ? -1 : 1 );
            case Constants.SORT_BY_ITEM_FAVORITE_STATUS_DESC:
                return newItems.sort((a,b)=>(a.favorite > b.favorite) ? 1 : -1 );
            case Constants.SORT_BY_ITEM_TYPE_ASC:
                return newItems.sort((a,b)=>(a.type > b.type) ? 1 : -1 );
            case Constants.SORT_BY_ITEM_TYPE_DESC:
                return newItems.sort((a,b)=>(a.type > b.type) ? -1 : 1 );
            default:
                return this.sortDates(newItems, false);
        }

    }

    reloadFolderContents = () =>{
        this.props.dispatch(ReportActions.reloadReportObjects(localStorage.getItem('userAccount'), this.props.selectedFolder, this.isTeamMode()));
    }

    getSpinner = () => {
        return (
          <div className="lds-spinner-container">
            <div className="lds-spinner">
                <div></div><div></div><div></div><div></div><div></div><div></div>
                <div></div><div></div><div></div><div></div><div></div><div></div>
            </div>
          </div>
        );
    }

    getFilterItems = ()=>{
        let selItemSet = this.props.selectedFolder.children;

        if (this.props.filterMode == Constants.ITEM_TYPE_DEFAULT){
            return selItemSet;
        }

        var displayItems = [];
        selItemSet.forEach((item, index)=>{
            if(item.type == this.props.filterMode){
                displayItems.push(item);
            }
        });

        return displayItems;
    }

    render(){
        let content = null;
        if(!localStorage.getItem('userAccount')){
            content = (<Redirect to='/'/>);
        }else{
            content = this.getReportMgmntContent();
        }
        let title = this.props.match.path == '/team-reports' ? 'Team Reports' : 'My Reports'
        return (
          <div>
            <Helmet defer={false}>
                <meta charSet="utf-8" />
                <title>{title}</title>
            </Helmet>
            { content }
            {/* Item deletion confirmation dialog */}
            { this.getItemConfirmationDialog() }
          </div>
        );
    }
    checkAll(event) {
        let checkboxes = '';
        externalId.clear();
        if(event.currentTarget.checked){
            teamsGridData.map((rep, i) =>{
                externalId.set(rep.externalId.toString(),rep.name);
            })
        }
        checkboxes = document.querySelectorAll('input[type="checkbox"]');
        for (let i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i] != event)
                checkboxes[i].checked = event.currentTarget.checked;
        }
    }
    checkOne(event) {
        if(event.currentTarget.checked){
            externalId.set(event.currentTarget.defaultValue.toString(),event.currentTarget.name);
        } else {
            externalId.delete(event.currentTarget.defaultValue);
        }
    }

    loadReportShareGrid=(sharedTeams)=>  {
        teamsGridData = sharedTeams;
        if(teamsGridData === null || teamsGridData === undefined)
            return (<div  style={{'margin': '17px','textAlign': 'center'}}> No teams are assigned </div>);
        return teamsGridData.map((rep, i) => {
            return (
              <div className={'criteriaListPanel col-sm-12 col-md-12'}>
                <div className={'filterNamePanel col-sm-1 col-md-1'}>
                    <input name={rep.name} type="checkbox" value={rep.externalId} onChange={(event) => this.checkOne(event)}/>
                    &nbsp;&nbsp;&nbsp;&nbsp;{rep.updatedDate === undefined ? "" : <span className="fas fa-history" />}
                </div>
                <div className={'filterNamePanel col-sm-3 col-md-3'}><label style={{'fontSize':'17px','textTransform': 'none'}}>{rep.name}</label></div>
                <div className={'filterNamePanel col-sm-3 col-md-3'}><label style={{'fontSize':'17px','textTransform': 'none'}}>{rep.deletedBy}</label></div>
                <div className={'filterNamePanel col-sm-5 col-md-5'}><label onClick={() => this.editFolderPath(rep)} style={{'fontSize':'17px','textTransform': 'none'}}>
                    <span className="selectableBreadcrumbLink"  style={{'cursor': 'pointer'}}>{rep.finalFolderPath}</span>
                                                                     </label>
                </div>
              </div>
            )
        })
    }

    editFolderPath = (selectedFolderRow) => {
        this.props.dispatch(ReportActions.editFolderPath(selectedFolderRow.name, selectedFolderRow.externalId,selectedFolderRow));
        this.setState({
            isShareReportPanelVisible: true
        });
    }

    shareReportHandler(selectExternalId) {
        this.setState({
            selectExternalId: selectExternalId,
        });
    }
    handleShareReportPanelCancel = e => {
        this.setState({
            isShareReportPanelVisible: false
        });
    };


    actionDialog = (event) => {
        this.setState({
            isShareReportPanelVisible: true
        });
    }

    copyReportUrl = (selItem, index) => {
        let reqUrl = null;
        if(selItem.type === Constants.ITEM_TYPE_REPORT){
            reqUrl = `/#/displayReport/${selItem.id}`;
        }
        else if(selItem.type === Constants.ITEM_TYPE_DASHBOARD){
            reqUrl = `/#/displayDashboard/${selItem.id}`;
        }
        const textField = document.createElement('textarea');
        textField.innerText = window.location.origin + reqUrl;
        document.body.appendChild(textField);
        textField.select();
        document.execCommand('copy');
        textField.remove();
    }

    callSearchTeams=(searchString)=> {
        if(searchString) {
            TeamService.searchTeams(searchString).then((response)=>{
                response.data.forEach((item, index) => {
                    response.data[index]['finalFolderPath'] = '/' + item.name + '/';
                    response.data[index]['selectedFolderMap'] = '';
                });
                this.props.dispatch(ReportActions.saveFolderPath(response.data));
                this.setState({reportSharedTeams:response.data});
            })

        } else {
            this.props.dispatch(ReportActions.saveFolderPath(this.props.sharedTeams));
            this.setState({reportSharedTeams:this.props.sharedTeams})
        }
    }

};

const mapStateToProps = (state, ownProps) => {
    return {
        currentUserName: state.user.currentUserName,
        displayNewFolderForm: state.spaceMgmnt.displayNewFolderForm ? state.spaceMgmnt.displayNewFolderForm : false,
        currentUser: state.user.currentUser,
        selectedFolder: state.spaceMgmnt.selectedFolder,
        userSpace: state.spaceMgmnt.userSpace,
        selItem: state.spaceMgmnt.selItem,
        sortOrder: state.spaceMgmnt.sortOrder,
        displayConfirmationDialog: state.spaceMgmnt.displayConfirmationDialog,
        selectedItemForDeletion: state.spaceMgmnt.selectedItemForDeletion,
        selectedItemType: state.spaceMgmnt.selectedItemType,
        reloadingContents: state.spaceMgmnt.reloadingContents,
        selectedItemIndex: state.spaceMgmnt.selectedItemIndex,
        itemDescription: state.spaceMgmnt.itemDescription,
        selectedItemTitle: state.spaceMgmnt.selectedItemTitle,
        selectedItemDescription: state.spaceMgmnt.selectedItemDescription,
        mode: state.spaceMgmnt.mode,
        isOperationPending: state.spaceMgmnt.isOperationPending,
        customGroupDialog: state.customFilterCriteria.customGroupDialog,
        filterMode: state.spaceMgmnt.filterMode,
        sharedTeams:state.spaceMgmnt.sharedTeams,
        teamReportsError: state.spaceMgmnt.teamReportsError,
        userEditor: state.userMgmnt.userEditor,
        sharedFolderEditor: state.spaceMgmnt.sharedFolderEditor,
        selectedFolderRow:state.spaceMgmnt.selectedFolderRow,
        finalFolderPath: state.spaceMgmnt.finalFolderPath,
        selectFolderMap:state.spaceMgmnt.selectFolderMap,
        collaborationTeamId:state.spaceMgmnt.collaborationTeamId,
        adminAccess: state.accountSettings.adminAccess
    };
}

export default connect(mapStateToProps)(ReportManagementContainer);