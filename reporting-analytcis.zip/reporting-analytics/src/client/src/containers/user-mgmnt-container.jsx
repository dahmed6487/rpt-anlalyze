import React, {Component} from "react";
import {connect} from "react-redux";

import * as UserMgmntActions from '../redux/actions/user-mgmnt-actions';
import {SET_MOCK_USER} from '../redux/constants/user-constants';
import EditUserContainer from './edit-user-container';
import Modal from 'react-modal';
import Icon from '../components/icons/icon';

class UserManagementContainer extends Component{

    constructor(props) {
        super(props)
        const { dispatch } = props;
        this.actions = props.actions;
    }

    componentDidMount = () => {
        
    }

    handleUserSelection = (event) => {
        this.props.dispatch({type: SET_MOCK_USER, payload: event.target.value});
    }

    editUser = (firstName, lastName) => {
        this.props.dispatch(UserMgmntActions.editUser(firstName, lastName));
    }

    getNewFolderEntryDialogClasses = () => {
        if(this.props.displayNewFolderForm==true){
            return "newUserDialog";
        }
        else{
            return "modal fade newUserDialog";
        }   
    }

    enterNewFolder = () => {
        this.props.dispatch(UserMgmntActions.enterNewFolder()); 
    }

    cancelAddFolderAction = () => {
        this.props.dispatch(UserMgmntActions.cancelNewFolderEntry());
    }

    render(){
        let items = this.props.userResults && this.props.userResults.map((rep, i) => {
        return (
          <div className="row reportListRow" key={i}>
          <div className="col-lg-2">
          <input type="checkbox" />
        </div>
          <div className="col-lg-4">
          {rep.first_name}
          {' '}
          {rep.last_name}
        </div>
          <div className="col-lg-2">
          {rep.groups.name}
        </div>
          <div className="col-lg-2 col-align-left">
          {rep.roles.name}
        </div>
          <div className="col-lg-2">
          <span>
              <Icon eventHandler={() => { this.editUser(rep.first_name, rep.last_name) }} iconClass="fas fa-edit" />
          </span>
        </div>
        </div>
        )
        })

        if (!this.props.modalOpen) {
            return null;
        }
        const customStyles = {
            content : {
              top                   : '44.5%',
              left                  : '53%',
              right                 : 'auto',
              width                 : '70%',
              height                : '100%',
              bottom                : 'auto',
              background            : 'none',
              marginRight           : '-50%',
              border                : '0',
              overflow              : 'auto',
              transform             : 'translate(-50%, -50%)'
            },
            overlay: {
                position: "fixed",
                top: 0,
                bottom: 0,
                left: 0,
                right: 0,
                width: "100%",
                height: "100%",
                backgroundColor: "rgba(0,0,0,0)",
                zIndex: 1050
              }
          };
        return (
          <div>
              {this.props.currentUser
              ? (
                <div id="myModal" role="dialog">
                  <Modal
                        isOpen={this.props.userEditor}
                        onAfterOpen={this.afterOpenModal}
                        onRequestClose={this.props.userEditor}
                        style={customStyles}
                  >
                      <EditUserContainer />
                  </Modal>

                  <div className={this.getNewFolderEntryDialogClasses()} id="myModal" role="dialog">
                      <div className="modal-dialog modal-sm">
                          <div className="modal-content">
                              <div className="modal-header">
                                  <button type="button" className="close" data-dismiss="modal">&times;</button>
                                  <h4 className="modal-title" eventHandler={this.enterNewFolder}>Add New User</h4>
                              </div>
                              <div className="modal-body">
                                  <p>User Name:</p>
                                  <input type="text" value={this.props.newFolderTitle} onChange={this.folderNameUpdated} />
                              </div>
                              <div className="modal-footer">
                                  <button type="button" className="btn btn-default" data-dismiss="modal" onClick={this.saveNewFolderAction}>Save</button>
                                  <button type="button" className="btn btn-default" data-dismiss="modal" onClick={this.cancelAddFolderAction}>Cancel</button>
                              </div>
                          </div>
                      </div>
                  </div>

                  <div className="modal-dialog modal-sm">
                      <div className=" user-modal">
                          <div className="modal-header user-mgmnt-header">
                              <h4 className="modal-title">User Management</h4>
                              <button type="button" onClick={this.props.close} className="close user-mgmnt-close" data-dismiss="modal">&times;</button>
                            </div>
                          <div className="modal-body">
                              <div className="titlePanel user-mgmnt-title">
                                  <div className="userNameElement col-lg-11">{this.props.currentUserName}</div>
                                  <div className="topActionItemsElement col-lg-1">
                                      <span className="link-icon fas fa-plus plus-icon" />
                                      <button type="button" className="btn btn-default add-button" onClick={this.enterNewFolder}>
                                          <span className="add-user-text">ADD USER</span>
                                      </button>
                                  </div>
                              </div>
                              <div className="panel user-mgmnt-panel">
                                  <div className="top-action-panel user-mgmnt-top-panel">
                                      <div>
                                          <input type="text" className="form-control search-input user-search" placeholder="Search Users" />
                                          <span className="glyphicon glyphicon-search form-control-feedback search-logo user-search-logo" />
                                      </div>
                                  </div>
                                  <div>
                                      <div className="reportListSortPanel">
                                          <div className="row user-mgmnt-row">
                                              <div className="col-lg-1">
                                                  <input type="checkbox" className="user-checkbox" onChange={this.handleBulkSelectionEvent} />
                                              </div>
                                              <div className="col-lg-1">
                                                    &nbsp;
                                              </div>
                                              <div className="col-lg-4">
                                                  <span className="user-name" onClick={this.sortByName}>Name</span>
                                              </div>
                                              <div className="col-lg-3">
                                                  <span className="user-groups" onClick={this.sortByLastModificationDate}>Groups</span>
                                              </div>
                                              <div className="col-lg-2">
                                                  <span className="user-roles" onClick={this.sortByReportType}>Roles</span>
                                              </div>
                                              <div className="col-lg-1">
                                                  <span onClick={this.sortByFavoriteAttribute} />
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                                  <div className="reportListPanel">
                                      {items}
                                    </div>
                                </div>
                          </div>
                      </div>
                  </div>
                </div>
)
                : (
                <div className="select-user ">
                  <div className="select-user-text ">Select User</div>
                  <hr />
                  <div>
                      <div className="select-user-account ">Please select a demo user account</div>
                      <div>
                          <select className="select-user-dropdown " onChange={this.handleUserSelection}>
                              <option>Select an account</option>
                              <option>Account V</option>
                              <option>Account F</option>
                          </select>
                      </div>
                  </div>
                </div>
)}
          </div>
        );
    }
};

const mapStateToProps = (state, ownProps) => {
    return {
        currentUserName: state.user.currentUserName,
        currentUser: state.user.currentUser,
        displayNewFolderForm: state.userMgmnt.displayNewFolderForm ? state.userMgmnt.displayNewFolderForm : false,
        userEditor: state.userMgmnt.userEditor,
        showModal: state.userMgmnt.showModal,
        userResults: state.lookerAdmin.userResults,
        roleResults: state.lookerAdmin.roleResults
    };
}

export default connect(mapStateToProps)(UserManagementContainer);