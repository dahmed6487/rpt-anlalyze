import React, { Component } from "react";
import { connect } from "react-redux";
import SearchForm from '../components/form/search-form';


class UserPermissionContainer extends Component{

    constructor(props) {
        super(props)
        const { dispatch } = props;
        this.actions = props.actions;
    }

    componentDidMount = () => {
    }

    getListPanelContent = () => {
        const panelContent = [];

            panelContent.push(
                (
                  <div>
                    <div className="row reportListRow">
                      <div className="col-lg-2">
                      <input type="checkbox" />
                    </div>
                      <div className="col-lg-1">
                      <img src="/static/media/mock-dashboard.a5d1393f.svg" className="looker-icon" />
                    </div>
                      <div className="col-lg-4">
                      <div>
                          <div className="itemName">80/20 Descending $</div>
                          <div className="itemDescription">A Sample Dashboard</div>
                        </div>
                    </div>
                      <div className="col-lg-2">
                      Dashboard
                      </div>
                      <div className="col-lg-2 col-align-right">
                      Dashboard
                      </div>
                    </div>
                    <div className="row reportListRow">
                      <div className="col-lg-2">
                      <input type="checkbox" />
                    </div>
                      <div className="col-lg-1">
                      <img src="/static/media/mock-dashboard.a5d1393f.svg" className="looker-icon" />
                    </div>
                      <div className="col-lg-4">
                      <div>
                          <div className="itemName">80/20 Descending $</div>
                          <div className="itemDescription">A Sample Dashboard</div>
                        </div>
                    </div>
                      <div className="col-lg-2">
                      Report
                      </div>
                      <div className="col-lg-2 col-align-right">
                      Report
                      </div>
                    </div>
                  </div>
                )
            );
        return panelContent;
    }

    render(){
        return (
          <div className="permissions-panel">
            <div className="row user-mgmnt-row">
              <div className="col-lg-2">
                  <div className="form-group">
                      <select className="form-control user-mgmnt-select" onChange={this.filterReportType}>
                          <option>View All</option>
                          <option>View Reports</option>
                          <option>View Dashboards</option>
                          <option>View Folders</option>
                        </select>
                    </div>
                </div>
              <div className="col-lg-2">
                  <button type="button" className="btn btn-default sudo-btn toggle-btn">
                      <span className="link-icon fas fa-toggle-off sudo-icon" />
                      <span className="sudo-lbl">TOGGLE OFF</span>
                    </button>
                </div>
              <div className="col-lg-2">
                  <button type="button" className="btn btn-default sudo-btn toggle-btn">
                      <span className="link-icon fas fa-toggle-off sudo-icon" />
                      <span className="sudo-lbl">TOGGLE ON</span>
                    </button>
                </div>
              <div className="col-lg-6">
                  <SearchForm placeHolder="Search Users" />
              </div>
            </div>
            <hr className="top-action-divider" />
            <div className="reportListSortPanel dashboard-pnl">
              <div className="row user-mgmnt-row">
                  <div className="col-lg-1">
                      <input type="checkbox" className="user-checkbox" onChange={this.handleBulkSelectionEvent} />
                  </div>
                  <div className="col-lg-1">
                            &nbsp;
                  </div>
                  <div className="col-lg-4">
                      <span className="user-name" onClick={this.sortByName}>Name</span>
                  </div>
                  <div className="col-lg-2 user-type">
                      <span className="user-roles" onClick={this.sortByReportType}>Type</span>
                  </div>
                  <div className="col-lg-1">
                      <span onClick={this.sortByFavoriteAttribute}>Permission</span>
                  </div>
              </div>
            </div>
            <div className="reportListPanel dashboard-pnl">
              { this.getListPanelContent() }
            </div>
          </div>
        );
    }
};

const mapStateToProps = (state, ownProps) => {
    return {
        currentUserName: state.user.currentUserName
    };
}

export default connect(mapStateToProps)(UserPermissionContainer);