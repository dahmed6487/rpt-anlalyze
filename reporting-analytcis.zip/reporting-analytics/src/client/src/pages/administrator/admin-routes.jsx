import React from 'react';
import { Route } from 'react-router-dom';

import AdminHome from './admin-home';
import AdminUsers from './admin-users';
import AdminUserEdit from './admin-user-edit';
import AdminCustomers from './admin-customers';
import AdminTeams from './admin-teams';
import AdminCustomerEdit from './admin-customer-edit';
import AdminTeamsNew from "./admin-teams-new";
import AdminTeamMembersEdit from "./admin-team-members-edit";
import AdminTeamEdit from "./admin-team-edit";
import AccountSegmentation from "./account-segmentation";
import otherVendorPurchase from "./other-vendor-purchase";
import {Redirect} from "react-router-dom";
import AdminCustomerNew from './admin-customer-new';

function AdminRoutes(isAllAccounts, userManagementAccess, teamManagementAccess, customerManagementAccess, accountSegmentationAccess, vendorPurchasesAccess, adminAccess)
{
    return(
        <React.Fragment>
            {(vendorPurchasesAccess && !isAllAccounts) ? <Route path={'/admin/otherVendorPurchase'} exact component={otherVendorPurchase} /> : <Redirect to="/admin" />}
            {(accountSegmentationAccess && !isAllAccounts) ? <Route path="/admin/accountSegmentation" exact component={AccountSegmentation} /> : <Redirect to="/admin" />}
            {userManagementAccess && <Route path="/admin/users" exact component={AdminUsers} />}
            {userManagementAccess && <Route path="/admin/user/edit/:username" exact component={AdminUserEdit} />}
            {(customerManagementAccess && !isAllAccounts) ? <Route path="/admin/customers" exact component={AdminCustomers} /> : <Redirect to="/admin" />}
            {(customerManagementAccess && !isAllAccounts) ? <Route path="/admin/customer/new" exact component={AdminCustomerNew} />: <Redirect to="/admin" />}
            {(customerManagementAccess && !isAllAccounts) ? <Route path="/admin/customer/edit/:customerId" exact component={AdminCustomerEdit} /> : <Redirect to="/admin" />}
            {(customerManagementAccess && !isAllAccounts) ? <Route path="/admin/customer/edit/:customerId/new/team" exact component={AdminTeamsNew} /> : <Redirect to="/admin" />}
            {(customerManagementAccess && !isAllAccounts) ? <Route path="/admin/customer/edit/:customerId/team/:team/members" exact component={AdminTeamMembersEdit} /> : <Redirect to="/admin" />}
            {teamManagementAccess && <Route path="/admin/teams" exact component={AdminTeams} />}
            {teamManagementAccess && <Route path="/admin/team/new/:customerId" exact component={AdminTeamsNew} />}
            {teamManagementAccess && <Route path="/admin/team/edit/:team" exact component={AdminTeamEdit} />}
            {teamManagementAccess && <Route path="/admin/team/edit/:team/members/:customerId" exact component={AdminTeamMembersEdit} />}
            {adminAccess && <Route path="/admin" exact component={() => <AdminHome isAllAccounts={isAllAccounts} />} />}
        </React.Fragment>
    );
}

export default AdminRoutes;