import React, { Component } from 'react';
import autoBind from 'react-autobind';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { actions } from '../../redux/state';
import uploadIcon from '../../img/upload-icon.svg';
import uploadLoadingIcon from '../../img/upload-loading-icon.svg';
import uploadSuccessIcon from '../../img/upload-success-icon.svg';
import uploadErrorIcon from '../../img/upload-error-icon.svg';
import axios from 'axios';
import { Redirect } from 'react-router-dom';
import Alert from '../../components/alert/alert';
import RecordRow from "../../components/record/RecordRow";
import RecordMeta from "../../components/record/RecordMeta";

class AccountSegmentation extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);
        this.actions = props.actions;
        this.uploadInputRef = React.createRef();

        this.state = {
            error: false,
            dragging: false,
            file: null,
            targetIcon: uploadIcon,
            uploadText: 'Drag updated file here to begin upload',
            otherError: null,
            buttonTitle:'Download Configuration Report',
            selectedFile:'',
            fileUploadButtonTitle:'UPLOAD FILE',
            errorDataInfo: [],
            validationErrorFlag:false

        };
    }

    dragEventCounter = 0;

    //Checks if there is a file when user enters the drop zone - State can be changed
    handleDragEnter = e => {
        e.preventDefault();
        this.dragEventCounter++;
        e.stopPropagation();
        if ((e.dataTransfer.items && e.dataTransfer.items[0]) || (e.dataTransfer.types &&
            e.dataTransfer.types[0] === 'Files')) {
            console.log('drag enter');
            this.setState({
                dragging: true,
                targetIcon: uploadLoadingIcon,
                uploadText: 'Upload in progress'
            });
        }
    };

    //Checks if user enters the drop zone with a file but leaves without dropping
    handleDragLeave = e => {
        e.preventDefault();
        e.stopPropagation();
        this.dragEventCounter--;
        if (this.dragEventCounter === 0) {
            this.setState({
                dragging: false,
                targetIcon: uploadIcon,
                uploadText: 'Drag updated file here to begin upload'
            });
        }
    };

    //preventing default browser events
    handleDragOver = e => {
        e.preventDefault();
        e.stopPropagation();
    }

    //Checks if user dropped the file and the type of file (other validations can be added at this step)
    handleDrop = e => {
        e.preventDefault();
        e.stopPropagation();
        let file = e.dataTransfer.files[0];
        if (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel') {
            this.uploadSuccess(file);
        } else {
            this.setState({
                error: true,
                file: null,
                dragging: false,
                targetIcon: uploadErrorIcon,
                uploadText: 'File format not supported. Please upload only XLSX files',
            })
        }
    };

    //This is for the "browse for files" button click file upload
    handleFileUpload = e => {
        e.preventDefault();
        e.stopPropagation();
        let file = this.state.file;
        if (file === null) {
            this.setState({
                error: true,
                file: null,
                fileUploadButtonTitle: 'UPLOAD FILE',
                otherError: {
                    text: 'Please select a file and click on upload file again',
                    type: 'warning'
                },
                validationErrorFlag:false
            })
        } else {
            if (file.type === '.csv' || file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel') {
                this.uploadSuccess(file);
            } else {
                this.setState({
                    error: true,
                    file: null,
                    dragging: false,
                    targetIcon: uploadErrorIcon,
                    uploadText: 'File format not supported. Please upload only XLSX files',
                    fileUploadButtonTitle: 'UPLOAD FILE',
                    otherError: {
                        text: 'File format is not supported. Please upload only XLSX files',
                        type: 'warning'
                    },
                    validationErrorFlag:false
                })
            }
        }
    }

    handleUploadFileDetails= e => {
        e.preventDefault();
        e.stopPropagation();
        let file = e.target.files[0];
        if (file.type === '.csv' || file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel') {
            this.setState({
                error: true,
                file: file,
                dragging: false,
                targetIcon: uploadErrorIcon,
                uploadText: 'File format not supported. Please upload only XLSX files',
                otherError:null,
                validationErrorFlag:false
            })
        } else {
            this.setState({
                error: true,
                file: null,
                dragging: false,
                targetIcon: uploadErrorIcon,
                uploadText: 'File format not supported. Please upload only XLSX files',
                otherError:null,
                validationErrorFlag:false
            })
        }
    }

    //Triggering the hidden input click via a ref (inputs cannot be styled, so it is hidden beside a button)
    handleUploadButtonClick = e => {
        if(this.uploadInputRef.current === undefined)
            return
        this.uploadInputRef.current.click();
    }

//overwriting existing file in state if user uploads multiple times
    uploadSuccess = (file) => {
        const _this = this;
        _this.setState({
            dragging: true,
            targetIcon: uploadLoadingIcon,
            uploadText: 'Upload in progress',
            fileUploadButtonTitle:' PROCESSING',
            otherError: {
                text: 'Your file is being processed. Please do not close this browser or navigate away from this page…', type: 'success'
            },
            validationErrorFlag:false
        });
        const data = new FormData()
        data.append('file', file)
        data.append('customerName', localStorage.getItem('userAccount'));
        data.append('uploadType', 'ACCOUNT_SEGMENTATION');
        axios({
            method: 'POST',
            url: '/api/file/upload',
            dataType: 'json',
            data: data,
            headers: {
                'Content-Type': 'application/json; charset=utf-8'
            }
        }).then(res => {
            if(res.data[0][0]==='SUCCESS' || res.data[0][0]==="SUCCESS") {
                this.setState({
                    error: false,
                    file: null,
                    dragging: false,
                    targetIcon: uploadSuccessIcon,
                    uploadText: 'Upload Complete!',
                    fileUploadButtonTitle:'UPLOAD FILE',
                    otherError: {
                        text: 'File uploaded successfully.', type: 'success'
                    },
                    validationErrorFlag:false
                })
            } else if(res.data[0][0]==='INVALID_ERROR' || res.data[0][0]==='MANDATORY_ERROR'){
                this.setState({
                    error: true,
                    file: null,
                    dragging: true,
                    targetIcon: uploadErrorIcon,
                    uploadText: "Sorry. Something went wrong!",
                    fileUploadButtonTitle:'UPLOAD FILE',
                    otherError: {
                        text: res.data[0][1] +res.data[0][2],
                        type: 'warning'
                    },
                    errorDataInfo: null,
                    validationErrorFlag:false
                })
            }else if(res.data[0][0]==='ERROR'){
                this.setState({
                    error: true,
                    file: null,
                    dragging: true,
                    targetIcon: uploadErrorIcon,
                    uploadText: "Sorry. Something went wrong!",
                    fileUploadButtonTitle:'UPLOAD FILE',
                    otherError: {
                        text: 'Uploaded file is empty.' ,
                        type: 'warning'
                    },
                    errorDataInfo: null,
                    validationErrorFlag:false
                })
            }else {
                let resErrorDataInfo = [];
                for (let r of res.data) {
                    let tempData = {
                        columnName    : r[0],
                        columnValue   : r[1],
                        errorMsg      : r[2],
                        row           : r[3],
                        col           : r[4]
                    };
                    resErrorDataInfo.push(tempData);
                }

                this.setState({
                    error: true,
                    file: null,
                    dragging: true,
                    targetIcon: uploadErrorIcon,
                    uploadText: "Sorry. Something went wrong!",
                    fileUploadButtonTitle:'UPLOAD FILE',
                    otherError: {
                        text: "File upload has failed due to validation errors. Please " ,
                        type: 'warning'
                    },
                    errorDataInfo: resErrorDataInfo,
                    validationErrorFlag: true
                })
            }
        }).catch(function (error) {
            _this.setState({
                error: true,
                file: null,
                dragging: true,
                targetIcon: uploadErrorIcon,
                uploadText: 'Sorry. Something went wrong!',
                fileUploadButtonTitle:'UPLOAD FILE',
                otherError: {
                    text: error.response.data.error_desc.toString(),
                    type: 'warning'
                },
                validationErrorFlag:false
            })
        });
    }

    uploadError = () => {
        this.setState({
            error: true,
            file: null,
            dragging: true,
            targetIcon: uploadErrorIcon,
            uploadText: 'Sorry. Something went wrong!',
            otherError:null,
            validationErrorFlag:false
        })
    }

    openErrorModal() {
        let modal = document.getElementById("eraErrorModal");
        if (modal) {
            modal.style.display = "flex";
        }
    }

    closeErrorModal() {
        let modal = document.getElementById("eraErrorModal");
        if (modal) {
            modal.style.display = "none";
        }
    }

    downloadButtonHandler(e) {
        const _this = this;
        _this.setState({
            buttonTitle:'Please wait Report is downloading...',
            otherError:null,
            targetIcon: uploadIcon,
            uploadText: 'Drag updated file here to begin upload',
        });
        axios.get(`/looker/account-configuration-report/${localStorage.getItem('userAccount')}`,{ responseType: 'arraybuffer' })
            .then((response) => {
                let FileSaver = require('file-saver');
                let blob = new Blob([response.data]);
                const time = Date.now();

                FileSaver.saveAs(blob, 'Account Configuration Report_' + time + '.xlsx');
                _this.setState({
                    buttonTitle:'Download Configuration Report',
                    otherError:null
                });
            }).catch((error) => {
            _this.setState({
                buttonTitle:'Download Configuration Report',
                otherError: {
                    text: 'Sorry. Something went wrong while downloading the Account configuration report.',
                    type: 'warning'
                }
            });
        });
    }

    render() {
        let { otherError, errorDataInfo, validationErrorFlag } = this.state;
        const selectedCustomer = localStorage.getItem('userAccount');
        if (!selectedCustomer) {
            return (<Redirect to="/" />);
        } else {
            return (
              <div className="container-fluid">
                  <div className="col-md-12 admin-accounts-main-container">
                      <div className="container-fluid admin-accounts-header">
                          How to update Account Segmentation
                        </div>
                      <div className="container-fluid admin-accounts-sub-header">
                          You can segment your accounts by type or facility. This utility lets you download your
                          current configuration, make additions or edits to the Account Type or Facility field and
                          re-upload the file to ERA. Account Type is used for indicating whether the account is Acute,
                          Clinic, Retail or other values. Facility is meant to indicate which physical facility the
                          account is attached to.
                        </div>
                      <div className="container-fluid admin-accounts-step-1">
                          <div className="col-md-1 admin-accounts-numbers">
                              1
                            </div>
                          <div className="col-md-11 admin-accounts-text-content-container">
                              <div className="admin-accounts-step-header">
                                  Download the data from your Account Configuration report to an XLSX file
                                </div>
                              <button
                                        type="button"
                                        className="admin-accounts-download-button"
                                        onClick={(e) => this.downloadButtonHandler(e)}
                              >
                                  <span
                                        className="admin-accounts-download-button-text"
                                  >
                                      {this.state.buttonTitle}
                                    </span>
                                </button>
                            </div>
                        </div>
                      <div className="container-fluid admin-accounts-step-2">
                          <div className="col-md-1 admin-accounts-numbers">
                              2
                            </div>
                          <div className="col-md-11 admin-accounts-text-content-container">
                              <div className="admin-accounts-step-header">
                                  Update and save your downloaded file
                                </div>
                              <div className="admin-accounts-step-sub-header">
                                  Open your downloaded file in Excel. Update the Account Type data to properly segment
                                  your account data. Save your XLSX file. DO NOT change any of the column names in
                                  your downloaded file.
                                </div>
                          </div>
                      </div>
                      <div className="container-fluid admin-accounts-step-3">
                          <div className="col-md-1 admin-accounts-numbers">
                              3
                          </div>
                          <div className="col-md-11 admin-accounts-text-content-container">
                              <div className="admin-accounts-step-header">
                                  Upload your new Account Configuration data
                              </div>
                              <div className="admin-accounts-step-sub-header">
                                  Updates will be available in reports within 15-30 minutes.
                             </div>
                          </div>
                      </div>

                      <div className="container-fluid admin-accounts-step-4">
                            {otherError &&
                            <Alert type={otherError.type}>
                                {otherError.text}
                              { validationErrorFlag &&  <j><i><a onClick={() => this.openErrorModal()}>click here</a> </i>to see detailed errors.</j>}
                            </Alert>
                            }
                            {validationErrorFlag && <div id="eraErrorModal" className="modal" style={{height: "fit-content", width: "100%"}} tabIndex="-1" role="dialog">
                                <div className="modal-dialog" role="document" style={{width: "100%"}}>
                                    <div className="modal-content">
                                        <div className="modal-header no-icon">
                                            <button type="button" onClick={() => this.closeErrorModal()} className="close" data-dismiss="modal" aria-label="Close">
                                                <span className="fa fa-times"/>
                                            </button>
                                            <h4 className="modal-title">Detailed Validation Errors from failed upload</h4></div>
                                        <div className="modal-body">
                                            <div className="admin-era-list">
                                                {errorDataInfo.map((errorRow, key) =>
                                                    <RecordRow key={key}>
                                                        <RecordMeta classes={'col-md-3'} label={'Column Name'} meta={errorRow.columnName}/>
                                                        <RecordMeta classes={'col-md-3'} label={'Column Value'} meta={errorRow.columnValue}/>
                                                        <RecordMeta classes={'col-md-4'} label={'Error Description'} meta={errorRow.errorMsg}/>
                                                        <RecordMeta classes={'col-md-1'} label={'Row'} meta={errorRow.row}/>
                                                        <RecordMeta classes={'col-md-1'} label={'Col'} meta={errorRow.col}/>
                                                    </RecordRow>
                                                )}
                                            </div>
                                        </div>
                                        <div className="modal-footer">
                                            <button type="button" onClick={() => this.closeErrorModal()} className="btn btn-primary btn-sm" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>}
                      </div>
                      <div className="container-fluid admin-accounts-step-5">
                          <div className="row">
                              <div className="col-md-2" />
                              <div className="col-md-5">
                              {' '}
                              <input
                            type="text"
                                value={this.state.file === null ? '' : this.state.file.name}
                            className="form-control"
                            style={{ width: '111%' }}
                              />
                            </div>
                              <div className="col-md-3">
                              <button
                                       type="button"
                                        className="admin-accounts-browse-for-file"
                                        onClick={(e) => this.handleUploadButtonClick(e)}
                              >
                                  <input
                                        type="file"
                                           accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
                                           style={{ display: 'none' }}
                                           ref={this.uploadInputRef}
                                           onChange={e => this.handleUploadFileDetails(e)}
                                           onClick={e =>e.target.value = ''}
                                  />
                                  <span className="admin-accounts-browse-for-file-text">
                                      Browse for file
                                  </span>
                              </button>
                              </div>
                          </div>
                      </div>
                      <div className="container-fluid admin-accounts-step-6">
                          <button
                                    type="button" className="admin-accounts-download-button"
                                    onClick={(e) => this.handleFileUpload(e)}
                          >
                              <span
                                        className="admin-accounts-download-button-text"
                              >
                                {this.state.fileUploadButtonTitle === ' PROCESSING' && <i className="fas fa-sync" />}
                                {this.state.fileUploadButtonTitle}
                                </span>
                            </button>
                        </div>
                    </div>
                  <div className="col-md-1">&nbsp;</div>
                </div>
            );
        }
    }
}

const mapStateToProps = (state, ownProps) => {
    return { store: state };
};

const mapDispatchToProps = dispatch => {
    return { actions: bindActionCreators(actions, dispatch) };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(AccountSegmentation);