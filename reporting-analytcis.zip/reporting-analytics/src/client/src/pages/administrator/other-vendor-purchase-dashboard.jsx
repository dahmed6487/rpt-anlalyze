import React, { Component } from 'react';
import autoBind from 'react-autobind';
import axios from 'axios';
import Alert from "../../components/alert/alert";
import Loading from "../../components/ui/loading";
import RecordRow from "../../components/record/RecordRow";
import RecordMeta from "../../components/record/RecordMeta";
import Timezone from "../../helpers/timezone";

let loadFileId= new Map();

export default class OtherVendorPurchaseDashboard extends Component{
    constructor(props) {
        super(props);
        autoBind(this);

        this.state = {
            filesInfo: [],
            fileToRemove: {},
            error: null,
            loading: true,
            removed: false,
            searchTerm: "",
            sortByProperty: "fileName",
            filteredFilesSolutions: [],
            removedLoadFileId:0,
            deleteSelectedFiles:0
        }
    }

    componentDidMount(){
        this.getCustomers();
    }

    render() {
        const { filteredFilesSolutions, loading, error,fileToRemove, removed } = this.state;
        let sortRows = this.generateSortRows();

        if (document.getElementById("filesSearch")) {
            let fileSearchClearButton = document.getElementById(("fileSearchClearButton"));
            if (document.getElementById("filesSearch").value === "") {
                fileSearchClearButton.style.display = "none";
            } else {
                fileSearchClearButton.style.display = "inline-flex";
            }
        }
        return (
            <div className={'customer-list'}>
                {error &&
                <Alert type={error.type}>{error.text}</Alert>
                }
                {loading &&
                <Loading />
                }
               {removed &&
                <Alert type={'success'}>
                    The file(s) have been marked for deletion and will be deleted from McKesson ERA overnight.
                </Alert>
                }
                <div className="search-container">
                    <input id="filesSearch" className="era-solutions-search form-control search-input" type="text"
                           placeholder="Search uploaded files" aria-label="Search"
                           onChange={e => this.handleFilesSearch(e.target.value)}/>
                    <button id="fileSearchClearButton" className="era-solutions-search-clear-button btn bg-transparent"
                            onClick={() => this.clearFileSearchInput()}>
                        <i className="fa fa-times"></i>
                    </button>
                </div>

                {(filteredFilesSolutions.length > 0 && !loading && !error) &&
                <div className="admin-era-list" style={{height: "55px", borderBottom: "1px solid #CCCCCC",overflow: "hidden"}}>
                    <RecordRow>
                        <div className={'col-md-1'}>
                        <input type="checkbox" style={{marginLeft: "18px",marginTop: "6px",height: "18px",width: "18px"}} onChange={(event) => this.checkAllFiles(event)}/>
                    </div>
                    <div className={'col-md-4'} style={{marginTop: "6px"}}>
                            ({this.state.deleteSelectedFiles})&nbsp;&nbsp;&nbsp;&nbsp;
                            <j style={{borderLeft: "1px solid #CCCCCC"}} onClick={() => this.removeFile()}>&nbsp;&nbsp;&nbsp;&nbsp;
                                <j className="far fa-check-circle"/>&nbsp;&nbsp;<a>Backout Selected File Uploads</a></j>
                    </div>
                    <div className={'col-md-2'}></div>
                    <div className={'col-md-2'}></div>
                    <div className={'col-md-3'}>
                        {/*<div className="sort-by-file-container">
                        <span>Sort By</span>
                        <div tabIndex="0" className="sort-by-dropdown-button" onClick={() => this.toggleSortOptionsFileDropdown()}>
                            <strong className="sort-by-state">{this.state.sortByProperty}</strong>
                            <i className="fas fa-chevron-down" />
                            <div>
                                <select className="select-user-dropdown" onChange={this.handleUserSelection}>
                                    {this.state.accounts.map((item, index) => {
                                        return <option key={item[1]} value={item[1]}>{item[1]}</option>
                                    })}
                                </select>
                            </div>
                        </div>
                    </div>
                        <div className="sort-by-dropdown">
                            {sortRows}
                        </div>*/}
                    </div>
                    </RecordRow>
                </div>
                }
                {(filteredFilesSolutions.length > 0 && !loading && !error) &&
                <div className="admin-era-list">
                    {filteredFilesSolutions.map((file, key) =>
                        <RecordRow key={key}>
                            <div className={'record-col col-md-1'}>
                                {file.uploadStatus==='Error' || file.uploadStatus==='Delete Requested' ? <input name={file.fileName} type="checkbox" id="disabledCheckbox" style={{marginLeft: "18px",marginTop: "22px",height: "18px",width: "18px"}} value={file.loadFileId} onChange={(event) => this.checkOneFile(event)} disabled/>
                                :<input name={file.fileName} type="checkbox" id="checkbox" style={{marginLeft: "18px",marginTop: "22px",height: "18px",width: "18px"}} value={file.loadFileId} onChange={(event) => this.checkOneFile(event)}/>}
                            </div>
                            <RecordMeta classes={'col-md-3'} label={'File Name'} meta={file.fileName}/>
                            <RecordMeta classes={'col-md-2'} label={'Customer Name'} meta={file.customerName}/>
                            <RecordMeta classes={'col-md-2'} label={'Uploaded dateTime'} meta={file.uploadedDateTime===null || file.uploadedDateTime===undefined? '' :Timezone.formatDate(file.uploadedDateTime)}/>
                            <RecordMeta classes={'col-md-2'} label={'Uploaded By'} meta={file.createdBy}/>
                            <RecordMeta classes={'col-md-2'} label={'Status'} title={this.uploadStatusText(file.uploadStatus)} meta={file.uploadStatus}/>
                        </RecordRow>
                    )}
                </div>
                }
                <div id="eraRemoveFileModal" className="modal" style={{height: "fit-content"}} tabIndex="-1"
                     role="dialog">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header no-icon">
                                <button type="button" onClick={() => this.closeRemoveFileModal()} className="close"
                                        data-dismiss="modal" aria-label="Close">
                                    <span className="fa fa-times"/>
                                </button>
                                <h4 className="modal-title">Are you sure you want to backout uploads?</h4></div>
                            <div className="modal-body">
                                <p>This action will delete Vendor Purchase data uploaded in the  ({loadFileId.size}) selected file(s).</p>
                            </div>
                            <div className="modal-footer">
                                <button type="button" onClick={() => this.closeRemoveFileModal()}
                                        className="btn btn-link btn-sm" data-dismiss="modal">Cancel
                                </button>
                                <button type="button" onClick={() => this.deleteFile()}
                                        className="btn btn-primary btn-sm">backout
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    uploadStatusText(uploadStatus) {
        switch (uploadStatus) {
            case "Uploaded":
                return 'File was successfully uploaded to McKesson ERA.';
            case "Delete Requested":
                return 'The file(s) have been marked for deletion and will be deleted from McKesson ERA overnight.';
            case "Backed Out":
                return 'File was successfully backed out of the customer data';
            case "Error":
                return 'File was not successfully uploaded. Please try again.';
            case "Delete Error":
                return 'Please attempt deletion again.';
            default:
                return '';
        }
    }
    checkAllFiles(event) {
        let checkboxes ="";
        loadFileId.clear();
        var status = ['Uploaded', 'Delete Error', 'Backed Out'];

        if(event.currentTarget.checked){
            this.state.filesInfo.map((rep, i) =>{
                if(status.includes(rep.uploadStatus)) {
                    loadFileId.set(rep.loadFileId, rep.fileName);
                }
            })
        }
        checkboxes = document.querySelectorAll('input[type="checkbox"]');
        for (let i = 0; i < checkboxes.length; i++) {
            if(checkboxes[i].id==='checkbox') {
                if (checkboxes[i] !== event)
                    checkboxes[i].checked = event.currentTarget.checked;
            }
        }
        this.setState({deleteSelectedFiles:loadFileId.size});
    }
    checkOneFile(event) {
        if(event.currentTarget.checked){
            loadFileId.set(parseInt(event.currentTarget.defaultValue),event.currentTarget.name);
        } else {
            loadFileId.delete(parseInt(event.currentTarget.defaultValue));
        }

        this.setState({deleteSelectedFiles:loadFileId.size});
    }

    toggleSortOptionsFileDropdown() {
        let sortOptionsDropdown = document.querySelector(".sort-by-dropdown");
        if (sortOptionsDropdown.style.display === "block") {
            sortOptionsDropdown.style.display = "none";
        }else{
            sortOptionsDropdown.style.display = "block";
        }
    }

    closeSortOptionsDropdown() {
        let sortOptionsDropdown = document.querySelector(".sort-by-dropdown");
        if (sortOptionsDropdown.style.display === "block") {
            sortOptionsDropdown.style.display = "none";
        } else{
            sortOptionsDropdown.style.display = "block";
        }
    }
    removeFile(file) {
        let modal = document.getElementById("eraRemoveFileModal");
        if (loadFileId.size === 0) {
            if (modal) {
                modal.style.display = "none";
            }
        } else {
          this.setState({fileToRemove: file}, () => {
            if (modal) {
                modal.style.display = "flex";
            }
        });
    }
    }

    closeRemoveFileModal() {
        let modal = document.getElementById("eraRemoveFileModal");
        if (modal) {
            modal.style.display = "none";
        }
    }

    removeFileFromFiles() {
        let updatedFiles = this.state.filesInfo.filter((file) => {
            return file.loadFileId.toString() !== this.state.removedLoadFileId;
        });

        this.setState({filesInfo: updatedFiles,filteredFilesSolutions:updatedFiles});
    }

    fileSortBy(property) {
        this.closeSortOptionsDropdown();
        this.setState({ sortByProperty: property }, () => this.filterFiles());
    }

    generateSortRows() {
        return (
            <>
                <div tabIndex="0" className="era-dropdown-option" onClick={() => this.fileSortBy("fileName")}>Name</div>
                <div tabIndex="0" className="era-dropdown-option" onClick={() => this.fileSortBy("customerName")}>Type</div>
            </>
        );
    }

    clearFileSearchInput() {
        document.getElementById("filesSearch").value = "";
        this.handleFilesSearch("");
    }
    handleFilesSearch(searchTerm) {
        this.setState({ searchTerm: searchTerm }, () => this.filterFiles());
    }

    filterFiles() {
        let searchFiltered = this.searchFilesFilter(this.state.filesInfo);
        let sortedSolutions = this.sortByFileFilter(searchFiltered);
        this.setState({ filteredFilesSolutions: sortedSolutions });
    }

    searchFilesFilter(filesInfo) {
        let searchTerm = this.state.searchTerm;
        if (searchTerm !== "") {
            let searchFiltered = filesInfo.filter(file => {
                let lcName = file.fileName.toLowerCase();
                const searchFilter = searchTerm.toLowerCase();
                if (file.description) {
                    let lcDescription = file.description.toLowerCase();
                    return lcName.includes(searchFilter) || lcDescription.includes(searchFilter);
                } else {
                    return lcName.includes(searchFilter);
                }
            });
            return searchFiltered;
        } else {
            return filesInfo;
        }
    }

    sortByFileFilter(searchFiltered) {
        let sortByProperty = this.state.sortByProperty;
        switch (sortByProperty) {
            case "fileName":
                return searchFiltered.sort(function (a, b) {
                    if (a.fileName < b.fileName) { return -1; }
                    if (a.fileName > b.fileName) { return 1; }
                    return 0;
                });
            case "customerName":
                return searchFiltered.sort(function (a, b) {
                    if (a.customerName < b.customerName) { return -1; }
                    if (a.customerName > b.customerName) { return 1; }
                    return 0;
                });
            default:
                return searchFiltered;
        }
    }

    deleteFile(){
        this.setState({loading:true});
        let checkboxes ="";
        for (let r of loadFileId) {
            axios.delete(`/api/file/delete/file/${r[0]}`).then((response) => {
                this.setState({
                    removedLoadFileId:r[0],
                    loading: false,
                    error: null,
                    deleteSelectedFiles:0,
                    removed:true
                });
                this.getCustomers();
            }).catch(() => {
                this.closeRemoveFileModal();
                this.setState({
                    error: {text: 'There was an error while removing this file, please try again.', type: 'danger'},
                    save: false,
                    loading: false
                });
            });
        }
        checkboxes = document.querySelectorAll('input[type="checkbox"]');
        for (let i = 0; i < checkboxes.length; i++) {
           // if (event !== checkboxes[i])
                checkboxes[i].checked = false;
        }
        this.closeRemoveFileModal();
        loadFileId.clear();
    }

    getCustomers(){
        axios.get(`/api/file/get/uploaded-files-info/${localStorage.getItem('userAccount')}`).then((response) => {
            let filesInfo = [];
            for (let r of response.data) {
                let fileInfo = {
                    loadFileId       : r[0],
                    customerName     : r[8],
                    fileName         : r[2],
                    createdDateTime  : r[3],
                    createdBy        : r[4],
                    uploadStatus     : r[5],
                    uploadedDateTime : r[6],
                    uploadType       : r[7]
                };
                filesInfo.push(fileInfo);
            }
            if (filesInfo.length === 0) {
                this.setState({
                    error: {text: 'You have No Upload History.', type: 'info'},
                    filesInfo: filesInfo,
                    loading: false,
                    filteredFilesSolutions :filesInfo,
                })
            } else {
                this.setState({
                    error: null,
                    filesInfo: filesInfo,
                    loading: false,
                    filteredFilesSolutions :filesInfo,
                })
            }
        }).catch(() => {
            this.setState({
                error: {text: 'There was an error while loading files information, please try again.', type: 'danger'},
                loading: false,
                removed: false
            });
        });
    }
}
