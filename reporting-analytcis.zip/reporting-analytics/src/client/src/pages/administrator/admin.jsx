import React, { Component } from 'react';
import { connect } from 'react-redux';
import * as UserUIActions from '../../redux/actions/user-actions';
import { Helmet } from 'react-helmet';
// Routes
import AdminRoutes from './admin-routes';
import { Link } from 'react-router-dom';
import autoBind from 'react-autobind';
import otherVendorPurchase from "./other-vendor-purchase";
class AdminPages extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);

    }

    render() {
        const { tasks = true } = this.props;

        const userManagementButton = document.getElementById('era-user-management-link');
        const teamManagementButton = document.getElementById('era-team-management-link');
        const customerManagementButton = document.getElementById('era-customer-management-link');
        const accountSegmentationButton = document.getElementById('era-account-segmentation-link');
        const nonMcKessonPurchasesButton = document.getElementById("era-non-mckesson-purchases-link");

        const urlCurrentPage = window.location.href;
        let title = 'Administration Tasks';
          this.props.dispatch(UserUIActions.dialogClose());
                let solutionsPanel = document.querySelector('#solutionsPanel');
                if(solutionsPanel){
                solutionsPanel.style.display = 'none';
                }

        if (userManagementButton) {
            userManagementButton.style.backgroundColor = 'initial';
            if (urlCurrentPage.includes('/admin/user')) {
                title = 'User Management';
                userManagementButton.style.backgroundColor = '#eee';
            }
        }

        if (teamManagementButton) {
            teamManagementButton.style.backgroundColor = 'initial';
            if (urlCurrentPage.includes('/admin/team')) {
                title = 'Team Management';
                teamManagementButton.style.backgroundColor = '#eee';
            }
        }

        if (customerManagementButton) {
            customerManagementButton.style.backgroundColor = 'initial';
            if (urlCurrentPage.includes('/admin/customer')) {
                title = 'Customer Management';
                customerManagementButton.style.backgroundColor = '#eee';
            }
        }
        if (accountSegmentationButton) {
            accountSegmentationButton.style.backgroundColor = 'initial';
            if (urlCurrentPage.includes('/admin/accountSegmentation')) {
                title = 'Account Segmentation';
                accountSegmentationButton.style.backgroundColor = '#eee';
            }
        }

        if (nonMcKessonPurchasesButton) {
            nonMcKessonPurchasesButton.style.backgroundColor = "initial";
            if (urlCurrentPage.includes("/admin/otherVendorPurchase")) {
                nonMcKessonPurchasesButton.style.backgroundColor = "#eee";
            }
        }

    // If SuperAdmin or CustomerAdmin select All Accounts/All My Accounts, we hide customer management, account segmentation, and vendor purchases.
    // currentUser is updated when an account is selected, which then re-renders this component with updated task access.
    // Upon page refresh, currentUser resets as undefined. In this case, we check local storage for this value.
        let isAllAccounts = false;
        if (this.props.userRole === "SuperAdmin" && (this.props.currentUser === 'All ACCOUNTS'|| localStorage.getItem('userAccount') === 'All ACCOUNTS')) {
            isAllAccounts = true;
        } else if (this.props.userRole === "CustomerAdmin" && (this.props.currentUser === 'ALL MY ACCOUNTS'|| localStorage.getItem('userAccount') === 'ALL MY ACCOUNTS')) {
            isAllAccounts = true;
        }

        return (
          <div className="administrator">
                <Helmet defer={false}>
                    <meta charSet="utf-8" />
                    <title>{title}</title>
                  </Helmet>
                <div className="admin-task-area">
                      {AdminRoutes(isAllAccounts, this.props.userManagementAccess, this.props.teamManagementAccess, this.props.customerManagementAccess, this.props.accountSegmentationAccess, this.props.vendorPurchasesAccess, this.props.adminAccess)}
                </div>
          </div>
        );
    }
}
const mapStateToProps = (state, ownProps) => {
    return {
        userManagementAccess: state.accountSettings.userManagementAccess,
        teamManagementAccess: state.accountSettings.teamManagementAccess,
        customerManagementAccess: state.accountSettings.customerManagementAccess,
        accountSegmentationAccess: state.accountSettings.accountSegmentationAccess,
        vendorPurchasesAccess: state.accountSettings.vendorPurchasesAccess,
        adminAccess: state.accountSettings.adminAccess,
        userRole: state.accountSettings.userRole,
        currentUser: state.user.currentUser
    };
}

export default connect(mapStateToProps)(AdminPages);



