import React, { Component } from "react";
import autoBind from "react-autobind";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { actions } from "../../redux/state";
import uploadIcon from "../../img/upload-icon.svg";
import uploadLoadingIcon from "../../img/upload-loading-icon.svg";
import uploadSuccessIcon from "../../img/upload-success-icon.svg";
import uploadErrorIcon from "../../img/upload-error-icon.svg";
import axios from 'axios';
import {Link, Redirect} from "react-router-dom";
import Alert from "../../components/alert/alert";
import RecordRow from "../../components/record/RecordRow";
import RecordMeta from "../../components/record/RecordMeta";
import Timezone from "../../helpers/timezone";

class OtherVendorPurchaseUpload extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);
        this.actions = props.actions;
        this.uploadInputRef = React.createRef();

        this.state = {
            error: false,
            dragging: false,
            file: null,
            targetIcon: uploadIcon,
            uploadText: "Drag updated file here to begin upload",
            otherError: null,
            buttonTitle:"Download Other Vendor Purchase Template",
            fileUploadButtonTitle:'UPLOAD FILE',
            errorDataInfo: [],
            validationErrorFlag:false
        };
    }

    dragEventCounter = 0;

    //Checks if there is a file when user enters the drop zone - State can be changed
    handleDragEnter = e => {
        e.preventDefault();
        this.dragEventCounter++;
        e.stopPropagation();
        if ((e.dataTransfer.items && e.dataTransfer.items[0]) || (e.dataTransfer.types &&
            e.dataTransfer.types[0] === "Files")) {
            console.log("drag enter");
            this.setState({
                dragging: true,
                targetIcon: uploadLoadingIcon,
                uploadText: "Upload in progress"
            });
        }
    };

    //Checks if user enters the drop zone with a file but leaves without dropping
    handleDragLeave = e => {
        e.preventDefault();
        e.stopPropagation();
        this.dragEventCounter--;
        if (this.dragEventCounter === 0) {
            this.setState({
                dragging: false,
                targetIcon: uploadIcon,
                uploadText: "Drag updated file here to begin upload"
            });
        }
    };

    //preventing default browser events
    handleDragOver = e => {
        e.preventDefault();
        e.stopPropagation();
    }

    //Checks if user dropped the file and the type of file (other validations can be added at this step)
    handleDrop = e => {
        e.preventDefault();
        e.stopPropagation();
        let file = e.dataTransfer.files[0];
        if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || file.type === "application/vnd.ms-excel") {
            this.uploadSuccess(file);
        } else {
            this.setState({
                error: true,
                file: null,
                dragging: false,
                targetIcon: uploadErrorIcon,
                uploadText: "File format not supported. Please upload only XLSX files",
                fileUploadButtonTitle:'UPLOAD FILE',
                validationErrorFlag:false
            })
        }
    };

    //This is for the "browse for files" button click file upload
    handleFileUpload = e => {
        e.preventDefault();
        e.stopPropagation();
        if(localStorage.getItem('userAccount')==='All ACCOUNTS'){
            this.setState({
                error: true,
                file: null,
                fileUploadButtonTitle: 'UPLOAD FILE',
                otherError: {
                    text: 'Upload is not applicable for All ACCOUNTS',
                    type: 'warning'
                },
                validationErrorFlag:false
            })
        } else {
            let file = this.state.file;
            if (file === null) {
                this.setState({
                    error: true,
                    file: null,
                    fileUploadButtonTitle: 'UPLOAD FILE',
                    otherError: {
                        text: 'Please select a file and click on upload file again',
                        type: 'warning'
                    },
                    validationErrorFlag: false
                })
            } else {
                if (file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || file.type === "application/vnd.ms-excel") {
                    this.uploadSuccess(file);
                } else {
                    this.setState({
                        error: true,
                        file: null,
                        dragging: false,
                        targetIcon: uploadErrorIcon,
                        uploadText: "File format not supported. Please upload only XLSX files",
                        fileUploadButtonTitle: 'UPLOAD FILE',
                        otherError: {
                            text: 'File format is not supported. Please upload only XLSX files',
                            type: 'warning'
                        },
                        validationErrorFlag: false
                    })
                }
            }
        }
    }

    handleUploadFileDetails= e => {
        e.preventDefault();
        e.stopPropagation();
        let file = e.target.files[0];

        if (file.type === ".csv" || file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || file.type === "application/vnd.ms-excel") {
            this.setState({
                error: true,
                file: file,
                dragging: false,
                targetIcon: uploadErrorIcon,
                uploadText: "File format not supported. Please upload only XLSX files",
                otherError: null,
                validationErrorFlag:false
            })
        } else {
            this.setState({
                error: true,
                file: null,
                dragging: false,
                targetIcon: uploadErrorIcon,
                uploadText: "File format not supported. Please upload only XLSX files",
                otherError: null,
                validationErrorFlag:false
            })
        }
    }
    //Triggering the hidden input click via a ref (inputs cannot be styled, so it is hidden beside a button)
    handleUploadButtonClick = e => {
        if(this.uploadInputRef.current===undefined)
            return;
        this.uploadInputRef.current.click();
    }

//overwriting existing file in state if user uploads multiple times
    uploadSuccess = (file) => {
        const _this=this;
        _this.setState({
            dragging: true,
            targetIcon: uploadLoadingIcon,
            uploadText: "Upload in progress",
            fileUploadButtonTitle:' PROCESSING'
        });
        const data = new FormData()
        data.append('file', file)
        data.append('customerName', localStorage.getItem("userAccount"));
        data.append('uploadType', 'NON_MCKESSON_PURCHASES');
        axios({
            method: "POST",
            url: "/api/file/upload",
            dataType: "json",
            data: data,
            headers: {
                'Content-Type': 'application/json; charset=utf-8'
            }
        }).then(res => {
            console.log("Upload response " + JSON.stringify(res));
            console.log("Upload response " + JSON.stringify(res.data));
            if(res.data[0][0]==='SUCCESS' || res.data[0][0]==="SUCCESS") {
                this.setState({
                    file: null,
                    fileUploadButtonTitle:'UPLOAD FILE',
                    otherError: {
                        text: "File uploaded successfully." ,
                        type: 'success'
                    },
                    validationErrorFlag:false
                })
            }  else if(res.data[0][0]==='INVALID_ERROR' || res.data[0][0]==='MANDATORY_ERROR'){
                this.setState({
                    error: true,
                    file: null,
                    dragging: true,
                    targetIcon: uploadErrorIcon,
                    uploadText: "Sorry. Something went wrong!",
                    fileUploadButtonTitle:'UPLOAD FILE',
                    otherError: {
                        text: res.data[0][1] +res.data[0][2],
                        type: 'warning'
                    },
                    errorDataInfo: null,
                    validationErrorFlag:false
                })
            }else if(res.data[0][0]==='ERROR'){
                this.setState({
                    error: true,
                    file: null,
                    dragging: true,
                    targetIcon: uploadErrorIcon,
                    uploadText: "Sorry. Something went wrong!",
                    fileUploadButtonTitle:'UPLOAD FILE',
                    otherError: {
                        text: res.data[0][1] ,
                        type: 'warning'
                    },
                    errorDataInfo: null,
                    validationErrorFlag:false
                })
            }
            else {
                let resErrorDataInfo = [];
             /*   var myStringArray = res.data;

                var arrayLength = myStringArray.length;
                for (var i = 0; i < arrayLength; i++) {
                    console.log(myStringArray[i]);
                    if(myStringArray[i]!==" " || myStringArray[i].length>0)
                    resErrorDataInfo.push(myStringArray[i]);
                }*/


                for (let r of res.data) {
                    let tempData = {
                        columnName    : r[0],
                        columnValue   : r[1],
                        errorMsg      : r[2],
                        row           : r[3],
                        col           : r[4]
                    };
                    resErrorDataInfo.push(tempData);
                }

                this.setState({
                    error: true,
                    file: null,
                    dragging: true,
                    targetIcon: uploadErrorIcon,
                    uploadText: "Sorry. Something went wrong!",
                    fileUploadButtonTitle:'UPLOAD FILE',
                    otherError: {
                        text: "File upload has failed due to validation errors. Please " ,
                        type: 'warning'
                    },
                    errorDataInfo: resErrorDataInfo,
                    validationErrorFlag:true
                })
            }
        }).catch(function (error) {
            if (error.message === "Network Error") {
                _this.setState({
                    file: null,
                    fileUploadButtonTitle:'UPLOAD FILE',
                    otherError: {
                        text: "File uploaded successfully." ,
                        type: 'success'
                    },
                    validationErrorFlag:false
                })
            } else {
                _this.setState({
                    error: true,
                    file: null,
                    dragging: true,
                    targetIcon: uploadErrorIcon,
                    uploadText: "Sorry. Something went wrong!",
                    fileUploadButtonTitle:'UPLOAD FILE',
                    otherError: {
                        text: 'Unknown error.',
                        type: 'warning',
                    },
                    validationErrorFlag:false
                })
            }
        });
    }

    uploadError = () => {
        this.setState({
            error: true,
            file: null,
            dragging: true,
            targetIcon: uploadErrorIcon,
            uploadText: "Sorry. Something went wrong!",
            otherError:null
        })
    };

    openErrorModal() {
      //  this.getErrorData();
        let modal = document.getElementById("eraErrorModal");
        if (modal) {
            modal.style.display = "flex";
        }
    }

    getErrorData(){
        axios.get(`/api/file/get/uploaded-files-info`).then((response) => {
            let resErrorDataInfo = [];

            for (let r of response.data) {
                let tempData = {
                    loadFileId       : r[0],
                    customerName     : r[8],
                    fileName         : r[2],
                    createdDateTime  : r[3],
                    createdBy        : r[4],
                    uploadStatus     : r[5],
                    uploadedDateTime : r[6],
                    uploadType       : r[7]
                };
                resErrorDataInfo.push(tempData);
            }

            if (resErrorDataInfo.length === 0) {
                this.setState({
                    error: {text: 'No uploaded files data available.', type: 'info'},
                    errorDataInfo: resErrorDataInfo,
                    loading: false,
                    validationErrorFlag:false
                })
            } else {
                this.setState({
                    error: null,
                    errorDataInfo: resErrorDataInfo,
                    loading: false,
                    validationErrorFlag:false
                })
            }
        }).catch(() => {
            this.setState({
                error: {text: 'There was an error while loading files information, please try again.', type: 'danger'},
                loading: false,
                validationErrorFlag:false
            });
        });
    }

    closeErrorModal() {
        let modal = document.getElementById("eraErrorModal");
        if (modal) {
            modal.style.display = "none";
        }
    }

    downloadButtonHandler(e) {
        const _this=this;
        _this.setState({
            buttonTitle:"Please wait Template is downloading...",
            otherError:null,
            targetIcon: uploadIcon,
            uploadText: "Drag updated file here to begin upload",
        });
        axios.get(`/api/file/download/non-mck-purchases/template`,{ responseType: 'arraybuffer' })
            .then((response) => {
                let FileSaver = require('file-saver');
                let blob = new Blob([response.data]);

                FileSaver.saveAs(blob, "Other Vendor Purchase Template.xlsx");
                _this.setState({
                    buttonTitle:"Download Other Vendor Purchase Template",
                    otherError:null,
                    validationErrorFlag:false
                });
            }).catch((error) => {
            _this.setState({
                buttonTitle:"Download Other Vendor Purchase Template",
                otherError: {
                    text: `Sorry. Something went wrong while downloading the Account configuration report.`,
                    type: 'warning'
                },
                validationErrorFlag:false
            });
        });
    }

    render() {
        let {otherError, errorDataInfo, validationErrorFlag} = this.state;
        const selectedCustomer = localStorage.getItem('userAccount');
        if (!selectedCustomer) {
            return (<Redirect to='/'/>);
        } else {
            return (
                <div className="container-fluid">
                    <div className="col-md-12 admin-accounts-main-container">
                        <div className="container-fluid admin-accounts-header">
                            How to upload purchases from other vendors
                        </div>
                        <div className="container-fluid admin-accounts-sub-header">
                            In this screen, you can upload purchases from other vendors. The utility lets you download a template, then you bring in your other vendor purchases data
                            and finally re-upload the populated template file to ERA.
                        </div>
                        <div className="container-fluid admin-accounts-step-1">
                            <div className="col-md-1 admin-accounts-numbers">
                                1
                            </div>
                            <div className="col-md-11 admin-accounts-text-content-container">
                                <div className="admin-accounts-step-header">
                                    Download Other Vendor Purchase template
                                </div>
                                <button className="admin-accounts-download-button"
                                        onClick={(e) => this.downloadButtonHandler(e)}>
                                    <span
                                        className="admin-accounts-download-button-text">{this.state.buttonTitle}</span>
                                </button>
                            </div>
                        </div>
                        <div className="container-fluid admin-accounts-step-2">
                            <div className="col-md-1 admin-accounts-numbers">
                                2
                            </div>
                            <div className="col-md-11 admin-accounts-text-content-container">
                                <div className="admin-accounts-step-header">
                                    Update and save your downloaded template
                                </div>
                                <div className="admin-accounts-step-sub-header">
                                    Open your downloaded template in Excel, populate your purchase data into the template, and save in XLSX file format.
                                    The columns in the template with a red header are required. DO NOT change any of the column names in the template file.
                                </div>
                            </div>
                        </div>
                        <div className="container-fluid admin-accounts-step-3">
                            <div className="col-md-1 admin-accounts-numbers">
                                3
                            </div>
                            <div className="col-md-11 admin-accounts-text-content-container">
                                <div className="admin-accounts-step-header">
                                    Upload the updated Other Vendor Purchase template
                                </div>
                            </div>
                        </div>
                        <div className="container-fluid admin-accounts-step-4">
                            {otherError &&
                            <Alert type={otherError.type}>
                                {otherError.text}
                              { validationErrorFlag &&  <j><i><a onClick={() => this.openErrorModal()}>click here</a> </i>to see detailed errors.</j>}
                            </Alert>
                            }
                            {validationErrorFlag && <div id="eraErrorModal" className="modal" style={{height: "fit-content", width: "100%"}} tabIndex="-1" role="dialog">
                                <div className="modal-dialog" role="document" style={{width: "100%"}}>
                                    <div className="modal-content">
                                        <div className="modal-header no-icon">
                                            <button type="button" onClick={() => this.closeErrorModal()} className="close" data-dismiss="modal" aria-label="Close">
                                                <span className="fa fa-times"/>
                                            </button>
                                            <h4 className="modal-title">Detailed Validation Errors from failed upload</h4></div>
                                        <div className="modal-body">
                                            <div className="admin-era-list">
                                                {errorDataInfo.map((errorRow, key) =>
                                                    <RecordRow key={key}>
                                                        <RecordMeta classes={'col-md-3'} label={'Column Name'} meta={errorRow.columnName}/>
                                                        <RecordMeta classes={'col-md-3'} label={'Column Value'} meta={errorRow.columnValue}/>
                                                        <RecordMeta classes={'col-md-4'} label={'Error Description'} meta={errorRow.errorMsg}/>
                                                        <RecordMeta classes={'col-md-1'} label={'Row'} meta={errorRow.row}/>
                                                        <RecordMeta classes={'col-md-1'} label={'Col'} meta={errorRow.col}/>
                                                    </RecordRow>
                                                )}
                                            </div>
                                        </div>
                                        <div className="modal-footer">
                                            <button type="button" onClick={() => this.closeErrorModal()} className="btn btn-primary btn-sm" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>}
                        </div>
                        <div className="container-fluid admin-accounts-step-5">
                            <div className="row"><div className="col-md-2"></div><div className="col-md-5">
                                <input type="text"
                                       value={this.state.file===null?'':this.state.file.name}
                                                                                                                    className="form-control" style={{width: "111%"}}
                            /></div><div className="col-md-3">
                                <button className="admin-accounts-browse-for-file"
                                        onClick={(e) => this.handleUploadButtonClick(e)}>
                                    <input type="file"
                                           accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
                                           style={{display: "none"}}
                                           ref={this.uploadInputRef}
                                           onChange={e => this.handleUploadFileDetails(e)}
                                           onClick={e =>e.target.value = ''}
                                    >
                                    </input>
                                    <span className="admin-accounts-browse-for-file-text">
                                Browse for file
                            </span>
                                </button>
                            </div>
                            </div></div>
                        <div className="container-fluid admin-accounts-step-6">
                            <button className="admin-accounts-download-button"
                                    onClick={(e) => this.handleFileUpload(e)}>
                                    <span
                                        className="admin-accounts-download-button-text">{this.state.fileUploadButtonTitle===' PROCESSING' && <i className={'fas fa-sync'}/>}{this.state.fileUploadButtonTitle}</span>
                            </button>
                        </div>
                    </div>
                    <div className="col-md-1">&nbsp;</div>
                </div>
            );
        }
    }
}

const mapStateToProps = (state, ownProps) => {
    return { store: state };
};

const mapDispatchToProps = dispatch => {
    return { actions: bindActionCreators(actions, dispatch) };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(OtherVendorPurchaseUpload);
