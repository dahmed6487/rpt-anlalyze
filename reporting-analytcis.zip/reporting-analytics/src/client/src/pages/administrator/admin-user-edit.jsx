import React, { Component } from "react";
import autoBind from "react-autobind";
import axios from 'axios';
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { actions } from "../../redux/state";
import Alert from '../../components/alert/alert';
import Tabs from '../../components/tabs/tabs';
import UserForm from '../../components/user/user-form';
import CustomerList from '../../components/customer/customer-list';
import Loading from '../../components/ui/loading';
import UserTeams from "../../components/user/user-teams";
import UserPermissions from "../../components/user/user-permissions";

class AdminUserEdit extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);
    this.actions = props.actions;

    this.username = props.match.params.username;

    this.state = {
      user: {},
      error: null,
      tabDisplay: 'user',
      loading: true,
      tabs: [],
      userPermissions: false
    }

  }

  componentDidMount() {

    this.getUser();

    let tabs = [
      {
        id: 'user',
        title: 'User',
        toolTip: 'Manage information about the user.'
      },
      {
        id: 'customers',
        title: 'Customers',
        toolTip: 'Lists which customer organizations the user has access to.'
      },
      {
        id: 'teams',
        title: 'Teams',
        toolTip: 'Lists which user teams the user is a member of.'
      },
    ];

    // if (this.props.userRole === "SuperAdmin") {
    //   tabs.push({
    //     id: 'permissions',
    //     title: 'Permissions',
    //     toolTip: 'Lists user permissions.'
    //   })
    // }

    this.setState({ tabs: tabs })
  }

  render() {
    const { user, error, tabDisplay, save, loading } = this.state;

    return (
      <div>
        <h3 className="no-top">
          Edit
          {' '}
          {this.username}
        </h3>
        {error
          && (
          <Alert type={error.type}>
            {error.text}
          </Alert>
          )}
        {loading
          && <Loading />}
        {(user && loading === false)
          && (
          <React.Fragment>
            <Tabs tabs={this.state.tabs} onClickFn={this.displayTab} active={tabDisplay} />

            {tabDisplay === 'user'
              && <UserForm user={user} originalUserSudoFlag={this.props.originalUserSudoFlag} />}

            {tabDisplay === 'customers'
              && <CustomerList user={this.username} />}

            {tabDisplay === 'teams'
              && <UserTeams user={this.username} />}

            {tabDisplay === 'permissions' && this.props.userRole === 'SuperAdmin' && this.state.userPermissions
              && <UserPermissions user={user} username={this.username} />
            }
          </React.Fragment>
)}
      </div>
    );
  }

  displayTab(event, tab) {
    if (event) event.preventDefault();
    this.setState({
      tabDisplay: tab
    });
  }

  getUser() {
    axios.get(`/api/user/username/${this.username}`).then((response) => {
      this.setState({
        error: null,
        user: response.data,
        loading: false
      })
    }).catch(() => {
      this.setState({
        error: { text: 'There was an error while loading this user, please try again.', type: 'warning' },
        loading: false
      });
    });
  }
}

const mapStateToProps = (state, ownProps) => {
  return { store: state, originalUserSudoFlag: state.accountSettings.originalUserSudoFlag, userRole: state.accountSettings.userRole };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(actions, dispatch) };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AdminUserEdit);