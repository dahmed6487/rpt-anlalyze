import React, { Component } from "react";
import autoBind from "react-autobind";

// React-Redux
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { actions } from "../../redux/state";
import { Link } from "react-router-dom";

class AdminHome extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);
        this.actions = props.actions;
    }

    render() {
        const { isAllAccounts } = this.props;

        return (
            <div className="admin-home">
                {this.props.userManagementAccess && <h4><Link to="/admin/users" title="Manage users within the customer organization.">User Management</Link></h4>}
                {this.props.userManagementAccess && <p>Allows maintenance of user details and permissions including membership in teams and access to folders</p>}
                {this.props.teamManagementAccess && <h4><Link to="/admin/teams" title="Manage teams of users within the customer organization.">Team Management</Link></h4>}
                {this.props.teamManagementAccess && <p>Allows creation and maintenance of teams including membership and access to folders</p>}
                {this.props.customerManagementAccess && !isAllAccounts && <h4><Link to="/admin/customers" title="Manage organizational-level settings for the customer.">Customer Management</Link></h4>}
                {this.props.customerManagementAccess && !isAllAccounts &&  <p>Allows maintenance of customer information including custom aliases, mappings to Common Entity, access to solutions, teams and accounts</p>}
                {this.props.accountSegmentationAccess && !isAllAccounts && <h4><Link to="/admin/accountSegmentation" title="Account Segmentation helps McKesson organize your data.">Account Segmentation</Link></h4>}
                {this.props.accountSegmentationAccess && !isAllAccounts && <p>Allows upload of the Facility / Account Type data</p>}
                {this.props.vendorPurchasesAccess && !isAllAccounts && <h4><Link to={'/admin/otherVendorPurchase'} title={'Other Vendor Purchases.'}>Other Vendor Purchases</Link></h4>}
                {this.props.vendorPurchasesAccess && !isAllAccounts && <p>Allows upload of purchases from other vendors</p>}
            </div>
        );
    }
}

const mapStateToProps = (state, ownProps) => {
    return {
        store: state,
        userManagementAccess: state.accountSettings.userManagementAccess,
        teamManagementAccess: state.accountSettings.teamManagementAccess,
        customerManagementAccess: state.accountSettings.customerManagementAccess,
        accountSegmentationAccess: state.accountSettings.accountSegmentationAccess,
        vendorPurchasesAccess: state.accountSettings.vendorPurchasesAccess,
        userRole: state.accountSettings.userRole,
        currentUser: state.user.currentUser
    };
};

const mapDispatchToProps = dispatch => {
    return { actions: bindActionCreators(actions, dispatch) };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(AdminHome);
