import React, { Component } from 'react';
import autoBind from 'react-autobind';
import axios from 'axios';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { actions } from '../../redux/state';
import SearchForm from '../../components/form/search-form';
import Alert from '../../components/alert/alert';
import RecordRow from '../../components/record/RecordRow';
import RecordMeta from '../../components/record/RecordMeta';
import { Link, Redirect } from 'react-router-dom';
import Loading from '../../components/ui/loading';
import { CamelCaseToHumanReadable } from '../../components/user/user-form';

class AdminUsers extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);
    this.actions = props.actions;

    this.state = {
      users: [],
      totalPages: 0,
      currentPage: 0,
      error: null,
      loading: true,
      searching: false,
      searchString: '',
      sortBy: 'ID',
      sortDirection: 'Ascending',
      customerId: '',
      customerName: '',
      fetchingUsersForCSVDownload: false
    }
  }

  async componentDidUpdate(prevProps) {
    if (this.props.currentUser != prevProps.currentUser) {
      this.setState({
        customerId: await this.getCustomerId(),
        customerName: this.props.currentUser
      }, () => this.getUsersPage(1));
    }
  }

  async componentDidMount() {
    this.setState({
      customerId: await this.getCustomerId(),
      customerName: this.props.currentUser || localStorage.getItem('userAccount')
    }, () => this.getUsersPage(1));
  }

  render() {
    const { users, error, loading, currentPage, totalPages, fetchingUsersForCSVDownload } = this.state;
    let sortRows = this.generateSortRows();
    let sortDirectionRows = this.generateSortDirectionRows();

    let pageButtons = this.renderPageButtons(currentPage, totalPages);
    const selectedCustomer = localStorage.getItem('userAccount');
    if (!selectedCustomer) {
      return (<Redirect to="/" />);
    } else {
      return (
        <div className="row">
          <div className="col-xs-12">
            <h3 className="no-top">Find a User</h3>
            <SearchForm classes="xtra-bottom" onChange={(searchString) => this.searchUsers(1, searchString)} placeHolder="Search" />
            {loading
              && <Loading />}
            {error
              && (
              <Alert type={error.type}>
                {error.text}
              </Alert>
              )}
            {(!loading && users.length > 0)
              && (
              <div className="era-export-users-container">
                {fetchingUsersForCSVDownload && <Alert type="info">Exporting users, please wait...</Alert>}
                <button
                  type="button"
                  onClick={() => this.exportUsers()}
                  className="era-export-users-button btn btn-default"
                >
                Export
                </button>
              </div>
              )}
            {(!loading && users.length === 0)
              && <div>No results</div>}
            {(users.length > 0 && loading === false)
              && (
              <div className="era-user-list-container">

                <div className="era-tabs-container">
                  <div className="era-right-controls">
                    <div className="era-sort-direction-container">
                      <span>Sort Direction</span>
                      <div tabIndex="0" className="era-users-sort-direction-dropdown-button" onClick={() => this.toggleSortDirectionOptionsDropdown()}>
                        <strong className="era-sort-direction-state">{this.state.sortDirection}</strong>
                        <i className="fas fa-chevron-down" />
                      </div>
                    </div>

                    <div className="era-sort-by-container">
                      <span>Sort By</span>
                      <div tabIndex="0" className="era-users-sort-by-dropdown-button" onClick={() => this.toggleSortOptionsDropdown()}>
                        <strong className="era-sort-by-state">{this.state.sortBy}</strong>
                        <i className="fas fa-chevron-down" />
                      </div>
                    </div>

                    <div className="era-users-sort-direction-dropdown">{sortDirectionRows}</div>
                    <div className="era-users-sort-by-dropdown">{sortRows}</div>
                  </div>
                </div>

                <div className="era-user-list">
                  {users.map((user, key) => (
                    <RecordRow key={key}>
                      <RecordMeta
                        classes="col-md-2"
                        label="ID"
                        meta={<Link to={`/admin/user/edit/${user.username}`}>{user.username}</Link>}
                      />
                      <RecordMeta
                        classes="col-md-3"
                        label="Name"
                        meta={(user.firstName || '') + ' ' + (user.lastName || '')}
                      />
                      <RecordMeta classes="col-md-4" label="Email" meta={user.email || ''} />
                      <RecordMeta classes="col-md-2" label="Role" meta={GetHumanReadableRole(user.userRole)} />
                      <RecordMeta
                        classes="col-md-1 text-right"
                        label="Status"
                        meta={(user.active === 'Y' || user.active === null || user.active === undefined ? 'Active' : 'Inactive')}
                      />
                    </RecordRow>
                  )
                  )}
                  <nav>
                    <ul className="pagination">
                      {pageButtons}
                    </ul>
                  </nav>
                </div>
              </div>
              )}
          </div>
        </div>
      );
    }
  }

  renderPageButtons(currentPage, totalPages) {
    let pageButtons = [];

    if (currentPage !== 1) {
      pageButtons.push(<li className="page-item"><a style={{ cursor: 'pointer' }} className="page-link" onClick={() => this.getPage(currentPage - 1)}>Previous</a></li>);
    }

    for (let i = currentPage - 3; i <= currentPage + 3; i++) {
      if (i > 0 && i <= totalPages) {
        if (i === currentPage) {
          pageButtons.push(<li className="page-item"><a style={{ cursor: 'pointer', backgroundColor: '#ddd' }} className="page-link" onClick={() => this.getPage(i)}>{i}</a></li>);
        } else {
          pageButtons.push(<li className="page-item"><a style={{ cursor: 'pointer' }} className="page-link" onClick={() => this.getPage(i)}>{i}</a></li>);
        }
      }
    }

    if (currentPage <= totalPages - 4) {
      pageButtons.push(<li className="page-item"><a style={{ cursor: 'pointer' }} className="page-link">...</a></li>);
      pageButtons.push(<li className="page-item"><a style={{ cursor: 'pointer' }} className="page-link" onClick={() => this.getPage(totalPages)}>{totalPages}</a></li>);
    }

    if (currentPage < totalPages) {
      pageButtons.push(<li className="page-item"><a style={{ cursor: 'pointer' }} className="page-link" onClick={() => this.getPage(currentPage + 1)}>Next</a></li>);
    }

    return pageButtons;
  }

  getPage(page) {
    if (this.state.searching === true) {
      this.searchUsers(page, this.state.searchString);
    } else {
      this.getUsersPage(page);
    }
  }

  async searchUsers(page, searchString) {
    this.setState({ loading: true, users: [], searching: true, searchString: searchString });

    if (searchString) {
      let url = '/api/user/search/active?page=' + (page - 1) + '&search=' + searchString + '&sortBy=' + this.state.sortBy + '&sortDirection=' + this.state.sortDirection;
      if (localStorage.getItem('userAccount').toLowerCase() !== 'all accounts') {
        url = url + '&customerName=' + localStorage.getItem('userAccount');
      }

      axios.get(url)
        .then((response) => {
          this.setState({
            error: null,
            users: response.data.userProfiles,
            currentPage: page,
            totalPages: response.data.totalPages,
            loading: false
          });
        })
        .catch((error) => {
          this.setState({
            error: { text: `${searchString} did not return results, please try again.`, type: 'warning' },
            loading: false
          })
        });
    } else {
      this.getUsersPage(1);
    }
  }

  async getUsersPage(page) {
    this.setState({ searching: false });

    let url = '/api/user/get/active?page=' + (page - 1) + '&sortBy=' + this.state.sortBy + '&sortDirection=' + this.state.sortDirection;
    if (this.state.customerName.toLowerCase() !== 'all accounts') {
      url = url + '&customerId=' + this.state.customerId;
    }

    axios.get(url)
      .then((response) => {
        this.setState({
          error: null,
          users: response.data.userProfiles,
          currentPage: page,
          totalPages: response.data.totalPages,
          loading: false
        });
      })
      .catch(() => {
        this.setState({
          error: { text: 'There was an error while retrieving users, please try again.', type: 'warning' },
          loading: false
        });
      });
  }

  async getCustomerId() {
    let customerId = await GetCustomerId(this.props.currentUser);
    if (customerId) {
      return customerId;
    } else {
      this.setState({
        error: { text: 'There was an error while retrieving users, please try again.', type: 'warning' },
        loading: false
      });
    }
  }

  async exportUsers() {
    this.setState({ fetchingUsersForCSVDownload: true });
    const users = await this.getAllUsers();
    if (users) {
      this.setState({ fetchingUsersForCSVDownload: false });

      const replacer = (key, value) => value === null ? '' : value;
      let header = Object.keys(users[0]);
      let csv = users.map(row => header.map(fieldName => JSON.stringify(row[fieldName], replacer)).join(','));
      header = header.map((headerString) => {
        return CamelCaseToHumanReadable(headerString)
      });
      csv.unshift(header.join(','));
      csv = csv.join('\r\n');

      const csvData = new Blob([csv], { type: 'text/csv;charset=utf-8;' });

      this.downloadBlob(csvData, 'users.csv');
    }
  }

  async getAllUsers() {
    if (this.state.searching === true) {
      return await this.searchAllUsers();
    } else {
      return await this.getAllUsersPage();
    }
  }

  async searchAllUsers() {
    let url = '/api/user/search/active?page=All&search=' + this.state.searchString + '&sortBy=' + this.state.sortBy + '&sortDirection=' + this.state.sortDirection;
    if (this.state.customerName.toLowerCase() !== 'all accounts') {
      url = url + '&customerId=' + this.state.customerId;
    }

    return axios.get(url)
      .then((response) => {
        return response.data.userProfiles;
      })
      .catch(() => {
        this.setState({
          error: { text: 'Failed to export users, please try again.', type: 'warning' }
        });
      });
  }

  async getAllUsersPage() {
    let url = '/api/user/get/active?page=All&sortBy=' + this.state.sortBy + '&sortDirection=' + this.state.sortDirection;
    if (this.state.customerName.toLowerCase() !== 'all accounts') {
      url = url + '&customerId=' + this.state.customerId;
    }

    return axios.get(url)
      .then((response) => {
        return response.data.userProfiles;
      }).catch(() => {
        this.setState({
          error: { text: 'Failed to export users, please try again.', type: 'warning' }
        });
      });
  }

  downloadBlob(blob, name) {
    const link = document.createElement('a');

    link.href = URL.createObjectURL(blob);
    link.download = name;

    document.body.appendChild(link);

    link.dispatchEvent(
      new MouseEvent('click', {
        bubbles: true,
        cancelable: true,
        view: window
      })
    );

    document.body.removeChild(link);
  }

  toggleSortOptionsDropdown() {
    let sortOptionsDropdown = document.querySelector('.era-users-sort-by-dropdown');

    if (sortOptionsDropdown.style.display === 'block') {
      sortOptionsDropdown.style.display = 'none';
    } else {
      this.closeSortDirectionOptionsDropdown();
      sortOptionsDropdown.style.display = 'block';
    }
  }

  closeSortOptionsDropdown() {
    let sortOptionsDropdown = document.querySelector('.era-users-sort-by-dropdown');

    if (sortOptionsDropdown.style.display === 'block') {
      sortOptionsDropdown.style.display = 'none';
    }
  }

  generateSortRows() {
    return (
      <>
        <div tabIndex="0" className="era-dropdown-option" onClick={() => this.sortBy('ID')}>ID</div>
        <div tabIndex="0" className="era-dropdown-option" onClick={() => this.sortBy('First Name')}>First Name</div>
        <div tabIndex="0" className="era-dropdown-option" onClick={() => this.sortBy('Last Name')}>Last Name</div>
        <div tabIndex="0" className="era-dropdown-option" onClick={() => this.sortBy('Email')}>Email</div>
        <div tabIndex="0" className="era-dropdown-option" onClick={() => this.sortBy('Role')}>Role</div>
        <div tabIndex="0" className="era-dropdown-option" onClick={() => this.sortBy('Status')}>Status</div>
      </>
    );
  }

  sortDirection(direction) {
    this.toggleSortDirectionOptionsDropdown();
    this.setState({ sortDirection: direction }, () => this.getPage(this.state.currentPage));
  }

  toggleSortDirectionOptionsDropdown() {
    let sortDirectionOptionsDropdown = document.querySelector('.era-users-sort-direction-dropdown');

    if (sortDirectionOptionsDropdown.style.display === 'block') {
      sortDirectionOptionsDropdown.style.display = 'none';
    } else {
      this.closeSortOptionsDropdown();
      sortDirectionOptionsDropdown.style.display = 'block';
    }
  }

  closeSortDirectionOptionsDropdown() {
    let sortDirectionOptionsDropdown = document.querySelector('.era-users-sort-direction-dropdown');

    if (sortDirectionOptionsDropdown.style.display === 'block') {
      sortDirectionOptionsDropdown.style.display = 'none';
    }
  }

  generateSortDirectionRows() {
    return (
      <>
        <div tabIndex="0" className="era-dropdown-option" onClick={() => this.sortDirection('Ascending')}>Ascending</div>
        <div tabIndex="0" className="era-dropdown-option" onClick={() => this.sortDirection('Descending')}>Descending</div>
      </>
    );
  }

  sortBy(property) {
    this.toggleSortOptionsDropdown();
    this.setState({ sortBy: property }, () => this.getPage(this.state.currentPage));
  }
}

export async function GetCustomerId(currentUser) {
  const currentCustomer = currentUser ||  localStorage.getItem('userAccount');;
  if (currentCustomer) {
    return axios.get(`/api/customer/get?customerName=${currentCustomer}`)
      .then((response) => {
        return response.data.customerId
      })
      .catch((error) => {
        return undefined;
      });
  }
}

/**
 * @return {string}
 */
export function GetHumanReadableRole(roleCode) {
  switch (roleCode) {
    case 'ISA':
      return 'Internal Sales';
    case 'ISU':
      return 'Internal Support';
    case 'IU':
      return 'Internal User';
    case 'IA':
      return 'Internal Admin';
    case 'CU':
      return 'Customer User';
    case 'CA':
      return 'Customer Admin';
    case 'SA':
      return 'Super Admin';
    default:
      return '';
  }
}

const mapStateToProps = (state, ownProps) => {
  return { currentUser: state.user.currentUser };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(actions, dispatch) };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AdminUsers);
