import React, { Component } from "react";
import autoBind from "react-autobind";
import axios from "axios";

import Tabs from '../../components/tabs/tabs';
import CustomerForm from '../../components/customer/customer-form';
import CustomerContentAccesses from '../../components/customer/customer-content-accesses';
import Alert from "../../components/alert/alert";
import CustomerAccounts from "../../components/customer/CustomerAccounts";
import AdminTeams from "./admin-teams";

class AdminCustomerEdit extends Component {
  constructor(props) {
    super(props);
    autoBind(this);

    this.customerId = props.match.params.customerId;

    this.state = {
      customer: {},
      tabDisplay: 'customer',
      error: null
    }
  }

  componentDidMount() {
    this.getCustomer();
  }

  render() {
    const { customer, error, tabDisplay } = this.state;
    const customerName = customer.customerName || customer.amdmEraOwnrName;
    const tabs = [
      {
        id: 'customer',
        title: 'Customer',
        toolTip:'Manage organizational-level settings for the customer.'
      },
      {
        id: 'contentAccesses',
        title: 'Solutions Access',
        toolTip:'Manage which Solution folders the customer organization has access to.'
      },
      {
        id: 'exploreAccesses',
        title: 'Explore Access',
        toolTip:'Manage which Explore folders the customer organization has access to.'
      },
      {
        id: 'accounts',
        title: 'Accounts',
        toolTip:'Displays a list of accounts tied to the customer organization (common entity). Read only, this is managed by McKesson Connect.'
      },
      {
        id: 'teams',
        title: 'Teams',
        toolTip:'Manage teams of users within the customer organization.'
      }
    ];

    let tabContent = this.getTabContent();

    return (
        <div className="row">
          <div className="col-xs-12">
            <h3 className="no-top">
            Edit
            {' '}
            {customerName}
            </h3>
            {error
              && (
              <Alert type={error.type}>
                {error.text}
              </Alert>
              )}
            <Tabs tabs={tabs} onClickFn={this.displayTab} active={tabDisplay} />
            {tabContent}
          </div>
        </div>
    );
  }

  getTabContent() {
    const { customer } = this.state;

    switch(this.state.tabDisplay)  {
      case "customer":
        return <CustomerForm customer={customer} />;
      case "contentAccesses":
        return <CustomerContentAccesses key="canned report" customer={customer} moduleType="canned report"/>;
      case "exploreAccesses":
        return <CustomerContentAccesses key="explore" customer={customer} moduleType="explore"/>;
      case "accounts":
        return <CustomerAccounts customer={customer} />;
      case "teams":
        return <AdminTeams customer={customer} />;
    }
  }

  displayTab(event, tabId){
    if(event) event.preventDefault();
    this.setState({
      tabDisplay: tabId
    });
  }

  getCustomer() {
    axios.get(`/api/customer/get/customer?id=${this.customerId}`)
        .then((response) => {
          this.setState({
            customer: response.data,
            error: null
          })
        }).catch((error) => {
          this.setState({
            error: { text: `There was an error while loading this customer, please try again.`, type: 'warning' }
          });
        });
  }
}

export default AdminCustomerEdit;
