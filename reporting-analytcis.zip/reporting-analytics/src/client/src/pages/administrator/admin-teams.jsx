import React, { Component } from 'react';
import autoBind from 'react-autobind';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { actions } from '../../redux/state';
import axios from 'axios';
import Alert from '../../components/alert/alert';
import RecordRow from '../../components/record/RecordRow';
import RecordMeta from '../../components/record/RecordMeta';
import { Link, Redirect } from 'react-router-dom';

class AdminTeams extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);
        this.actions = props.actions;

        this.state = {
            teams: [],
            teamToRemove: {},
            customer: {},
            error: null,
            loading: true,
            removed: false
        };
    }

    componentDidUpdate(prevProps) {
      if (this.props.currentUser != prevProps.currentUser) {
        this.getState();
      }
    }
    componentDidMount() {
        this.getState();
    }

    render() {
        let { teams, teamToRemove, loading, error, removed } = this.state;
        const customerName = this.state.customer.customerName || this.state.customer.amdmEraOwnrName;

        const selectedCustomer = this.props.currentUser || localStorage.getItem('userAccount');
        if (!selectedCustomer) {
            return (<Redirect to='/' />);
        } else {
            return (
              <div>
                  {/* {(document.getElementsByTagName('h3')[1] && document.getElementsByTagName('h3')[1].innerText !== `Edit ${customerName}`) &&
                    } */}
                <h3 className="no-top">Find a Team</h3>
                  {error
                    && (
                    <Alert type={error.type}>
                        {error.text}
                    </Alert>
                    )}
                  {loading
                    && <div>Loading...</div>}
                  {removed
                    && (
                    <Alert type="success">
                      Team
                        {' '}
                        {teamToRemove.name}
                        {' '}
                      has been removed.
                    </Alert>
                    )}

                  {(teams.length > 0 && loading === false)
                    && (
                    <div>
                        {teams.map((team, key) => (
                          <RecordRow key={key}>
                              <RecordMeta
                                    classes="col-md-4"
                                    label="Name"
                                    meta={(
                                      <Link
                                    to={`/admin/team/edit/${team.collaborationTeamId}`}
                                      >
                                  {team.name}
                                </Link>
                                )}
                              />
                              <Link
                                    to={`/admin/team/edit/${team.collaborationTeamId}/members/${this.state.customer.customerId}`}
                                    style={{ fontSize: '1.2em', marginTop: '10px' }}
                                    className="btn btn-link col-md-3"
                              >
                                  Members...
                                </Link>
                              <button
                                        type="button"
                                        className="era-remove-team-button col-md-5 btn btn-link"
                                        style={{ fontSize: '1.2em', marginTop: '10px' }}
                                        onClick={() => this.removeTeam(team)}
                              >
                                  Remove
                                </button>
                            </RecordRow>
                          ))}
                    </div>
)}

                  <div
                        id="eraRemoveTeamModal"
                        className="modal"
                        style={{ height: 'fit-content' }}
                        tabIndex="-1"
                        role="dialog"
                  >
                      <div className="modal-dialog" role="document">
                          <div className="modal-content">
                              <div className="modal-header no-icon">
                                  <button
                                            type="button"
                                            onClick={() => this.closeRemoveTeamModal()}
                                            className="close"
                                            data-dismiss="modal"
                                            aria-label="Close"
                                  >
                                      <span className="fa fa-times" />
                                  </button>
                                  <h4 className="modal-title">Confirm Action</h4>
                                </div>
                              <div className="modal-body">
                                  <p>
                                      Are you sure you want to remove
                                      {' '}
                                      {teamToRemove.name}
                                      ?
                                  </p>
                              </div>
                              <div className="modal-footer">
                                  <button
                                            type="button"
                                            onClick={() => this.closeRemoveTeamModal()}
                                            className="btn btn-link btn-sm"
                                            data-dismiss="modal"
                                  >
                                      Cancel
                                  </button>
                                  <button
                                            type="button"
                                            onClick={() => this.confirmRemoveTeam()}
                                            className="btn btn-primary btn-sm"
                                  >
                                      Confirm
                                  </button>
                              </div>
                          </div>
                      </div>
                  </div>

                  <div className="form-footer">
                      <Link to={`/admin/team/new/${this.state.customer.customerId}`} className="btn btn-primary">
                          Create
                          New Team
                      </Link>
                  </div>
              </div>
            );
        }
    }

    getState() {
        if (this.props.customer) {
            this.setState({ customer: this.props.customer }, () => this.getTeams());
        } else {
            let currentCustomer = this.props.currentUser || localStorage.getItem('userAccount');;
            if (currentCustomer && currentCustomer !== 'Reporting and Analytics') {
                return axios.get(`/api/customer/get?customerName=${currentCustomer}`)
                    .then((response) => {
                        this.setState({
                            customer: response.data
                        }, () => this.getTeams());
                    })
                    .catch((error) => {
                        this.setState({
                            error: {
                                text: `There was an error getting teams for the customer ${currentCustomer}, please try again`,
                                type: 'warning'
                            },
                            loading: false
                        });
                    });
            }
        }
    }

    getTeams() {
        if (this.state.customer.amdmEraOwnrName === 'All ACCOUNTS') {
            axios.get('/api/teams/get')
                .then(async (response) => {
                    let teams = response.data;

                    if (teams) {
                        teams = await this.removeTopLevelTeams(teams);
                        if (teams.length === 0) {
                            this.setState({
                                teams: teams,
                                error: {
                                    text: 'There are no Teams. Click Create New Team to get started. Once you create a team, it will appear here.',
                                    type: 'info'
                                },
                                loading: false
                            })
                        } else {
                            this.setState({
                                teams: teams,
                                error: null,
                                loading: false
                            });
                        }
                    }
                })
                .catch((error) => {
                    this.setState({
                        error: { text: 'There was an error getting teams, please try again', type: 'warning' },
                        loading: false
                    });
                });
        } else {
            axios.get(`/api/teams/get?commonEntityId=${this.state.customer.amdmEraOwnrPartyId}`)
                .then((response) => {
                    let teams = response.data;

                  //  teams = this.removeTopLevelTeam(teams);

                    if (teams && teams.length === 0) {
                        this.setState({
                            teams: teams,
                            error: {
                                text: 'There are no Teams set up for this Customer. Click Create New Team to get started. Once you create a team, it will appear here.',
                                type: 'info'
                            },
                            loading: false
                        })
                    } else {
                        this.setState({
                            teams: teams,
                            error: null,
                            loading: false
                        });
                    }
                })
                .catch((error) => {
                    this.setState({
                        error: { text: 'There was an error getting teams, please try again', type: 'warning' },
                        loading: false
                    });
                });
        }
    }

    removeTeam(team) {
        this.setState({ teamToRemove: team }, () => {
            let modal = document.getElementById('eraRemoveTeamModal');
            if (modal) {
                modal.style.display = 'flex';
            }
        });
    }

    closeRemoveTeamModal() {
        let modal = document.getElementById('eraRemoveTeamModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    confirmRemoveTeam() {
        this.setState({
            error: null,
            loading: true
        });
        this.closeRemoveTeamModal();
        const { teamToRemove } = this.state;
        axios.delete(`/api/teams/delete/${teamToRemove.collaborationTeamId}`)
            .then((response) => {
                this.closeRemoveTeamModal();
                this.removeTeamFromTeams();
                this.setState({
                    removed: true,
                    error: null,
                    loading: false
                });
            })
            .catch((error) => {
                this.closeRemoveTeamModal();
                this.setState({
                    error: { text: `There was an error removing ${teamToRemove.name}, please try again.`, type: 'warning' },
                    loading: false
                });
            });
    }

    removeTeamFromTeams() {
        let updatedTeams = this.state.teams.filter((team) => {
            return team.collaborationTeamId !== this.state.teamToRemove.collaborationTeamId;
        });

        this.setState({ teams: updatedTeams,loading: true });
    }

    removeTopLevelTeam(teams) {
        const customerName = this.state.customer.customerName || this.state.customer.amdmEraOwnrName;
        return teams.filter((team) => {
            return team.name !== customerName;
        });
    }

    async removeTopLevelTeams(teams) {
        return axios.get('/api/customer/get')
            .then((response) => {
                const customers = response.data.customers;

                let lowerLevelTeams = new Set();
                for (const team of teams) {
                    const matchFound = customers.some((customer) => customer.customerName === team.name || customer.amdmEraOwnrName === team.name);
                    if (!matchFound) {
                        lowerLevelTeams.add(team.name);
                    }
                }

                this.filterInPlace(teams, team => lowerLevelTeams.has(team.name));
                return teams;
            })
            .catch((error) => {
                this.setState({
                    error: { text: 'There was an error getting teams, please try again', type: 'warning' },
                    loading: false
                });
            });
    }

    filterInPlace(array, predicate) {
        let end = 0;

        for (let i = 0; i < array.length; i++) {
            const obj = array[i];

            if (predicate(obj)) {
                array[end++] = obj;
            }
        }

        array.length = end;
    };
}

const mapStateToProps = (state, ownProps) => {
    return { currentUser: state.user.currentUser };
};

const mapDispatchToProps = dispatch => {
    return { actions: bindActionCreators(actions, dispatch) };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(AdminTeams);
