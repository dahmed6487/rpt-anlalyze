import React, { Component } from 'react';
import autoBind from 'react-autobind';
import { withRouter } from 'react-router';
import SearchForm from '../../components/form/search-form';
import RecordMeta from '../../components/record/RecordMeta';
import { Link } from 'react-router-dom';
import Alert from '../../components/alert/alert';
import axios from 'axios';
import RecordRow from '../../components/record/RecordRow';
import Loading from '../../components/ui/loading';

class AdminCustomers extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);
    this.actions = props.actions;

    this.state = {
      customers: [],
      totalPages: 0,
      currentPage: 0,
      error: null,
      save: false,
      loading: true,
      searching: false,
      searchString: "",
    };
  }

  componentDidMount() {
    this.getCustomersPage(1);
  }

  render() {
    const { customers, error, loading, currentPage, totalPages } = this.state;
    const {
      location: { state },
    } = this.props;

    let paginationButtons = this.renderPaginationButtons(
      currentPage,
      totalPages
    );
    return (
      <div className="row">
        <div className="col-xs-12">
          <div className="col-xs-6">
            <h3 className="no-top">Find a Customer</h3>
          </div>
          <div className="col-xs-6">
            {state && state.status && (
              <Alert type="success" dismiss>
                <span className="fas fa-info-circle" /> Customer Definition for{" "}
                {state.customerName} added successfully.
              </Alert>
            )}
          </div>
          <div className="col-xs-12">
            {/* <div className="col-xs-12"> */}
              <SearchForm
                classes="xtra-bottom"
                onChange={(searchString) =>
                  this.searchCustomers(1, searchString)
                }
                placeHolder="Search"
              />
            {/* </div>
            <div className="col-xs-6">
              <Link
                to={"/admin/customer/new"}
                className="btn btn-primary pull-right"
              >
                DEFINE NEW CUSTOMER
              </Link>
            </div> */}
          </div>
          {loading && <Loading />}
          {error && <Alert type={error.type}>{error.text}</Alert>}
          {customers.length > 0 && loading === false && (
            <div className="col-xs-12 customer-list">
              {customers.map((customer, key) => {
                let id=customer.amdmEraOwnrPartyId === ''? customer.customerId.toString() : customer.amdmEraOwnrPartyId;
                if (id) {
                  if (!id.includes("%")) {
                    return (
                      <RecordRow key={key}>
                        <RecordMeta
                          classes="col-md-2"
                          label="ID"
                          meta={customer.customerId.toString()}
                        />
                        {customer.amdmEraOwnrPartyId === ''? <RecordMeta
                          classes="col-md-6"
                          label="Name"
                          meta={customer.amdmEraOwnrName}
                        /> :
                        <RecordMeta
                            classes="col-md-6"
                            label="ERA Owner Name"
                            meta={
                              <Link
                                  to={`/admin/customer/edit/${id}`}
                              >
                                {customer.amdmEraOwnrName}
                              </Link>
                            }
                        />}
                        <RecordMeta
                            classes="col-md-2"
                            label="ERA Owner ID"
                            meta={customer.amdmEraOwnrPartyId}
                        />
                      </RecordRow>
                    );
                  }
                }
              })}
              <nav>
                <ul className="pagination">{paginationButtons}</ul>
              </nav>
            </div>
          )}
        </div>
      </div>
    );
  }

  renderPaginationButtons(currentPage, totalPages) {
    let pageButtons = [];

    if (currentPage !== 1) {
      pageButtons.push(
        <li className="page-item">
          <a
            style={{ cursor: "pointer" }}
            className="page-link"
            onClick={() => this.getPage(currentPage - 1)}
          >
            Previous
          </a>
        </li>
      );
    }

    for (let i = currentPage - 3; i <= currentPage + 3; i++) {
      if (i > 0 && i <= totalPages) {
        if (i === currentPage) {
          pageButtons.push(
            <li className="page-item">
              <a
                style={{ cursor: "pointer", backgroundColor: "#ddd" }}
                className="page-link"
                onClick={() => this.getPage(i)}
              >
                {i}
              </a>
            </li>
          );
        } else {
          pageButtons.push(
            <li className="page-item">
              <a
                style={{ cursor: "pointer" }}
                className="page-link"
                onClick={() => this.getPage(i)}
              >
                {i}
              </a>
            </li>
          );
        }
      }
    }

    if (currentPage <= totalPages - 4) {
      pageButtons.push(
        <li className="page-item">
          <a style={{ cursor: "pointer" }} className="page-link">
            ...
          </a>
        </li>
      );
      pageButtons.push(
        <li className="page-item">
          <a
            style={{ cursor: "pointer" }}
            className="page-link"
            onClick={() => this.getPage(totalPages)}
          >
            {totalPages}
          </a>
        </li>
      );
    }

    if (currentPage < totalPages) {
      pageButtons.push(
        <li className="page-item">
          <a
            style={{ cursor: "pointer" }}
            className="page-link"
            onClick={() => this.getPage(currentPage + 1)}
          >
            Next
          </a>
        </li>
      );
    }

    return pageButtons;
  }

  getPage(page) {
    if (this.state.searching === true) {
      this.searchCustomers(page, this.state.searchString);
    } else {
      this.getCustomersPage(page);
    }
  }

  searchCustomers(page, searchString) {
    this.setState({
      loading: true,
      searching: true,
      searchString: searchString,
    });
    if (searchString) {
      axios
        .get(
          "/api/customer/search?page=" + (page - 1) + "&search=" + searchString
        )
        .then((response) => {
          if (response.data.customers.length === 0) {
            this.setState({
              error: {
                text: `Sorry, no matches were found for ${searchString}.`,
                type: "warning",
              },
              customers: response.data.customers,
              currentPage: page,
              totalPages: response.data.totalPages,
              loading: false,
            });
          } else {
            this.setState({
              error: null,
              customers: response.data.customers,
              currentPage: page,
              totalPages: response.data.totalPages,
              loading: false,
            });
          }
        })
        .catch(() => {
          this.setState({
            error: {
              text: `${searchString} did not return results, please try again.`,
              type: "warning",
            },
            loading: false,
          });
        });
    } else {
      this.getCustomersPage(1);
    }
  }

  getCustomersPage(page) {
    this.setState({ searching: false });
    axios
      .get("/api/customer/get?page=" + (page - 1))
      .then((response) => {
        this.setState({
          error: null,
          customers: response.data.customers,
          currentPage: page,
          totalPages: response.data.totalPages,
          loading: false,
        });
      })
      .catch(() => {
        this.setState({
          error: {
            text: "There was an error while retrieving customers, please try again.",
            type: "warning",
          },
          loading: false,
        });
      });
  }
}

export default withRouter(AdminCustomers);
