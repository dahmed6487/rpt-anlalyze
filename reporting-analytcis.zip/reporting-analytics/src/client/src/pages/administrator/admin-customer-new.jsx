import * as React from "react";
import { withRouter } from "react-router";
import classNames from "classnames";
import { connect } from "react-redux";
import AsyncSelect from "react-select/async";
import TabButtons from "../../components/tabs/tab-buttons";
//import ToggleSwitch from "../../components/toggle-switch";
import Popover from "../../components/popover";
import "./../../less/components/admin-customer-new.less";
import UserService from "../../redux/services/user-service";

const filterOwnerValue = ({ searchValue, callback }) => {
  if (!searchValue) {
    return callback([]);
  }
  UserService.filterOwnerValue(searchValue).then((ownerResponse) => {
    const getOwner = ownerResponse.data.reduce(
      (previousOwnerData, currentOwnerData) => {
        previousOwnerData.push({
          label: currentOwnerData,
          value: currentOwnerData,
        });
        return previousOwnerData;
      },
      []
    );
    return callback(getOwner);
  });
};

const filterAccountCodeValue = ({ searchValue, callback, accountCode }) => {
  if (!searchValue) {
    return callback([]);
  }
  UserService.filterAccountCodeValue(accountCode, searchValue).then(
    (ownerResponse) => {
      const getAccoutCode = ownerResponse.data.reduce(
        (previousAccountCodeData, currentAccountCodeData) => {
          previousAccountCodeData.push({
            label: currentAccountCodeData,
            value: currentAccountCodeData,
          });
          return previousAccountCodeData;
        },
        []
      );
      return callback(getAccoutCode);
    }
  );
};

const filterCommonEntityGroup = ({
  searchValue,
  callback,
  searchField,
  props,
}) => {
  callback(
    props.customersData
      .filter((customerData) =>
        new RegExp(`^${searchValue}`, "i").test(customerData[searchField])
      )
      .reduce((prevCustValue, currentCustValue) => {
        prevCustValue.push({
          label: currentCustValue[searchField],
          value: currentCustValue["totalAccounts"],
        });
        return prevCustValue;
      }, [])
      .sort((a, b) => a.label - b.label)
  );
};

const listOfDefinitionsState = {
  ownerId: [],
  commonEntityName: [],
  commonEntityId: [],
  commonGroupName: [],
  commonGroupId: [],
  buyingGroupName: [],
  NATIONALGROUP: [],
  NATIONALGROUPNUMBER: [],
  NATIONALSUBGROUPNAME: [],
  NATIONALSUBGROUPNUMBER: [],
  CUSTOMERREGION: [],
  CUSTOMERDISTRICT: [],
  CUSTOMERDISTRICTNAME: [],
  CHAIN: [],
  TERRITORY: [],
};
const listOfDefinitions = [
  {
    label: "Top-Level Owner",
    value: "Owner",
    options: [
      {
        id: "ownerId",
        label: "Owner Name",
        filterCallback: filterOwnerValue,
        searchField: "ownerId",
      },
    ],
  },
  {
    label: "Common Entity/Group",
    value: "CommonEntity",
    options: [
      {
        id: "commonEntityId",
        label: "Common Entity ID",
        filterCallback: filterCommonEntityGroup,
        searchField: "commonEntityId",
      },
      {
        id: "commonEntityName",
        label: "Common Entity Name",
        filterCallback: filterCommonEntityGroup,
        searchField: "commonEntityName",
      },
      {
        id: "commonGroupId",
        label: "Common Group ID",
        filterCallback: filterCommonEntityGroup,
        searchField: "commonGroupId",
      },
      {
        id: "commonGroupName",
        label: "Common Group Name",
        filterCallback: filterCommonEntityGroup,
        searchField: "commonGroupName",
      },
      {
        id: "buyingGroupName",
        label: "Buying Group Name",
        filterCallback: filterCommonEntityGroup,
        searchField: "buyingGroupName",
      },
    ],
  },
  {
    label: "Account Coding/Chain",
    value: "AccountCoding",
    options: [
      {
        id: "NATIONALGROUP",
        label: "National Group Name",
        filterCallback: filterAccountCodeValue,
        searchField: "natlGrpNam",
        accountCode: "natl_grp_nam",
      },
      {
        id: "NATIONALGROUPNUMBER",
        label: "National Group Number",
        filterCallback: filterAccountCodeValue,
        searchField: "natlRrpCd",
        accountCode: "natl_grp_cd",
      },
      {
        id: "NATIONALSUBGROUPNAME",
        label: "National Subgroup Name",
        filterCallback: filterAccountCodeValue,
        searchField: "natlSubGrpNam",
        accountCode: "natl_sub_grp_nam",
      },
      {
        id: "NATIONALSUBGROUPNUMBER",
        label: "National Subgroup Number",
        filterCallback: filterAccountCodeValue,
        searchField: "natlSubGrpCd",
        accountCode: "natl_sub_grp_cd",
      },
      {
        id: "CUSTOMERREGION",
        label: "Region",
        filterCallback: filterAccountCodeValue,
        searchField: "custRgnNum",
        accountCode: "cust_rgn_num",
      },
      {
        id: "CUSTOMERDISTRICTNAME",
        label: "District Name",
        filterCallback: filterAccountCodeValue,
        searchField: "custDstrctName",
        accountCode: "cust_dstrct_name",
      },
      {
        id: "CUSTOMERDISTRICT",
        label: "District Number",
        filterCallback: filterAccountCodeValue,
        searchField: "custDstrctNum",
        accountCode: "cust_dstrct_num",
      },
      {
        id: "CHAIN",
        label: "Chain ID",
        // filterCallback: filterAccountCodeValue,
        searchField: "custChnId",
        accountCode: "acct_chn_id",
      },
      {
        id: "TERRITORY",
        label: "Territory ID",
        filterCallback: filterAccountCodeValue,
        searchField: "slsTerrId",
        accountCode: "TERRITORY_ID",
      },
    ],
  },
];

const tabs = [
  {
    id: "primary",
    title: "Primary",
    inlineStyle: {
      width: "100px",
    },
  },
  {
    id: "secondary",
    title: "Secondary",
    inlineStyle: {
      width: "100px",
    },
  },
];

const CreateDefinitionRadioGroup = React.memo(
  ({ onChangeRadioOption, defaultDefinitionIndex }) => {
    return listOfDefinitions.map((definition, index) => {
      return (
        <div className="col-lg-2" key={index}>
          <label className="radio-inline f5" htmlFor={`definition${index}`}>
            <input
              className="form-check-input"
              type="radio"
              name="flexRadioDefault"
              id={`definition${index}`}
              value={definition.value}
              checked={defaultDefinitionIndex === index}
              onChange={(e) => onChangeRadioOption(definition.value, index)}
            />
            <span className="ml-16">{definition.label}</span>
          </label>
        </div>
      );
    });
  }
);

const ConfirmDialogModal = React.memo(
  ({ closeDialogModal, confirmDialogModal }) => {
    return (
      <div
        id="eraSaveCustomerModal"
        className="modal"
        style={{ height: "fit-content", display: "flex" }}
        tabIndex="-1"
        role="dialog"
      >
        <div className="modal-dialog" role="document">
          <div className="modal-content">
            <div className="modal-header no-icon">
              <button
                type="button"
                onClick={closeDialogModal}
                className="close"
                data-dismiss="modal"
                aria-label="Close"
              >
                <span className="fa fa-times" />
              </button>
              <h4 className="modal-title">Confirm Edit</h4>
            </div>
            <div className="modal-body">
              <p>Are you sure you want to make the following changes?</p>
            </div>
            <div className="modal-footer">
              <button
                type="button"
                onClick={closeDialogModal}
                className="btn btn-link btn-sm"
                data-dismiss="modal"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDialogModal}
                className="btn btn-primary btn-sm"
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
);

const AdminCustomerNew = (props) => {
  const [isValidCustomerName, setIsValidCustomerName] = React.useState(false);
  const [showDialogModal, setShowDialogModal] = React.useState(false);
  const [customerName, setCustomerName] = React.useState("");
  const [customerType, setCustomerType] = React.useState("primary");
  const [tempSelectedOption, setTempSelectedOption] = React.useState({});
  const [defaultDefinitionIndex, setDefaultDefinitionIndex] = React.useState(1);
  /* let [customerToggle, setCustomerToggle] = React.useState({
    "contract-pharmacy-accounts": true,
    "show-340b-solutions": true,
    "include-mpb-accounts": true,
    "show-idb-solutions": true,
    "include-re-pack-accounts": true,
  }); */
  const [isAnyValue, setIsAnyValue] = React.useState({});
  const [isAnyValueList, setIsAnyValueList] = React.useState(
    listOfDefinitionsState
  );
  const [clickOutsidePopOver, setClickOutsidePopOver] = React.useState("");

  /* const onToggleChange = (checked, id) => {
    setCustomerToggle((prevCustomerToggle) => ({
      ...prevCustomerToggle,
      [id]: checked,
    })) 
  } */

  const onChangeRadioOption = (value, index) => {
    setShowDialogModal(true);
    setTempSelectedOption({
      value,
      index,
    });
  };

  const isEmptyObject = (obj) => {
    return !obj || Object.keys(obj).length === 0;
  };

  const updateIsAnyValue = (id, valueList) => {
    let getIsAnyValue = valueList
      .reduce((prevDataValue, newDataValue) => {
        if (!isEmptyObject(newDataValue)) {
          prevDataValue.push(newDataValue.label);
        }
        return prevDataValue;
      }, [])
      .join(",");

    setIsAnyValue((prevValues) => ({
      ...prevValues,
      [id]: getIsAnyValue.length > 0 ? getIsAnyValue : "",
    }));
  };

  const onChangeFilterValue = (e, option) => {
    let updateValues = { [option.id]: isAnyValueList[option.id] };
    updateValues[option.id] = e || [];
    setIsAnyValueList((prevValues) => ({
      ...prevValues,
      ...updateValues,
    }));
    updateIsAnyValue(option.id, updateValues[option.id]);
  };

  const onClickOutsidePopOver = (id) => {
    let isAnyValueArr = isAnyValueList[id].filter(
      (isAnyValue) => !isEmptyObject(isAnyValue)
    );
    if (isAnyValueArr.length === 0) {
      isAnyValueArr = [];
    }

    setIsAnyValueList((prevValues) => {
      prevValues[id] = isAnyValueArr;
      return {
        ...prevValues,
      };
    });
  };

  const closeDialogModal = () => {
    setShowDialogModal(false);
  };

  const confirmDialogModal = () => {
    setShowDialogModal(false);
    if (defaultDefinitionIndex === 1) {
      setIsAnyValueList((prevValues) => {
        return {
          ...prevValues,
          commonEntityName: [],
          commonEntityId: [],
          commonGroupName: [],
          commonGroupId: [],
          buyingGroupName: [],
        };
      });
    }
    if (defaultDefinitionIndex === 0) {
      setIsAnyValueList((prevValues) => {
        return {
          ...prevValues,
          OwnerId: [],
        };
      });
    }
    if (defaultDefinitionIndex === 2) {
      setIsAnyValueList((prevValues) => {
        return {
          ...prevValues,
          NATIONALGROUP: [],
          NATIONALGROUPNUMBER: [],
          NATIONALSUBGROUPNAME: [],
          NATIONALSUBGROUPNUMBER: [],
          CUSTOMERREGION: [],
          CUSTOMERDISTRICTNAME: [],
          CUSTOMERDISTRICT: [],
          CHAIN: [],
          TERRITORY: [],
        };
      });
    }
    setIsAnyValue({});
    setDefaultDefinitionIndex(tempSelectedOption.index);
  };

  const createOrUpdateCustomerInfo = () => {
    if (!customerName) {
      setIsValidCustomerName(true);
      return;
    }
    setIsValidCustomerName(false);
    UserService.createOrUpdateCustomerInfo({
      customerName: customerName,
      priSecFlag: customerType,
      // bFlag: customerToggle["show-340b-solutions"],
      // Top-Level Owner
      ...(isAnyValue["ownerId"] && { owner_id: isAnyValue["ownerId"] }),

      // Common Entity/Group
      ...(isAnyValue["commonEntityId"] && {
        common_entity_id: isAnyValue["commonEntityId"],
      }),
      ...(isAnyValue["commonEntityName"] && {
        common_entity_name: isAnyValue["commonEntityName"],
      }),
      ...(isAnyValue["commonGroupId"] && {
        common_grp_id: isAnyValue["commonGroupId"],
      }),
      ...(isAnyValue["commonGroupName"] && {
        common_grp_name: isAnyValue["commonGroupName"],
      }),
      ...(isAnyValue["buyingGroupName"] && {
        buying_grp_name: isAnyValue["buyingGroupName"],
      }),

      // Account Coding/Chain
      ...(isAnyValue["NATIONALGROUP"] && {
        natl_grp_nam: isAnyValue["NATIONALGROUP"],
      }),
      ...(isAnyValue["NATIONALGROUPNUMBER"] && {
        natl_grp_cd: isAnyValue["NATIONALGROUPNUMBER"],
      }),
      ...(isAnyValue["NATIONALSUBGROUPNAME"] && {
        natl_sub_grp_nam: isAnyValue["NATIONALSUBGROUPNAME"],
      }),
      ...(isAnyValue["NATIONALSUBGROUPNUMBER"] && {
        natl_sub_grp_cd: isAnyValue["NATIONALSUBGROUPNUMBER"],
      }),
      ...(isAnyValue["CUSTOMERREGION"] && {
        cust_rgn_num: isAnyValue["CUSTOMERREGION"],
      }),
      ...(isAnyValue["CUSTOMERDISTRICTNAME"] && {
        cust_dstrct_name: isAnyValue["CUSTOMERDISTRICTNAME"],
      }),
      ...(isAnyValue["CUSTOMERDISTRICT"] && {
        cust_dstrct_num: isAnyValue["CUSTOMERDISTRICT"],
      }),
      ...(isAnyValue["CHAIN"] && {
        cust_chn_id: isAnyValue["CHAIN"],
      }),
      ...(isAnyValue["TERRITORY"] && {
        sls_terr_id: isAnyValue["TERRITORY"],
      }),
      //}
    }).then((response) => {
      props.history.push({
        pathname: "/admin/customers",
        state: {
          status: true,
          customerName,
        },
      });
    }) .catch((err) => {
      alert(JSON.stringify(err.response.data.error_desc));
    });
  };

  React.useEffect(() => {
    if (clickOutsidePopOver) {
      onClickOutsidePopOver(clickOutsidePopOver.id);
    }
  }, [clickOutsidePopOver]);
  return (
    <div className="row admin-customer-new">
      <div className="col-xs-12">
        <h3>New Customer Definition</h3>
        <section>
          <h4 className="mt-40 mb-34">Customer Details</h4>
          <div className="row">
            <div className="col-lg-4">
              <label htmlFor="era-new-team-team-name">
                CUSTOMER DISPLAY NAME
              </label>
              <input
                type="text"
                className={`form-control ${
                  isValidCustomerName ? "input-error" : ""
                }`}
                id="era-new-team-team-name"
                placeholder="Give a name to your team"
                onChange={(e) => {
                  setIsValidCustomerName(e.target.value ? false : true);
                  setCustomerName(e.target.value);
                }}
              />
              {isValidCustomerName && (
                <span className="error">
                  Please choose a customer display name
                </span>
              )}
            </div>
          </div>
          <div className="row mt-32">
            <div className="col-lg-4">
              <span className="label-text">Customer type</span>
            </div>
            <div className="col-lg-2">
              <TabButtons
                tabs={tabs}
                activeTab={customerType}
                onClick={(event, customerTypeId) => {
                  setCustomerType(customerTypeId);
                }}
              />
            </div>
          </div>
        </section>
        <section>
          <h4 className="mt-32 mb-32">Definition</h4>
          <div className="row">
            <CreateDefinitionRadioGroup
              onChangeRadioOption={onChangeRadioOption}
              defaultDefinitionIndex={defaultDefinitionIndex}
            />
          </div>
          <div className="row mt-24">
            {listOfDefinitions[defaultDefinitionIndex].options.map(
              (option, index) => {
                const selectedIsAnyValue = isAnyValue?.[option.id];
                const isAnyValueListValue = isAnyValueList[option.id];

                return (
                  <div className="col-lg-2" key={index}>
                    <span>{option.label}</span>
                    <Popover
                      {...(index !== 0 &&
                        index % 5 === 0 && {
                          style: {
                            right: 117,
                          },
                        })}
                      triggerNode={
                        <button
                          className={classNames("is-any-value", {
                            active: selectedIsAnyValue,
                          })}
                        >
                          {selectedIsAnyValue
                            ? `is ${selectedIsAnyValue}`
                            : "Is any value"}
                        </button>
                      }
                      trigger="click"
                      onClickOutSide={(e) => {
                        setClickOutsidePopOver({
                          id: option.id,
                          list: isAnyValueListValue,
                        });
                      }}
                    >
                      <div className={classNames("popover-box")}>
                        <div className="display-flex popover-container">
                          <AsyncSelect
                            cacheOptions
                            placeholder={"Search"}
                            className="select-dropdown-list"
                            isSearchable={true}
                            isClearable={true}
                            isMulti
                            value={isAnyValueListValue}
                            defaultValue={isAnyValueListValue}
                            loadOptions={(e, callback) =>
                              option.filterCallback &&
                              option.filterCallback({
                                searchValue: e,
                                callback,
                                searchField: option?.searchField,
                                accountCode: option?.accountCode,
                                props,
                              })
                            }
                            onChange={(e) => onChangeFilterValue(e, option)}
                            styles={{
                              multiValue: (styles) => ({
                                ...styles,
                                background: "#F0F6FB",
                                color: "#3185CD",
                              }),
                              multiValueLabel: (styles) => ({
                                ...styles,
                                color: "#3185CD",
                              }),
                            }}
                          />
                        </div>
                      </div>
                    </Popover>
                  </div>
                );
              }
            )}
          </div>
        </section>
        <section>
          {showDialogModal && (
            <ConfirmDialogModal
              closeDialogModal={closeDialogModal}
              confirmDialogModal={confirmDialogModal}
            />
          )}
          {/* <div className="row mt-32">
            <div className="col-lg-4">
              <span className="label-text">
                Include Contract Pharmacy Accounts?
              </span>
            </div>
            <div className="col-lg-2">
              <ToggleSwitch
                id="contract-pharmacy-accounts"
                checked={customerToggle["contract-pharmacy-accounts"]}
                onChange={(checked) =>
                  onToggleChange(checked, "contract-pharmacy-accounts")
                }
              />
            </div>
            <div className="col-lg-4">
              <span className="label-text">Show 340b Solutions?</span>
            </div>
            <div className="col-lg-2">
              <ToggleSwitch
                id="show-340b-solutions"
                checked={customerToggle["show-340b-solutions"]}
                onChange={(checked) =>
                  onToggleChange(checked, "show-340b-solutions")
                }
              />
            </div>
          </div>
          <div className="row mt-32">
            <div className="col-lg-4">
              <span className="label-text">Include MPB Accounts?</span>
            </div>
            <div className="col-lg-2">
              <ToggleSwitch
                id="includee-mpb-accounts"
                checked={customerToggle["include-mpb-accounts"]}
                onChange={(checked) =>
                  onToggleChange(checked, "include-mpb-accounts")
                }
              />
            </div>
            <div className="col-lg-4">
              <span className="label-text">Show IDB Solutions?</span>
            </div>
            <div className="col-lg-2">
              <ToggleSwitch
                id="show-idb-solutions"
                checked={customerToggle["show-idb-solutions"]}
                onChange={(checked) =>
                  onToggleChange(checked, "show-idb-solutions")
                }
              />
            </div>
          </div>
          <div className="row mt-32 mb-28">
            <div className="col-lg-4">
              <span className="label-text">Include Re-Pack Accounts?</span>
            </div>
            <div className="col-lg-2">
              <ToggleSwitch
                id="include-re-pack-accounts"
                checked={customerToggle["include-re-pack-accounts"]}
                onChange={(checked) =>
                  onToggleChange(checked, "include-re-pack-accounts")
                }
              />
            </div>
          </div> */}
          <div className="row mt-57 admin-customer-new-footer">
            <div className="col-lg-11 text-right">
              <button className="btn admin-customer-new-footer-cancel-btn">
                CANCEL
              </button>
              <button
                className="btn admin-customer-new-footer-save-btn"
                onClick={createOrUpdateCustomerInfo}
              >
                SAVE
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

const mapStateToProps = (state) => {
  return {
    store: state,
    customersData: state.user.customersData,
  };
};

const AdminCustomerNewComp = withRouter(AdminCustomerNew);

export default connect(mapStateToProps)(AdminCustomerNewComp);
