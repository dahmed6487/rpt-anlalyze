import React, { Component } from 'react';
import autoBind from 'react-autobind';
import axios from 'axios';
import { GetHumanReadableRole } from './admin-users';
import { GetHumanReadableStatus } from './admin-team-members-edit';
import { Link } from 'react-router-dom';
import Alert from '../../components/alert/alert';
import { PauseAndRedirect } from '../../components/user/user-form';

class AdminTeamsNew extends Component {
    constructor(props) {
        super(props);
        autoBind(this);

        this.customerId = props.match.params.customerId;

        this.state = {
            teamName: '',
            teamMembers: [],
            newTeamMemberUserName: '',
            error: null,
            save: false,
            loading: false,
            disabled : false
        }
    }

    render() {
        const { teamName, error, save, loading } = this.state;
        let teamMembers = this.generateTeamMembers();
        let newTeamDetails = this.generateNewTeamDetails();

        return (
            <div className="era-teams-new-container">
                <h3>Create Team</h3>

                {error
                    && (
                    <Alert type={error.type}>
                        {error.text}
                    </Alert>
                    )}
                {save
                    && (
                    <Alert type="success">
                        Team
                        {' '}
                        {teamName}
                        {' '}
                        has been created.
                    </Alert>
                    )}
                {loading
                    && <div>Loading...</div>
                }

                <div className="era-new-team-form">
                    <div>
                        <label htmlFor="era-new-team-team-name">Name</label>
                        <input type="text" className="form-control" id="era-new-team-team-name" placeholder="Give a name to your team" onChange={(e) => { this.setState({ teamName: e.target.value }) }} />
                    </div>
                    <div className="era-add-user-team-form">
                        <label htmlFor="era-new-team-add-user">Add User</label>
                        <input type="text" className="form-control" id="era-new-team-add-user" placeholder="Type user name and click add" onChange={(e) => { this.setState({ newTeamMemberUserName: e.target.value }) }} />
                    </div>
                    <button type="button" className="era-add-team-member-button btn btn-primary" onClick={() => this.handleAddTeamMemberClick()}>Add</button>
                </div>
                <div className="era-teams-new-members">
                    <h4>Members</h4>
                    {teamMembers}
                </div>

                <div id="eraCreateTeamModal" className="modal" style={{ height: 'fit-content' }} tabIndex="-1" role="dialog">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header no-icon">
                                <button type="button" onClick={() => this.closeCreateTeamModal()} className="close" data-dismiss="modal" aria-label="Close">
                                    <span className="fa fa-times" />
                                </button>
                                <h4 className="modal-title">Confirm New Team</h4>
                            </div>
                            <div className="modal-body">
                                <p>Are you sure you want to make the following team?</p>
                                {newTeamDetails}
                            </div>
                            <div className="modal-footer">
                                <button type="button" onClick={() => this.closeCreateTeamModal()} className="btn btn-link btn-sm" data-dismiss="modal">Cancel</button>
                                <button type="button" disabled={this.state.disabled} onClick={() => this.confirmCreateTeam() } className="btn btn-primary btn-sm">Confirm</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="form-footer">
                    <div className="text-right">
                        <Link to="/admin/teams" className="btn btn-link">Cancel</Link>
                        <button type="button" disabled={this.state.disabled} onClick={() => this.onNewTeamSave()} className="btn btn-primary">Create</button>
                    </div>
                </div>
            </div>
        );
    }

    generateTeamMembers() {
        let teamMembers = [];

        for (let teamMember of this.state.teamMembers) {
            teamMembers.push(
                <div className="era-new-team-member-row">
                    <div className="era-new-team-member-username">{teamMember.username}</div>
                    <div className="era-new-team-member-name">{(teamMember.firstName || '') + ' ' + (teamMember.lastName || '')}</div>
                    <div className="era-new-team-member-email">{teamMember.email}</div>
                    <div className="era-new-team-member-role">{GetHumanReadableRole(teamMember.userRole)}</div>
                    <div className="era-new-team-member-status">{GetHumanReadableStatus(teamMember.active)}</div>
                    <button type="button" className="remove-new-member-button btn btn-link" onClick={() => this.handleRemoveTeamMemberClick(teamMember.username)}>Remove</button>
                </div>
            )
        }

        return teamMembers;
    }

    handleAddTeamMemberClick() {
        let newTeamMemberUserName = this.state.newTeamMemberUserName;
        this.setState({ loading: true });
        this.findAndAddTeamMember(newTeamMemberUserName);
    }

    findAndAddTeamMember(newTeamMemberUserName) {
        let userAlreadyInList = this.state.teamMembers.find((teamMember) => {
            return teamMember.username === newTeamMemberUserName;
        });

        if (!userAlreadyInList) {
            axios.get(`/api/user/username/${newTeamMemberUserName}?customerId=${this.customerId}`)
                .then((response) => {
                    let userInput = document.getElementById('era-new-team-add-user');
                    if (userInput) {
                        userInput.value = '';
                    }
                    this.setState({ newTeamMemberUserName: '' });

                    let teamMembers = [...this.state.teamMembers];
                    teamMembers.push(response.data);

                    this.setState({
                        teamMembers: teamMembers,
                        error: null,
                        loading: false
                    })
                })
                .catch((error) => {
                    this.setState({
                        error: { text: `Sorry, no matches were found for ${newTeamMemberUserName} for this customer.`, type: 'warning' },
                        loading: false
                    });
                });
        } else {
            this.setState({
                error: null,
                loading: false
            });
        }
    }

    handleRemoveTeamMemberClick(username) {
        let updatedTeamMembers = this.state.teamMembers.filter((teamMember) => {
            return teamMember.username !== username;
        });

        this.setState({ teamMembers: updatedTeamMembers });
    }

    onNewTeamSave() {
        const modal = document.getElementById('eraCreateTeamModal');
        if (modal) {
            modal.style.display = 'flex';
        }
    }

    closeCreateTeamModal() {
        const modal = document.getElementById('eraCreateTeamModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    confirmCreateTeam() {
        this.setState({
            error: null,
            loading: true,
            disabled : true
        })
        this.closeCreateTeamModal();
        axios.post('/api/teams', { customerId: this.customerId, name: this.state.teamName, platformId:'P' })
            .then((response) => {
                this.addMembersToTeam(response.data.collaborationTeamId);
            })
            .catch((error) => {
                this.setState({
                    error: { text: 'There was an error while creating the team, please try again.', type: 'warning' },
                    loading: false,
                    disabled : false
                });
            });
    }

    addMembersToTeam(collaborationTeamId) {
        this.closeCreateTeamModal();
        axios.post(`/api/teams/users?teamId=${collaborationTeamId}&customerId=${this.customerId}`, this.state.teamMembers)
            .then((response) => {
                this.setState({
                    save: true,
                    error: null,
                    loading: false,
                    disabled : true
                }, () => PauseAndRedirect('#/admin/teams'));
            })
            .catch((error) => {
                this.setState({
                    error: { text: 'The team was created but there was an error adding members to the team, please try again.', type: 'warning' },
                    loading: false,
                    disabled : false
                });
            });
    }

    generateNewTeamDetails() {
        const { teamName, teamMembers } = this.state;
        let teamMembersElements = [];

        teamMembersElements.push(<div style={{ color: 'black' }}>Members: </div>);
        for (let teamMember of teamMembers) {
            teamMembersElements.push(
                <div>{teamMember.username}</div>
            );
        }

        return (
            <div>
                <span style={{ color: 'black' }}>Team Name: </span>
{teamName}
                {teamMembersElements}
            </div>
        );
    }
}

export default AdminTeamsNew;