import React, { Component } from 'react';
import autoBind from 'react-autobind';
import Alert from '../../components/alert/alert';
import axios from 'axios';
import { GetHumanReadableRole } from './admin-users'
import { Link } from 'react-router-dom';

class AdminTeamMembersEdit extends Component {
    constructor(props) {
        super(props);
        autoBind(this);

        let customerId;
        if (props.match) {
            customerId = props.match.params.customerId;
        } else {
            customerId = props.customerId;
        }
        this.customerId = customerId;

        this.state = {
            teamId: '',
            teamMembers: [],
            newTeamMembers: [],
            userIdToDelete: '',
            newTeamMemberUserName: '',
            save: false,
            error: null,
            loading: true,
            removed: false
        }
    }

    componentDidMount() {
        let teamId;
        if (this.props.match) {
            teamId = this.props.match.params.team;
        } else {
            teamId = this.props.team;
        }
        if (teamId) {
            this.setState({ teamId: teamId }, () => this.getTeamMembers(teamId));
        }
    }

    componentDidUpdate(prevProps) {
        if (this.props.team !== prevProps.team) {
            this.setState({ teamId: this.props.team });
        }
    }

    render() {
        let { newTeamMembers, userIdToDelete, error, loading, removed, save } = this.state;
        let teamMembersElements = this.generateTeamMembers(this.state.teamMembers);
        let newTeamMembersElements = this.generateNewTeamMembers(this.state.newTeamMembers);
        let newTeamMembersDetails = this.generateNewTeamMemberDetails();

        return (
            <div className="era-team-members-edit-container">
                {error
                    && (
                    <Alert type={error.type}>
                        {error.text}
                    </Alert>
                    )}
                {loading
                    && <div>Loading...</div>}

                {save
                    && (
                    <Alert type="success">
                        Team was saved.
                    </Alert>
                    )}

                {removed
                    && (
                    <Alert type="success">
                        User
                        {' '}
                        {userIdToDelete}
                        {' '}
                        has been removed.
                    </Alert>
                    )}

                <div className="era-add-members-form">
                    <div className="">
                        <label htmlFor="era-add-members-user">Add User</label>
                        <input type="text" className="form-control" id="era-add-members-user" placeholder="Type user name and click add" onChange={(e) => { this.setState({ newTeamMemberUserName: e.target.value }) }} />
                    </div>
                    <button type="button" className="era-add-members-button btn btn-primary" onClick={() => this.handleAddTeamMemberClick()}>Add</button>
                </div>

                <div className="era-team-members-edit">
                    <h4>Members</h4>
                    {teamMembersElements}
                </div>

                {newTeamMembers.length > 0
                    && (
                    <div className="era-new-members">
                        <h4>Added Members</h4>
                        {newTeamMembersElements}
                    </div>
                    )}

                <div className="form-footer">
                    <div className="text-right">
                        <Link to="/admin/teams" className="btn btn-link">Cancel</Link>
                        <button type="button" onClick={() => this.handleSaveButtonClick()} className="btn btn-primary">Save</button>
                    </div>
                </div>

                <div id="eraRemoveMemberModal" className="modal" style={{ height: 'fit-content' }} tabIndex="-1" role="dialog">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header no-icon">
                                <button type="button" onClick={() => this.closeRemoveMemberModal()} className="close" data-dismiss="modal" aria-label="Close">
                                    <span className="fa fa-times" />
                                </button>
                                <h4 className="modal-title">Confirm Edit</h4>
                            </div>
                            <div className="modal-body">
                                <p>Are you sure you want to make the following edits?</p>
                                <div>
                                    <span style={{ color: 'black' }}>Remove: </span>
                                    {this.state.userIdToDelete}
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" onClick={() => this.closeRemoveMemberModal()} className="btn btn-link btn-sm" data-dismiss="modal">Cancel</button>
                                <button type="button" onClick={() => this.confirmRemoveMember()} className="btn btn-primary btn-sm">Confirm</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="eraSaveModal" className="modal" style={{ height: 'fit-content' }} tabIndex="-1" role="dialog">
                    <div className="modal-dialog" role="document">
                        <div className="modal-content">
                            <div className="modal-header no-icon">
                                <button type="button" onClick={() => this.closeSaveModal()} className="close" data-dismiss="modal" aria-label="Close">
                                    <span className="fa fa-times" />
                                </button>
                                <h4 className="modal-title">Confirm Edit</h4>
                            </div>
                            <div className="modal-body">
                                <p>Are you sure you want to make the following edits?</p>
                                {newTeamMembersDetails}
                            </div>
                            <div className="modal-footer">
                                <button type="button" onClick={() => this.closeSaveModal()} className="btn btn-link btn-sm" data-dismiss="modal">Cancel</button>
                                <button type="button" onClick={() => this.confirmSave()} className="btn btn-primary btn-sm">Confirm</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        );
    }

    getTeamMembers(collabTeamId) {
        axios.get(`/api/teams/get/${collabTeamId}/members`)
            .then((response) => {
                this.setState({
                    teamMembers: response.data,
                    error: null,
                    loading: false
                })
            }).catch((error) => {
                this.setState({
                    error: { text: 'There are no Members for this team.', type: 'info' },
                    loading: false
                });
            });
    }

    generateTeamMembers(stateTeamMembers) {
        let teamMembers = [];

        for (let teamMember of stateTeamMembers) {
            teamMembers.push(
                <div className="era-team-member-edit-row">
                    <div className="era-team-member-edit-username">{teamMember.username}</div>
                    <div className="era-team-member-edit-name">{(teamMember.firstName || '') + ' ' + (teamMember.lastName || '')}</div>
                    <div className="era-team-member-edit-email">{teamMember.email}</div>
                    <div className="era-team-member-edit-role">{GetHumanReadableRole(teamMember.userRole)}</div>
                    <div className="era-team-member-edit-status">{GetHumanReadableStatus(teamMember.active)}</div>
                    <button type="button" className="remove-member-button btn btn-link" onClick={() => this.removeMemberClick(teamMember.username)}>Remove</button>
                </div>
            );
        }

        return teamMembers;
    }

    generateNewTeamMembers(stateTeamMembers) {
        let teamMembers = [];

        for (let teamMember of stateTeamMembers) {
            teamMembers.push(
                <div className="era-team-member-edit-row">
                    <div className="era-team-member-edit-username">{teamMember.username}</div>
                    <div className="era-team-member-edit-name">{(teamMember.firstName || '') + ' ' + (teamMember.lastName || '')}</div>
                    <div className="era-team-member-edit-email">{teamMember.email}</div>
                    <div className="era-team-member-edit-role">{GetHumanReadableRole(teamMember.userRole)}</div>
                    <div className="era-team-member-edit-status">{GetHumanReadableStatus(teamMember.active)}</div>
                    <button type="button" className="remove-member-button btn btn-link" onClick={() => this.removeNewMemberClick(teamMember.username)}>Remove</button>
                </div>
            );
        }

        return teamMembers;
    }

    removeMemberClick(userId) {
        this.setState({ userIdToDelete: userId });
        let modal = document.getElementById('eraRemoveMemberModal');
        if (modal) {
            modal.style.display = 'flex';
        }
    }

    closeRemoveMemberModal() {
        let modal = document.getElementById('eraRemoveMemberModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    confirmRemoveMember() {
        this.removeMember();
    }

    async removeMember() {
        const { userIdToDelete, teamId } = this.state;
        axios.delete(`/api/teams/users?teamId=${teamId}&customerId=${this.customerId}&userId=${userIdToDelete}`)
            .then((response) => {
                this.closeRemoveMemberModal();
                this.removeMemberFromTeamMembers(userIdToDelete);
                this.setState({
                    removed: true,
                    error: null
                })
            }).catch((error) => {
                this.setState({
                    removed: false,
                    error: { text: 'There was an error removing this user, please try again', type: 'warning' }
                });
            });
    }

    removeMemberFromTeamMembers(userIdToDelete) {
        let updatedTeamMembers = this.state.teamMembers.filter((teamMember) => {
            return teamMember.username !== userIdToDelete;
        });

        this.setState({ teamMembers: updatedTeamMembers });
    }

    handleAddTeamMemberClick() {
        let newTeamMemberUserName = this.state.newTeamMemberUserName;
        this.setState({ loading: true });
        this.findAndAddTeamMember(newTeamMemberUserName);
    }

    findAndAddTeamMember(newTeamMemberUserName) {
        let userAlreadyInList = this.state.newTeamMembers.find((teamMember) => {
            return teamMember.username === newTeamMemberUserName;
        });

        if (!userAlreadyInList) {
            axios.get(`/api/user/username/${newTeamMemberUserName}?customerId=${this.customerId}`)
                .then((response) => {
                    let userInput = document.getElementById('era-add-members-user');
                    if (userInput) {
                        userInput.value = '';
                    }
                    this.setState({ newTeamMemberUserName: '' });

                    let teamMembers = [...this.state.newTeamMembers];
                    teamMembers.push(response.data);

                    this.setState({
                        newTeamMembers: teamMembers,
                        error: null,
                        loading: false,
                        removed: false
                    })
                })
                .catch((error) => {
                    this.setState({
                        error: { text: `Sorry, no matches were found for ${newTeamMemberUserName} for this customer.`, type: 'warning' },
                        loading: false,
                        removed: false
                    });
                });
        } else {
            this.setState({
                error: null,
                loading: false,
                removed: false
            });
        }
    }

    handleSaveButtonClick() {
        let modal = document.getElementById('eraSaveModal');
        if (modal) {
            modal.style.display = 'flex';
        }
    }

    closeSaveModal() {
        let modal = document.getElementById('eraSaveModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    confirmSave() {
        this.addMembersToTeam(this.state.teamId);
    }

    addMembersToTeam(collaborationTeamId) {
        const { newTeamMembers, teamMembers } = this.state;
        axios.post(`/api/teams/users?teamId=${collaborationTeamId}&customerId=${this.customerId}`, newTeamMembers)
            .then((response) => {
                this.closeSaveModal();
                this.setState({
                    save: true,
                    teamMembers: newTeamMembers.concat(teamMembers),
                    newTeamMembers: [],
                    error: null,
                    removed: false
                });
            })
            .catch((error) => {
                this.closeSaveModal();
                this.setState({
                    error: { text: 'There was an error adding members to the team, please try again.', type: 'warning' },
                    removed: false
                });
            });
    }

    generateNewTeamMemberDetails() {
        const { newTeamMembers } = this.state;
        let teamMembersElements = [];

        teamMembersElements.push(<div style={{ color: 'black' }}>Members: </div>);
        for (let teamMember of newTeamMembers) {
            teamMembersElements.push(
                <div>{teamMember.username}</div>
            );
        }

        return (
            <div>
                {teamMembersElements}
            </div>
        );
    }

    removeNewMemberClick(username) {
        let updatedNewTeamMembers = this.state.newTeamMembers.filter((teamMember) => {
            return teamMember.username !== username;
        });

        this.setState({ newTeamMembers: updatedNewTeamMembers });
    }
}

/**
/**
 * @return {string}
 */
export function GetHumanReadableStatus(status) {
    if (status === 'Y') {
        return 'Active';
    } else if (status === 'N') {
        return 'Inactive';
    } else {
        return '';
    }
}

export default AdminTeamMembersEdit;