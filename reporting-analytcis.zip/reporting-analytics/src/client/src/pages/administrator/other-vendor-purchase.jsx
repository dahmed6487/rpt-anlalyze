import React, { Component } from "react";
import autoBind from "react-autobind";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { actions } from "../../redux/state";
import Tabs from '../../components/tabs/tabs';
import OtherVendorPurchaseUpload from "./other-vendor-purchase-upload";
import OtherVendorPurchaseDashboard from "./other-vendor-purchase-dashboard";

class OtherVendorPurchase extends Component {
    constructor(props, context) {
        super(props, context);
        autoBind(this);
        this.actions = props.actions;

        this.state = {
            tabDisplay: 'upload',
            tabs: [],
        }

    }

    componentDidMount() {

        let tabs = [
            {
                id: 'upload',
                title: 'UPLOAD DATA',
                toolTip: 'Upload Other Vendor Purchase data.'
            },
            {
                id: 'dashboard',
                title: 'UPLOAD HISTORY',
                toolTip: 'Show all the successfully uploaded files information.'
            },
        ];

        this.setState({ tabs: tabs })
    }

    render() {
        const { tabDisplay, } = this.state;

        return (
            <div>
                <React.Fragment>
                    <Tabs tabs={this.state.tabs} onClickFn={this.displayTab} active={tabDisplay} />

                    {tabDisplay === 'upload' &&
                    <OtherVendorPurchaseUpload />
                    }

                    {tabDisplay === 'dashboard' &&
                    <OtherVendorPurchaseDashboard />
                    }

                </React.Fragment>
            </div>
        );
    }

    displayTab(event, tab) {
        if (event) event.preventDefault();
        this.setState({
            tabDisplay: tab
        });
    }

}

const mapStateToProps = (state, ownProps) => {
    return { store: state };
};

const mapDispatchToProps = dispatch => {
    return { actions: bindActionCreators(actions, dispatch) };
};

export default connect( mapStateToProps, mapDispatchToProps)(OtherVendorPurchase)