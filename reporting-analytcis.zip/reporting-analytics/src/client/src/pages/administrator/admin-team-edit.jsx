import React, { Component } from "react";
import autoBind from "react-autobind";
import axios from "axios";
import { connect } from 'react-redux';
import AdminTeamMembersEdit from "./admin-team-members-edit";
import TeamForm from "../../components/teams/team-form";
import TeamContentAccesses from "../../components/teams/team-content-accesses";
import Alert from "../../components/alert/alert";
import Tabs from "../../components/tabs/tabs";
import {GetCustomerId} from "./admin-users";

class AdminTeamEdit extends Component {
    constructor(props) {
        super(props);
        autoBind(this);

        this.teamId = props.match.params.team;

        this.state = {
            team: {},
            customerId: "",
            error: null,
            tabDisplay: "team"
        }
    }

    async componentDidMount() {
        this.setState({customerId: await GetCustomerId(this.props.currentUser)});
        this.getTeam();
    }

    render() {
        let teamName = this.state.team.name;
        const { error, tabDisplay } = this.state;
        const tabs = [
            {
                id: 'team',
                title: 'Team',
                toolTip:'Manage teams of users within the customer organization.'
            },
            {
                id: 'contentAccesses',
                title: 'Solutions Access',
                toolTip:'Manage which Solution folders the team has access to.'
            },
            {
                id: 'teamMembers',
                title: 'Members',
                toolTip:'Manage membership of teams.'
            }
        ];

        let tabContent = this.getTabContent();

        return (
            <div className="row">
                <div className="col-xs-12">
                    <h3 className="no-top">
                    Edit
                    {' '}
                    {teamName}
                    </h3>
                    {error
                        && (
                        <Alert type={error.type}>
                            {error.text}
                        </Alert>
                        )}
                    <Tabs tabs={tabs} onClickFn={this.displayTab} active={tabDisplay} />
                    {tabContent}
                </div>
            </div>
        );
    }

    getTabContent() {
        const { team } = this.state;

        switch(this.state.tabDisplay)  {
            case "team":
                return <TeamForm team={team}/>;
            case "contentAccesses":
                return <TeamContentAccesses team={team}/>;
            case "teamMembers":
                return <AdminTeamMembersEdit team={team.collaborationTeamId} customerId={this.state.customerId}/>;
        }
    }

    displayTab(event, tabId){
        if(event) event.preventDefault();
        this.setState({
            tabDisplay: tabId
        });
    }

    getTeam() {
        axios.get(`/api/teams/get/${this.teamId}`)
            .then((response) => {
                this.setState({
                    team: response.data,
                    error: null
                })
            }).catch((error) => {
                this.setState({
                    error: { text: `There was an error while loading this team, please try again.`, type: 'warning' }
                });
            });
    }
}

const mapStateToProps = (state, ownProps) => {
  return { currentUser: state.user.currentUser };
};

export default connect(
 mapStateToProps,
)(AdminTeamEdit);
