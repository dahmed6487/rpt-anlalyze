import React, { Component } from 'react';
import autoBind from 'react-autobind';

// React-Redux
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { actions } from '../redux/state';

class About extends Component {
  constructor(props, context){
    super(props, context);
    autoBind(this);
    this.actions = props.actions;
  }

  render(){
    return (
            <div className="home">
                <div className="row">
                    <div className="col-xs-12">
                        <p>About page.</p>
                    </div>
                </div>
            </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return { store: state };
};

const mapDispatchToProps = (dispatch) => {
  return { actions: bindActionCreators(actions, dispatch) };
};

export default connect(mapStateToProps, mapDispatchToProps)(About);
