import React, { Component } from 'react';
import autoBind from 'react-autobind';
import looker from '../img/looker.svg';

// React-Redux
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import { actions } from '../redux/state';

class Home extends Component {
  constructor(props, context) {
    super(props, context);
    autoBind(this);
    this.actions = props.actions;
  }

  render() {
    return (
      <div className="home">
        <div className="row">
          <div className="col-xs-12">
            <img src={looker} alt="iframe" />
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state, ownProps) => {
  return { store: state };
};

const mapDispatchToProps = dispatch => {
  return { actions: bindActionCreators(actions, dispatch) };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Home);
