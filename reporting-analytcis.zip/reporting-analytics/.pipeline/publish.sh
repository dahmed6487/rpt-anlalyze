#!/usr/bin/env bash

set -e

handle_error() {
    echo "${0##*/}: Error occurred on line $1"
    exit 1
}

trap 'handle_error $LINENO' ERR

echo "-------------------------------------------------"
echo "       Running ${0##*/}"
echo "-------------------------------------------------"

echo "-------------------------------------------------"
echo "       Reading Base Version"
echo "-------------------------------------------------"

ARTIFACTORY_URL='https://mck.jfrog.io/artifactory/'
ARTIFACTORY_PATH='cxp-data-analytics-gradle-local/reporting-analytics/' 

BASE_VERSION="$(mckduc get-version --file gradle.properties --pattern "currentVersion=__VERSION__")"
echo "----- Base Version in file is $BASE_VERSION -----"

echo "-------------------------------------------------"
echo "       Calculating Next Version"
echo "-------------------------------------------------"

NEXT_VERSION="$(mckduc next-version --artifactory-user $ARTIFACTORY_USER --artifactory-apikey $ARTIFACTORY_API_KEY --artifact-path $ARTIFACTORY_PATH --pattern /__VERSION__/ --build-version ${BASE_VERSION})"
echo "----- Next publishable version is $NEXT_VERSION -----"

.pipeline/ci.sh "${NEXT_VERSION}"

echo "-------------------------------------------------"
echo "       Publishing to Artifactory"
echo "-------------------------------------------------"

LOCAL_ARTIFACT_PATH="./build/libs/reporting-analytics-${NEXT_VERSION}.jar" # to the local jar file

export JFROG_CLI_OFFER_CONFIG=false

ARTIFACTORY_PATH_WITH_VERSION=$ARTIFACTORY_PATH$NEXT_VERSION'/'

# Upload jar to artifactory
jfrog rt upload "${LOCAL_ARTIFACT_PATH}" "${ARTIFACTORY_PATH_WITH_VERSION}" --recursive=False --url "${ARTIFACTORY_URL}" --user "${ARTIFACTORY_USER}" --password "${ARTIFACTORY_API_KEY}"
# Upload manifests to artifactory in the same version folder as the artifact e.g. mcklabs-local/0.0.1/manifest-dev.yml
jfrog rt upload "manifest*" "${ARTIFACTORY_PATH_WITH_VERSION}" --recursive=False --url "${ARTIFACTORY_URL}" --user "${ARTIFACTORY_USER}" --password "${ARTIFACTORY_API_KEY}"

PUBLISHED_ARTIFACT="reporting-analytics-${NEXT_VERSION}.jar"
echo "-------------------------------------------------"
echo "       Artifactory path:      $ARTIFACTORY_PATH_WITH_VERSION"
echo "       Artifact published:    $PUBLISHED_ARTIFACT"
echo "-------------------------------------------------"
