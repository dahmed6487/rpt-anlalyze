#!/usr/bin/env bash

set -e

handle_error() {
    echo "${0##*/}: Error occurred on line $1"
    exit 1
}

trap 'handle_error $LINENO' ERR

echo "-------------------------------------------------"
echo "       Running ${0##*/}"
echo "-------------------------------------------------"

echo "-------------------------------------------------"
echo "       Building and Testing"
echo "-------------------------------------------------"

./gradlew build -x test --console plain -Pjfrog_user="${ARTIFACTORY_USER}" -Pjfrog_password="${ARTIFACTORY_API_KEY}" -PcurrentVersion="${1:-0.0.1}"

echo "-------------------------------------------------"
echo "       SonarQube Analysis"
echo "-------------------------------------------------"

sonarscanner --branch $BRANCH --api-key $SONARQUBE_API_KEY 
