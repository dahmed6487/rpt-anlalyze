##REPORTING-ANALYTICS

### What technologies being used?
#### Development
	1. Java-8
	2. Spring Boot
	3. Spring Boot Data JPA
	4. SAML & OAuth (IAM)
	5. Swagger
	6. Gradle
	7. React JS
####Testing
	1. JUnit (test case executor)	

### New Developer Local setup instructions.

_...ALL THE BEST...._

#### `Step 1` OnBoarding Goals
    1.Get access and check that it works (OKTA, Artifactory, Bitbucket, VPN, etc)
    2.Setup tools and configs (IntelliJ, Clone BB repos, Gradle, SSH, NPM)
    3.Run Config-Server locally
    4.Run Reporting analytics locally

### `Step 2` Bitbucket Repos
    Clone these repos to C:\Users\<EID>\WS\ERA
    1. Config-Server (server) > [config-server](https://bitbucket.mckesson.com:8443/projects/ES/repos/com.mckesson.ms.config-server/browse) 
    2. ERA application > [reporting-analytics ](https://bitbucket.mckesson.com:8443/projects/REP/repos/reporting-analytics/browse)
    3.Rna-config > [rna-config ](https://bitbucket.mckesson.com:8443/projects/REP/repos/rna-config/browse)

###  Tools Setup
 ### `Step 3` IDE
    IntelliJ IDEA (recommended)
    personally I am using using IntelliJ now, so this is not recommended.
    If you are more familiar and comfortable with Eclipse then go for it.

### `Step 4` NodeJS
    You can just download the latest version of Node.
     Node and NPM are needed for building the front end files of Simone.
     See #NPM Setup for details on how to configure NPM.

### `Step 5` Java Development Kit (JDK)
    1.Download the latest version of JDK 8 from Oracle. An Oracle account is needed for this, but it is simple and free to setup.
    2.After installing the JDK, you will want to setup CA certs, follow this guide to do so: Installing
       McKesson CA in Java
    3.Setup the JAVA_HOME environmental variable and add the JDK to your PATH variable if
       not done automatically during the installation process.

###  `Step 6` Git
    You will want to use git bash at times which comes installed with Git.

### `Step 7` SSH Setup
    1.You will need to setup SSH on your machine so that the remote Bitbucket repositories can
    be accessed from your local Config Server.
    2.To setup SSH, you can go to Bitbucket > Manage Account > SSH Keys. https://bitbucket.mckesson.com:8443/plugins/servlet/ssh/account/keys
    3.Here if you do not already have a key, you can add a new key by clicking Add Key.
    4.Here you will paste in the key, if you are not sure how to create the key, or what to paste in,
    follow the helpful link on the Add Key page, which should bring you to the Creating SSH Keys
    help page.

### `Step 8` Artifactory Setup
    1.Your JFrog account will need to have been enabled in order for you to do this.
    2.Navigate to https://mckesson.okta.com/app/UserHome and login using your email and
       password. This will require verification via the Okta Verify app.
    3.Once logged in, click the Artifactory link.
    4.You should be navigated to the McKesson JFrog page and be logged in automatically.
    5.Click on the top right where it shows your email address.
    6.In the dropdown, you should see an option for "Edit Profile". If you do not see this option,
       you will need to reach out to other team members so that the correct access can be
       provided.
    7.After clicking "Edit Profile" you should be navigated to the User Profile page. Here you
       should see an option to generate an API key. Generate the key, this will be needed later.

### `Step 9` NPM Setup
    You will need to configure NPM to use the internal McKesson registry. To this you need to set the
    registry in the .npmrc file.
     1.The below commands can be used to configure the needed settings. Please use Terminal to run cmds.
        Note that you need to replace the email and the API key with your values.
        This is the same API key that we generated in #Artifactory Setup.
        The _auth value will in the end just be a base64 encoded string of your email
         address and your API key

                    npm config set strict-ssl false
                    npm config set registry https://mck.
                    jfrog.io/artifactory/api/npm/npmcommon
                    curl -k -u <mckessonEmail>:<APIKey>
                    https://mck.jfrog.io/artifactory/api
                    /npm/auth/
                    npm config set _auth=<from last
                    response>

    2.Validate that your NPM is configured by viewing the .npmrc file found in your home directory
      HOME\.npmrc


### `Step 10` Gradle Setup
       
     Install gradle and Set up your environment variables. version should be Gradle 7.4.1 and up

     You will need to setup Gradle to use the internal McKesson registry similar to how we did for NPM.
     Create empty init.gradle and gradle.properties in your HOME/.gradle/ folder
     Update the empty gradle.properties with your McKesson email and API Key from
     JFrog
     Update the empty init.gradle with what's in the example as is

###### gradle.properties
               systemProp.artifactory-username=shiva.elakapally@mckesson.com
               systemProp.artifactory-password=  ** key from Artifactory Setup step 6 **

###### init.gradle
                    
                    allprojects{
                    repositories {
                    
                    
                    
                    maven {
                    url 'https://mck.jfrog.io/artifactory/cxp'
                    credentials {
                    username = System.properties['artifactory-username']
                    password = System.properties['artifactory-password']
                    }
                    }
                    maven {
                    url 'https://mck.jfrog.io/artifactory/cxp-common-local/'
                    credentials {
                    username = System.properties['artifactory-username']
                    password = System.properties['artifactory-password']
                    }
                    }
                    maven {
                    url 'https://mck.jfrog.io/artifactory/common/'
                    credentials {
                    username = System.properties['artifactory-username']
                    password = System.properties['artifactory-password']
                    }
                    }
                    maven {
                    url 'https://mck.jfrog.io/artifactory/cxp-data-analytics-gradle-local/'
                    credentials {
                    username = System.properties['artifactory-username']
                    password = System.properties['artifactory-password']
                    }
                    }
                    }
                    }
                    
                    
                    
                    ext._ver = gradle.gradleVersion.substring(0, gradle.gradleVersion.indexOf("."))
                    ext._majorVersion = ext._ver.isInteger() ? ext._ver.toInteger() : 0
                    
                    
                    
                    if(ext._majorVersion < 5){
                    println "Gradle version " + ext._majorVersion + ".X.Y - no support for mck-gradle plugin!"
                    }else{
                    settingsEvaluated { settings ->
                    settings.pluginManagement {
                    
                    
                    
                    resolutionStrategy {
                    eachPlugin {
                    if (requested.id.id == 'com.mckesson.mck-gradle') {
                    useModule("com.mckesson.plugin:mck-gradle:${requested.version}")
                    }
                    }
                    }
                    repositories {
                    maven {
                    url 'https://mck.jfrog.io/artifactory/common'
                    credentials {
                    username = System.properties['artifactory-username']
                    password = System.properties['artifactory-password']
                    }
                    }
                    gradlePluginPortal()
                    }
                    }
                    }
                    }

## Set up your environment variables in order to run

      SPRING_PROFILES_ACTIVE=local
      SPRING_CLOUD_CONFIG_USERNAME=user
      SPRING_CLOUD_CONFIG_PORT=8888
      SPRING_CLOUD_CONFIG_PASSWORD=(reach out to a developer for values)

### `Step 11` Running the Config Server

    Open Gitbash or IDE for C:\Users\e4b71rl\Documents\WS\ERA\z_archive_com.mckesson.ms.config-server and run follwing cmd
  
            ./gradlew bootRun \
            -Dapp.encrypt.key=$ENCRYPT_KEY \
            -Dapp.spring.security.user.name=$SPRING_CLOUD_CONFIG_USERNAME \
            -Dapp.spring.security.user.password=$SPRING_CLOUD_CONFIG_PASSWORD \
            -Dapp.spring.cloud.config.server.git.uri=$SPRING_CLOUD_CONFIG_SERVER_GIT_URI \
            -Dapp.server.port=$SPRING_CLOUD_CONFIG_PORT

        `(reach out to a developer for values)`

### `Step 12` Running the ERA app
        Open the Project in IDE and wait for dependecy download then do a bootRun

            ./gradlew bootRun from Terminal
      If you see below logs then Login at [http://localhost:8080/](http://localhost:8080/) 

        2022-03-14 14:09:56,986 INFO  [main] waa  [] [] [] com.mckesson.app.Application : Started Application in 23.244 seconds (JVM running for 23.893)
        2022-03-14 14:09:57,023 INFO  [main] waa  [] [] [] mckesson.config : Ready to Go!!

_END OF SETUP HAPPY CODING......._



