#!/bin/bash

echo $NODE_PATH

npm config list
npm config ls -l

npm install
#--verbose
npm run build
#--verbose